/*
 * File: top_multi_nat.h
 *
 * Code generated for Simulink model 'top_multi_nat'.
 *
 * Model version                  : 1.128
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Fri Jun 26 15:03:11 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Infineon->TriCore
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_top_multi_nat_h_
#define RTW_HEADER_top_multi_nat_h_
#ifndef top_multi_nat_COMMON_INCLUDES_
# define top_multi_nat_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* top_multi_nat_COMMON_INCLUDES_ */

#include "top_multi_nat_types.h"

/* Shared type includes */
#include "model_reference_types.h"

/* Child system includes */
#define tsk_1ms_fcn2n_MDLREF_HIDE_CHILD_
#include "tsk_1ms_fcn2n.h"
#define tsk_1ms_fcn1n_MDLREF_HIDE_CHILD_
#include "tsk_1ms_fcn1n.h"
#define tsk_10ms_fcn2n_MDLREF_HIDE_CHILD_
#include "tsk_10ms_fcn2n.h"
#define tsk_10ms_fcn1n_MDLREF_HIDE_CHILD_
#include "tsk_10ms_fcn1n.h"

/* Macros for accessing real-time model data structure */

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern u1 In1;                    /* '<Root>/In1' */
extern u1 In2;                    /* '<Root>/In2' */
extern u1 Out1_RT;                /* '<S1>/RT' */
extern u1 Out1_Delay;             /* '<S3>/Unit Delay' */
extern u1 tsk_1ms_Out1;           /* '<S3>/tsk_1ms_fcn1' */
extern u1 Out1;                   /* '<S3>/tsk_1ms_fcn2' */
extern u1 tsk_10ms_Out1;          /* '<S2>/tsk_10ms_fcn1' */
extern u1 Out2;                   /* '<S2>/tsk_10ms_fcn2' */

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern u1 Out1_Delay_State;       /* '<S3>/Unit Delay' */

/* Model entry point functions */
extern void top_multi_nat_initialize(void);
extern void top_multi_nat_step0(void);
extern void top_multi_nat_step1(void);
extern void top_multi_nat_step2(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'top_multi_nat'
 * '<S1>'   : 'top_multi_nat/MCU'
 * '<S2>'   : 'top_multi_nat/MCU/tsk_10ms_fcns'
 * '<S3>'   : 'top_multi_nat/MCU/tsk_1ms_fcns'
 */
#endif                                 /* RTW_HEADER_top_multi_nat_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
