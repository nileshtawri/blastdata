/*
 * File: top_multi_nat.c
 *
 * Code generated for Simulink model 'top_multi_nat'.
 *
 * Model version                  : 1.128
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Fri Jun 26 15:03:11 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Infineon->TriCore
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "top_multi_nat.h"
#include "top_multi_nat_private.h"

/* Exported block signals */
u1 In1;                           /* '<Root>/In1' */
u1 In2;                           /* '<Root>/In2' */
u1 Out1_RT;                       /* '<S1>/RT' */
u1 Out1_Delay;                    /* '<S3>/Unit Delay' */
u1 tsk_1ms_Out1;                  /* '<S3>/tsk_1ms_fcn1' */
u1 Out1;                          /* '<S3>/tsk_1ms_fcn2' */
u1 tsk_10ms_Out1;                 /* '<S2>/tsk_10ms_fcn1' */
u1 Out2;                          /* '<S2>/tsk_10ms_fcn2' */

/* Exported block states */
u1 Out1_Delay_State;              /* '<S3>/Unit Delay' */

/* Model step function for TID0 */
void top_multi_nat_step0(void)         /* Sample time: [0.001s, 0.0s] */
{
  Out1_Delay = Out1_Delay_State;
  tsk_1ms_fcn1n();
  tsk_1ms_fcn2n();
  Out1_Delay_State = Out1;
}

/* Model step function for TID1 */
void top_multi_nat_step1(void)         /* Sample time: [0.01s, 0.0s] */
{
  Out1_RT = Out1;
  tsk_10ms_fcn1n();
  tsk_10ms_fcn2nTID0();
}

/* Model step function for TID2 */
void top_multi_nat_step2(void)         /* Sample time: [0.1s, 0.0s] */
{
  tsk_10ms_fcn2nTID1();
}

/* Model initialize function */
void top_multi_nat_initialize(void)
{
  /* Registration code */

  /* block I/O */

  /* exported global signals */
  Out1 = 0U;
  Out2 = 0U;

  /* external inputs */
  In1 = 0U;
  In2 = 0U;

  /* Model Initialize fcn for ModelReference Block: '<S2>/tsk_10ms_fcn1' */
  tsk_10ms_fcn1n_initialize();

  /* Model Initialize fcn for ModelReference Block: '<S2>/tsk_10ms_fcn2' */
  tsk_10ms_fcn2n_initialize();

  /* Model Initialize fcn for ModelReference Block: '<S3>/tsk_1ms_fcn1' */
  tsk_1ms_fcn1n_initialize();

  /* Model Initialize fcn for ModelReference Block: '<S3>/tsk_1ms_fcn2' */
  tsk_1ms_fcn2n_initialize();
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
