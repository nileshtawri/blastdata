/*
 * File: top_multi_nat_types.h
 *
 * Code generated for Simulink model 'top_multi_nat'.
 *
 * Model version                  : 1.128
 * Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
 * C/C++ source code generated on : Fri Jun 26 15:03:11 2015
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Infineon->TriCore
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_top_multi_nat_types_h_
#define RTW_HEADER_top_multi_nat_types_h_
#endif                                 /* RTW_HEADER_top_multi_nat_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
