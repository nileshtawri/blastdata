% Define Simulink Numeric Types
u1          = Simulink.AliasType;
u1.BaseType = 'uint8';

u2          = Simulink.AliasType;
u2.BaseType = 'uint16';

u4          = Simulink.AliasType;
u4.BaseType = 'uint32';

s1          = Simulink.AliasType;
s1.BaseType = 'int8';

s2          = Simulink.AliasType;
s2.BaseType = 'int16';

s4          = Simulink.AliasType;
s4.BaseType = 'int32';

DSM_Global                 = mpt.Signal;
DSM_Global.DataType        = 'uint8';
DSM_Global.Dimensions      = 1;
DSM_Global.Complexity      = 'real';
DSM_Global.SamplingMode    = 'Sample based';
