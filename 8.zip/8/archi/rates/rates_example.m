%% Single tasking
open_system('rtwdemo_srbb');

%% Multirate multi tasking
open_system('rtwdemo_mrmtbb');

%% Multirate single tasking
open_system('rtwdemo_mrstbb');

%% Exported function caller
open_system('rtwdemo_export_functions');