﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.cbDeviceList = New System.Windows.Forms.ComboBox()
        Me.lbDevice = New System.Windows.Forms.Label()
        Me.chDebugMode = New System.Windows.Forms.CheckBox()
        Me.btStartCAN = New System.Windows.Forms.Button()
        Me.chCanFD = New System.Windows.Forms.CheckBox()
        Me.cbBaudrate = New System.Windows.Forms.ComboBox()
        Me.laBaudrate = New System.Windows.Forms.Label()
        Me.tbCANConfiginfo = New System.Windows.Forms.TextBox()
        Me.rbCANStatus = New System.Windows.Forms.RadioButton()
        Me.ComTmr = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.gbAPMCtrl = New System.Windows.Forms.GroupBox()
        Me.pnApmModeCtrl = New System.Windows.Forms.Panel()
        Me.rbApmTest = New System.Windows.Forms.RadioButton()
        Me.rbApmStby = New System.Windows.Forms.RadioButton()
        Me.rbApmOff = New System.Windows.Forms.RadioButton()
        Me.rbApmDcdc = New System.Windows.Forms.RadioButton()
        Me.chAPMCtrlmsg = New System.Windows.Forms.CheckBox()
        Me.nudAPMCurr = New System.Windows.Forms.NumericUpDown()
        Me.nudAPMVolt = New System.Windows.Forms.NumericUpDown()
        Me.VoltUnit = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.CurrentUnit = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.gbOBCCtrl = New System.Windows.Forms.GroupBox()
        Me.pnModeCtrl = New System.Windows.Forms.Panel()
        Me.rbTestmode = New System.Windows.Forms.RadioButton()
        Me.rbStandby = New System.Windows.Forms.RadioButton()
        Me.rbSleep = New System.Windows.Forms.RadioButton()
        Me.rbForward = New System.Windows.Forms.RadioButton()
        Me.rbReverse = New System.Windows.Forms.RadioButton()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.chOBCSafetymsg = New System.Windows.Forms.CheckBox()
        Me.chOBCCtrlmsg = New System.Windows.Forms.CheckBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.nudOBCPower = New System.Windows.Forms.NumericUpDown()
        Me.nudOBCCurr = New System.Windows.Forms.NumericUpDown()
        Me.btUpdateOBCCmd = New System.Windows.Forms.Button()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nudOBCVolt = New System.Windows.Forms.NumericUpDown()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbObcBcCyTime = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.gbSecDebCtrl = New System.Windows.Forms.GroupBox()
        Me.nudBurstDty = New System.Windows.Forms.NumericUpDown()
        Me.nudPhaseShift = New System.Windows.Forms.NumericUpDown()
        Me.nudFrequency = New System.Windows.Forms.NumericUpDown()
        Me.rbSecPwmOn2 = New System.Windows.Forms.RadioButton()
        Me.rbSecPwmOn1 = New System.Windows.Forms.RadioButton()
        Me.rbSecPwmOff = New System.Windows.Forms.RadioButton()
        Me.buSecOLCmd = New System.Windows.Forms.Button()
        Me.buGetSecFwRev = New System.Windows.Forms.Button()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.chSecDeb1 = New System.Windows.Forms.CheckBox()
        Me.chSecDeb2 = New System.Windows.Forms.CheckBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.gbPriDebCtrl = New System.Windows.Forms.GroupBox()
        Me.nudKi = New System.Windows.Forms.NumericUpDown()
        Me.nudKp = New System.Windows.Forms.NumericUpDown()
        Me.chPriFutMode = New System.Windows.Forms.CheckBox()
        Me.buSetKi = New System.Windows.Forms.Button()
        Me.buSetKp = New System.Windows.Forms.Button()
        Me.buGetPriFwRev = New System.Windows.Forms.Button()
        Me.chPriDeb1 = New System.Windows.Forms.CheckBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label211 = New System.Windows.Forms.Label()
        Me.chPriDeb2 = New System.Windows.Forms.CheckBox()
        Me.Label210 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.tbSecFwRev = New System.Windows.Forms.TextBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.gbOBCInfo = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.tbSecState = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.pnSecDeb = New System.Windows.Forms.Panel()
        Me.chSecDebInDec = New System.Windows.Forms.CheckBox()
        Me.tbFreq2 = New System.Windows.Forms.TextBox()
        Me.tbFreq1 = New System.Windows.Forms.TextBox()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.tbVauxSec = New System.Windows.Forms.TextBox()
        Me.tbPS2 = New System.Windows.Forms.TextBox()
        Me.sBit20 = New System.Windows.Forms.Panel()
        Me.tbPS1 = New System.Windows.Forms.TextBox()
        Me.sBit22 = New System.Windows.Forms.Panel()
        Me.tbIpri2 = New System.Windows.Forms.TextBox()
        Me.sBit21 = New System.Windows.Forms.Panel()
        Me.tbTRes2 = New System.Windows.Forms.TextBox()
        Me.sBit23 = New System.Windows.Forms.Panel()
        Me.tbSDeb6 = New System.Windows.Forms.TextBox()
        Me.sBit30 = New System.Windows.Forms.Panel()
        Me.tbSDeb3 = New System.Windows.Forms.TextBox()
        Me.sBit32 = New System.Windows.Forms.Panel()
        Me.tbBurstDty2 = New System.Windows.Forms.TextBox()
        Me.sBit31 = New System.Windows.Forms.Panel()
        Me.sBit33 = New System.Windows.Forms.Panel()
        Me.tbBurstDty1 = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.tbIpri1 = New System.Windows.Forms.TextBox()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.tbTRes1 = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.tbIpriTot = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.tbTClllcS2 = New System.Windows.Forms.TextBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.sBit24 = New System.Windows.Forms.Panel()
        Me.tbIout2 = New System.Windows.Forms.TextBox()
        Me.sBit26 = New System.Windows.Forms.Panel()
        Me.tbSDeb5 = New System.Windows.Forms.TextBox()
        Me.sBit25 = New System.Windows.Forms.Panel()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.sBit27 = New System.Windows.Forms.Panel()
        Me.tbSDeb2 = New System.Windows.Forms.TextBox()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.tbSDeb4 = New System.Windows.Forms.TextBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.tbIshareAdj = New System.Windows.Forms.TextBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.tbSDeb1 = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.tbIshareStat = New System.Windows.Forms.TextBox()
        Me.sBit34 = New System.Windows.Forms.Panel()
        Me.tbIshareErr = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.tbSRStat = New System.Windows.Forms.TextBox()
        Me.sBit36 = New System.Windows.Forms.Panel()
        Me.tbCCorCV = New System.Windows.Forms.TextBox()
        Me.sBit35 = New System.Windows.Forms.Panel()
        Me.tbCtrlMode = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.tbTClllcS1 = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.sBit37 = New System.Windows.Forms.Panel()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.tbIout1 = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.tbIout = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.sBit17 = New System.Windows.Forms.Panel()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.tbVbulk = New System.Windows.Forms.TextBox()
        Me.tbVout = New System.Windows.Forms.TextBox()
        Me.sBit16 = New System.Windows.Forms.Panel()
        Me.sBit10 = New System.Windows.Forms.Panel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.sBit14 = New System.Windows.Forms.Panel()
        Me.sBit15 = New System.Windows.Forms.Panel()
        Me.sBit04 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.sBit06 = New System.Windows.Forms.Panel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.sBit13 = New System.Windows.Forms.Panel()
        Me.sBit12 = New System.Windows.Forms.Panel()
        Me.sBit05 = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.sBit07 = New System.Windows.Forms.Panel()
        Me.Label209 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.sBit11 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.tbPIacA = New System.Windows.Forms.TextBox()
        Me.tbPriState = New System.Windows.Forms.TextBox()
        Me.pnPriDeb = New System.Windows.Forms.Panel()
        Me.chPriDebInDec = New System.Windows.Forms.CheckBox()
        Me.tbPTclllcP2 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.sPBit20 = New System.Windows.Forms.Panel()
        Me.tbPTclllcP1 = New System.Windows.Forms.TextBox()
        Me.sPBit22 = New System.Windows.Forms.Panel()
        Me.tbPriFwRev = New System.Windows.Forms.TextBox()
        Me.tbIphaseC = New System.Windows.Forms.TextBox()
        Me.sPBit21 = New System.Windows.Forms.Panel()
        Me.tbPVaux = New System.Windows.Forms.TextBox()
        Me.sPBit23 = New System.Windows.Forms.Panel()
        Me.tbPDeb6 = New System.Windows.Forms.TextBox()
        Me.sPBit30 = New System.Windows.Forms.Panel()
        Me.tbPDeb3 = New System.Windows.Forms.TextBox()
        Me.sPBit32 = New System.Windows.Forms.Panel()
        Me.sPBit31 = New System.Windows.Forms.Panel()
        Me.sPBit33 = New System.Windows.Forms.Panel()
        Me.tbPTnpcC = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.tbIphaseB = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.tbPVbulk = New System.Windows.Forms.TextBox()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.tbIphaseA = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.tbPIacC = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.sPBit24 = New System.Windows.Forms.Panel()
        Me.tbPVacC = New System.Windows.Forms.TextBox()
        Me.sPBit26 = New System.Windows.Forms.Panel()
        Me.tbPDeb5 = New System.Windows.Forms.TextBox()
        Me.sPBit25 = New System.Windows.Forms.Panel()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.sPBit27 = New System.Windows.Forms.Panel()
        Me.tbPDeb2 = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.tbPDeb4 = New System.Windows.Forms.TextBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.tbPDeb1 = New System.Windows.Forms.TextBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.sPBit34 = New System.Windows.Forms.Panel()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.sPBit36 = New System.Windows.Forms.Panel()
        Me.tbPTnpcB = New System.Windows.Forms.TextBox()
        Me.sPBit35 = New System.Windows.Forms.Panel()
        Me.tbPTnpcA = New System.Windows.Forms.TextBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.tbPIacB = New System.Windows.Forms.TextBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.sPBit37 = New System.Windows.Forms.Panel()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.tbPVacB = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.tbPVbulkMid = New System.Windows.Forms.TextBox()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.sPBit11 = New System.Windows.Forms.Panel()
        Me.sPBit17 = New System.Windows.Forms.Panel()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.tbPVacA = New System.Windows.Forms.TextBox()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.sPBit16 = New System.Windows.Forms.Panel()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.sPBit10 = New System.Windows.Forms.Panel()
        Me.sPBit07 = New System.Windows.Forms.Panel()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.sPBit14 = New System.Windows.Forms.Panel()
        Me.sPBit05 = New System.Windows.Forms.Panel()
        Me.sPBit15 = New System.Windows.Forms.Panel()
        Me.sPBit12 = New System.Windows.Forms.Panel()
        Me.sPBit04 = New System.Windows.Forms.Panel()
        Me.sPBit13 = New System.Windows.Forms.Panel()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.sPBit06 = New System.Windows.Forms.Panel()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.gbAPMinfo = New System.Windows.Forms.GroupBox()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.sABit50 = New System.Windows.Forms.Panel()
        Me.sABit40 = New System.Windows.Forms.Panel()
        Me.sABit20 = New System.Windows.Forms.Panel()
        Me.sABit30 = New System.Windows.Forms.Panel()
        Me.sABit10 = New System.Windows.Forms.Panel()
        Me.sABit54 = New System.Windows.Forms.Panel()
        Me.sABit44 = New System.Windows.Forms.Panel()
        Me.sABit24 = New System.Windows.Forms.Panel()
        Me.sABit34 = New System.Windows.Forms.Panel()
        Me.sABit14 = New System.Windows.Forms.Panel()
        Me.sABit04 = New System.Windows.Forms.Panel()
        Me.sABit52 = New System.Windows.Forms.Panel()
        Me.sABit42 = New System.Windows.Forms.Panel()
        Me.sABit22 = New System.Windows.Forms.Panel()
        Me.sABit32 = New System.Windows.Forms.Panel()
        Me.sABit12 = New System.Windows.Forms.Panel()
        Me.sABit56 = New System.Windows.Forms.Panel()
        Me.sABit46 = New System.Windows.Forms.Panel()
        Me.sABit26 = New System.Windows.Forms.Panel()
        Me.sABit36 = New System.Windows.Forms.Panel()
        Me.sABit16 = New System.Windows.Forms.Panel()
        Me.sABit06 = New System.Windows.Forms.Panel()
        Me.sABit51 = New System.Windows.Forms.Panel()
        Me.sABit41 = New System.Windows.Forms.Panel()
        Me.sABit21 = New System.Windows.Forms.Panel()
        Me.sABit31 = New System.Windows.Forms.Panel()
        Me.sABit11 = New System.Windows.Forms.Panel()
        Me.sABit55 = New System.Windows.Forms.Panel()
        Me.sABit45 = New System.Windows.Forms.Panel()
        Me.sABit25 = New System.Windows.Forms.Panel()
        Me.sABit35 = New System.Windows.Forms.Panel()
        Me.sABit15 = New System.Windows.Forms.Panel()
        Me.sABit05 = New System.Windows.Forms.Panel()
        Me.sABit53 = New System.Windows.Forms.Panel()
        Me.sABit43 = New System.Windows.Forms.Panel()
        Me.sABit23 = New System.Windows.Forms.Panel()
        Me.sABit33 = New System.Windows.Forms.Panel()
        Me.sABit13 = New System.Windows.Forms.Panel()
        Me.sABit57 = New System.Windows.Forms.Panel()
        Me.sABit47 = New System.Windows.Forms.Panel()
        Me.sABit27 = New System.Windows.Forms.Panel()
        Me.sABit37 = New System.Windows.Forms.Panel()
        Me.sABit17 = New System.Windows.Forms.Panel()
        Me.Label208 = New System.Windows.Forms.Label()
        Me.Label180 = New System.Windows.Forms.Label()
        Me.sABit07 = New System.Windows.Forms.Panel()
        Me.Label179 = New System.Windows.Forms.Label()
        Me.Label196 = New System.Windows.Forms.Label()
        Me.Label178 = New System.Windows.Forms.Label()
        Me.Label188 = New System.Windows.Forms.Label()
        Me.Label177 = New System.Windows.Forms.Label()
        Me.Label195 = New System.Windows.Forms.Label()
        Me.Label206 = New System.Windows.Forms.Label()
        Me.Label204 = New System.Windows.Forms.Label()
        Me.Label194 = New System.Windows.Forms.Label()
        Me.Label200 = New System.Windows.Forms.Label()
        Me.Label205 = New System.Windows.Forms.Label()
        Me.Label174 = New System.Windows.Forms.Label()
        Me.Label187 = New System.Windows.Forms.Label()
        Me.Label173 = New System.Windows.Forms.Label()
        Me.Label193 = New System.Windows.Forms.Label()
        Me.Label184 = New System.Windows.Forms.Label()
        Me.Label176 = New System.Windows.Forms.Label()
        Me.Label202 = New System.Windows.Forms.Label()
        Me.Label203 = New System.Windows.Forms.Label()
        Me.Label172 = New System.Windows.Forms.Label()
        Me.Label192 = New System.Windows.Forms.Label()
        Me.Label162 = New System.Windows.Forms.Label()
        Me.Label175 = New System.Windows.Forms.Label()
        Me.Label171 = New System.Windows.Forms.Label()
        Me.Label199 = New System.Windows.Forms.Label()
        Me.Label183 = New System.Windows.Forms.Label()
        Me.Label186 = New System.Windows.Forms.Label()
        Me.Label164 = New System.Windows.Forms.Label()
        Me.Label165 = New System.Windows.Forms.Label()
        Me.Label191 = New System.Windows.Forms.Label()
        Me.Label207 = New System.Windows.Forms.Label()
        Me.Label182 = New System.Windows.Forms.Label()
        Me.Label161 = New System.Windows.Forms.Label()
        Me.Label163 = New System.Windows.Forms.Label()
        Me.Label190 = New System.Windows.Forms.Label()
        Me.Label198 = New System.Windows.Forms.Label()
        Me.Label181 = New System.Windows.Forms.Label()
        Me.Label160 = New System.Windows.Forms.Label()
        Me.Label201 = New System.Windows.Forms.Label()
        Me.Label185 = New System.Windows.Forms.Label()
        Me.Label189 = New System.Windows.Forms.Label()
        Me.Label197 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.tbApmIcmd = New System.Windows.Forms.TextBox()
        Me.tbApmVcmd = New System.Windows.Forms.TextBox()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.tbApmHvdcCurr = New System.Windows.Forms.TextBox()
        Me.tbApmHvdcVolt = New System.Windows.Forms.TextBox()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.Label151 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.tbApmEvseImax = New System.Windows.Forms.TextBox()
        Me.Label159 = New System.Windows.Forms.Label()
        Me.tbApmHVAux = New System.Windows.Forms.TextBox()
        Me.Label149 = New System.Windows.Forms.Label()
        Me.tbApmLVIcmd = New System.Windows.Forms.TextBox()
        Me.tbApmLVAux = New System.Windows.Forms.TextBox()
        Me.Label154 = New System.Windows.Forms.Label()
        Me.Label157 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.tbApmTcool = New System.Windows.Forms.TextBox()
        Me.Label168 = New System.Windows.Forms.Label()
        Me.tbApmTsr = New System.Windows.Forms.TextBox()
        Me.tbApmTpcb = New System.Windows.Forms.TextBox()
        Me.Label169 = New System.Windows.Forms.Label()
        Me.Label170 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.tbApmBattVolt = New System.Windows.Forms.TextBox()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.tbApmLVDCCurr = New System.Windows.Forms.TextBox()
        Me.tbApmLVDCVolt = New System.Windows.Forms.TextBox()
        Me.Label166 = New System.Windows.Forms.Label()
        Me.Label167 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.tbApmVerBoot = New System.Windows.Forms.TextBox()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.tbApmVerApp = New System.Windows.Forms.TextBox()
        Me.tbApmMode = New System.Windows.Forms.TextBox()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.Label153 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.tbApmProxVolt = New System.Windows.Forms.TextBox()
        Me.tbApmProxState = New System.Windows.Forms.TextBox()
        Me.tbApmPilState = New System.Windows.Forms.TextBox()
        Me.tbApmCPVolt = New System.Windows.Forms.TextBox()
        Me.tbApmCPFreq = New System.Windows.Forms.TextBox()
        Me.tbApmCPDuty = New System.Windows.Forms.TextBox()
        Me.Label152 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label155 = New System.Windows.Forms.Label()
        Me.Label156 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label158 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.tbCanLog = New System.Windows.Forms.RichTextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.lbModel = New System.Windows.Forms.Label()
        Me.lbMode = New System.Windows.Forms.Label()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.tmrDisplay = New System.Windows.Forms.Timer(Me.components)
        Me.TxTimer = New System.Windows.Forms.Timer(Me.components)
        Me.lbPhase = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.gbAPMCtrl.SuspendLayout()
        Me.pnApmModeCtrl.SuspendLayout()
        CType(Me.nudAPMCurr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudAPMVolt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbOBCCtrl.SuspendLayout()
        Me.pnModeCtrl.SuspendLayout()
        CType(Me.nudOBCPower, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudOBCCurr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudOBCVolt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        Me.gbSecDebCtrl.SuspendLayout()
        CType(Me.nudBurstDty, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPhaseShift, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudFrequency, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbPriDebCtrl.SuspendLayout()
        CType(Me.nudKi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.gbOBCInfo.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.pnSecDeb.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.pnPriDeb.SuspendLayout()
        Me.gbAPMinfo.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cbDeviceList
        '
        Me.cbDeviceList.BackColor = System.Drawing.SystemColors.Window
        Me.cbDeviceList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDeviceList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.cbDeviceList.Location = New System.Drawing.Point(6, 14)
        Me.cbDeviceList.Margin = New System.Windows.Forms.Padding(4)
        Me.cbDeviceList.Name = "cbDeviceList"
        Me.cbDeviceList.Size = New System.Drawing.Size(165, 23)
        Me.cbDeviceList.TabIndex = 41
        '
        'lbDevice
        '
        Me.lbDevice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Underline)
        Me.lbDevice.Location = New System.Drawing.Point(6, -1)
        Me.lbDevice.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbDevice.Name = "lbDevice"
        Me.lbDevice.Size = New System.Drawing.Size(70, 19)
        Me.lbDevice.TabIndex = 42
        Me.lbDevice.Text = "Devices:-"
        '
        'chDebugMode
        '
        Me.chDebugMode.AutoSize = True
        Me.chDebugMode.Enabled = False
        Me.chDebugMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.chDebugMode.Location = New System.Drawing.Point(326, 40)
        Me.chDebugMode.Name = "chDebugMode"
        Me.chDebugMode.Size = New System.Drawing.Size(108, 21)
        Me.chDebugMode.TabIndex = 116
        Me.chDebugMode.Text = "Debug Mode"
        Me.chDebugMode.UseVisualStyleBackColor = True
        '
        'btStartCAN
        '
        Me.btStartCAN.Enabled = False
        Me.btStartCAN.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btStartCAN.Location = New System.Drawing.Point(321, 8)
        Me.btStartCAN.Name = "btStartCAN"
        Me.btStartCAN.Size = New System.Drawing.Size(112, 30)
        Me.btStartCAN.TabIndex = 118
        Me.btStartCAN.Text = "Start CAN"
        '
        'chCanFD
        '
        Me.chCanFD.AutoSize = True
        Me.chCanFD.Enabled = False
        Me.chCanFD.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.chCanFD.Location = New System.Drawing.Point(244, 41)
        Me.chCanFD.Margin = New System.Windows.Forms.Padding(4)
        Me.chCanFD.Name = "chCanFD"
        Me.chCanFD.Size = New System.Drawing.Size(78, 21)
        Me.chCanFD.TabIndex = 121
        Me.chCanFD.Text = "CAN-FD"
        Me.chCanFD.UseVisualStyleBackColor = True
        Me.chCanFD.Visible = False
        '
        'cbBaudrate
        '
        Me.cbBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbBaudrate.Enabled = False
        Me.cbBaudrate.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.cbBaudrate.Items.AddRange(New Object() {"1 MBit/sec", "800 kBit/sec", "500 kBit/sec", "250 kBit/sec", "125 kKBit/sec", "100 kBit/sec", "95,238 kBit/sec", "83,333 kBit/sec", "50 kBit/sec", "47,619 kBit/sec", "33,333 kBit/sec", "20 kBit/sec", "10 kBit/sec", "5 kBit/sec"})
        Me.cbBaudrate.Location = New System.Drawing.Point(179, 15)
        Me.cbBaudrate.Margin = New System.Windows.Forms.Padding(4)
        Me.cbBaudrate.Name = "cbBaudrate"
        Me.cbBaudrate.Size = New System.Drawing.Size(131, 23)
        Me.cbBaudrate.TabIndex = 119
        '
        'laBaudrate
        '
        Me.laBaudrate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Underline)
        Me.laBaudrate.Location = New System.Drawing.Point(179, -1)
        Me.laBaudrate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.laBaudrate.Name = "laBaudrate"
        Me.laBaudrate.Size = New System.Drawing.Size(70, 28)
        Me.laBaudrate.TabIndex = 120
        Me.laBaudrate.Text = "Baudrate :-"
        '
        'tbCANConfiginfo
        '
        Me.tbCANConfiginfo.Enabled = False
        Me.tbCANConfiginfo.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.tbCANConfiginfo.Location = New System.Drawing.Point(441, 8)
        Me.tbCANConfiginfo.Margin = New System.Windows.Forms.Padding(4)
        Me.tbCANConfiginfo.Multiline = True
        Me.tbCANConfiginfo.Name = "tbCANConfiginfo"
        Me.tbCANConfiginfo.ReadOnly = True
        Me.tbCANConfiginfo.Size = New System.Drawing.Size(435, 54)
        Me.tbCANConfiginfo.TabIndex = 122
        '
        'rbCANStatus
        '
        Me.rbCANStatus.AutoSize = True
        Me.rbCANStatus.BackColor = System.Drawing.Color.Red
        Me.rbCANStatus.Checked = True
        Me.rbCANStatus.Enabled = False
        Me.rbCANStatus.Font = New System.Drawing.Font("Times New Roman", 11.0!, System.Drawing.FontStyle.Bold)
        Me.rbCANStatus.Location = New System.Drawing.Point(1069, 48)
        Me.rbCANStatus.Name = "rbCANStatus"
        Me.rbCANStatus.Size = New System.Drawing.Size(107, 21)
        Me.rbCANStatus.TabIndex = 134
        Me.rbCANStatus.TabStop = True
        Me.rbCANStatus.Text = "CAN Offline"
        Me.rbCANStatus.UseVisualStyleBackColor = False
        '
        'ComTmr
        '
        Me.ComTmr.Enabled = True
        Me.ComTmr.Interval = 200
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Enabled = False
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 13.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(5, 48)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1201, 126)
        Me.TabControl1.TabIndex = 135
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.gbAPMCtrl)
        Me.TabPage1.Controls.Add(Me.gbOBCCtrl)
        Me.TabPage1.Controls.Add(Me.cbObcBcCyTime)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1193, 93)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "System Control"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'gbAPMCtrl
        '
        Me.gbAPMCtrl.Controls.Add(Me.pnApmModeCtrl)
        Me.gbAPMCtrl.Controls.Add(Me.chAPMCtrlmsg)
        Me.gbAPMCtrl.Controls.Add(Me.nudAPMCurr)
        Me.gbAPMCtrl.Controls.Add(Me.nudAPMVolt)
        Me.gbAPMCtrl.Controls.Add(Me.VoltUnit)
        Me.gbAPMCtrl.Controls.Add(Me.Label5)
        Me.gbAPMCtrl.Controls.Add(Me.Label6)
        Me.gbAPMCtrl.Controls.Add(Me.Label42)
        Me.gbAPMCtrl.Controls.Add(Me.CurrentUnit)
        Me.gbAPMCtrl.Controls.Add(Me.Label7)
        Me.gbAPMCtrl.Enabled = False
        Me.gbAPMCtrl.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.gbAPMCtrl.Location = New System.Drawing.Point(96, 6)
        Me.gbAPMCtrl.Name = "gbAPMCtrl"
        Me.gbAPMCtrl.Size = New System.Drawing.Size(397, 84)
        Me.gbAPMCtrl.TabIndex = 65
        Me.gbAPMCtrl.TabStop = False
        Me.gbAPMCtrl.Text = "APM"
        '
        'pnApmModeCtrl
        '
        Me.pnApmModeCtrl.Controls.Add(Me.rbApmTest)
        Me.pnApmModeCtrl.Controls.Add(Me.rbApmStby)
        Me.pnApmModeCtrl.Controls.Add(Me.rbApmOff)
        Me.pnApmModeCtrl.Controls.Add(Me.rbApmDcdc)
        Me.pnApmModeCtrl.Enabled = False
        Me.pnApmModeCtrl.Location = New System.Drawing.Point(251, 15)
        Me.pnApmModeCtrl.Name = "pnApmModeCtrl"
        Me.pnApmModeCtrl.Size = New System.Drawing.Size(140, 63)
        Me.pnApmModeCtrl.TabIndex = 0
        '
        'rbApmTest
        '
        Me.rbApmTest.AutoSize = True
        Me.rbApmTest.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbApmTest.Location = New System.Drawing.Point(76, 29)
        Me.rbApmTest.Name = "rbApmTest"
        Me.rbApmTest.Size = New System.Drawing.Size(56, 23)
        Me.rbApmTest.TabIndex = 133
        Me.rbApmTest.Text = "Test "
        Me.rbApmTest.UseVisualStyleBackColor = True
        '
        'rbApmStby
        '
        Me.rbApmStby.AutoSize = True
        Me.rbApmStby.Checked = True
        Me.rbApmStby.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbApmStby.Location = New System.Drawing.Point(2, 29)
        Me.rbApmStby.Name = "rbApmStby"
        Me.rbApmStby.Size = New System.Drawing.Size(77, 23)
        Me.rbApmStby.TabIndex = 133
        Me.rbApmStby.TabStop = True
        Me.rbApmStby.Text = "Standby"
        Me.rbApmStby.UseVisualStyleBackColor = True
        '
        'rbApmOff
        '
        Me.rbApmOff.AutoSize = True
        Me.rbApmOff.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbApmOff.Location = New System.Drawing.Point(3, 5)
        Me.rbApmOff.Name = "rbApmOff"
        Me.rbApmOff.Size = New System.Drawing.Size(55, 23)
        Me.rbApmOff.TabIndex = 133
        Me.rbApmOff.Text = "IDLE"
        Me.rbApmOff.UseVisualStyleBackColor = True
        '
        'rbApmDcdc
        '
        Me.rbApmDcdc.AutoSize = True
        Me.rbApmDcdc.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbApmDcdc.Location = New System.Drawing.Point(74, 3)
        Me.rbApmDcdc.Name = "rbApmDcdc"
        Me.rbApmDcdc.Size = New System.Drawing.Size(65, 23)
        Me.rbApmDcdc.TabIndex = 133
        Me.rbApmDcdc.Text = "DCDC"
        Me.rbApmDcdc.UseVisualStyleBackColor = True
        '
        'chAPMCtrlmsg
        '
        Me.chAPMCtrlmsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.chAPMCtrlmsg.Location = New System.Drawing.Point(28, 53)
        Me.chAPMCtrlmsg.Name = "chAPMCtrlmsg"
        Me.chAPMCtrlmsg.Size = New System.Drawing.Size(16, 21)
        Me.chAPMCtrlmsg.TabIndex = 117
        Me.chAPMCtrlmsg.UseVisualStyleBackColor = True
        '
        'nudAPMCurr
        '
        Me.nudAPMCurr.DecimalPlaces = 1
        Me.nudAPMCurr.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudAPMCurr.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudAPMCurr.Location = New System.Drawing.Point(157, 43)
        Me.nudAPMCurr.Maximum = New Decimal(New Integer() {265, 0, 0, 0})
        Me.nudAPMCurr.Minimum = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudAPMCurr.Name = "nudAPMCurr"
        Me.nudAPMCurr.Size = New System.Drawing.Size(75, 29)
        Me.nudAPMCurr.TabIndex = 65
        Me.nudAPMCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudAPMCurr.Value = New Decimal(New Integer() {2200, 0, 0, 65536})
        '
        'nudAPMVolt
        '
        Me.nudAPMVolt.DecimalPlaces = 1
        Me.nudAPMVolt.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudAPMVolt.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudAPMVolt.Location = New System.Drawing.Point(64, 43)
        Me.nudAPMVolt.Maximum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.nudAPMVolt.Minimum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.nudAPMVolt.Name = "nudAPMVolt"
        Me.nudAPMVolt.Size = New System.Drawing.Size(75, 29)
        Me.nudAPMVolt.TabIndex = 64
        Me.nudAPMVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudAPMVolt.Value = New Decimal(New Integer() {135, 0, 0, 65536})
        '
        'VoltUnit
        '
        Me.VoltUnit.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.VoltUnit.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VoltUnit.Location = New System.Drawing.Point(138, 42)
        Me.VoltUnit.Name = "VoltUnit"
        Me.VoltUnit.Size = New System.Drawing.Size(22, 31)
        Me.VoltUnit.TabIndex = 14
        Me.VoltUnit.Text = "V"
        Me.VoltUnit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(154, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 17)
        Me.Label5.TabIndex = 132
        Me.Label5.Text = "Target Current:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(7, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 18)
        Me.Label6.TabIndex = 132
        Me.Label6.Text = "Broadcast"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label42.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(61, 19)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(109, 23)
        Me.Label42.TabIndex = 132
        Me.Label42.Text = "Target Voltage:"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CurrentUnit
        '
        Me.CurrentUnit.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.CurrentUnit.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CurrentUnit.Location = New System.Drawing.Point(230, 43)
        Me.CurrentUnit.Name = "CurrentUnit"
        Me.CurrentUnit.Size = New System.Drawing.Size(22, 28)
        Me.CurrentUnit.TabIndex = 13
        Me.CurrentUnit.Text = "A"
        Me.CurrentUnit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 35)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 19)
        Me.Label7.TabIndex = 132
        Me.Label7.Text = "ID - 0x200"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'gbOBCCtrl
        '
        Me.gbOBCCtrl.Controls.Add(Me.pnModeCtrl)
        Me.gbOBCCtrl.Controls.Add(Me.Label28)
        Me.gbOBCCtrl.Controls.Add(Me.Label10)
        Me.gbOBCCtrl.Controls.Add(Me.chOBCSafetymsg)
        Me.gbOBCCtrl.Controls.Add(Me.chOBCCtrlmsg)
        Me.gbOBCCtrl.Controls.Add(Me.Label27)
        Me.gbOBCCtrl.Controls.Add(Me.Label9)
        Me.gbOBCCtrl.Controls.Add(Me.nudOBCPower)
        Me.gbOBCCtrl.Controls.Add(Me.nudOBCCurr)
        Me.gbOBCCtrl.Controls.Add(Me.btUpdateOBCCmd)
        Me.gbOBCCtrl.Controls.Add(Me.Label139)
        Me.gbOBCCtrl.Controls.Add(Me.Label3)
        Me.gbOBCCtrl.Controls.Add(Me.Label2)
        Me.gbOBCCtrl.Controls.Add(Me.nudOBCVolt)
        Me.gbOBCCtrl.Controls.Add(Me.Label140)
        Me.gbOBCCtrl.Controls.Add(Me.Label1)
        Me.gbOBCCtrl.Controls.Add(Me.Label4)
        Me.gbOBCCtrl.Enabled = False
        Me.gbOBCCtrl.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.gbOBCCtrl.Location = New System.Drawing.Point(496, 6)
        Me.gbOBCCtrl.Name = "gbOBCCtrl"
        Me.gbOBCCtrl.Size = New System.Drawing.Size(694, 84)
        Me.gbOBCCtrl.TabIndex = 65
        Me.gbOBCCtrl.TabStop = False
        Me.gbOBCCtrl.Text = "OBC"
        '
        'pnModeCtrl
        '
        Me.pnModeCtrl.Controls.Add(Me.rbTestmode)
        Me.pnModeCtrl.Controls.Add(Me.rbStandby)
        Me.pnModeCtrl.Controls.Add(Me.rbSleep)
        Me.pnModeCtrl.Controls.Add(Me.rbForward)
        Me.pnModeCtrl.Controls.Add(Me.rbReverse)
        Me.pnModeCtrl.Enabled = False
        Me.pnModeCtrl.Location = New System.Drawing.Point(453, 15)
        Me.pnModeCtrl.Name = "pnModeCtrl"
        Me.pnModeCtrl.Size = New System.Drawing.Size(238, 63)
        Me.pnModeCtrl.TabIndex = 0
        '
        'rbTestmode
        '
        Me.rbTestmode.AutoSize = True
        Me.rbTestmode.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbTestmode.Location = New System.Drawing.Point(144, 5)
        Me.rbTestmode.Name = "rbTestmode"
        Me.rbTestmode.Size = New System.Drawing.Size(92, 23)
        Me.rbTestmode.TabIndex = 133
        Me.rbTestmode.Text = "Test Mode"
        Me.rbTestmode.UseVisualStyleBackColor = True
        '
        'rbStandby
        '
        Me.rbStandby.AutoSize = True
        Me.rbStandby.Checked = True
        Me.rbStandby.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbStandby.Location = New System.Drawing.Point(66, 5)
        Me.rbStandby.Name = "rbStandby"
        Me.rbStandby.Size = New System.Drawing.Size(77, 23)
        Me.rbStandby.TabIndex = 133
        Me.rbStandby.TabStop = True
        Me.rbStandby.Text = "Standby"
        Me.rbStandby.UseVisualStyleBackColor = True
        '
        'rbSleep
        '
        Me.rbSleep.AutoSize = True
        Me.rbSleep.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbSleep.Location = New System.Drawing.Point(4, 5)
        Me.rbSleep.Name = "rbSleep"
        Me.rbSleep.Size = New System.Drawing.Size(59, 23)
        Me.rbSleep.TabIndex = 133
        Me.rbSleep.Text = "Sleep"
        Me.rbSleep.UseVisualStyleBackColor = True
        '
        'rbForward
        '
        Me.rbForward.AutoSize = True
        Me.rbForward.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbForward.Location = New System.Drawing.Point(31, 31)
        Me.rbForward.Name = "rbForward"
        Me.rbForward.Size = New System.Drawing.Size(102, 23)
        Me.rbForward.TabIndex = 133
        Me.rbForward.Text = "Forward ON"
        Me.rbForward.UseVisualStyleBackColor = True
        '
        'rbReverse
        '
        Me.rbReverse.AutoSize = True
        Me.rbReverse.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbReverse.Location = New System.Drawing.Point(137, 30)
        Me.rbReverse.Name = "rbReverse"
        Me.rbReverse.Size = New System.Drawing.Size(99, 23)
        Me.rbReverse.TabIndex = 133
        Me.rbReverse.Text = "Reverse ON"
        Me.rbReverse.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label28.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(66, 20)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(56, 21)
        Me.Label28.TabIndex = 132
        Me.Label28.Text = "Broadcast"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 21)
        Me.Label10.TabIndex = 132
        Me.Label10.Text = "Broadcast"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chOBCSafetymsg
        '
        Me.chOBCSafetymsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.chOBCSafetymsg.Location = New System.Drawing.Point(86, 53)
        Me.chOBCSafetymsg.Name = "chOBCSafetymsg"
        Me.chOBCSafetymsg.Size = New System.Drawing.Size(16, 21)
        Me.chOBCSafetymsg.TabIndex = 117
        Me.chOBCSafetymsg.UseVisualStyleBackColor = True
        '
        'chOBCCtrlmsg
        '
        Me.chOBCCtrlmsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.chOBCCtrlmsg.Location = New System.Drawing.Point(26, 53)
        Me.chOBCCtrlmsg.Name = "chOBCCtrlmsg"
        Me.chOBCCtrlmsg.Size = New System.Drawing.Size(16, 21)
        Me.chOBCCtrlmsg.TabIndex = 117
        Me.chOBCCtrlmsg.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label27.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(63, 37)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(59, 18)
        Me.Label27.TabIndex = 132
        Me.Label27.Text = "ID - 0x102"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 37)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 18)
        Me.Label9.TabIndex = 132
        Me.Label9.Text = "ID - 0x100"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'nudOBCPower
        '
        Me.nudOBCPower.DecimalPlaces = 2
        Me.nudOBCPower.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudOBCPower.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudOBCPower.Location = New System.Drawing.Point(303, 44)
        Me.nudOBCPower.Maximum = New Decimal(New Integer() {2200, 0, 0, 131072})
        Me.nudOBCPower.Minimum = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudOBCPower.Name = "nudOBCPower"
        Me.nudOBCPower.Size = New System.Drawing.Size(75, 29)
        Me.nudOBCPower.TabIndex = 65
        Me.nudOBCPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudOBCPower.Value = New Decimal(New Integer() {100, 0, 0, 131072})
        '
        'nudOBCCurr
        '
        Me.nudOBCCurr.DecimalPlaces = 2
        Me.nudOBCCurr.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudOBCCurr.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudOBCCurr.Location = New System.Drawing.Point(211, 44)
        Me.nudOBCCurr.Maximum = New Decimal(New Integer() {370, 0, 0, 65536})
        Me.nudOBCCurr.Minimum = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudOBCCurr.Name = "nudOBCCurr"
        Me.nudOBCCurr.Size = New System.Drawing.Size(75, 29)
        Me.nudOBCCurr.TabIndex = 65
        Me.nudOBCCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudOBCCurr.Value = New Decimal(New Integer() {370, 0, 0, 65536})
        '
        'btUpdateOBCCmd
        '
        Me.btUpdateOBCCmd.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btUpdateOBCCmd.Location = New System.Drawing.Point(402, 16)
        Me.btUpdateOBCCmd.Name = "btUpdateOBCCmd"
        Me.btUpdateOBCCmd.Size = New System.Drawing.Size(46, 58)
        Me.btUpdateOBCCmd.TabIndex = 118
        Me.btUpdateOBCCmd.Text = "Set"
        '
        'Label139
        '
        Me.Label139.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label139.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label139.Location = New System.Drawing.Point(299, 24)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(87, 18)
        Me.Label139.TabIndex = 132
        Me.Label139.Text = "Target Power:"
        Me.Label139.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(121, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 15)
        Me.Label3.TabIndex = 132
        Me.Label3.Text = "Target Voltage:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(208, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 18)
        Me.Label2.TabIndex = 132
        Me.Label2.Text = "Target Current:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'nudOBCVolt
        '
        Me.nudOBCVolt.DecimalPlaces = 1
        Me.nudOBCVolt.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudOBCVolt.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.nudOBCVolt.Location = New System.Drawing.Point(124, 44)
        Me.nudOBCVolt.Maximum = New Decimal(New Integer() {480, 0, 0, 0})
        Me.nudOBCVolt.Minimum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.nudOBCVolt.Name = "nudOBCVolt"
        Me.nudOBCVolt.Size = New System.Drawing.Size(75, 29)
        Me.nudOBCVolt.TabIndex = 64
        Me.nudOBCVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudOBCVolt.Value = New Decimal(New Integer() {450, 0, 0, 0})
        '
        'Label140
        '
        Me.Label140.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label140.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label140.Location = New System.Drawing.Point(367, 44)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(47, 31)
        Me.Label140.TabIndex = 13
        Me.Label140.Text = "kW"
        Me.Label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(193, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(22, 27)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "V"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(283, 43)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 31)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "A"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbObcBcCyTime
        '
        Me.cbObcBcCyTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbObcBcCyTime.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.cbObcBcCyTime.Items.AddRange(New Object() {"25mS", "50mS", "75mS", "100mS", "125mS", "150mS", "175mS", "200mS", "300mS", "400mS", "500mS", "600mS", "700mS", "800mS", "900mS", "1000mS"})
        Me.cbObcBcCyTime.Location = New System.Drawing.Point(7, 53)
        Me.cbObcBcCyTime.Margin = New System.Windows.Forms.Padding(4)
        Me.cbObcBcCyTime.Name = "cbObcBcCyTime"
        Me.cbObcBcCyTime.Size = New System.Drawing.Size(82, 25)
        Me.cbObcBcCyTime.TabIndex = 119
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Underline)
        Me.Label11.Location = New System.Drawing.Point(4, 20)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 41)
        Me.Label11.TabIndex = 120
        Me.Label11.Text = "Broadcast Cycle Time :-"
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.gbSecDebCtrl)
        Me.TabPage8.Controls.Add(Me.gbPriDebCtrl)
        Me.TabPage8.Location = New System.Drawing.Point(4, 29)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(1193, 93)
        Me.TabPage8.TabIndex = 2
        Me.TabPage8.Text = "Debug Control"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'gbSecDebCtrl
        '
        Me.gbSecDebCtrl.Controls.Add(Me.nudBurstDty)
        Me.gbSecDebCtrl.Controls.Add(Me.nudPhaseShift)
        Me.gbSecDebCtrl.Controls.Add(Me.nudFrequency)
        Me.gbSecDebCtrl.Controls.Add(Me.rbSecPwmOn2)
        Me.gbSecDebCtrl.Controls.Add(Me.rbSecPwmOn1)
        Me.gbSecDebCtrl.Controls.Add(Me.rbSecPwmOff)
        Me.gbSecDebCtrl.Controls.Add(Me.buSecOLCmd)
        Me.gbSecDebCtrl.Controls.Add(Me.buGetSecFwRev)
        Me.gbSecDebCtrl.Controls.Add(Me.Label76)
        Me.gbSecDebCtrl.Controls.Add(Me.Label77)
        Me.gbSecDebCtrl.Controls.Add(Me.chSecDeb1)
        Me.gbSecDebCtrl.Controls.Add(Me.chSecDeb2)
        Me.gbSecDebCtrl.Controls.Add(Me.Label106)
        Me.gbSecDebCtrl.Controls.Add(Me.Label98)
        Me.gbSecDebCtrl.Controls.Add(Me.Label78)
        Me.gbSecDebCtrl.Controls.Add(Me.Label114)
        Me.gbSecDebCtrl.Controls.Add(Me.Label112)
        Me.gbSecDebCtrl.Controls.Add(Me.Label109)
        Me.gbSecDebCtrl.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbSecDebCtrl.Location = New System.Drawing.Point(536, 6)
        Me.gbSecDebCtrl.Name = "gbSecDebCtrl"
        Me.gbSecDebCtrl.Size = New System.Drawing.Size(652, 89)
        Me.gbSecDebCtrl.TabIndex = 186
        Me.gbSecDebCtrl.TabStop = False
        Me.gbSecDebCtrl.Text = "Secondary Deb. Control"
        Me.gbSecDebCtrl.Visible = False
        '
        'nudBurstDty
        '
        Me.nudBurstDty.Enabled = False
        Me.nudBurstDty.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudBurstDty.Location = New System.Drawing.Point(162, 43)
        Me.nudBurstDty.Name = "nudBurstDty"
        Me.nudBurstDty.Size = New System.Drawing.Size(70, 26)
        Me.nudBurstDty.TabIndex = 187
        Me.nudBurstDty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudBurstDty.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'nudPhaseShift
        '
        Me.nudPhaseShift.Enabled = False
        Me.nudPhaseShift.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudPhaseShift.Location = New System.Drawing.Point(238, 43)
        Me.nudPhaseShift.Name = "nudPhaseShift"
        Me.nudPhaseShift.Size = New System.Drawing.Size(70, 26)
        Me.nudPhaseShift.TabIndex = 187
        Me.nudPhaseShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'nudFrequency
        '
        Me.nudFrequency.DecimalPlaces = 2
        Me.nudFrequency.Enabled = False
        Me.nudFrequency.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudFrequency.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudFrequency.Location = New System.Drawing.Point(316, 43)
        Me.nudFrequency.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.nudFrequency.Minimum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.nudFrequency.Name = "nudFrequency"
        Me.nudFrequency.Size = New System.Drawing.Size(70, 26)
        Me.nudFrequency.TabIndex = 187
        Me.nudFrequency.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudFrequency.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'rbSecPwmOn2
        '
        Me.rbSecPwmOn2.AutoSize = True
        Me.rbSecPwmOn2.Enabled = False
        Me.rbSecPwmOn2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbSecPwmOn2.Location = New System.Drawing.Point(13, 62)
        Me.rbSecPwmOn2.Name = "rbSecPwmOn2"
        Me.rbSecPwmOn2.Size = New System.Drawing.Size(137, 23)
        Me.rbSecPwmOn2.TabIndex = 186
        Me.rbSecPwmOn2.Text = "PWM ON CLLLC2"
        Me.rbSecPwmOn2.UseVisualStyleBackColor = True
        '
        'rbSecPwmOn1
        '
        Me.rbSecPwmOn1.AutoSize = True
        Me.rbSecPwmOn1.Enabled = False
        Me.rbSecPwmOn1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbSecPwmOn1.Location = New System.Drawing.Point(13, 40)
        Me.rbSecPwmOn1.Name = "rbSecPwmOn1"
        Me.rbSecPwmOn1.Size = New System.Drawing.Size(137, 23)
        Me.rbSecPwmOn1.TabIndex = 186
        Me.rbSecPwmOn1.Text = "PWM ON CLLLC1"
        Me.rbSecPwmOn1.UseVisualStyleBackColor = True
        '
        'rbSecPwmOff
        '
        Me.rbSecPwmOff.AutoSize = True
        Me.rbSecPwmOff.Checked = True
        Me.rbSecPwmOff.Enabled = False
        Me.rbSecPwmOff.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.rbSecPwmOff.Location = New System.Drawing.Point(13, 18)
        Me.rbSecPwmOff.Name = "rbSecPwmOff"
        Me.rbSecPwmOff.Size = New System.Drawing.Size(90, 23)
        Me.rbSecPwmOff.TabIndex = 186
        Me.rbSecPwmOff.TabStop = True
        Me.rbSecPwmOff.Text = "PWM OFF"
        Me.rbSecPwmOff.UseVisualStyleBackColor = True
        '
        'buSecOLCmd
        '
        Me.buSecOLCmd.Enabled = False
        Me.buSecOLCmd.Font = New System.Drawing.Font("Times New Roman", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buSecOLCmd.Location = New System.Drawing.Point(395, 18)
        Me.buSecOLCmd.Name = "buSecOLCmd"
        Me.buSecOLCmd.Size = New System.Drawing.Size(106, 61)
        Me.buSecOLCmd.TabIndex = 184
        Me.buSecOLCmd.Text = "Send Open Loop Cmd"
        Me.buSecOLCmd.UseVisualStyleBackColor = True
        '
        'buGetSecFwRev
        '
        Me.buGetSecFwRev.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buGetSecFwRev.Location = New System.Drawing.Point(511, 12)
        Me.buGetSecFwRev.Name = "buGetSecFwRev"
        Me.buGetSecFwRev.Size = New System.Drawing.Size(129, 28)
        Me.buGetSecFwRev.TabIndex = 184
        Me.buGetSecFwRev.Text = "Get Sec. FW Rev."
        Me.buGetSecFwRev.UseVisualStyleBackColor = True
        '
        'Label76
        '
        Me.Label76.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label76.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(540, 46)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(107, 22)
        Me.Label76.TabIndex = 183
        Me.Label76.Text = "Get Deb. 1"
        '
        'Label77
        '
        Me.Label77.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label77.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(540, 66)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(109, 22)
        Me.Label77.TabIndex = 183
        Me.Label77.Text = "Get Deb. 2"
        '
        'chSecDeb1
        '
        Me.chSecDeb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.chSecDeb1.Location = New System.Drawing.Point(517, 46)
        Me.chSecDeb1.Name = "chSecDeb1"
        Me.chSecDeb1.Size = New System.Drawing.Size(16, 21)
        Me.chSecDeb1.TabIndex = 134
        Me.chSecDeb1.UseVisualStyleBackColor = True
        '
        'chSecDeb2
        '
        Me.chSecDeb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.chSecDeb2.Location = New System.Drawing.Point(517, 66)
        Me.chSecDeb2.Name = "chSecDeb2"
        Me.chSecDeb2.Size = New System.Drawing.Size(16, 21)
        Me.chSecDeb2.TabIndex = 134
        Me.chSecDeb2.UseVisualStyleBackColor = True
        '
        'Label106
        '
        Me.Label106.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label106.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(312, 22)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(70, 19)
        Me.Label106.TabIndex = 175
        Me.Label106.Text = "Frequency:"
        Me.Label106.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label98
        '
        Me.Label98.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label98.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(236, 22)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(70, 19)
        Me.Label98.TabIndex = 175
        Me.Label98.Text = "Phase Shift:"
        Me.Label98.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label78
        '
        Me.Label78.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label78.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(161, 22)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(70, 19)
        Me.Label78.TabIndex = 175
        Me.Label78.Text = "Burst Duty:"
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label114
        '
        Me.Label114.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label114.BackColor = System.Drawing.Color.Transparent
        Me.Label114.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.Location = New System.Drawing.Point(349, 69)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(33, 22)
        Me.Label114.TabIndex = 183
        Me.Label114.Text = "Khz"
        '
        'Label112
        '
        Me.Label112.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label112.BackColor = System.Drawing.Color.Transparent
        Me.Label112.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(279, 69)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(18, 22)
        Me.Label112.TabIndex = 183
        Me.Label112.Text = "%"
        '
        'Label109
        '
        Me.Label109.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label109.BackColor = System.Drawing.Color.Transparent
        Me.Label109.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.Location = New System.Drawing.Point(196, 69)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(18, 22)
        Me.Label109.TabIndex = 183
        Me.Label109.Text = "%"
        '
        'gbPriDebCtrl
        '
        Me.gbPriDebCtrl.Controls.Add(Me.nudKi)
        Me.gbPriDebCtrl.Controls.Add(Me.nudKp)
        Me.gbPriDebCtrl.Controls.Add(Me.chPriFutMode)
        Me.gbPriDebCtrl.Controls.Add(Me.buSetKi)
        Me.gbPriDebCtrl.Controls.Add(Me.buSetKp)
        Me.gbPriDebCtrl.Controls.Add(Me.buGetPriFwRev)
        Me.gbPriDebCtrl.Controls.Add(Me.chPriDeb1)
        Me.gbPriDebCtrl.Controls.Add(Me.Label82)
        Me.gbPriDebCtrl.Controls.Add(Me.Label91)
        Me.gbPriDebCtrl.Controls.Add(Me.Label211)
        Me.gbPriDebCtrl.Controls.Add(Me.chPriDeb2)
        Me.gbPriDebCtrl.Controls.Add(Me.Label210)
        Me.gbPriDebCtrl.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPriDebCtrl.Location = New System.Drawing.Point(6, 3)
        Me.gbPriDebCtrl.Name = "gbPriDebCtrl"
        Me.gbPriDebCtrl.Size = New System.Drawing.Size(524, 92)
        Me.gbPriDebCtrl.TabIndex = 186
        Me.gbPriDebCtrl.TabStop = False
        Me.gbPriDebCtrl.Text = "Primary Deb. Control"
        Me.gbPriDebCtrl.Visible = False
        '
        'nudKi
        '
        Me.nudKi.DecimalPlaces = 1
        Me.nudKi.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudKi.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudKi.InterceptArrowKeys = False
        Me.nudKi.Location = New System.Drawing.Point(300, 29)
        Me.nudKi.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudKi.Name = "nudKi"
        Me.nudKi.Size = New System.Drawing.Size(70, 26)
        Me.nudKi.TabIndex = 187
        Me.nudKi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudKi.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'nudKp
        '
        Me.nudKp.DecimalPlaces = 1
        Me.nudKp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudKp.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudKp.InterceptArrowKeys = False
        Me.nudKp.Location = New System.Drawing.Point(224, 29)
        Me.nudKp.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudKp.Name = "nudKp"
        Me.nudKp.Size = New System.Drawing.Size(70, 26)
        Me.nudKp.TabIndex = 187
        Me.nudKp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudKp.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'chPriFutMode
        '
        Me.chPriFutMode.AutoSize = True
        Me.chPriFutMode.Enabled = False
        Me.chPriFutMode.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.chPriFutMode.Location = New System.Drawing.Point(6, 22)
        Me.chPriFutMode.Name = "chPriFutMode"
        Me.chPriFutMode.Size = New System.Drawing.Size(143, 23)
        Me.chPriFutMode.TabIndex = 189
        Me.chPriFutMode.Text = "Primary FUT Mode"
        Me.chPriFutMode.UseVisualStyleBackColor = True
        '
        'buSetKi
        '
        Me.buSetKi.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buSetKi.Location = New System.Drawing.Point(300, 58)
        Me.buSetKi.Name = "buSetKi"
        Me.buSetKi.Size = New System.Drawing.Size(69, 28)
        Me.buSetKi.TabIndex = 188
        Me.buSetKi.Text = "Set Ki"
        Me.buSetKi.UseVisualStyleBackColor = True
        '
        'buSetKp
        '
        Me.buSetKp.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buSetKp.Location = New System.Drawing.Point(224, 58)
        Me.buSetKp.Name = "buSetKp"
        Me.buSetKp.Size = New System.Drawing.Size(69, 28)
        Me.buSetKp.TabIndex = 188
        Me.buSetKp.Text = "Set Kp"
        Me.buSetKp.UseVisualStyleBackColor = True
        '
        'buGetPriFwRev
        '
        Me.buGetPriFwRev.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buGetPriFwRev.Location = New System.Drawing.Point(379, 12)
        Me.buGetPriFwRev.Name = "buGetPriFwRev"
        Me.buGetPriFwRev.Size = New System.Drawing.Size(129, 28)
        Me.buGetPriFwRev.TabIndex = 188
        Me.buGetPriFwRev.Text = "Get Pri. FW Rev."
        Me.buGetPriFwRev.UseVisualStyleBackColor = True
        '
        'chPriDeb1
        '
        Me.chPriDeb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.chPriDeb1.Location = New System.Drawing.Point(385, 46)
        Me.chPriDeb1.Name = "chPriDeb1"
        Me.chPriDeb1.Size = New System.Drawing.Size(16, 21)
        Me.chPriDeb1.TabIndex = 185
        Me.chPriDeb1.UseVisualStyleBackColor = True
        '
        'Label82
        '
        Me.Label82.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label82.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(407, 46)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(111, 22)
        Me.Label82.TabIndex = 186
        Me.Label82.Text = "Get Deb. 1"
        '
        'Label91
        '
        Me.Label91.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label91.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(407, 66)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(113, 22)
        Me.Label91.TabIndex = 187
        Me.Label91.Text = "Get Deb. 2"
        '
        'Label211
        '
        Me.Label211.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label211.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label211.Location = New System.Drawing.Point(299, 8)
        Me.Label211.Name = "Label211"
        Me.Label211.Size = New System.Drawing.Size(70, 19)
        Me.Label211.TabIndex = 175
        Me.Label211.Text = "NPC Ki:"
        Me.Label211.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chPriDeb2
        '
        Me.chPriDeb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.chPriDeb2.Location = New System.Drawing.Point(385, 66)
        Me.chPriDeb2.Name = "chPriDeb2"
        Me.chPriDeb2.Size = New System.Drawing.Size(16, 21)
        Me.chPriDeb2.TabIndex = 184
        Me.chPriDeb2.UseVisualStyleBackColor = True
        '
        'Label210
        '
        Me.Label210.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label210.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label210.Location = New System.Drawing.Point(223, 8)
        Me.Label210.Name = "Label210"
        Me.Label210.Size = New System.Drawing.Size(70, 19)
        Me.Label210.TabIndex = 175
        Me.Label210.Text = "NPC Kp:"
        Me.Label210.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label52.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(4, 300)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(82, 22)
        Me.Label52.TabIndex = 183
        Me.Label52.Text = "Firmware Rev:"
        '
        'tbSecFwRev
        '
        Me.tbSecFwRev.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSecFwRev.Location = New System.Drawing.Point(4, 314)
        Me.tbSecFwRev.Name = "tbSecFwRev"
        Me.tbSecFwRev.ReadOnly = True
        Me.tbSecFwRev.Size = New System.Drawing.Size(155, 21)
        Me.tbSecFwRev.TabIndex = 182
        Me.tbSecFwRev.Text = "-"
        Me.tbSecFwRev.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Enabled = False
        Me.TabControl2.Font = New System.Drawing.Font("Times New Roman", 13.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl2.Location = New System.Drawing.Point(5, 174)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1201, 528)
        Me.TabControl2.TabIndex = 135
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.gbOBCInfo)
        Me.TabPage3.Controls.Add(Me.gbAPMinfo)
        Me.TabPage3.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 29)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1193, 495)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Information"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'gbOBCInfo
        '
        Me.gbOBCInfo.Controls.Add(Me.GroupBox7)
        Me.gbOBCInfo.Controls.Add(Me.GroupBox6)
        Me.gbOBCInfo.Enabled = False
        Me.gbOBCInfo.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.gbOBCInfo.Location = New System.Drawing.Point(329, 0)
        Me.gbOBCInfo.Name = "gbOBCInfo"
        Me.gbOBCInfo.Size = New System.Drawing.Size(858, 500)
        Me.gbOBCInfo.TabIndex = 153
        Me.gbOBCInfo.TabStop = False
        Me.gbOBCInfo.Text = "OBC"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.tbSecState)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Controls.Add(Me.pnSecDeb)
        Me.GroupBox7.Controls.Add(Me.tbIout)
        Me.GroupBox7.Controls.Add(Me.Label16)
        Me.GroupBox7.Controls.Add(Me.Label23)
        Me.GroupBox7.Controls.Add(Me.sBit17)
        Me.GroupBox7.Controls.Add(Me.Label25)
        Me.GroupBox7.Controls.Add(Me.tbVbulk)
        Me.GroupBox7.Controls.Add(Me.tbVout)
        Me.GroupBox7.Controls.Add(Me.sBit16)
        Me.GroupBox7.Controls.Add(Me.sBit10)
        Me.GroupBox7.Controls.Add(Me.Label18)
        Me.GroupBox7.Controls.Add(Me.sBit14)
        Me.GroupBox7.Controls.Add(Me.sBit15)
        Me.GroupBox7.Controls.Add(Me.sBit04)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.sBit06)
        Me.GroupBox7.Controls.Add(Me.Label22)
        Me.GroupBox7.Controls.Add(Me.sBit13)
        Me.GroupBox7.Controls.Add(Me.sBit12)
        Me.GroupBox7.Controls.Add(Me.sBit05)
        Me.GroupBox7.Controls.Add(Me.Label21)
        Me.GroupBox7.Controls.Add(Me.sBit07)
        Me.GroupBox7.Controls.Add(Me.Label209)
        Me.GroupBox7.Controls.Add(Me.Label14)
        Me.GroupBox7.Controls.Add(Me.Label13)
        Me.GroupBox7.Controls.Add(Me.Label20)
        Me.GroupBox7.Controls.Add(Me.Label24)
        Me.GroupBox7.Controls.Add(Me.sBit11)
        Me.GroupBox7.Controls.Add(Me.Label15)
        Me.GroupBox7.Controls.Add(Me.Label19)
        Me.GroupBox7.Controls.Add(Me.Label26)
        Me.GroupBox7.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(437, 13)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(413, 483)
        Me.GroupBox7.TabIndex = 153
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Secondary"
        '
        'tbSecState
        '
        Me.tbSecState.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSecState.Location = New System.Drawing.Point(328, 46)
        Me.tbSecState.Name = "tbSecState"
        Me.tbSecState.ReadOnly = True
        Me.tbSecState.Size = New System.Drawing.Size(78, 23)
        Me.tbSecState.TabIndex = 179
        Me.tbSecState.Text = "-"
        Me.tbSecState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(328, 27)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(54, 23)
        Me.Label17.TabIndex = 175
        Me.Label17.Text = "State:"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnSecDeb
        '
        Me.pnSecDeb.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pnSecDeb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnSecDeb.Controls.Add(Me.chSecDebInDec)
        Me.pnSecDeb.Controls.Add(Me.tbFreq2)
        Me.pnSecDeb.Controls.Add(Me.tbFreq1)
        Me.pnSecDeb.Controls.Add(Me.Label141)
        Me.pnSecDeb.Controls.Add(Me.tbVauxSec)
        Me.pnSecDeb.Controls.Add(Me.tbPS2)
        Me.pnSecDeb.Controls.Add(Me.sBit20)
        Me.pnSecDeb.Controls.Add(Me.tbPS1)
        Me.pnSecDeb.Controls.Add(Me.sBit22)
        Me.pnSecDeb.Controls.Add(Me.tbSecFwRev)
        Me.pnSecDeb.Controls.Add(Me.tbIpri2)
        Me.pnSecDeb.Controls.Add(Me.sBit21)
        Me.pnSecDeb.Controls.Add(Me.tbTRes2)
        Me.pnSecDeb.Controls.Add(Me.sBit23)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb6)
        Me.pnSecDeb.Controls.Add(Me.sBit30)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb3)
        Me.pnSecDeb.Controls.Add(Me.sBit32)
        Me.pnSecDeb.Controls.Add(Me.tbBurstDty2)
        Me.pnSecDeb.Controls.Add(Me.sBit31)
        Me.pnSecDeb.Controls.Add(Me.sBit33)
        Me.pnSecDeb.Controls.Add(Me.tbBurstDty1)
        Me.pnSecDeb.Controls.Add(Me.Label75)
        Me.pnSecDeb.Controls.Add(Me.tbIpri1)
        Me.pnSecDeb.Controls.Add(Me.Label74)
        Me.pnSecDeb.Controls.Add(Me.tbTRes1)
        Me.pnSecDeb.Controls.Add(Me.Label73)
        Me.pnSecDeb.Controls.Add(Me.tbIpriTot)
        Me.pnSecDeb.Controls.Add(Me.Label72)
        Me.pnSecDeb.Controls.Add(Me.tbTClllcS2)
        Me.pnSecDeb.Controls.Add(Me.Label71)
        Me.pnSecDeb.Controls.Add(Me.Label45)
        Me.pnSecDeb.Controls.Add(Me.sBit24)
        Me.pnSecDeb.Controls.Add(Me.tbIout2)
        Me.pnSecDeb.Controls.Add(Me.sBit26)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb5)
        Me.pnSecDeb.Controls.Add(Me.sBit25)
        Me.pnSecDeb.Controls.Add(Me.Label41)
        Me.pnSecDeb.Controls.Add(Me.sBit27)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb2)
        Me.pnSecDeb.Controls.Add(Me.Label70)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb4)
        Me.pnSecDeb.Controls.Add(Me.Label69)
        Me.pnSecDeb.Controls.Add(Me.tbIshareAdj)
        Me.pnSecDeb.Controls.Add(Me.Label68)
        Me.pnSecDeb.Controls.Add(Me.tbSDeb1)
        Me.pnSecDeb.Controls.Add(Me.Label67)
        Me.pnSecDeb.Controls.Add(Me.tbIshareStat)
        Me.pnSecDeb.Controls.Add(Me.sBit34)
        Me.pnSecDeb.Controls.Add(Me.tbIshareErr)
        Me.pnSecDeb.Controls.Add(Me.Label66)
        Me.pnSecDeb.Controls.Add(Me.tbSRStat)
        Me.pnSecDeb.Controls.Add(Me.sBit36)
        Me.pnSecDeb.Controls.Add(Me.tbCCorCV)
        Me.pnSecDeb.Controls.Add(Me.sBit35)
        Me.pnSecDeb.Controls.Add(Me.tbCtrlMode)
        Me.pnSecDeb.Controls.Add(Me.Label65)
        Me.pnSecDeb.Controls.Add(Me.tbTClllcS1)
        Me.pnSecDeb.Controls.Add(Me.Label64)
        Me.pnSecDeb.Controls.Add(Me.Label44)
        Me.pnSecDeb.Controls.Add(Me.sBit37)
        Me.pnSecDeb.Controls.Add(Me.Label59)
        Me.pnSecDeb.Controls.Add(Me.Label38)
        Me.pnSecDeb.Controls.Add(Me.Label56)
        Me.pnSecDeb.Controls.Add(Me.Label40)
        Me.pnSecDeb.Controls.Add(Me.Label63)
        Me.pnSecDeb.Controls.Add(Me.tbIout1)
        Me.pnSecDeb.Controls.Add(Me.Label62)
        Me.pnSecDeb.Controls.Add(Me.Label43)
        Me.pnSecDeb.Controls.Add(Me.Label61)
        Me.pnSecDeb.Controls.Add(Me.Label37)
        Me.pnSecDeb.Controls.Add(Me.Label60)
        Me.pnSecDeb.Controls.Add(Me.Label58)
        Me.pnSecDeb.Controls.Add(Me.Label39)
        Me.pnSecDeb.Controls.Add(Me.Label55)
        Me.pnSecDeb.Controls.Add(Me.Label33)
        Me.pnSecDeb.Controls.Add(Me.Label51)
        Me.pnSecDeb.Controls.Add(Me.Label36)
        Me.pnSecDeb.Controls.Add(Me.Label57)
        Me.pnSecDeb.Controls.Add(Me.Label49)
        Me.pnSecDeb.Controls.Add(Me.Label54)
        Me.pnSecDeb.Controls.Add(Me.Label32)
        Me.pnSecDeb.Controls.Add(Me.Label50)
        Me.pnSecDeb.Controls.Add(Me.Label47)
        Me.pnSecDeb.Controls.Add(Me.Label48)
        Me.pnSecDeb.Controls.Add(Me.Label35)
        Me.pnSecDeb.Controls.Add(Me.Label46)
        Me.pnSecDeb.Controls.Add(Me.Label31)
        Me.pnSecDeb.Controls.Add(Me.Label34)
        Me.pnSecDeb.Controls.Add(Me.Label30)
        Me.pnSecDeb.Controls.Add(Me.Label127)
        Me.pnSecDeb.Controls.Add(Me.Label52)
        Me.pnSecDeb.Location = New System.Drawing.Point(6, 131)
        Me.pnSecDeb.Name = "pnSecDeb"
        Me.pnSecDeb.Size = New System.Drawing.Size(400, 343)
        Me.pnSecDeb.TabIndex = 182
        Me.pnSecDeb.Visible = False
        '
        'chSecDebInDec
        '
        Me.chSecDebInDec.AutoSize = True
        Me.chSecDebInDec.Font = New System.Drawing.Font("Times New Roman", 7.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chSecDebInDec.Location = New System.Drawing.Point(345, 277)
        Me.chSecDebInDec.Name = "chSecDebInDec"
        Me.chSecDebInDec.Size = New System.Drawing.Size(15, 14)
        Me.chSecDebInDec.TabIndex = 190
        Me.chSecDebInDec.UseVisualStyleBackColor = True
        '
        'tbFreq2
        '
        Me.tbFreq2.BackColor = System.Drawing.Color.Snow
        Me.tbFreq2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbFreq2.Location = New System.Drawing.Point(317, 202)
        Me.tbFreq2.Name = "tbFreq2"
        Me.tbFreq2.ReadOnly = True
        Me.tbFreq2.Size = New System.Drawing.Size(75, 21)
        Me.tbFreq2.TabIndex = 182
        Me.tbFreq2.Text = "-"
        Me.tbFreq2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbFreq1
        '
        Me.tbFreq1.BackColor = System.Drawing.Color.Snow
        Me.tbFreq1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbFreq1.Location = New System.Drawing.Point(317, 163)
        Me.tbFreq1.Name = "tbFreq1"
        Me.tbFreq1.ReadOnly = True
        Me.tbFreq1.Size = New System.Drawing.Size(75, 21)
        Me.tbFreq1.TabIndex = 182
        Me.tbFreq1.Text = "-"
        Me.tbFreq1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label141
        '
        Me.Label141.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label141.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label141.Location = New System.Drawing.Point(315, 239)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(74, 40)
        Me.Label141.TabIndex = 132
        Me.Label141.Text = "Debug Data in Decimal"
        Me.Label141.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbVauxSec
        '
        Me.tbVauxSec.BackColor = System.Drawing.Color.Snow
        Me.tbVauxSec.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbVauxSec.Location = New System.Drawing.Point(317, 125)
        Me.tbVauxSec.Name = "tbVauxSec"
        Me.tbVauxSec.ReadOnly = True
        Me.tbVauxSec.Size = New System.Drawing.Size(75, 21)
        Me.tbVauxSec.TabIndex = 182
        Me.tbVauxSec.Text = "-"
        Me.tbVauxSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPS2
        '
        Me.tbPS2.BackColor = System.Drawing.Color.Snow
        Me.tbPS2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPS2.Location = New System.Drawing.Point(238, 202)
        Me.tbPS2.Name = "tbPS2"
        Me.tbPS2.ReadOnly = True
        Me.tbPS2.Size = New System.Drawing.Size(75, 21)
        Me.tbPS2.TabIndex = 182
        Me.tbPS2.Text = "-"
        Me.tbPS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit20
        '
        Me.sBit20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit20.Location = New System.Drawing.Point(370, 59)
        Me.sBit20.Name = "sBit20"
        Me.sBit20.Size = New System.Drawing.Size(23, 13)
        Me.sBit20.TabIndex = 0
        '
        'tbPS1
        '
        Me.tbPS1.BackColor = System.Drawing.Color.Snow
        Me.tbPS1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPS1.Location = New System.Drawing.Point(238, 163)
        Me.tbPS1.Name = "tbPS1"
        Me.tbPS1.ReadOnly = True
        Me.tbPS1.Size = New System.Drawing.Size(75, 21)
        Me.tbPS1.TabIndex = 182
        Me.tbPS1.Text = "-"
        Me.tbPS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit22
        '
        Me.sBit22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit22.Location = New System.Drawing.Point(370, 23)
        Me.sBit22.Name = "sBit22"
        Me.sBit22.Size = New System.Drawing.Size(23, 13)
        Me.sBit22.TabIndex = 0
        '
        'tbIpri2
        '
        Me.tbIpri2.BackColor = System.Drawing.Color.Snow
        Me.tbIpri2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIpri2.Location = New System.Drawing.Point(317, 87)
        Me.tbIpri2.Name = "tbIpri2"
        Me.tbIpri2.ReadOnly = True
        Me.tbIpri2.Size = New System.Drawing.Size(75, 21)
        Me.tbIpri2.TabIndex = 182
        Me.tbIpri2.Text = "-"
        Me.tbIpri2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit21
        '
        Me.sBit21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit21.Location = New System.Drawing.Point(370, 40)
        Me.sBit21.Name = "sBit21"
        Me.sBit21.Size = New System.Drawing.Size(23, 13)
        Me.sBit21.TabIndex = 0
        '
        'tbTRes2
        '
        Me.tbTRes2.BackColor = System.Drawing.Color.Snow
        Me.tbTRes2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTRes2.Location = New System.Drawing.Point(238, 125)
        Me.tbTRes2.Name = "tbTRes2"
        Me.tbTRes2.ReadOnly = True
        Me.tbTRes2.Size = New System.Drawing.Size(75, 21)
        Me.tbTRes2.TabIndex = 182
        Me.tbTRes2.Text = "-"
        Me.tbTRes2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit23
        '
        Me.sBit23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit23.Location = New System.Drawing.Point(370, 4)
        Me.sBit23.Name = "sBit23"
        Me.sBit23.Size = New System.Drawing.Size(23, 13)
        Me.sBit23.TabIndex = 0
        '
        'tbSDeb6
        '
        Me.tbSDeb6.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb6.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb6.Location = New System.Drawing.Point(240, 278)
        Me.tbSDeb6.Name = "tbSDeb6"
        Me.tbSDeb6.ReadOnly = True
        Me.tbSDeb6.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb6.TabIndex = 182
        Me.tbSDeb6.Text = "-"
        Me.tbSDeb6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit30
        '
        Me.sBit30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit30.Location = New System.Drawing.Point(177, 59)
        Me.sBit30.Name = "sBit30"
        Me.sBit30.Size = New System.Drawing.Size(23, 13)
        Me.sBit30.TabIndex = 0
        '
        'tbSDeb3
        '
        Me.tbSDeb3.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb3.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb3.Location = New System.Drawing.Point(239, 240)
        Me.tbSDeb3.Name = "tbSDeb3"
        Me.tbSDeb3.ReadOnly = True
        Me.tbSDeb3.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb3.TabIndex = 182
        Me.tbSDeb3.Text = "-"
        Me.tbSDeb3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit32
        '
        Me.sBit32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit32.Location = New System.Drawing.Point(177, 23)
        Me.sBit32.Name = "sBit32"
        Me.sBit32.Size = New System.Drawing.Size(23, 13)
        Me.sBit32.TabIndex = 0
        '
        'tbBurstDty2
        '
        Me.tbBurstDty2.BackColor = System.Drawing.Color.Snow
        Me.tbBurstDty2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbBurstDty2.Location = New System.Drawing.Point(159, 202)
        Me.tbBurstDty2.Name = "tbBurstDty2"
        Me.tbBurstDty2.ReadOnly = True
        Me.tbBurstDty2.Size = New System.Drawing.Size(75, 21)
        Me.tbBurstDty2.TabIndex = 182
        Me.tbBurstDty2.Text = "-"
        Me.tbBurstDty2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit31
        '
        Me.sBit31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit31.Location = New System.Drawing.Point(177, 40)
        Me.sBit31.Name = "sBit31"
        Me.sBit31.Size = New System.Drawing.Size(23, 13)
        Me.sBit31.TabIndex = 0
        '
        'sBit33
        '
        Me.sBit33.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit33.Location = New System.Drawing.Point(177, 4)
        Me.sBit33.Name = "sBit33"
        Me.sBit33.Size = New System.Drawing.Size(23, 13)
        Me.sBit33.TabIndex = 0
        '
        'tbBurstDty1
        '
        Me.tbBurstDty1.BackColor = System.Drawing.Color.Snow
        Me.tbBurstDty1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbBurstDty1.Location = New System.Drawing.Point(159, 163)
        Me.tbBurstDty1.Name = "tbBurstDty1"
        Me.tbBurstDty1.ReadOnly = True
        Me.tbBurstDty1.Size = New System.Drawing.Size(75, 21)
        Me.tbBurstDty1.TabIndex = 182
        Me.tbBurstDty1.Text = "-"
        Me.tbBurstDty1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label75
        '
        Me.Label75.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label75.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(301, 57)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(63, 17)
        Me.Label75.TabIndex = 175
        Me.Label75.Text = "Vout OVP"
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIpri1
        '
        Me.tbIpri1.BackColor = System.Drawing.Color.Snow
        Me.tbIpri1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIpri1.Location = New System.Drawing.Point(238, 87)
        Me.tbIpri1.Name = "tbIpri1"
        Me.tbIpri1.ReadOnly = True
        Me.tbIpri1.Size = New System.Drawing.Size(75, 21)
        Me.tbIpri1.TabIndex = 182
        Me.tbIpri1.Text = "-"
        Me.tbIpri1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label74
        '
        Me.Label74.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label74.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(301, 21)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(63, 17)
        Me.Label74.TabIndex = 175
        Me.Label74.Text = "Vout OCP1"
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbTRes1
        '
        Me.tbTRes1.BackColor = System.Drawing.Color.Snow
        Me.tbTRes1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTRes1.Location = New System.Drawing.Point(159, 125)
        Me.tbTRes1.Name = "tbTRes1"
        Me.tbTRes1.ReadOnly = True
        Me.tbTRes1.Size = New System.Drawing.Size(75, 21)
        Me.tbTRes1.TabIndex = 182
        Me.tbTRes1.Text = "-"
        Me.tbTRes1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label73
        '
        Me.Label73.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label73.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(301, 2)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(63, 17)
        Me.Label73.TabIndex = 175
        Me.Label73.Text = "Vout OCP2"
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIpriTot
        '
        Me.tbIpriTot.BackColor = System.Drawing.Color.Snow
        Me.tbIpriTot.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIpriTot.Location = New System.Drawing.Point(159, 87)
        Me.tbIpriTot.Name = "tbIpriTot"
        Me.tbIpriTot.ReadOnly = True
        Me.tbIpriTot.Size = New System.Drawing.Size(75, 21)
        Me.tbIpriTot.TabIndex = 182
        Me.tbIpriTot.Text = "-"
        Me.tbIpriTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label72
        '
        Me.Label72.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label72.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(108, 57)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(63, 17)
        Me.Label72.TabIndex = 175
        Me.Label72.Text = "Bulk OVP"
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbTClllcS2
        '
        Me.tbTClllcS2.BackColor = System.Drawing.Color.Snow
        Me.tbTClllcS2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTClllcS2.Location = New System.Drawing.Point(79, 125)
        Me.tbTClllcS2.Name = "tbTClllcS2"
        Me.tbTClllcS2.ReadOnly = True
        Me.tbTClllcS2.Size = New System.Drawing.Size(75, 21)
        Me.tbTClllcS2.TabIndex = 182
        Me.tbTClllcS2.Text = "-"
        Me.tbTClllcS2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label71
        '
        Me.Label71.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label71.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(108, 21)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(63, 17)
        Me.Label71.TabIndex = 175
        Me.Label71.Text = "Bulk OCP1"
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label45
        '
        Me.Label45.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label45.BackColor = System.Drawing.Color.Transparent
        Me.Label45.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(317, 188)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(78, 22)
        Me.Label45.TabIndex = 183
        Me.Label45.Text = "LLC Freq. 2"
        '
        'sBit24
        '
        Me.sBit24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit24.Location = New System.Drawing.Point(274, 59)
        Me.sBit24.Name = "sBit24"
        Me.sBit24.Size = New System.Drawing.Size(23, 13)
        Me.sBit24.TabIndex = 0
        '
        'tbIout2
        '
        Me.tbIout2.BackColor = System.Drawing.Color.Snow
        Me.tbIout2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIout2.Location = New System.Drawing.Point(79, 87)
        Me.tbIout2.Name = "tbIout2"
        Me.tbIout2.ReadOnly = True
        Me.tbIout2.Size = New System.Drawing.Size(75, 21)
        Me.tbIout2.TabIndex = 182
        Me.tbIout2.Text = "-"
        Me.tbIout2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit26
        '
        Me.sBit26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit26.Location = New System.Drawing.Point(274, 23)
        Me.sBit26.Name = "sBit26"
        Me.sBit26.Size = New System.Drawing.Size(23, 13)
        Me.sBit26.TabIndex = 0
        '
        'tbSDeb5
        '
        Me.tbSDeb5.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb5.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb5.Location = New System.Drawing.Point(161, 278)
        Me.tbSDeb5.Name = "tbSDeb5"
        Me.tbSDeb5.ReadOnly = True
        Me.tbSDeb5.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb5.TabIndex = 182
        Me.tbSDeb5.Text = "-"
        Me.tbSDeb5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit25
        '
        Me.sBit25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit25.Location = New System.Drawing.Point(274, 40)
        Me.sBit25.Name = "sBit25"
        Me.sBit25.Size = New System.Drawing.Size(23, 13)
        Me.sBit25.TabIndex = 0
        '
        'Label41
        '
        Me.Label41.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(317, 149)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(78, 22)
        Me.Label41.TabIndex = 183
        Me.Label41.Text = "LLC Freq. 1"
        '
        'sBit27
        '
        Me.sBit27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit27.Location = New System.Drawing.Point(274, 4)
        Me.sBit27.Name = "sBit27"
        Me.sBit27.Size = New System.Drawing.Size(23, 13)
        Me.sBit27.TabIndex = 0
        '
        'tbSDeb2
        '
        Me.tbSDeb2.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb2.Location = New System.Drawing.Point(160, 240)
        Me.tbSDeb2.Name = "tbSDeb2"
        Me.tbSDeb2.ReadOnly = True
        Me.tbSDeb2.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb2.TabIndex = 182
        Me.tbSDeb2.Text = "-"
        Me.tbSDeb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label70
        '
        Me.Label70.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label70.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(205, 57)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(63, 17)
        Me.Label70.TabIndex = 175
        Me.Label70.Text = "-"
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbSDeb4
        '
        Me.tbSDeb4.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb4.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb4.Location = New System.Drawing.Point(82, 278)
        Me.tbSDeb4.Name = "tbSDeb4"
        Me.tbSDeb4.ReadOnly = True
        Me.tbSDeb4.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb4.TabIndex = 182
        Me.tbSDeb4.Text = "-"
        Me.tbSDeb4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label69
        '
        Me.Label69.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label69.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(201, 21)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(67, 19)
        Me.Label69.TabIndex = 175
        Me.Label69.Text = "Aux UV"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIshareAdj
        '
        Me.tbIshareAdj.BackColor = System.Drawing.Color.Snow
        Me.tbIshareAdj.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIshareAdj.Location = New System.Drawing.Point(3, 278)
        Me.tbIshareAdj.Name = "tbIshareAdj"
        Me.tbIshareAdj.ReadOnly = True
        Me.tbIshareAdj.Size = New System.Drawing.Size(75, 21)
        Me.tbIshareAdj.TabIndex = 182
        Me.tbIshareAdj.Text = "-"
        Me.tbIshareAdj.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label68
        '
        Me.Label68.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label68.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(196, 40)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(73, 15)
        Me.Label68.TabIndex = 175
        Me.Label68.Text = "Aux OV"
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbSDeb1
        '
        Me.tbSDeb1.BackColor = System.Drawing.Color.Snow
        Me.tbSDeb1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSDeb1.Location = New System.Drawing.Point(81, 240)
        Me.tbSDeb1.Name = "tbSDeb1"
        Me.tbSDeb1.ReadOnly = True
        Me.tbSDeb1.Size = New System.Drawing.Size(75, 21)
        Me.tbSDeb1.TabIndex = 182
        Me.tbSDeb1.Text = "-"
        Me.tbSDeb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label67
        '
        Me.Label67.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label67.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(205, 2)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(63, 17)
        Me.Label67.TabIndex = 175
        Me.Label67.Text = "TZ Fault"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIshareStat
        '
        Me.tbIshareStat.BackColor = System.Drawing.Color.Snow
        Me.tbIshareStat.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIshareStat.Location = New System.Drawing.Point(82, 202)
        Me.tbIshareStat.Name = "tbIshareStat"
        Me.tbIshareStat.ReadOnly = True
        Me.tbIshareStat.Size = New System.Drawing.Size(75, 21)
        Me.tbIshareStat.TabIndex = 182
        Me.tbIshareStat.Text = "-"
        Me.tbIshareStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit34
        '
        Me.sBit34.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit34.Location = New System.Drawing.Point(70, 59)
        Me.sBit34.Name = "sBit34"
        Me.sBit34.Size = New System.Drawing.Size(23, 13)
        Me.sBit34.TabIndex = 0
        '
        'tbIshareErr
        '
        Me.tbIshareErr.BackColor = System.Drawing.Color.Snow
        Me.tbIshareErr.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIshareErr.Location = New System.Drawing.Point(3, 240)
        Me.tbIshareErr.Name = "tbIshareErr"
        Me.tbIshareErr.ReadOnly = True
        Me.tbIshareErr.Size = New System.Drawing.Size(75, 21)
        Me.tbIshareErr.TabIndex = 182
        Me.tbIshareErr.Text = "-"
        Me.tbIshareErr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label66
        '
        Me.Label66.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label66.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(1, 57)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(63, 17)
        Me.Label66.TabIndex = 175
        Me.Label66.Text = " S1 OT"
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbSRStat
        '
        Me.tbSRStat.BackColor = System.Drawing.Color.Snow
        Me.tbSRStat.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbSRStat.Location = New System.Drawing.Point(4, 202)
        Me.tbSRStat.Name = "tbSRStat"
        Me.tbSRStat.ReadOnly = True
        Me.tbSRStat.Size = New System.Drawing.Size(75, 21)
        Me.tbSRStat.TabIndex = 182
        Me.tbSRStat.Text = "-"
        Me.tbSRStat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit36
        '
        Me.sBit36.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit36.Location = New System.Drawing.Point(70, 23)
        Me.sBit36.Name = "sBit36"
        Me.sBit36.Size = New System.Drawing.Size(23, 13)
        Me.sBit36.TabIndex = 0
        '
        'tbCCorCV
        '
        Me.tbCCorCV.BackColor = System.Drawing.Color.Snow
        Me.tbCCorCV.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCCorCV.Location = New System.Drawing.Point(81, 163)
        Me.tbCCorCV.Name = "tbCCorCV"
        Me.tbCCorCV.ReadOnly = True
        Me.tbCCorCV.Size = New System.Drawing.Size(75, 21)
        Me.tbCCorCV.TabIndex = 182
        Me.tbCCorCV.Text = "-"
        Me.tbCCorCV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit35
        '
        Me.sBit35.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit35.Location = New System.Drawing.Point(70, 40)
        Me.sBit35.Name = "sBit35"
        Me.sBit35.Size = New System.Drawing.Size(23, 13)
        Me.sBit35.TabIndex = 0
        '
        'tbCtrlMode
        '
        Me.tbCtrlMode.BackColor = System.Drawing.Color.Snow
        Me.tbCtrlMode.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCtrlMode.Location = New System.Drawing.Point(3, 163)
        Me.tbCtrlMode.Name = "tbCtrlMode"
        Me.tbCtrlMode.ReadOnly = True
        Me.tbCtrlMode.Size = New System.Drawing.Size(75, 21)
        Me.tbCtrlMode.TabIndex = 182
        Me.tbCtrlMode.Text = "-"
        Me.tbCtrlMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label65
        '
        Me.Label65.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label65.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(5, 21)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(59, 19)
        Me.Label65.TabIndex = 175
        Me.Label65.Text = "-"
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbTClllcS1
        '
        Me.tbTClllcS1.BackColor = System.Drawing.Color.Snow
        Me.tbTClllcS1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbTClllcS1.Location = New System.Drawing.Point(3, 125)
        Me.tbTClllcS1.Name = "tbTClllcS1"
        Me.tbTClllcS1.ReadOnly = True
        Me.tbTClllcS1.Size = New System.Drawing.Size(75, 21)
        Me.tbTClllcS1.TabIndex = 182
        Me.tbTClllcS1.Text = "-"
        Me.tbTClllcS1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label64
        '
        Me.Label64.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label64.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(1, 40)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(64, 15)
        Me.Label64.TabIndex = 175
        Me.Label64.Text = "S2 OT"
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label44
        '
        Me.Label44.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label44.BackColor = System.Drawing.Color.Transparent
        Me.Label44.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(234, 188)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(84, 22)
        Me.Label44.TabIndex = 183
        Me.Label44.Text = "Phase Shift 2"
        '
        'sBit37
        '
        Me.sBit37.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit37.Location = New System.Drawing.Point(70, 4)
        Me.sBit37.Name = "sBit37"
        Me.sBit37.Size = New System.Drawing.Size(23, 13)
        Me.sBit37.TabIndex = 0
        '
        'Label59
        '
        Me.Label59.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label59.BackColor = System.Drawing.Color.Transparent
        Me.Label59.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(235, 264)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(91, 22)
        Me.Label59.TabIndex = 183
        Me.Label59.Text = "Debug 5"
        '
        'Label38
        '
        Me.Label38.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(317, 111)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(73, 22)
        Me.Label38.TabIndex = 183
        Me.Label38.Text = "V Aux Sec"
        '
        'Label56
        '
        Me.Label56.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label56.BackColor = System.Drawing.Color.Transparent
        Me.Label56.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(234, 226)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(91, 22)
        Me.Label56.TabIndex = 183
        Me.Label56.Text = "Debug 2"
        '
        'Label40
        '
        Me.Label40.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(234, 149)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(84, 22)
        Me.Label40.TabIndex = 183
        Me.Label40.Text = "Phase Shift 1"
        '
        'Label63
        '
        Me.Label63.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label63.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(-3, 2)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(69, 19)
        Me.Label63.TabIndex = 175
        Me.Label63.Text = "OT Warning"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIout1
        '
        Me.tbIout1.BackColor = System.Drawing.Color.Snow
        Me.tbIout1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIout1.Location = New System.Drawing.Point(3, 87)
        Me.tbIout1.Name = "tbIout1"
        Me.tbIout1.ReadOnly = True
        Me.tbIout1.Size = New System.Drawing.Size(75, 21)
        Me.tbIout1.TabIndex = 182
        Me.tbIout1.Text = "-"
        Me.tbIout1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label62
        '
        Me.Label62.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label62.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(88, 2)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(83, 19)
        Me.Label62.TabIndex = 175
        Me.Label62.Text = "Bulk OCP2"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label43
        '
        Me.Label43.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(156, 188)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(84, 22)
        Me.Label43.TabIndex = 183
        Me.Label43.Text = "Burst Duty 2"
        '
        'Label61
        '
        Me.Label61.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label61.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(283, 40)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(82, 17)
        Me.Label61.TabIndex = 175
        Me.Label61.Text = "Vout OCP"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label37
        '
        Me.Label37.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(236, 111)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(73, 22)
        Me.Label37.TabIndex = 183
        Me.Label37.Text = "T Reserved"
        '
        'Label60
        '
        Me.Label60.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label60.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(92, 40)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(80, 19)
        Me.Label60.TabIndex = 175
        Me.Label60.Text = "Bulk OCP"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label58
        '
        Me.Label58.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label58.BackColor = System.Drawing.Color.Transparent
        Me.Label58.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(161, 264)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(82, 22)
        Me.Label58.TabIndex = 183
        Me.Label58.Text = "Debug 4"
        '
        'Label39
        '
        Me.Label39.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label39.BackColor = System.Drawing.Color.Transparent
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(156, 149)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(84, 22)
        Me.Label39.TabIndex = 183
        Me.Label39.Text = "Burst Duty 1"
        '
        'Label55
        '
        Me.Label55.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label55.BackColor = System.Drawing.Color.Transparent
        Me.Label55.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(160, 226)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(82, 22)
        Me.Label55.TabIndex = 183
        Me.Label55.Text = "Debug 1"
        '
        'Label33
        '
        Me.Label33.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(317, 73)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(73, 22)
        Me.Label33.TabIndex = 183
        Me.Label33.Text = "IPri2"
        '
        'Label51
        '
        Me.Label51.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label51.BackColor = System.Drawing.Color.Transparent
        Me.Label51.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(3, 264)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(82, 22)
        Me.Label51.TabIndex = 183
        Me.Label51.Text = "IShare Adj."
        '
        'Label36
        '
        Me.Label36.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(159, 111)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(73, 22)
        Me.Label36.TabIndex = 183
        Me.Label36.Text = "T Reserved"
        '
        'Label57
        '
        Me.Label57.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label57.BackColor = System.Drawing.Color.Transparent
        Me.Label57.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(82, 264)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(73, 22)
        Me.Label57.TabIndex = 183
        Me.Label57.Text = "Debug 3"
        '
        'Label49
        '
        Me.Label49.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label49.BackColor = System.Drawing.Color.Transparent
        Me.Label49.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(82, 188)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(82, 22)
        Me.Label49.TabIndex = 183
        Me.Label49.Text = "IShare Stat."
        '
        'Label54
        '
        Me.Label54.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label54.BackColor = System.Drawing.Color.Transparent
        Me.Label54.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(81, 226)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(73, 22)
        Me.Label54.TabIndex = 183
        Me.Label54.Text = "Debug 0"
        '
        'Label32
        '
        Me.Label32.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(236, 73)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(73, 22)
        Me.Label32.TabIndex = 183
        Me.Label32.Text = "IPri1"
        '
        'Label50
        '
        Me.Label50.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label50.BackColor = System.Drawing.Color.Transparent
        Me.Label50.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(3, 226)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(73, 22)
        Me.Label50.TabIndex = 183
        Me.Label50.Text = "IShare Err."
        '
        'Label47
        '
        Me.Label47.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label47.BackColor = System.Drawing.Color.Transparent
        Me.Label47.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(81, 149)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(73, 22)
        Me.Label47.TabIndex = 183
        Me.Label47.Text = "CC / CV"
        '
        'Label48
        '
        Me.Label48.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label48.BackColor = System.Drawing.Color.Transparent
        Me.Label48.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(4, 188)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(73, 22)
        Me.Label48.TabIndex = 183
        Me.Label48.Text = "SR Stat."
        '
        'Label35
        '
        Me.Label35.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(79, 111)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(73, 22)
        Me.Label35.TabIndex = 183
        Me.Label35.Text = "T Clllc S2"
        '
        'Label46
        '
        Me.Label46.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label46.BackColor = System.Drawing.Color.Transparent
        Me.Label46.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(3, 149)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(73, 22)
        Me.Label46.TabIndex = 183
        Me.Label46.Text = "Ctrl Mode"
        '
        'Label31
        '
        Me.Label31.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(159, 73)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(73, 22)
        Me.Label31.TabIndex = 183
        Me.Label31.Text = "IPri Total"
        '
        'Label34
        '
        Me.Label34.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(3, 111)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(73, 22)
        Me.Label34.TabIndex = 183
        Me.Label34.Text = "T Clllc S1"
        '
        'Label30
        '
        Me.Label30.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(79, 73)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 22)
        Me.Label30.TabIndex = 183
        Me.Label30.Text = "Iout2"
        '
        'Label127
        '
        Me.Label127.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label127.BackColor = System.Drawing.Color.Transparent
        Me.Label127.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(3, 73)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(73, 22)
        Me.Label127.TabIndex = 183
        Me.Label127.Text = "Iout1"
        '
        'tbIout
        '
        Me.tbIout.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIout.Location = New System.Drawing.Point(188, 100)
        Me.tbIout.Name = "tbIout"
        Me.tbIout.ReadOnly = True
        Me.tbIout.Size = New System.Drawing.Size(92, 23)
        Me.tbIout.TabIndex = 181
        Me.tbIout.Text = "-"
        Me.tbIout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(-2, 22)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(78, 15)
        Me.Label16.TabIndex = 175
        Me.Label16.Text = "CAN Tout"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label23
        '
        Me.Label23.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label23.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(-4, 39)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(80, 19)
        Me.Label23.TabIndex = 175
        Me.Label23.Text = "OT Fault"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sBit17
        '
        Me.sBit17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit17.Location = New System.Drawing.Point(81, 22)
        Me.sBit17.Name = "sBit17"
        Me.sBit17.Size = New System.Drawing.Size(23, 13)
        Me.sBit17.TabIndex = 0
        '
        'Label25
        '
        Me.Label25.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label25.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(-2, 78)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(82, 17)
        Me.Label25.TabIndex = 175
        Me.Label25.Text = "OBC OK"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbVbulk
        '
        Me.tbVbulk.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbVbulk.Location = New System.Drawing.Point(333, 100)
        Me.tbVbulk.Name = "tbVbulk"
        Me.tbVbulk.ReadOnly = True
        Me.tbVbulk.Size = New System.Drawing.Size(73, 23)
        Me.tbVbulk.TabIndex = 180
        Me.tbVbulk.Text = "-"
        Me.tbVbulk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbVout
        '
        Me.tbVout.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbVout.Location = New System.Drawing.Point(55, 100)
        Me.tbVout.Name = "tbVout"
        Me.tbVout.ReadOnly = True
        Me.tbVout.Size = New System.Drawing.Size(92, 23)
        Me.tbVout.TabIndex = 179
        Me.tbVout.Text = "-"
        Me.tbVout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sBit16
        '
        Me.sBit16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit16.Location = New System.Drawing.Point(81, 39)
        Me.sBit16.Name = "sBit16"
        Me.sBit16.Size = New System.Drawing.Size(23, 13)
        Me.sBit16.TabIndex = 0
        '
        'sBit10
        '
        Me.sBit10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit10.Location = New System.Drawing.Point(188, 79)
        Me.sBit10.Name = "sBit10"
        Me.sBit10.Size = New System.Drawing.Size(23, 13)
        Me.sBit10.TabIndex = 0
        '
        'Label18
        '
        Me.Label18.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(3, 60)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(73, 15)
        Me.Label18.TabIndex = 175
        Me.Label18.Text = "CLLLC Fault"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sBit14
        '
        Me.sBit14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit14.Location = New System.Drawing.Point(81, 79)
        Me.sBit14.Name = "sBit14"
        Me.sBit14.Size = New System.Drawing.Size(23, 13)
        Me.sBit14.TabIndex = 0
        '
        'sBit15
        '
        Me.sBit15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit15.Location = New System.Drawing.Point(81, 60)
        Me.sBit15.Name = "sBit15"
        Me.sBit15.Size = New System.Drawing.Size(23, 13)
        Me.sBit15.TabIndex = 0
        '
        'sBit04
        '
        Me.sBit04.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit04.Location = New System.Drawing.Point(296, 79)
        Me.sBit04.Name = "sBit04"
        Me.sBit04.Size = New System.Drawing.Size(23, 13)
        Me.sBit04.TabIndex = 0
        '
        'Label12
        '
        Me.Label12.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(107, 20)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 15)
        Me.Label12.TabIndex = 175
        Me.Label12.Text = "CLLLC OK"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sBit06
        '
        Me.sBit06.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit06.Location = New System.Drawing.Point(296, 41)
        Me.sBit06.Name = "sBit06"
        Me.sBit06.Size = New System.Drawing.Size(23, 13)
        Me.sBit06.TabIndex = 0
        '
        'Label22
        '
        Me.Label22.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label22.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(227, 77)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(63, 17)
        Me.Label22.TabIndex = 175
        Me.Label22.Text = "CP Ready"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sBit13
        '
        Me.sBit13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit13.Location = New System.Drawing.Point(188, 22)
        Me.sBit13.Name = "sBit13"
        Me.sBit13.Size = New System.Drawing.Size(23, 13)
        Me.sBit13.TabIndex = 0
        '
        'sBit12
        '
        Me.sBit12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit12.Location = New System.Drawing.Point(188, 41)
        Me.sBit12.Name = "sBit12"
        Me.sBit12.Size = New System.Drawing.Size(23, 13)
        Me.sBit12.TabIndex = 0
        '
        'sBit05
        '
        Me.sBit05.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit05.Location = New System.Drawing.Point(296, 60)
        Me.sBit05.Name = "sBit05"
        Me.sBit05.Size = New System.Drawing.Size(23, 13)
        Me.sBit05.TabIndex = 0
        '
        'Label21
        '
        Me.Label21.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(217, 58)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(73, 17)
        Me.Label21.TabIndex = 175
        Me.Label21.Text = "Forward EN"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sBit07
        '
        Me.sBit07.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit07.Location = New System.Drawing.Point(296, 22)
        Me.sBit07.Name = "sBit07"
        Me.sBit07.Size = New System.Drawing.Size(23, 13)
        Me.sBit07.TabIndex = 0
        '
        'Label209
        '
        Me.Label209.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label209.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label209.Location = New System.Drawing.Point(200, 20)
        Me.Label209.Name = "Label209"
        Me.Label209.Size = New System.Drawing.Size(90, 19)
        Me.Label209.TabIndex = 175
        Me.Label209.Text = "PFC Enabled"
        Me.Label209.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(119, 39)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(63, 17)
        Me.Label14.TabIndex = 175
        Me.Label14.Text = "CLLLC EN"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(88, 58)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(98, 17)
        Me.Label13.TabIndex = 175
        Me.Label13.Text = "PFC OK"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label20
        '
        Me.Label20.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(207, 39)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(83, 19)
        Me.Label20.TabIndex = 175
        Me.Label20.Text = "Reverse EN"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label24
        '
        Me.Label24.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(147, 99)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(54, 23)
        Me.Label24.TabIndex = 175
        Me.Label24.Text = "IBat:"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'sBit11
        '
        Me.sBit11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sBit11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sBit11.Location = New System.Drawing.Point(188, 60)
        Me.sBit11.Name = "sBit11"
        Me.sBit11.Size = New System.Drawing.Size(23, 13)
        Me.sBit11.TabIndex = 0
        '
        'Label15
        '
        Me.Label15.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(119, 77)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(63, 17)
        Me.Label15.TabIndex = 175
        Me.Label15.Text = "AC OK"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(8, 99)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 23)
        Me.Label19.TabIndex = 175
        Me.Label19.Text = "VBat:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label26.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(278, 100)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(60, 23)
        Me.Label26.TabIndex = 175
        Me.Label26.Text = "VBulk:"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.tbPIacA)
        Me.GroupBox6.Controls.Add(Me.tbPriState)
        Me.GroupBox6.Controls.Add(Me.pnPriDeb)
        Me.GroupBox6.Controls.Add(Me.Label138)
        Me.GroupBox6.Controls.Add(Me.tbPVbulkMid)
        Me.GroupBox6.Controls.Add(Me.Label122)
        Me.GroupBox6.Controls.Add(Me.Label137)
        Me.GroupBox6.Controls.Add(Me.Label124)
        Me.GroupBox6.Controls.Add(Me.Label136)
        Me.GroupBox6.Controls.Add(Me.sPBit11)
        Me.GroupBox6.Controls.Add(Me.sPBit17)
        Me.GroupBox6.Controls.Add(Me.Label125)
        Me.GroupBox6.Controls.Add(Me.Label135)
        Me.GroupBox6.Controls.Add(Me.Label126)
        Me.GroupBox6.Controls.Add(Me.Label128)
        Me.GroupBox6.Controls.Add(Me.tbPVacA)
        Me.GroupBox6.Controls.Add(Me.Label129)
        Me.GroupBox6.Controls.Add(Me.sPBit16)
        Me.GroupBox6.Controls.Add(Me.Label130)
        Me.GroupBox6.Controls.Add(Me.sPBit10)
        Me.GroupBox6.Controls.Add(Me.sPBit07)
        Me.GroupBox6.Controls.Add(Me.Label134)
        Me.GroupBox6.Controls.Add(Me.Label131)
        Me.GroupBox6.Controls.Add(Me.sPBit14)
        Me.GroupBox6.Controls.Add(Me.sPBit05)
        Me.GroupBox6.Controls.Add(Me.sPBit15)
        Me.GroupBox6.Controls.Add(Me.sPBit12)
        Me.GroupBox6.Controls.Add(Me.sPBit04)
        Me.GroupBox6.Controls.Add(Me.sPBit13)
        Me.GroupBox6.Controls.Add(Me.Label133)
        Me.GroupBox6.Controls.Add(Me.Label132)
        Me.GroupBox6.Controls.Add(Me.sPBit06)
        Me.GroupBox6.Controls.Add(Me.Label123)
        Me.GroupBox6.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(6, 14)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(425, 483)
        Me.GroupBox6.TabIndex = 153
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Primary"
        '
        'tbPIacA
        '
        Me.tbPIacA.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPIacA.Location = New System.Drawing.Point(188, 98)
        Me.tbPIacA.Name = "tbPIacA"
        Me.tbPIacA.ReadOnly = True
        Me.tbPIacA.Size = New System.Drawing.Size(86, 23)
        Me.tbPIacA.TabIndex = 181
        Me.tbPIacA.Text = "-"
        Me.tbPIacA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbPriState
        '
        Me.tbPriState.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPriState.Location = New System.Drawing.Point(328, 44)
        Me.tbPriState.Name = "tbPriState"
        Me.tbPriState.ReadOnly = True
        Me.tbPriState.Size = New System.Drawing.Size(91, 23)
        Me.tbPriState.TabIndex = 179
        Me.tbPriState.Text = "-"
        Me.tbPriState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pnPriDeb
        '
        Me.pnPriDeb.BackColor = System.Drawing.Color.WhiteSmoke
        Me.pnPriDeb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnPriDeb.Controls.Add(Me.chPriDebInDec)
        Me.pnPriDeb.Controls.Add(Me.tbPTclllcP2)
        Me.pnPriDeb.Controls.Add(Me.Label8)
        Me.pnPriDeb.Controls.Add(Me.TextBox3)
        Me.pnPriDeb.Controls.Add(Me.sPBit20)
        Me.pnPriDeb.Controls.Add(Me.tbPTclllcP1)
        Me.pnPriDeb.Controls.Add(Me.sPBit22)
        Me.pnPriDeb.Controls.Add(Me.tbPriFwRev)
        Me.pnPriDeb.Controls.Add(Me.tbIphaseC)
        Me.pnPriDeb.Controls.Add(Me.sPBit21)
        Me.pnPriDeb.Controls.Add(Me.tbPVaux)
        Me.pnPriDeb.Controls.Add(Me.sPBit23)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb6)
        Me.pnPriDeb.Controls.Add(Me.sPBit30)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb3)
        Me.pnPriDeb.Controls.Add(Me.sPBit32)
        Me.pnPriDeb.Controls.Add(Me.sPBit31)
        Me.pnPriDeb.Controls.Add(Me.sPBit33)
        Me.pnPriDeb.Controls.Add(Me.tbPTnpcC)
        Me.pnPriDeb.Controls.Add(Me.Label29)
        Me.pnPriDeb.Controls.Add(Me.tbIphaseB)
        Me.pnPriDeb.Controls.Add(Me.Label53)
        Me.pnPriDeb.Controls.Add(Me.tbPVbulk)
        Me.pnPriDeb.Controls.Add(Me.Label79)
        Me.pnPriDeb.Controls.Add(Me.tbIphaseA)
        Me.pnPriDeb.Controls.Add(Me.Label80)
        Me.pnPriDeb.Controls.Add(Me.tbPIacC)
        Me.pnPriDeb.Controls.Add(Me.Label81)
        Me.pnPriDeb.Controls.Add(Me.sPBit24)
        Me.pnPriDeb.Controls.Add(Me.tbPVacC)
        Me.pnPriDeb.Controls.Add(Me.sPBit26)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb5)
        Me.pnPriDeb.Controls.Add(Me.sPBit25)
        Me.pnPriDeb.Controls.Add(Me.Label83)
        Me.pnPriDeb.Controls.Add(Me.sPBit27)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb2)
        Me.pnPriDeb.Controls.Add(Me.Label84)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb4)
        Me.pnPriDeb.Controls.Add(Me.Label85)
        Me.pnPriDeb.Controls.Add(Me.Label86)
        Me.pnPriDeb.Controls.Add(Me.tbPDeb1)
        Me.pnPriDeb.Controls.Add(Me.Label87)
        Me.pnPriDeb.Controls.Add(Me.sPBit34)
        Me.pnPriDeb.Controls.Add(Me.Label88)
        Me.pnPriDeb.Controls.Add(Me.sPBit36)
        Me.pnPriDeb.Controls.Add(Me.tbPTnpcB)
        Me.pnPriDeb.Controls.Add(Me.sPBit35)
        Me.pnPriDeb.Controls.Add(Me.tbPTnpcA)
        Me.pnPriDeb.Controls.Add(Me.Label89)
        Me.pnPriDeb.Controls.Add(Me.tbPIacB)
        Me.pnPriDeb.Controls.Add(Me.Label90)
        Me.pnPriDeb.Controls.Add(Me.sPBit37)
        Me.pnPriDeb.Controls.Add(Me.Label92)
        Me.pnPriDeb.Controls.Add(Me.Label93)
        Me.pnPriDeb.Controls.Add(Me.Label94)
        Me.pnPriDeb.Controls.Add(Me.Label95)
        Me.pnPriDeb.Controls.Add(Me.Label96)
        Me.pnPriDeb.Controls.Add(Me.tbPVacB)
        Me.pnPriDeb.Controls.Add(Me.Label97)
        Me.pnPriDeb.Controls.Add(Me.Label99)
        Me.pnPriDeb.Controls.Add(Me.Label100)
        Me.pnPriDeb.Controls.Add(Me.Label101)
        Me.pnPriDeb.Controls.Add(Me.Label102)
        Me.pnPriDeb.Controls.Add(Me.Label103)
        Me.pnPriDeb.Controls.Add(Me.Label104)
        Me.pnPriDeb.Controls.Add(Me.Label105)
        Me.pnPriDeb.Controls.Add(Me.Label107)
        Me.pnPriDeb.Controls.Add(Me.Label108)
        Me.pnPriDeb.Controls.Add(Me.Label110)
        Me.pnPriDeb.Controls.Add(Me.Label111)
        Me.pnPriDeb.Controls.Add(Me.Label113)
        Me.pnPriDeb.Controls.Add(Me.Label115)
        Me.pnPriDeb.Controls.Add(Me.Label116)
        Me.pnPriDeb.Controls.Add(Me.Label117)
        Me.pnPriDeb.Controls.Add(Me.Label118)
        Me.pnPriDeb.Controls.Add(Me.Label119)
        Me.pnPriDeb.Controls.Add(Me.Label120)
        Me.pnPriDeb.Controls.Add(Me.Label121)
        Me.pnPriDeb.Location = New System.Drawing.Point(6, 132)
        Me.pnPriDeb.Name = "pnPriDeb"
        Me.pnPriDeb.Size = New System.Drawing.Size(413, 343)
        Me.pnPriDeb.TabIndex = 182
        Me.pnPriDeb.Visible = False
        '
        'chPriDebInDec
        '
        Me.chPriDebInDec.AutoSize = True
        Me.chPriDebInDec.Font = New System.Drawing.Font("Times New Roman", 7.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chPriDebInDec.Location = New System.Drawing.Point(282, 237)
        Me.chPriDebInDec.Name = "chPriDebInDec"
        Me.chPriDebInDec.Size = New System.Drawing.Size(15, 14)
        Me.chPriDebInDec.TabIndex = 190
        Me.chPriDebInDec.UseVisualStyleBackColor = True
        '
        'tbPTclllcP2
        '
        Me.tbPTclllcP2.BackColor = System.Drawing.Color.Snow
        Me.tbPTclllcP2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPTclllcP2.Location = New System.Drawing.Point(328, 162)
        Me.tbPTclllcP2.Name = "tbPTclllcP2"
        Me.tbPTclllcP2.ReadOnly = True
        Me.tbPTclllcP2.Size = New System.Drawing.Size(75, 21)
        Me.tbPTclllcP2.TabIndex = 182
        Me.tbPTclllcP2.Text = "-"
        Me.tbPTclllcP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(251, 199)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 40)
        Me.Label8.TabIndex = 132
        Me.Label8.Text = "Debug Data in Decimal"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Snow
        Me.TextBox3.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(328, 124)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(75, 21)
        Me.TextBox3.TabIndex = 182
        Me.TextBox3.Text = "-"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit20
        '
        Me.sPBit20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit20.Location = New System.Drawing.Point(384, 59)
        Me.sPBit20.Name = "sPBit20"
        Me.sPBit20.Size = New System.Drawing.Size(23, 13)
        Me.sPBit20.TabIndex = 0
        '
        'tbPTclllcP1
        '
        Me.tbPTclllcP1.BackColor = System.Drawing.Color.Snow
        Me.tbPTclllcP1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPTclllcP1.Location = New System.Drawing.Point(247, 162)
        Me.tbPTclllcP1.Name = "tbPTclllcP1"
        Me.tbPTclllcP1.ReadOnly = True
        Me.tbPTclllcP1.Size = New System.Drawing.Size(75, 21)
        Me.tbPTclllcP1.TabIndex = 182
        Me.tbPTclllcP1.Text = "-"
        Me.tbPTclllcP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit22
        '
        Me.sPBit22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit22.Location = New System.Drawing.Point(384, 23)
        Me.sPBit22.Name = "sPBit22"
        Me.sPBit22.Size = New System.Drawing.Size(23, 13)
        Me.sPBit22.TabIndex = 0
        '
        'tbPriFwRev
        '
        Me.tbPriFwRev.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPriFwRev.Location = New System.Drawing.Point(5, 276)
        Me.tbPriFwRev.Name = "tbPriFwRev"
        Me.tbPriFwRev.ReadOnly = True
        Me.tbPriFwRev.Size = New System.Drawing.Size(155, 21)
        Me.tbPriFwRev.TabIndex = 182
        Me.tbPriFwRev.Text = "-"
        Me.tbPriFwRev.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbIphaseC
        '
        Me.tbIphaseC.BackColor = System.Drawing.Color.Snow
        Me.tbIphaseC.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIphaseC.Location = New System.Drawing.Point(328, 86)
        Me.tbIphaseC.Name = "tbIphaseC"
        Me.tbIphaseC.ReadOnly = True
        Me.tbIphaseC.Size = New System.Drawing.Size(75, 21)
        Me.tbIphaseC.TabIndex = 182
        Me.tbIphaseC.Text = "-"
        Me.tbIphaseC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit21
        '
        Me.sPBit21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit21.Location = New System.Drawing.Point(384, 40)
        Me.sPBit21.Name = "sPBit21"
        Me.sPBit21.Size = New System.Drawing.Size(23, 13)
        Me.sPBit21.TabIndex = 0
        '
        'tbPVaux
        '
        Me.tbPVaux.BackColor = System.Drawing.Color.Snow
        Me.tbPVaux.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVaux.Location = New System.Drawing.Point(247, 124)
        Me.tbPVaux.Name = "tbPVaux"
        Me.tbPVaux.ReadOnly = True
        Me.tbPVaux.Size = New System.Drawing.Size(75, 21)
        Me.tbPVaux.TabIndex = 182
        Me.tbPVaux.Text = "-"
        Me.tbPVaux.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit23
        '
        Me.sPBit23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit23.Location = New System.Drawing.Point(384, 4)
        Me.sPBit23.Name = "sPBit23"
        Me.sPBit23.Size = New System.Drawing.Size(23, 13)
        Me.sPBit23.TabIndex = 0
        '
        'tbPDeb6
        '
        Me.tbPDeb6.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb6.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb6.Location = New System.Drawing.Point(168, 238)
        Me.tbPDeb6.Name = "tbPDeb6"
        Me.tbPDeb6.ReadOnly = True
        Me.tbPDeb6.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb6.TabIndex = 182
        Me.tbPDeb6.Text = "-"
        Me.tbPDeb6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit30
        '
        Me.sPBit30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit30.Location = New System.Drawing.Point(180, 59)
        Me.sPBit30.Name = "sPBit30"
        Me.sPBit30.Size = New System.Drawing.Size(23, 13)
        Me.sPBit30.TabIndex = 0
        '
        'tbPDeb3
        '
        Me.tbPDeb3.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb3.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb3.Location = New System.Drawing.Point(168, 200)
        Me.tbPDeb3.Name = "tbPDeb3"
        Me.tbPDeb3.ReadOnly = True
        Me.tbPDeb3.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb3.TabIndex = 182
        Me.tbPDeb3.Text = "-"
        Me.tbPDeb3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit32
        '
        Me.sPBit32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit32.Location = New System.Drawing.Point(180, 23)
        Me.sPBit32.Name = "sPBit32"
        Me.sPBit32.Size = New System.Drawing.Size(23, 13)
        Me.sPBit32.TabIndex = 0
        '
        'sPBit31
        '
        Me.sPBit31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit31.Location = New System.Drawing.Point(180, 40)
        Me.sPBit31.Name = "sPBit31"
        Me.sPBit31.Size = New System.Drawing.Size(23, 13)
        Me.sPBit31.TabIndex = 0
        '
        'sPBit33
        '
        Me.sPBit33.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit33.Location = New System.Drawing.Point(180, 4)
        Me.sPBit33.Name = "sPBit33"
        Me.sPBit33.Size = New System.Drawing.Size(23, 13)
        Me.sPBit33.TabIndex = 0
        '
        'tbPTnpcC
        '
        Me.tbPTnpcC.BackColor = System.Drawing.Color.Snow
        Me.tbPTnpcC.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPTnpcC.Location = New System.Drawing.Point(166, 162)
        Me.tbPTnpcC.Name = "tbPTnpcC"
        Me.tbPTnpcC.ReadOnly = True
        Me.tbPTnpcC.Size = New System.Drawing.Size(75, 21)
        Me.tbPTnpcC.TabIndex = 182
        Me.tbPTnpcC.Text = "-"
        Me.tbPTnpcC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label29
        '
        Me.Label29.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label29.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(315, 57)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(63, 17)
        Me.Label29.TabIndex = 175
        Me.Label29.Text = "Freq. Over"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIphaseB
        '
        Me.tbIphaseB.BackColor = System.Drawing.Color.Snow
        Me.tbIphaseB.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIphaseB.Location = New System.Drawing.Point(247, 86)
        Me.tbIphaseB.Name = "tbIphaseB"
        Me.tbIphaseB.ReadOnly = True
        Me.tbIphaseB.Size = New System.Drawing.Size(75, 21)
        Me.tbIphaseB.TabIndex = 182
        Me.tbIphaseB.Text = "-"
        Me.tbIphaseB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label53
        '
        Me.Label53.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label53.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(315, 21)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(63, 17)
        Me.Label53.TabIndex = 175
        Me.Label53.Text = "Phase Loss"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPVbulk
        '
        Me.tbPVbulk.BackColor = System.Drawing.Color.Snow
        Me.tbPVbulk.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVbulk.Location = New System.Drawing.Point(166, 124)
        Me.tbPVbulk.Name = "tbPVbulk"
        Me.tbPVbulk.ReadOnly = True
        Me.tbPVbulk.Size = New System.Drawing.Size(75, 21)
        Me.tbPVbulk.TabIndex = 182
        Me.tbPVbulk.Text = "-"
        Me.tbPVbulk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label79
        '
        Me.Label79.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label79.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(317, 2)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(61, 18)
        Me.Label79.TabIndex = 175
        Me.Label79.Text = "Phase Unbal."
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbIphaseA
        '
        Me.tbIphaseA.BackColor = System.Drawing.Color.Snow
        Me.tbIphaseA.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbIphaseA.Location = New System.Drawing.Point(166, 86)
        Me.tbIphaseA.Name = "tbIphaseA"
        Me.tbIphaseA.ReadOnly = True
        Me.tbIphaseA.Size = New System.Drawing.Size(75, 21)
        Me.tbIphaseA.TabIndex = 182
        Me.tbIphaseA.Text = "-"
        Me.tbIphaseA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label80
        '
        Me.Label80.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label80.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(111, 57)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(63, 17)
        Me.Label80.TabIndex = 175
        Me.Label80.Text = "PFC OVP"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPIacC
        '
        Me.tbPIacC.BackColor = System.Drawing.Color.Snow
        Me.tbPIacC.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPIacC.Location = New System.Drawing.Point(84, 124)
        Me.tbPIacC.Name = "tbPIacC"
        Me.tbPIacC.ReadOnly = True
        Me.tbPIacC.Size = New System.Drawing.Size(75, 21)
        Me.tbPIacC.TabIndex = 182
        Me.tbPIacC.Text = "-"
        Me.tbPIacC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label81
        '
        Me.Label81.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label81.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(111, 21)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(63, 17)
        Me.Label81.TabIndex = 175
        Me.Label81.Text = "PFC OCP"
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit24
        '
        Me.sPBit24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit24.Location = New System.Drawing.Point(288, 59)
        Me.sPBit24.Name = "sPBit24"
        Me.sPBit24.Size = New System.Drawing.Size(23, 13)
        Me.sPBit24.TabIndex = 0
        '
        'tbPVacC
        '
        Me.tbPVacC.BackColor = System.Drawing.Color.Snow
        Me.tbPVacC.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVacC.Location = New System.Drawing.Point(84, 86)
        Me.tbPVacC.Name = "tbPVacC"
        Me.tbPVacC.ReadOnly = True
        Me.tbPVacC.Size = New System.Drawing.Size(75, 21)
        Me.tbPVacC.TabIndex = 182
        Me.tbPVacC.Text = "-"
        Me.tbPVacC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit26
        '
        Me.sPBit26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit26.Location = New System.Drawing.Point(288, 23)
        Me.sPBit26.Name = "sPBit26"
        Me.sPBit26.Size = New System.Drawing.Size(23, 13)
        Me.sPBit26.TabIndex = 0
        '
        'tbPDeb5
        '
        Me.tbPDeb5.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb5.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb5.Location = New System.Drawing.Point(87, 238)
        Me.tbPDeb5.Name = "tbPDeb5"
        Me.tbPDeb5.ReadOnly = True
        Me.tbPDeb5.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb5.TabIndex = 182
        Me.tbPDeb5.Text = "-"
        Me.tbPDeb5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit25
        '
        Me.sPBit25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit25.Location = New System.Drawing.Point(288, 40)
        Me.sPBit25.Name = "sPBit25"
        Me.sPBit25.Size = New System.Drawing.Size(23, 13)
        Me.sPBit25.TabIndex = 0
        '
        'Label83
        '
        Me.Label83.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label83.BackColor = System.Drawing.Color.Transparent
        Me.Label83.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(328, 148)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(78, 22)
        Me.Label83.TabIndex = 183
        Me.Label83.Text = "T CLLLC P2"
        '
        'sPBit27
        '
        Me.sPBit27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit27.Location = New System.Drawing.Point(288, 4)
        Me.sPBit27.Name = "sPBit27"
        Me.sPBit27.Size = New System.Drawing.Size(23, 13)
        Me.sPBit27.TabIndex = 0
        '
        'tbPDeb2
        '
        Me.tbPDeb2.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb2.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb2.Location = New System.Drawing.Point(87, 200)
        Me.tbPDeb2.Name = "tbPDeb2"
        Me.tbPDeb2.ReadOnly = True
        Me.tbPDeb2.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb2.TabIndex = 182
        Me.tbPDeb2.Text = "-"
        Me.tbPDeb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label84
        '
        Me.Label84.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label84.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(219, 57)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(63, 17)
        Me.Label84.TabIndex = 175
        Me.Label84.Text = "I/P OVP"
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPDeb4
        '
        Me.tbPDeb4.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb4.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb4.Location = New System.Drawing.Point(6, 238)
        Me.tbPDeb4.Name = "tbPDeb4"
        Me.tbPDeb4.ReadOnly = True
        Me.tbPDeb4.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb4.TabIndex = 182
        Me.tbPDeb4.Text = "-"
        Me.tbPDeb4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label85
        '
        Me.Label85.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label85.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(215, 21)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(67, 19)
        Me.Label85.TabIndex = 175
        Me.Label85.Text = "-"
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label86
        '
        Me.Label86.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label86.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(210, 40)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(73, 15)
        Me.Label86.TabIndex = 175
        Me.Label86.Text = "I/P UVP"
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPDeb1
        '
        Me.tbPDeb1.BackColor = System.Drawing.Color.Snow
        Me.tbPDeb1.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPDeb1.Location = New System.Drawing.Point(6, 200)
        Me.tbPDeb1.Name = "tbPDeb1"
        Me.tbPDeb1.ReadOnly = True
        Me.tbPDeb1.Size = New System.Drawing.Size(75, 21)
        Me.tbPDeb1.TabIndex = 182
        Me.tbPDeb1.Text = "-"
        Me.tbPDeb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label87
        '
        Me.Label87.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label87.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(219, 2)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(63, 17)
        Me.Label87.TabIndex = 175
        Me.Label87.Text = "TZ Fault"
        Me.Label87.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit34
        '
        Me.sPBit34.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit34.Location = New System.Drawing.Point(73, 59)
        Me.sPBit34.Name = "sPBit34"
        Me.sPBit34.Size = New System.Drawing.Size(23, 13)
        Me.sPBit34.TabIndex = 0
        '
        'Label88
        '
        Me.Label88.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label88.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(4, 57)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(63, 17)
        Me.Label88.TabIndex = 175
        Me.Label88.Text = "NPC OT"
        Me.Label88.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit36
        '
        Me.sPBit36.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit36.Location = New System.Drawing.Point(73, 23)
        Me.sPBit36.Name = "sPBit36"
        Me.sPBit36.Size = New System.Drawing.Size(23, 13)
        Me.sPBit36.TabIndex = 0
        '
        'tbPTnpcB
        '
        Me.tbPTnpcB.BackColor = System.Drawing.Color.Snow
        Me.tbPTnpcB.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPTnpcB.Location = New System.Drawing.Point(86, 162)
        Me.tbPTnpcB.Name = "tbPTnpcB"
        Me.tbPTnpcB.ReadOnly = True
        Me.tbPTnpcB.Size = New System.Drawing.Size(75, 21)
        Me.tbPTnpcB.TabIndex = 182
        Me.tbPTnpcB.Text = "-"
        Me.tbPTnpcB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sPBit35
        '
        Me.sPBit35.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit35.Location = New System.Drawing.Point(73, 40)
        Me.sPBit35.Name = "sPBit35"
        Me.sPBit35.Size = New System.Drawing.Size(23, 13)
        Me.sPBit35.TabIndex = 0
        '
        'tbPTnpcA
        '
        Me.tbPTnpcA.BackColor = System.Drawing.Color.Snow
        Me.tbPTnpcA.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPTnpcA.Location = New System.Drawing.Point(6, 162)
        Me.tbPTnpcA.Name = "tbPTnpcA"
        Me.tbPTnpcA.ReadOnly = True
        Me.tbPTnpcA.Size = New System.Drawing.Size(75, 21)
        Me.tbPTnpcA.TabIndex = 182
        Me.tbPTnpcA.Text = "-"
        Me.tbPTnpcA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label89
        '
        Me.Label89.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label89.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(8, 21)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(59, 19)
        Me.Label89.TabIndex = 175
        Me.Label89.Text = "Aux OV"
        Me.Label89.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPIacB
        '
        Me.tbPIacB.BackColor = System.Drawing.Color.Snow
        Me.tbPIacB.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPIacB.Location = New System.Drawing.Point(6, 124)
        Me.tbPIacB.Name = "tbPIacB"
        Me.tbPIacB.ReadOnly = True
        Me.tbPIacB.Size = New System.Drawing.Size(75, 21)
        Me.tbPIacB.TabIndex = 182
        Me.tbPIacB.Text = "-"
        Me.tbPIacB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label90
        '
        Me.Label90.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label90.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(4, 40)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(64, 15)
        Me.Label90.TabIndex = 175
        Me.Label90.Text = "CLLLC OT"
        Me.Label90.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit37
        '
        Me.sPBit37.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit37.Location = New System.Drawing.Point(73, 4)
        Me.sPBit37.Name = "sPBit37"
        Me.sPBit37.Size = New System.Drawing.Size(23, 13)
        Me.sPBit37.TabIndex = 0
        '
        'Label92
        '
        Me.Label92.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label92.BackColor = System.Drawing.Color.Transparent
        Me.Label92.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(163, 224)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(91, 22)
        Me.Label92.TabIndex = 183
        Me.Label92.Text = "Debug 5"
        '
        'Label93
        '
        Me.Label93.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label93.BackColor = System.Drawing.Color.Transparent
        Me.Label93.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(328, 110)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(73, 22)
        Me.Label93.TabIndex = 183
        Me.Label93.Text = "-"
        '
        'Label94
        '
        Me.Label94.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label94.BackColor = System.Drawing.Color.Transparent
        Me.Label94.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(163, 186)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(91, 22)
        Me.Label94.TabIndex = 183
        Me.Label94.Text = "Debug 2"
        '
        'Label95
        '
        Me.Label95.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label95.BackColor = System.Drawing.Color.Transparent
        Me.Label95.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(243, 148)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(84, 22)
        Me.Label95.TabIndex = 183
        Me.Label95.Text = "T CLLLC P1"
        '
        'Label96
        '
        Me.Label96.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label96.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(0, 2)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(69, 19)
        Me.Label96.TabIndex = 175
        Me.Label96.Text = "Aux UV"
        Me.Label96.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPVacB
        '
        Me.tbPVacB.BackColor = System.Drawing.Color.Snow
        Me.tbPVacB.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVacB.Location = New System.Drawing.Point(6, 86)
        Me.tbPVacB.Name = "tbPVacB"
        Me.tbPVacB.ReadOnly = True
        Me.tbPVacB.Size = New System.Drawing.Size(75, 21)
        Me.tbPVacB.TabIndex = 182
        Me.tbPVacB.Text = "-"
        Me.tbPVacB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label97
        '
        Me.Label97.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label97.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(91, 2)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(83, 19)
        Me.Label97.TabIndex = 175
        Me.Label97.Text = "PFC Unbal."
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label99
        '
        Me.Label99.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label99.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(297, 40)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(82, 17)
        Me.Label99.TabIndex = 175
        Me.Label99.Text = "Freq. Under"
        Me.Label99.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label100
        '
        Me.Label100.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label100.BackColor = System.Drawing.Color.Transparent
        Me.Label100.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(245, 110)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(73, 22)
        Me.Label100.TabIndex = 183
        Me.Label100.Text = "V Aux"
        '
        'Label101
        '
        Me.Label101.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label101.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(95, 40)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(80, 19)
        Me.Label101.TabIndex = 175
        Me.Label101.Text = "PFC UVP"
        Me.Label101.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label102
        '
        Me.Label102.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label102.BackColor = System.Drawing.Color.Transparent
        Me.Label102.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(87, 224)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(82, 22)
        Me.Label102.TabIndex = 183
        Me.Label102.Text = "Debug 4"
        '
        'Label103
        '
        Me.Label103.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label103.BackColor = System.Drawing.Color.Transparent
        Me.Label103.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(163, 148)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(84, 22)
        Me.Label103.TabIndex = 183
        Me.Label103.Text = "T NPC C"
        '
        'Label104
        '
        Me.Label104.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label104.BackColor = System.Drawing.Color.Transparent
        Me.Label104.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(87, 186)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(82, 22)
        Me.Label104.TabIndex = 183
        Me.Label104.Text = "Debug 1"
        '
        'Label105
        '
        Me.Label105.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label105.BackColor = System.Drawing.Color.Transparent
        Me.Label105.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(328, 72)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(73, 22)
        Me.Label105.TabIndex = 183
        Me.Label105.Text = "IPhase C"
        '
        'Label107
        '
        Me.Label107.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label107.BackColor = System.Drawing.Color.Transparent
        Me.Label107.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(166, 110)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(73, 22)
        Me.Label107.TabIndex = 183
        Me.Label107.Text = "VBulk"
        Me.Label107.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label108
        '
        Me.Label108.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label108.BackColor = System.Drawing.Color.Transparent
        Me.Label108.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(6, 224)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(73, 22)
        Me.Label108.TabIndex = 183
        Me.Label108.Text = "Debug 3"
        '
        'Label110
        '
        Me.Label110.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label110.BackColor = System.Drawing.Color.Transparent
        Me.Label110.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(6, 186)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(73, 22)
        Me.Label110.TabIndex = 183
        Me.Label110.Text = "Debug 0"
        '
        'Label111
        '
        Me.Label111.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label111.BackColor = System.Drawing.Color.Transparent
        Me.Label111.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.Location = New System.Drawing.Point(245, 72)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(73, 22)
        Me.Label111.TabIndex = 183
        Me.Label111.Text = "IPhase B"
        '
        'Label113
        '
        Me.Label113.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label113.BackColor = System.Drawing.Color.Transparent
        Me.Label113.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.Location = New System.Drawing.Point(86, 148)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(73, 22)
        Me.Label113.TabIndex = 183
        Me.Label113.Text = "T NPC B"
        '
        'Label115
        '
        Me.Label115.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label115.BackColor = System.Drawing.Color.Transparent
        Me.Label115.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.Location = New System.Drawing.Point(84, 110)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(73, 22)
        Me.Label115.TabIndex = 183
        Me.Label115.Text = "Iac C"
        '
        'Label116
        '
        Me.Label116.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label116.BackColor = System.Drawing.Color.Transparent
        Me.Label116.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(6, 148)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(73, 22)
        Me.Label116.TabIndex = 183
        Me.Label116.Text = "T NPC A"
        '
        'Label117
        '
        Me.Label117.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label117.BackColor = System.Drawing.Color.Transparent
        Me.Label117.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.Location = New System.Drawing.Point(166, 72)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(73, 22)
        Me.Label117.TabIndex = 183
        Me.Label117.Text = "IPhase A"
        '
        'Label118
        '
        Me.Label118.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label118.BackColor = System.Drawing.Color.Transparent
        Me.Label118.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.Location = New System.Drawing.Point(6, 110)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(73, 22)
        Me.Label118.TabIndex = 183
        Me.Label118.Text = "Iac B"
        '
        'Label119
        '
        Me.Label119.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label119.BackColor = System.Drawing.Color.Transparent
        Me.Label119.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label119.Location = New System.Drawing.Point(84, 72)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(73, 22)
        Me.Label119.TabIndex = 183
        Me.Label119.Text = "Vac C"
        '
        'Label120
        '
        Me.Label120.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label120.BackColor = System.Drawing.Color.Transparent
        Me.Label120.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label120.Location = New System.Drawing.Point(6, 72)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(73, 22)
        Me.Label120.TabIndex = 183
        Me.Label120.Text = "Vac B"
        '
        'Label121
        '
        Me.Label121.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label121.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.Location = New System.Drawing.Point(5, 262)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(82, 22)
        Me.Label121.TabIndex = 183
        Me.Label121.Text = "Firmware Rev:"
        '
        'Label138
        '
        Me.Label138.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label138.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Italic Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label138.Location = New System.Drawing.Point(328, 25)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(54, 23)
        Me.Label138.TabIndex = 175
        Me.Label138.Text = "State:"
        Me.Label138.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbPVbulkMid
        '
        Me.tbPVbulkMid.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVbulkMid.Location = New System.Drawing.Point(327, 98)
        Me.tbPVbulkMid.Name = "tbPVbulkMid"
        Me.tbPVbulkMid.ReadOnly = True
        Me.tbPVbulkMid.Size = New System.Drawing.Size(92, 23)
        Me.tbPVbulkMid.TabIndex = 180
        Me.tbPVbulkMid.Text = "-"
        Me.tbPVbulkMid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label122
        '
        Me.Label122.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label122.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label122.Location = New System.Drawing.Point(280, 92)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(46, 40)
        Me.Label122.TabIndex = 175
        Me.Label122.Text = "VBulk Mid:"
        Me.Label122.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label137
        '
        Me.Label137.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label137.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.Location = New System.Drawing.Point(-8, 20)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(78, 15)
        Me.Label137.TabIndex = 175
        Me.Label137.Text = "CAN Tout"
        Me.Label137.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label124
        '
        Me.Label124.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label124.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label124.Location = New System.Drawing.Point(113, 75)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(63, 17)
        Me.Label124.TabIndex = 175
        Me.Label124.Text = "+ve Seq"
        Me.Label124.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label136
        '
        Me.Label136.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label136.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.Location = New System.Drawing.Point(-10, 37)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(80, 19)
        Me.Label136.TabIndex = 175
        Me.Label136.Text = "OT Fault"
        Me.Label136.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit11
        '
        Me.sPBit11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit11.Location = New System.Drawing.Point(182, 58)
        Me.sPBit11.Name = "sPBit11"
        Me.sPBit11.Size = New System.Drawing.Size(23, 13)
        Me.sPBit11.TabIndex = 0
        '
        'sPBit17
        '
        Me.sPBit17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit17.Location = New System.Drawing.Point(75, 20)
        Me.sPBit17.Name = "sPBit17"
        Me.sPBit17.Size = New System.Drawing.Size(23, 13)
        Me.sPBit17.TabIndex = 0
        '
        'Label125
        '
        Me.Label125.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label125.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(141, 92)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(56, 32)
        Me.Label125.TabIndex = 175
        Me.Label125.Text = "Iac A:"
        Me.Label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label135
        '
        Me.Label135.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label135.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(-8, 76)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(82, 17)
        Me.Label135.TabIndex = 175
        Me.Label135.Text = "CLLLC OK"
        Me.Label135.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label126
        '
        Me.Label126.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label126.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.Location = New System.Drawing.Point(229, 37)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(55, 19)
        Me.Label126.TabIndex = 175
        Me.Label126.Text = "Inverter EN"
        Me.Label126.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label128
        '
        Me.Label128.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label128.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.Location = New System.Drawing.Point(130, 56)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(50, 19)
        Me.Label128.TabIndex = 175
        Me.Label128.Text = "Relay ON"
        Me.Label128.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbPVacA
        '
        Me.tbPVacA.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbPVacA.Location = New System.Drawing.Point(58, 98)
        Me.tbPVacA.Name = "tbPVacA"
        Me.tbPVacA.ReadOnly = True
        Me.tbPVacA.Size = New System.Drawing.Size(83, 23)
        Me.tbPVacA.TabIndex = 179
        Me.tbPVacA.Text = "-"
        Me.tbPVacA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label129
        '
        Me.Label129.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label129.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label129.Location = New System.Drawing.Point(113, 37)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(63, 17)
        Me.Label129.TabIndex = 175
        Me.Label129.Text = "AC OK"
        Me.Label129.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit16
        '
        Me.sPBit16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit16.Location = New System.Drawing.Point(75, 37)
        Me.sPBit16.Name = "sPBit16"
        Me.sPBit16.Size = New System.Drawing.Size(23, 13)
        Me.sPBit16.TabIndex = 0
        '
        'Label130
        '
        Me.Label130.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label130.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.Location = New System.Drawing.Point(213, 18)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(71, 19)
        Me.Label130.TabIndex = 175
        Me.Label130.Text = "CAN ON Cmd"
        Me.Label130.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit10
        '
        Me.sPBit10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit10.Location = New System.Drawing.Point(182, 77)
        Me.sPBit10.Name = "sPBit10"
        Me.sPBit10.Size = New System.Drawing.Size(23, 13)
        Me.sPBit10.TabIndex = 0
        '
        'sPBit07
        '
        Me.sPBit07.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit07.Location = New System.Drawing.Point(290, 20)
        Me.sPBit07.Name = "sPBit07"
        Me.sPBit07.Size = New System.Drawing.Size(23, 13)
        Me.sPBit07.TabIndex = 0
        '
        'Label134
        '
        Me.Label134.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label134.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(-3, 58)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(73, 15)
        Me.Label134.TabIndex = 175
        Me.Label134.Text = "NPC Fault"
        Me.Label134.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label131
        '
        Me.Label131.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label131.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.Location = New System.Drawing.Point(211, 56)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(73, 17)
        Me.Label131.TabIndex = 175
        Me.Label131.Text = "Rectifier EN"
        Me.Label131.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit14
        '
        Me.sPBit14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit14.Location = New System.Drawing.Point(75, 77)
        Me.sPBit14.Name = "sPBit14"
        Me.sPBit14.Size = New System.Drawing.Size(23, 13)
        Me.sPBit14.TabIndex = 0
        '
        'sPBit05
        '
        Me.sPBit05.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit05.Location = New System.Drawing.Point(290, 58)
        Me.sPBit05.Name = "sPBit05"
        Me.sPBit05.Size = New System.Drawing.Size(23, 13)
        Me.sPBit05.TabIndex = 0
        '
        'sPBit15
        '
        Me.sPBit15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit15.Location = New System.Drawing.Point(75, 58)
        Me.sPBit15.Name = "sPBit15"
        Me.sPBit15.Size = New System.Drawing.Size(23, 13)
        Me.sPBit15.TabIndex = 0
        '
        'sPBit12
        '
        Me.sPBit12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit12.Location = New System.Drawing.Point(182, 39)
        Me.sPBit12.Name = "sPBit12"
        Me.sPBit12.Size = New System.Drawing.Size(23, 13)
        Me.sPBit12.TabIndex = 0
        '
        'sPBit04
        '
        Me.sPBit04.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit04.Location = New System.Drawing.Point(290, 77)
        Me.sPBit04.Name = "sPBit04"
        Me.sPBit04.Size = New System.Drawing.Size(23, 13)
        Me.sPBit04.TabIndex = 0
        '
        'sPBit13
        '
        Me.sPBit13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit13.Location = New System.Drawing.Point(182, 20)
        Me.sPBit13.Name = "sPBit13"
        Me.sPBit13.Size = New System.Drawing.Size(23, 13)
        Me.sPBit13.TabIndex = 0
        '
        'Label133
        '
        Me.Label133.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label133.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label133.Location = New System.Drawing.Point(101, 18)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(75, 15)
        Me.Label133.TabIndex = 175
        Me.Label133.Text = "PFC OK"
        Me.Label133.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label132
        '
        Me.Label132.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label132.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.Location = New System.Drawing.Point(221, 75)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(63, 17)
        Me.Label132.TabIndex = 175
        Me.Label132.Text = "PFC En"
        Me.Label132.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sPBit06
        '
        Me.sPBit06.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sPBit06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sPBit06.Location = New System.Drawing.Point(290, 39)
        Me.sPBit06.Name = "sPBit06"
        Me.sPBit06.Size = New System.Drawing.Size(23, 13)
        Me.sPBit06.TabIndex = 0
        '
        'Label123
        '
        Me.Label123.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label123.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label123.Location = New System.Drawing.Point(7, 96)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(65, 27)
        Me.Label123.TabIndex = 175
        Me.Label123.Text = "Vac A:"
        Me.Label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'gbAPMinfo
        '
        Me.gbAPMinfo.Controls.Add(Me.Panel9)
        Me.gbAPMinfo.Controls.Add(Me.Panel7)
        Me.gbAPMinfo.Controls.Add(Me.Panel6)
        Me.gbAPMinfo.Controls.Add(Me.Panel8)
        Me.gbAPMinfo.Controls.Add(Me.Panel5)
        Me.gbAPMinfo.Controls.Add(Me.Panel4)
        Me.gbAPMinfo.Controls.Add(Me.Panel2)
        Me.gbAPMinfo.Controls.Add(Me.Panel3)
        Me.gbAPMinfo.Enabled = False
        Me.gbAPMinfo.Font = New System.Drawing.Font("Times New Roman", 10.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.gbAPMinfo.Location = New System.Drawing.Point(4, 0)
        Me.gbAPMinfo.Name = "gbAPMinfo"
        Me.gbAPMinfo.Size = New System.Drawing.Size(320, 495)
        Me.gbAPMinfo.TabIndex = 153
        Me.gbAPMinfo.TabStop = False
        Me.gbAPMinfo.Text = "APM"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.SystemColors.Control
        Me.Panel9.Controls.Add(Me.sABit50)
        Me.Panel9.Controls.Add(Me.sABit40)
        Me.Panel9.Controls.Add(Me.sABit20)
        Me.Panel9.Controls.Add(Me.sABit30)
        Me.Panel9.Controls.Add(Me.sABit10)
        Me.Panel9.Controls.Add(Me.sABit54)
        Me.Panel9.Controls.Add(Me.sABit44)
        Me.Panel9.Controls.Add(Me.sABit24)
        Me.Panel9.Controls.Add(Me.sABit34)
        Me.Panel9.Controls.Add(Me.sABit14)
        Me.Panel9.Controls.Add(Me.sABit04)
        Me.Panel9.Controls.Add(Me.sABit52)
        Me.Panel9.Controls.Add(Me.sABit42)
        Me.Panel9.Controls.Add(Me.sABit22)
        Me.Panel9.Controls.Add(Me.sABit32)
        Me.Panel9.Controls.Add(Me.sABit12)
        Me.Panel9.Controls.Add(Me.sABit56)
        Me.Panel9.Controls.Add(Me.sABit46)
        Me.Panel9.Controls.Add(Me.sABit26)
        Me.Panel9.Controls.Add(Me.sABit36)
        Me.Panel9.Controls.Add(Me.sABit16)
        Me.Panel9.Controls.Add(Me.sABit06)
        Me.Panel9.Controls.Add(Me.sABit51)
        Me.Panel9.Controls.Add(Me.sABit41)
        Me.Panel9.Controls.Add(Me.sABit21)
        Me.Panel9.Controls.Add(Me.sABit31)
        Me.Panel9.Controls.Add(Me.sABit11)
        Me.Panel9.Controls.Add(Me.sABit55)
        Me.Panel9.Controls.Add(Me.sABit45)
        Me.Panel9.Controls.Add(Me.sABit25)
        Me.Panel9.Controls.Add(Me.sABit35)
        Me.Panel9.Controls.Add(Me.sABit15)
        Me.Panel9.Controls.Add(Me.sABit05)
        Me.Panel9.Controls.Add(Me.sABit53)
        Me.Panel9.Controls.Add(Me.sABit43)
        Me.Panel9.Controls.Add(Me.sABit23)
        Me.Panel9.Controls.Add(Me.sABit33)
        Me.Panel9.Controls.Add(Me.sABit13)
        Me.Panel9.Controls.Add(Me.sABit57)
        Me.Panel9.Controls.Add(Me.sABit47)
        Me.Panel9.Controls.Add(Me.sABit27)
        Me.Panel9.Controls.Add(Me.sABit37)
        Me.Panel9.Controls.Add(Me.sABit17)
        Me.Panel9.Controls.Add(Me.Label208)
        Me.Panel9.Controls.Add(Me.Label180)
        Me.Panel9.Controls.Add(Me.sABit07)
        Me.Panel9.Controls.Add(Me.Label179)
        Me.Panel9.Controls.Add(Me.Label196)
        Me.Panel9.Controls.Add(Me.Label178)
        Me.Panel9.Controls.Add(Me.Label188)
        Me.Panel9.Controls.Add(Me.Label177)
        Me.Panel9.Controls.Add(Me.Label195)
        Me.Panel9.Controls.Add(Me.Label206)
        Me.Panel9.Controls.Add(Me.Label204)
        Me.Panel9.Controls.Add(Me.Label194)
        Me.Panel9.Controls.Add(Me.Label200)
        Me.Panel9.Controls.Add(Me.Label205)
        Me.Panel9.Controls.Add(Me.Label174)
        Me.Panel9.Controls.Add(Me.Label187)
        Me.Panel9.Controls.Add(Me.Label173)
        Me.Panel9.Controls.Add(Me.Label193)
        Me.Panel9.Controls.Add(Me.Label184)
        Me.Panel9.Controls.Add(Me.Label176)
        Me.Panel9.Controls.Add(Me.Label202)
        Me.Panel9.Controls.Add(Me.Label203)
        Me.Panel9.Controls.Add(Me.Label172)
        Me.Panel9.Controls.Add(Me.Label192)
        Me.Panel9.Controls.Add(Me.Label162)
        Me.Panel9.Controls.Add(Me.Label175)
        Me.Panel9.Controls.Add(Me.Label171)
        Me.Panel9.Controls.Add(Me.Label199)
        Me.Panel9.Controls.Add(Me.Label183)
        Me.Panel9.Controls.Add(Me.Label186)
        Me.Panel9.Controls.Add(Me.Label164)
        Me.Panel9.Controls.Add(Me.Label165)
        Me.Panel9.Controls.Add(Me.Label191)
        Me.Panel9.Controls.Add(Me.Label207)
        Me.Panel9.Controls.Add(Me.Label182)
        Me.Panel9.Controls.Add(Me.Label161)
        Me.Panel9.Controls.Add(Me.Label163)
        Me.Panel9.Controls.Add(Me.Label190)
        Me.Panel9.Controls.Add(Me.Label198)
        Me.Panel9.Controls.Add(Me.Label181)
        Me.Panel9.Controls.Add(Me.Label160)
        Me.Panel9.Controls.Add(Me.Label201)
        Me.Panel9.Controls.Add(Me.Label185)
        Me.Panel9.Controls.Add(Me.Label189)
        Me.Panel9.Controls.Add(Me.Label197)
        Me.Panel9.Location = New System.Drawing.Point(0, 19)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(320, 226)
        Me.Panel9.TabIndex = 187
        '
        'sABit50
        '
        Me.sABit50.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit50.Location = New System.Drawing.Point(293, 208)
        Me.sABit50.Name = "sABit50"
        Me.sABit50.Size = New System.Drawing.Size(23, 13)
        Me.sABit50.TabIndex = 0
        '
        'sABit40
        '
        Me.sABit40.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit40.Location = New System.Drawing.Point(293, 168)
        Me.sABit40.Name = "sABit40"
        Me.sABit40.Size = New System.Drawing.Size(23, 13)
        Me.sABit40.TabIndex = 0
        '
        'sABit20
        '
        Me.sABit20.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit20.Location = New System.Drawing.Point(293, 87)
        Me.sABit20.Name = "sABit20"
        Me.sABit20.Size = New System.Drawing.Size(23, 13)
        Me.sABit20.TabIndex = 0
        '
        'sABit30
        '
        Me.sABit30.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit30.Location = New System.Drawing.Point(293, 127)
        Me.sABit30.Name = "sABit30"
        Me.sABit30.Size = New System.Drawing.Size(23, 13)
        Me.sABit30.TabIndex = 0
        '
        'sABit10
        '
        Me.sABit10.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit10.Location = New System.Drawing.Point(293, 47)
        Me.sABit10.Name = "sABit10"
        Me.sABit10.Size = New System.Drawing.Size(23, 13)
        Me.sABit10.TabIndex = 0
        '
        'sABit54
        '
        Me.sABit54.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit54.Location = New System.Drawing.Point(293, 192)
        Me.sABit54.Name = "sABit54"
        Me.sABit54.Size = New System.Drawing.Size(23, 13)
        Me.sABit54.TabIndex = 0
        '
        'sABit44
        '
        Me.sABit44.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit44.Location = New System.Drawing.Point(293, 152)
        Me.sABit44.Name = "sABit44"
        Me.sABit44.Size = New System.Drawing.Size(23, 13)
        Me.sABit44.TabIndex = 0
        '
        'sABit24
        '
        Me.sABit24.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit24.Location = New System.Drawing.Point(293, 71)
        Me.sABit24.Name = "sABit24"
        Me.sABit24.Size = New System.Drawing.Size(23, 13)
        Me.sABit24.TabIndex = 0
        '
        'sABit34
        '
        Me.sABit34.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit34.Location = New System.Drawing.Point(293, 111)
        Me.sABit34.Name = "sABit34"
        Me.sABit34.Size = New System.Drawing.Size(23, 13)
        Me.sABit34.TabIndex = 0
        '
        'sABit14
        '
        Me.sABit14.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit14.Location = New System.Drawing.Point(293, 31)
        Me.sABit14.Name = "sABit14"
        Me.sABit14.Size = New System.Drawing.Size(23, 13)
        Me.sABit14.TabIndex = 0
        '
        'sABit04
        '
        Me.sABit04.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit04.Location = New System.Drawing.Point(293, 7)
        Me.sABit04.Name = "sABit04"
        Me.sABit04.Size = New System.Drawing.Size(23, 13)
        Me.sABit04.TabIndex = 0
        '
        'sABit52
        '
        Me.sABit52.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit52.Location = New System.Drawing.Point(141, 208)
        Me.sABit52.Name = "sABit52"
        Me.sABit52.Size = New System.Drawing.Size(23, 13)
        Me.sABit52.TabIndex = 0
        '
        'sABit42
        '
        Me.sABit42.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit42.Location = New System.Drawing.Point(141, 168)
        Me.sABit42.Name = "sABit42"
        Me.sABit42.Size = New System.Drawing.Size(23, 13)
        Me.sABit42.TabIndex = 0
        '
        'sABit22
        '
        Me.sABit22.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit22.Location = New System.Drawing.Point(141, 87)
        Me.sABit22.Name = "sABit22"
        Me.sABit22.Size = New System.Drawing.Size(23, 13)
        Me.sABit22.TabIndex = 0
        '
        'sABit32
        '
        Me.sABit32.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit32.Location = New System.Drawing.Point(141, 127)
        Me.sABit32.Name = "sABit32"
        Me.sABit32.Size = New System.Drawing.Size(23, 13)
        Me.sABit32.TabIndex = 0
        '
        'sABit12
        '
        Me.sABit12.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit12.Location = New System.Drawing.Point(141, 47)
        Me.sABit12.Name = "sABit12"
        Me.sABit12.Size = New System.Drawing.Size(23, 13)
        Me.sABit12.TabIndex = 0
        '
        'sABit56
        '
        Me.sABit56.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit56.Location = New System.Drawing.Point(141, 192)
        Me.sABit56.Name = "sABit56"
        Me.sABit56.Size = New System.Drawing.Size(23, 13)
        Me.sABit56.TabIndex = 0
        '
        'sABit46
        '
        Me.sABit46.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit46.Location = New System.Drawing.Point(141, 152)
        Me.sABit46.Name = "sABit46"
        Me.sABit46.Size = New System.Drawing.Size(23, 13)
        Me.sABit46.TabIndex = 0
        '
        'sABit26
        '
        Me.sABit26.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit26.Location = New System.Drawing.Point(141, 71)
        Me.sABit26.Name = "sABit26"
        Me.sABit26.Size = New System.Drawing.Size(23, 13)
        Me.sABit26.TabIndex = 0
        '
        'sABit36
        '
        Me.sABit36.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit36.Location = New System.Drawing.Point(141, 111)
        Me.sABit36.Name = "sABit36"
        Me.sABit36.Size = New System.Drawing.Size(23, 13)
        Me.sABit36.TabIndex = 0
        '
        'sABit16
        '
        Me.sABit16.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit16.Location = New System.Drawing.Point(141, 31)
        Me.sABit16.Name = "sABit16"
        Me.sABit16.Size = New System.Drawing.Size(23, 13)
        Me.sABit16.TabIndex = 0
        '
        'sABit06
        '
        Me.sABit06.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit06.Location = New System.Drawing.Point(141, 7)
        Me.sABit06.Name = "sABit06"
        Me.sABit06.Size = New System.Drawing.Size(23, 13)
        Me.sABit06.TabIndex = 0
        '
        'sABit51
        '
        Me.sABit51.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit51.Location = New System.Drawing.Point(216, 208)
        Me.sABit51.Name = "sABit51"
        Me.sABit51.Size = New System.Drawing.Size(23, 13)
        Me.sABit51.TabIndex = 0
        '
        'sABit41
        '
        Me.sABit41.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit41.Location = New System.Drawing.Point(216, 168)
        Me.sABit41.Name = "sABit41"
        Me.sABit41.Size = New System.Drawing.Size(23, 13)
        Me.sABit41.TabIndex = 0
        '
        'sABit21
        '
        Me.sABit21.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit21.Location = New System.Drawing.Point(216, 87)
        Me.sABit21.Name = "sABit21"
        Me.sABit21.Size = New System.Drawing.Size(23, 13)
        Me.sABit21.TabIndex = 0
        '
        'sABit31
        '
        Me.sABit31.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit31.Location = New System.Drawing.Point(216, 127)
        Me.sABit31.Name = "sABit31"
        Me.sABit31.Size = New System.Drawing.Size(23, 13)
        Me.sABit31.TabIndex = 0
        '
        'sABit11
        '
        Me.sABit11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit11.Location = New System.Drawing.Point(216, 47)
        Me.sABit11.Name = "sABit11"
        Me.sABit11.Size = New System.Drawing.Size(23, 13)
        Me.sABit11.TabIndex = 0
        '
        'sABit55
        '
        Me.sABit55.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit55.Location = New System.Drawing.Point(216, 192)
        Me.sABit55.Name = "sABit55"
        Me.sABit55.Size = New System.Drawing.Size(23, 13)
        Me.sABit55.TabIndex = 0
        '
        'sABit45
        '
        Me.sABit45.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit45.Location = New System.Drawing.Point(216, 152)
        Me.sABit45.Name = "sABit45"
        Me.sABit45.Size = New System.Drawing.Size(23, 13)
        Me.sABit45.TabIndex = 0
        '
        'sABit25
        '
        Me.sABit25.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit25.Location = New System.Drawing.Point(216, 71)
        Me.sABit25.Name = "sABit25"
        Me.sABit25.Size = New System.Drawing.Size(23, 13)
        Me.sABit25.TabIndex = 0
        '
        'sABit35
        '
        Me.sABit35.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit35.Location = New System.Drawing.Point(216, 111)
        Me.sABit35.Name = "sABit35"
        Me.sABit35.Size = New System.Drawing.Size(23, 13)
        Me.sABit35.TabIndex = 0
        '
        'sABit15
        '
        Me.sABit15.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit15.Location = New System.Drawing.Point(216, 31)
        Me.sABit15.Name = "sABit15"
        Me.sABit15.Size = New System.Drawing.Size(23, 13)
        Me.sABit15.TabIndex = 0
        '
        'sABit05
        '
        Me.sABit05.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit05.Location = New System.Drawing.Point(216, 7)
        Me.sABit05.Name = "sABit05"
        Me.sABit05.Size = New System.Drawing.Size(23, 13)
        Me.sABit05.TabIndex = 0
        '
        'sABit53
        '
        Me.sABit53.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit53.Location = New System.Drawing.Point(61, 208)
        Me.sABit53.Name = "sABit53"
        Me.sABit53.Size = New System.Drawing.Size(23, 13)
        Me.sABit53.TabIndex = 0
        '
        'sABit43
        '
        Me.sABit43.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit43.Location = New System.Drawing.Point(61, 168)
        Me.sABit43.Name = "sABit43"
        Me.sABit43.Size = New System.Drawing.Size(23, 13)
        Me.sABit43.TabIndex = 0
        '
        'sABit23
        '
        Me.sABit23.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit23.Location = New System.Drawing.Point(61, 87)
        Me.sABit23.Name = "sABit23"
        Me.sABit23.Size = New System.Drawing.Size(23, 13)
        Me.sABit23.TabIndex = 0
        '
        'sABit33
        '
        Me.sABit33.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit33.Location = New System.Drawing.Point(61, 127)
        Me.sABit33.Name = "sABit33"
        Me.sABit33.Size = New System.Drawing.Size(23, 13)
        Me.sABit33.TabIndex = 0
        '
        'sABit13
        '
        Me.sABit13.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit13.Location = New System.Drawing.Point(61, 47)
        Me.sABit13.Name = "sABit13"
        Me.sABit13.Size = New System.Drawing.Size(23, 13)
        Me.sABit13.TabIndex = 0
        '
        'sABit57
        '
        Me.sABit57.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit57.Location = New System.Drawing.Point(61, 192)
        Me.sABit57.Name = "sABit57"
        Me.sABit57.Size = New System.Drawing.Size(23, 13)
        Me.sABit57.TabIndex = 0
        '
        'sABit47
        '
        Me.sABit47.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit47.Location = New System.Drawing.Point(61, 152)
        Me.sABit47.Name = "sABit47"
        Me.sABit47.Size = New System.Drawing.Size(23, 13)
        Me.sABit47.TabIndex = 0
        '
        'sABit27
        '
        Me.sABit27.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit27.Location = New System.Drawing.Point(61, 71)
        Me.sABit27.Name = "sABit27"
        Me.sABit27.Size = New System.Drawing.Size(23, 13)
        Me.sABit27.TabIndex = 0
        '
        'sABit37
        '
        Me.sABit37.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit37.Location = New System.Drawing.Point(61, 111)
        Me.sABit37.Name = "sABit37"
        Me.sABit37.Size = New System.Drawing.Size(23, 13)
        Me.sABit37.TabIndex = 0
        '
        'sABit17
        '
        Me.sABit17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit17.Location = New System.Drawing.Point(61, 31)
        Me.sABit17.Name = "sABit17"
        Me.sABit17.Size = New System.Drawing.Size(23, 13)
        Me.sABit17.TabIndex = 0
        '
        'Label208
        '
        Me.Label208.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label208.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label208.Location = New System.Drawing.Point(15, 190)
        Me.Label208.Name = "Label208"
        Me.Label208.Size = New System.Drawing.Size(44, 19)
        Me.Label208.TabIndex = 175
        Me.Label208.Text = "-"
        Me.Label208.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label180
        '
        Me.Label180.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label180.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label180.Location = New System.Drawing.Point(15, 149)
        Me.Label180.Name = "Label180"
        Me.Label180.Size = New System.Drawing.Size(44, 19)
        Me.Label180.TabIndex = 175
        Me.Label180.Text = "BST UV"
        Me.Label180.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'sABit07
        '
        Me.sABit07.BackColor = System.Drawing.SystemColors.ControlLight
        Me.sABit07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sABit07.Location = New System.Drawing.Point(61, 7)
        Me.sABit07.Name = "sABit07"
        Me.sABit07.Size = New System.Drawing.Size(23, 13)
        Me.sABit07.TabIndex = 0
        '
        'Label179
        '
        Me.Label179.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label179.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label179.Location = New System.Drawing.Point(236, 125)
        Me.Label179.Name = "Label179"
        Me.Label179.Size = New System.Drawing.Size(58, 19)
        Me.Label179.TabIndex = 175
        Me.Label179.Text = "LV OC SW"
        Me.Label179.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label196
        '
        Me.Label196.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label196.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label196.Location = New System.Drawing.Point(248, 84)
        Me.Label196.Name = "Label196"
        Me.Label196.Size = New System.Drawing.Size(44, 19)
        Me.Label196.TabIndex = 175
        Me.Label196.Text = "BAT OV"
        Me.Label196.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label178
        '
        Me.Label178.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label178.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label178.Location = New System.Drawing.Point(16, 165)
        Me.Label178.Name = "Label178"
        Me.Label178.Size = New System.Drawing.Size(44, 19)
        Me.Label178.TabIndex = 175
        Me.Label178.Text = "CP OF"
        Me.Label178.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label188
        '
        Me.Label188.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label188.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label188.Location = New System.Drawing.Point(249, 44)
        Me.Label188.Name = "Label188"
        Me.Label188.Size = New System.Drawing.Size(44, 19)
        Me.Label188.TabIndex = 175
        Me.Label188.Text = "SBC ERR"
        Me.Label188.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label177
        '
        Me.Label177.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label177.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label177.Location = New System.Drawing.Point(247, 108)
        Me.Label177.Name = "Label177"
        Me.Label177.Size = New System.Drawing.Size(44, 19)
        Me.Label177.TabIndex = 175
        Me.Label177.Text = "PCB OT"
        Me.Label177.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label195
        '
        Me.Label195.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label195.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label195.Location = New System.Drawing.Point(231, 69)
        Me.Label195.Name = "Label195"
        Me.Label195.Size = New System.Drawing.Size(63, 19)
        Me.Label195.TabIndex = 175
        Me.Label195.Text = "LV OV HW"
        Me.Label195.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label206
        '
        Me.Label206.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label206.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label206.Location = New System.Drawing.Point(170, 190)
        Me.Label206.Name = "Label206"
        Me.Label206.Size = New System.Drawing.Size(44, 19)
        Me.Label206.TabIndex = 175
        Me.Label206.Text = "-"
        Me.Label206.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label204
        '
        Me.Label204.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label204.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label204.Location = New System.Drawing.Point(247, 28)
        Me.Label204.Name = "Label204"
        Me.Label204.Size = New System.Drawing.Size(44, 19)
        Me.Label204.TabIndex = 175
        Me.Label204.Text = "DSP NG"
        Me.Label204.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label194
        '
        Me.Label194.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label194.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label194.Location = New System.Drawing.Point(75, 84)
        Me.Label194.Name = "Label194"
        Me.Label194.Size = New System.Drawing.Size(66, 19)
        Me.Label194.TabIndex = 175
        Me.Label194.Text = "LV AUX OV"
        Me.Label194.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label200
        '
        Me.Label200.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label200.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label200.Location = New System.Drawing.Point(247, 4)
        Me.Label200.Name = "Label200"
        Me.Label200.Size = New System.Drawing.Size(44, 19)
        Me.Label200.TabIndex = 175
        Me.Label200.Text = "-"
        Me.Label200.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label205
        '
        Me.Label205.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label205.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label205.Location = New System.Drawing.Point(170, 205)
        Me.Label205.Name = "Label205"
        Me.Label205.Size = New System.Drawing.Size(44, 19)
        Me.Label205.TabIndex = 175
        Me.Label205.Text = "CAL Err"
        Me.Label205.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label174
        '
        Me.Label174.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label174.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label174.Location = New System.Drawing.Point(171, 164)
        Me.Label174.Name = "Label174"
        Me.Label174.Size = New System.Drawing.Size(44, 19)
        Me.Label174.TabIndex = 175
        Me.Label174.Text = "BST OC"
        Me.Label174.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label187
        '
        Me.Label187.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label187.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label187.Location = New System.Drawing.Point(87, 44)
        Me.Label187.Name = "Label187"
        Me.Label187.Size = New System.Drawing.Size(54, 19)
        Me.Label187.TabIndex = 175
        Me.Label187.Text = "CONF ERR"
        Me.Label187.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label173
        '
        Me.Label173.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label173.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label173.Location = New System.Drawing.Point(77, 108)
        Me.Label173.Name = "Label173"
        Me.Label173.Size = New System.Drawing.Size(62, 19)
        Me.Label173.TabIndex = 175
        Me.Label173.Text = "COOL OT"
        Me.Label173.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label193
        '
        Me.Label193.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label193.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label193.Location = New System.Drawing.Point(95, 68)
        Me.Label193.Name = "Label193"
        Me.Label193.Size = New System.Drawing.Size(44, 19)
        Me.Label193.TabIndex = 175
        Me.Label193.Text = "LV UV"
        Me.Label193.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label184
        '
        Me.Label184.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label184.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label184.Location = New System.Drawing.Point(95, 190)
        Me.Label184.Name = "Label184"
        Me.Label184.Size = New System.Drawing.Size(44, 19)
        Me.Label184.TabIndex = 175
        Me.Label184.Text = "-"
        Me.Label184.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label176
        '
        Me.Label176.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label176.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label176.Location = New System.Drawing.Point(162, 151)
        Me.Label176.Name = "Label176"
        Me.Label176.Size = New System.Drawing.Size(57, 19)
        Me.Label176.TabIndex = 175
        Me.Label176.Text = "HV Aux OV"
        Me.Label176.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label202
        '
        Me.Label202.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label202.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label202.Location = New System.Drawing.Point(148, 28)
        Me.Label202.Name = "Label202"
        Me.Label202.Size = New System.Drawing.Size(71, 20)
        Me.Label202.TabIndex = 175
        Me.Label202.Text = "CAN Loss OBC"
        Me.Label202.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label203
        '
        Me.Label203.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label203.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label203.Location = New System.Drawing.Point(71, 28)
        Me.Label203.Name = "Label203"
        Me.Label203.Size = New System.Drawing.Size(71, 20)
        Me.Label203.TabIndex = 175
        Me.Label203.Text = "CAN Loss VCU"
        Me.Label203.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label172
        '
        Me.Label172.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label172.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label172.Location = New System.Drawing.Point(84, 150)
        Me.Label172.Name = "Label172"
        Me.Label172.Size = New System.Drawing.Size(57, 19)
        Me.Label172.TabIndex = 175
        Me.Label172.Text = "HV Aux UV"
        Me.Label172.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label192
        '
        Me.Label192.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label192.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label192.Location = New System.Drawing.Point(171, 84)
        Me.Label192.Name = "Label192"
        Me.Label192.Size = New System.Drawing.Size(44, 19)
        Me.Label192.TabIndex = 175
        Me.Label192.Text = "BAT UV"
        Me.Label192.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label162
        '
        Me.Label162.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label162.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label162.Location = New System.Drawing.Point(2, 125)
        Me.Label162.Name = "Label162"
        Me.Label162.Size = New System.Drawing.Size(61, 19)
        Me.Label162.TabIndex = 175
        Me.Label162.Text = "APM HV OC"
        Me.Label162.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label175
        '
        Me.Label175.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label175.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label175.Location = New System.Drawing.Point(77, 125)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(64, 19)
        Me.Label175.TabIndex = 175
        Me.Label175.Text = "APM HV UV"
        Me.Label175.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label171
        '
        Me.Label171.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label171.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label171.Location = New System.Drawing.Point(155, 125)
        Me.Label171.Name = "Label171"
        Me.Label171.Size = New System.Drawing.Size(64, 19)
        Me.Label171.TabIndex = 175
        Me.Label171.Text = "APM HV OV"
        Me.Label171.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label199
        '
        Me.Label199.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label199.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label199.Location = New System.Drawing.Point(95, 1)
        Me.Label199.Name = "Label199"
        Me.Label199.Size = New System.Drawing.Size(42, 24)
        Me.Label199.TabIndex = 175
        Me.Label199.Text = "HV Aux State"
        Me.Label199.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label183
        '
        Me.Label183.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label183.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label183.Location = New System.Drawing.Point(80, 206)
        Me.Label183.Name = "Label183"
        Me.Label183.Size = New System.Drawing.Size(60, 19)
        Me.Label183.TabIndex = 175
        Me.Label183.Text = "CAL EMPTY"
        Me.Label183.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label186
        '
        Me.Label186.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label186.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label186.Location = New System.Drawing.Point(170, 44)
        Me.Label186.Name = "Label186"
        Me.Label186.Size = New System.Drawing.Size(44, 19)
        Me.Label186.TabIndex = 175
        Me.Label186.Text = "SBC FS"
        Me.Label186.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label164
        '
        Me.Label164.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label164.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label164.Location = New System.Drawing.Point(170, 108)
        Me.Label164.Name = "Label164"
        Me.Label164.Size = New System.Drawing.Size(44, 19)
        Me.Label164.TabIndex = 175
        Me.Label164.Text = "SR OT"
        Me.Label164.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label165
        '
        Me.Label165.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label165.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label165.Location = New System.Drawing.Point(96, 165)
        Me.Label165.Name = "Label165"
        Me.Label165.Size = New System.Drawing.Size(44, 19)
        Me.Label165.TabIndex = 175
        Me.Label165.Text = "LV OP"
        Me.Label165.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label191
        '
        Me.Label191.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label191.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label191.Location = New System.Drawing.Point(161, 69)
        Me.Label191.Name = "Label191"
        Me.Label191.Size = New System.Drawing.Size(55, 19)
        Me.Label191.TabIndex = 175
        Me.Label191.Text = "LV OV SW"
        Me.Label191.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label207
        '
        Me.Label207.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label207.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label207.Location = New System.Drawing.Point(233, 190)
        Me.Label207.Name = "Label207"
        Me.Label207.Size = New System.Drawing.Size(61, 19)
        Me.Label207.TabIndex = 175
        Me.Label207.Text = "DIAG SC FAIL"
        Me.Label207.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label182
        '
        Me.Label182.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label182.Font = New System.Drawing.Font("Times New Roman", 6.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label182.Location = New System.Drawing.Point(1, 205)
        Me.Label182.Name = "Label182"
        Me.Label182.Size = New System.Drawing.Size(61, 19)
        Me.Label182.TabIndex = 175
        Me.Label182.Text = "DIAG OV FAIL"
        Me.Label182.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label161
        '
        Me.Label161.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label161.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label161.Location = New System.Drawing.Point(240, 166)
        Me.Label161.Name = "Label161"
        Me.Label161.Size = New System.Drawing.Size(54, 19)
        Me.Label161.TabIndex = 175
        Me.Label161.Text = "BST OV HW"
        Me.Label161.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label163
        '
        Me.Label163.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label163.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label163.Location = New System.Drawing.Point(248, 150)
        Me.Label163.Name = "Label163"
        Me.Label163.Size = New System.Drawing.Size(44, 19)
        Me.Label163.TabIndex = 175
        Me.Label163.Text = "CP UF"
        Me.Label163.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label190
        '
        Me.Label190.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label190.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label190.Location = New System.Drawing.Point(5, 84)
        Me.Label190.Name = "Label190"
        Me.Label190.Size = New System.Drawing.Size(56, 19)
        Me.Label190.TabIndex = 175
        Me.Label190.Text = "LV AUX UV"
        Me.Label190.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label198
        '
        Me.Label198.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label198.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label198.Location = New System.Drawing.Point(168, 4)
        Me.Label198.Name = "Label198"
        Me.Label198.Size = New System.Drawing.Size(44, 19)
        Me.Label198.TabIndex = 175
        Me.Label198.Text = "J1772 S2"
        Me.Label198.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label181
        '
        Me.Label181.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label181.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label181.Location = New System.Drawing.Point(248, 205)
        Me.Label181.Name = "Label181"
        Me.Label181.Size = New System.Drawing.Size(44, 19)
        Me.Label181.TabIndex = 175
        Me.Label181.Text = "CPU Err"
        Me.Label181.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label160
        '
        Me.Label160.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label160.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label160.Location = New System.Drawing.Point(3, 108)
        Me.Label160.Name = "Label160"
        Me.Label160.Size = New System.Drawing.Size(57, 19)
        Me.Label160.TabIndex = 175
        Me.Label160.Text = "BST OV SW"
        Me.Label160.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label201
        '
        Me.Label201.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label201.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label201.Location = New System.Drawing.Point(16, 28)
        Me.Label201.Name = "Label201"
        Me.Label201.Size = New System.Drawing.Size(44, 19)
        Me.Label201.TabIndex = 175
        Me.Label201.Text = "OBC NG"
        Me.Label201.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label185
        '
        Me.Label185.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label185.Font = New System.Drawing.Font("Times New Roman", 6.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label185.Location = New System.Drawing.Point(1, 44)
        Me.Label185.Name = "Label185"
        Me.Label185.Size = New System.Drawing.Size(62, 19)
        Me.Label185.TabIndex = 175
        Me.Label185.Text = "CONF EMPTY"
        Me.Label185.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label189
        '
        Me.Label189.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label189.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label189.Location = New System.Drawing.Point(4, 69)
        Me.Label189.Name = "Label189"
        Me.Label189.Size = New System.Drawing.Size(57, 19)
        Me.Label189.TabIndex = 175
        Me.Label189.Text = "LV OC HW"
        Me.Label189.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label197
        '
        Me.Label197.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label197.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label197.Location = New System.Drawing.Point(5, 5)
        Me.Label197.Name = "Label197"
        Me.Label197.Size = New System.Drawing.Size(54, 18)
        Me.Label197.TabIndex = 175
        Me.Label197.Text = "IGN State"
        Me.Label197.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.Control
        Me.Panel7.Controls.Add(Me.tbApmIcmd)
        Me.Panel7.Controls.Add(Me.tbApmVcmd)
        Me.Panel7.Controls.Add(Me.Label146)
        Me.Panel7.Controls.Add(Me.Label147)
        Me.Panel7.Location = New System.Drawing.Point(239, 368)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(76, 80)
        Me.Panel7.TabIndex = 186
        '
        'tbApmIcmd
        '
        Me.tbApmIcmd.BackColor = System.Drawing.Color.Snow
        Me.tbApmIcmd.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmIcmd.Location = New System.Drawing.Point(4, 57)
        Me.tbApmIcmd.Name = "tbApmIcmd"
        Me.tbApmIcmd.ReadOnly = True
        Me.tbApmIcmd.Size = New System.Drawing.Size(68, 21)
        Me.tbApmIcmd.TabIndex = 182
        Me.tbApmIcmd.Text = "-"
        Me.tbApmIcmd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmVcmd
        '
        Me.tbApmVcmd.BackColor = System.Drawing.Color.Snow
        Me.tbApmVcmd.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmVcmd.Location = New System.Drawing.Point(4, 15)
        Me.tbApmVcmd.Name = "tbApmVcmd"
        Me.tbApmVcmd.ReadOnly = True
        Me.tbApmVcmd.Size = New System.Drawing.Size(68, 21)
        Me.tbApmVcmd.TabIndex = 182
        Me.tbApmVcmd.Text = "-"
        Me.tbApmVcmd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label146
        '
        Me.Label146.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label146.BackColor = System.Drawing.Color.Transparent
        Me.Label146.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label146.Location = New System.Drawing.Point(1, 1)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(71, 22)
        Me.Label146.TabIndex = 183
        Me.Label146.Text = "LV Vcmd (%)"
        '
        'Label147
        '
        Me.Label147.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label147.BackColor = System.Drawing.Color.Transparent
        Me.Label147.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label147.Location = New System.Drawing.Point(1, 43)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(68, 22)
        Me.Label147.TabIndex = 183
        Me.Label147.Text = "LV Icmd (%)"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.Control
        Me.Panel6.Controls.Add(Me.tbApmHvdcCurr)
        Me.Panel6.Controls.Add(Me.tbApmHvdcVolt)
        Me.Panel6.Controls.Add(Me.Label148)
        Me.Panel6.Controls.Add(Me.Label151)
        Me.Panel6.Location = New System.Drawing.Point(239, 292)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(76, 76)
        Me.Panel6.TabIndex = 186
        '
        'tbApmHvdcCurr
        '
        Me.tbApmHvdcCurr.BackColor = System.Drawing.Color.Snow
        Me.tbApmHvdcCurr.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmHvdcCurr.Location = New System.Drawing.Point(4, 52)
        Me.tbApmHvdcCurr.Name = "tbApmHvdcCurr"
        Me.tbApmHvdcCurr.ReadOnly = True
        Me.tbApmHvdcCurr.Size = New System.Drawing.Size(68, 21)
        Me.tbApmHvdcCurr.TabIndex = 182
        Me.tbApmHvdcCurr.Text = "-"
        Me.tbApmHvdcCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmHvdcVolt
        '
        Me.tbApmHvdcVolt.BackColor = System.Drawing.Color.Snow
        Me.tbApmHvdcVolt.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmHvdcVolt.Location = New System.Drawing.Point(4, 15)
        Me.tbApmHvdcVolt.Name = "tbApmHvdcVolt"
        Me.tbApmHvdcVolt.ReadOnly = True
        Me.tbApmHvdcVolt.Size = New System.Drawing.Size(68, 21)
        Me.tbApmHvdcVolt.TabIndex = 182
        Me.tbApmHvdcVolt.Text = "-"
        Me.tbApmHvdcVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label148
        '
        Me.Label148.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label148.BackColor = System.Drawing.Color.Transparent
        Me.Label148.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label148.Location = New System.Drawing.Point(4, -2)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(69, 11)
        Me.Label148.TabIndex = 183
        Me.Label148.Text = "APM HV V(V)"
        '
        'Label151
        '
        Me.Label151.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label151.BackColor = System.Drawing.Color.Transparent
        Me.Label151.Font = New System.Drawing.Font("Times New Roman", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label151.Location = New System.Drawing.Point(4, 38)
        Me.Label151.Name = "Label151"
        Me.Label151.Size = New System.Drawing.Size(68, 22)
        Me.Label151.TabIndex = 183
        Me.Label151.Text = "APM HV I(A)"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.Control
        Me.Panel8.Controls.Add(Me.tbApmEvseImax)
        Me.Panel8.Controls.Add(Me.Label159)
        Me.Panel8.Controls.Add(Me.tbApmHVAux)
        Me.Panel8.Controls.Add(Me.Label149)
        Me.Panel8.Controls.Add(Me.tbApmLVIcmd)
        Me.Panel8.Controls.Add(Me.tbApmLVAux)
        Me.Panel8.Controls.Add(Me.Label154)
        Me.Panel8.Controls.Add(Me.Label157)
        Me.Panel8.Location = New System.Drawing.Point(1, 451)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(313, 38)
        Me.Panel8.TabIndex = 184
        '
        'tbApmEvseImax
        '
        Me.tbApmEvseImax.BackColor = System.Drawing.Color.Snow
        Me.tbApmEvseImax.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmEvseImax.Location = New System.Drawing.Point(242, 15)
        Me.tbApmEvseImax.Name = "tbApmEvseImax"
        Me.tbApmEvseImax.ReadOnly = True
        Me.tbApmEvseImax.Size = New System.Drawing.Size(68, 21)
        Me.tbApmEvseImax.TabIndex = 182
        Me.tbApmEvseImax.Text = "-"
        Me.tbApmEvseImax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label159
        '
        Me.Label159.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label159.BackColor = System.Drawing.Color.Transparent
        Me.Label159.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label159.Location = New System.Drawing.Point(237, 1)
        Me.Label159.Name = "Label159"
        Me.Label159.Size = New System.Drawing.Size(73, 22)
        Me.Label159.TabIndex = 183
        Me.Label159.Text = "Evse Imax(A)"
        '
        'tbApmHVAux
        '
        Me.tbApmHVAux.BackColor = System.Drawing.Color.Snow
        Me.tbApmHVAux.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmHVAux.Location = New System.Drawing.Point(162, 15)
        Me.tbApmHVAux.Name = "tbApmHVAux"
        Me.tbApmHVAux.ReadOnly = True
        Me.tbApmHVAux.Size = New System.Drawing.Size(68, 21)
        Me.tbApmHVAux.TabIndex = 182
        Me.tbApmHVAux.Text = "-"
        Me.tbApmHVAux.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label149
        '
        Me.Label149.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label149.BackColor = System.Drawing.Color.Transparent
        Me.Label149.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label149.Location = New System.Drawing.Point(162, 1)
        Me.Label149.Name = "Label149"
        Me.Label149.Size = New System.Drawing.Size(68, 22)
        Me.Label149.TabIndex = 183
        Me.Label149.Text = "HV Aux (V)"
        '
        'tbApmLVIcmd
        '
        Me.tbApmLVIcmd.BackColor = System.Drawing.Color.Snow
        Me.tbApmLVIcmd.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmLVIcmd.Location = New System.Drawing.Point(82, 15)
        Me.tbApmLVIcmd.Name = "tbApmLVIcmd"
        Me.tbApmLVIcmd.ReadOnly = True
        Me.tbApmLVIcmd.Size = New System.Drawing.Size(68, 21)
        Me.tbApmLVIcmd.TabIndex = 182
        Me.tbApmLVIcmd.Text = "-"
        Me.tbApmLVIcmd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmLVAux
        '
        Me.tbApmLVAux.BackColor = System.Drawing.Color.Snow
        Me.tbApmLVAux.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmLVAux.Location = New System.Drawing.Point(2, 15)
        Me.tbApmLVAux.Name = "tbApmLVAux"
        Me.tbApmLVAux.ReadOnly = True
        Me.tbApmLVAux.Size = New System.Drawing.Size(68, 21)
        Me.tbApmLVAux.TabIndex = 182
        Me.tbApmLVAux.Text = "-"
        Me.tbApmLVAux.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label154
        '
        Me.Label154.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label154.BackColor = System.Drawing.Color.Transparent
        Me.Label154.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label154.Location = New System.Drawing.Point(82, 1)
        Me.Label154.Name = "Label154"
        Me.Label154.Size = New System.Drawing.Size(68, 22)
        Me.Label154.TabIndex = 183
        Me.Label154.Text = "LV ICmd (A)"
        '
        'Label157
        '
        Me.Label157.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label157.BackColor = System.Drawing.Color.Transparent
        Me.Label157.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label157.Location = New System.Drawing.Point(2, 1)
        Me.Label157.Name = "Label157"
        Me.Label157.Size = New System.Drawing.Size(68, 22)
        Me.Label157.TabIndex = 183
        Me.Label157.Text = "LV AUX (V)"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.Control
        Me.Panel5.Controls.Add(Me.tbApmTcool)
        Me.Panel5.Controls.Add(Me.Label168)
        Me.Panel5.Controls.Add(Me.tbApmTsr)
        Me.Panel5.Controls.Add(Me.tbApmTpcb)
        Me.Panel5.Controls.Add(Me.Label169)
        Me.Panel5.Controls.Add(Me.Label170)
        Me.Panel5.Location = New System.Drawing.Point(1, 410)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(236, 38)
        Me.Panel5.TabIndex = 184
        '
        'tbApmTcool
        '
        Me.tbApmTcool.BackColor = System.Drawing.Color.Snow
        Me.tbApmTcool.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmTcool.Location = New System.Drawing.Point(162, 15)
        Me.tbApmTcool.Name = "tbApmTcool"
        Me.tbApmTcool.ReadOnly = True
        Me.tbApmTcool.Size = New System.Drawing.Size(68, 21)
        Me.tbApmTcool.TabIndex = 182
        Me.tbApmTcool.Text = "-"
        Me.tbApmTcool.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label168
        '
        Me.Label168.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label168.BackColor = System.Drawing.Color.Transparent
        Me.Label168.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label168.Location = New System.Drawing.Point(162, 1)
        Me.Label168.Name = "Label168"
        Me.Label168.Size = New System.Drawing.Size(68, 22)
        Me.Label168.TabIndex = 183
        Me.Label168.Text = "T Cool ('C)"
        '
        'tbApmTsr
        '
        Me.tbApmTsr.BackColor = System.Drawing.Color.Snow
        Me.tbApmTsr.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmTsr.Location = New System.Drawing.Point(82, 15)
        Me.tbApmTsr.Name = "tbApmTsr"
        Me.tbApmTsr.ReadOnly = True
        Me.tbApmTsr.Size = New System.Drawing.Size(68, 21)
        Me.tbApmTsr.TabIndex = 182
        Me.tbApmTsr.Text = "-"
        Me.tbApmTsr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmTpcb
        '
        Me.tbApmTpcb.BackColor = System.Drawing.Color.Snow
        Me.tbApmTpcb.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmTpcb.Location = New System.Drawing.Point(2, 15)
        Me.tbApmTpcb.Name = "tbApmTpcb"
        Me.tbApmTpcb.ReadOnly = True
        Me.tbApmTpcb.Size = New System.Drawing.Size(68, 21)
        Me.tbApmTpcb.TabIndex = 182
        Me.tbApmTpcb.Text = "-"
        Me.tbApmTpcb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label169
        '
        Me.Label169.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label169.BackColor = System.Drawing.Color.Transparent
        Me.Label169.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label169.Location = New System.Drawing.Point(82, 1)
        Me.Label169.Name = "Label169"
        Me.Label169.Size = New System.Drawing.Size(68, 22)
        Me.Label169.TabIndex = 183
        Me.Label169.Text = "T SR ('C)"
        '
        'Label170
        '
        Me.Label170.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label170.BackColor = System.Drawing.Color.Transparent
        Me.Label170.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label170.Location = New System.Drawing.Point(2, 1)
        Me.Label170.Name = "Label170"
        Me.Label170.Size = New System.Drawing.Size(68, 22)
        Me.Label170.TabIndex = 183
        Me.Label170.Text = "T PCB ('C)"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.Control
        Me.Panel4.Controls.Add(Me.tbApmBattVolt)
        Me.Panel4.Controls.Add(Me.Label145)
        Me.Panel4.Controls.Add(Me.tbApmLVDCCurr)
        Me.Panel4.Controls.Add(Me.tbApmLVDCVolt)
        Me.Panel4.Controls.Add(Me.Label166)
        Me.Panel4.Controls.Add(Me.Label167)
        Me.Panel4.Location = New System.Drawing.Point(1, 368)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(236, 38)
        Me.Panel4.TabIndex = 184
        '
        'tbApmBattVolt
        '
        Me.tbApmBattVolt.BackColor = System.Drawing.Color.Snow
        Me.tbApmBattVolt.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmBattVolt.Location = New System.Drawing.Point(162, 15)
        Me.tbApmBattVolt.Name = "tbApmBattVolt"
        Me.tbApmBattVolt.ReadOnly = True
        Me.tbApmBattVolt.Size = New System.Drawing.Size(68, 21)
        Me.tbApmBattVolt.TabIndex = 182
        Me.tbApmBattVolt.Text = "-"
        Me.tbApmBattVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label145
        '
        Me.Label145.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label145.BackColor = System.Drawing.Color.Transparent
        Me.Label145.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label145.Location = New System.Drawing.Point(162, 1)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(68, 22)
        Me.Label145.TabIndex = 183
        Me.Label145.Text = "Batt Volt (V)"
        '
        'tbApmLVDCCurr
        '
        Me.tbApmLVDCCurr.BackColor = System.Drawing.Color.Snow
        Me.tbApmLVDCCurr.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmLVDCCurr.Location = New System.Drawing.Point(82, 15)
        Me.tbApmLVDCCurr.Name = "tbApmLVDCCurr"
        Me.tbApmLVDCCurr.ReadOnly = True
        Me.tbApmLVDCCurr.Size = New System.Drawing.Size(68, 21)
        Me.tbApmLVDCCurr.TabIndex = 182
        Me.tbApmLVDCCurr.Text = "-"
        Me.tbApmLVDCCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmLVDCVolt
        '
        Me.tbApmLVDCVolt.BackColor = System.Drawing.Color.Snow
        Me.tbApmLVDCVolt.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmLVDCVolt.Location = New System.Drawing.Point(2, 15)
        Me.tbApmLVDCVolt.Name = "tbApmLVDCVolt"
        Me.tbApmLVDCVolt.ReadOnly = True
        Me.tbApmLVDCVolt.Size = New System.Drawing.Size(68, 21)
        Me.tbApmLVDCVolt.TabIndex = 182
        Me.tbApmLVDCVolt.Text = "-"
        Me.tbApmLVDCVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label166
        '
        Me.Label166.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label166.BackColor = System.Drawing.Color.Transparent
        Me.Label166.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label166.Location = New System.Drawing.Point(82, 1)
        Me.Label166.Name = "Label166"
        Me.Label166.Size = New System.Drawing.Size(68, 22)
        Me.Label166.TabIndex = 183
        Me.Label166.Text = "LV Curr (A)"
        '
        'Label167
        '
        Me.Label167.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label167.BackColor = System.Drawing.Color.Transparent
        Me.Label167.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label167.Location = New System.Drawing.Point(2, 1)
        Me.Label167.Name = "Label167"
        Me.Label167.Size = New System.Drawing.Size(68, 22)
        Me.Label167.TabIndex = 183
        Me.Label167.Text = "LV Volt (V)"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.tbApmVerBoot)
        Me.Panel2.Controls.Add(Me.Label142)
        Me.Panel2.Controls.Add(Me.tbApmVerApp)
        Me.Panel2.Controls.Add(Me.tbApmMode)
        Me.Panel2.Controls.Add(Me.Label150)
        Me.Panel2.Controls.Add(Me.Label153)
        Me.Panel2.Location = New System.Drawing.Point(1, 248)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(313, 38)
        Me.Panel2.TabIndex = 184
        '
        'tbApmVerBoot
        '
        Me.tbApmVerBoot.BackColor = System.Drawing.Color.Snow
        Me.tbApmVerBoot.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmVerBoot.Location = New System.Drawing.Point(202, 15)
        Me.tbApmVerBoot.Name = "tbApmVerBoot"
        Me.tbApmVerBoot.ReadOnly = True
        Me.tbApmVerBoot.Size = New System.Drawing.Size(108, 21)
        Me.tbApmVerBoot.TabIndex = 182
        Me.tbApmVerBoot.Text = "-"
        Me.tbApmVerBoot.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label142
        '
        Me.Label142.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label142.BackColor = System.Drawing.Color.Transparent
        Me.Label142.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label142.Location = New System.Drawing.Point(202, 1)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(70, 22)
        Me.Label142.TabIndex = 183
        Me.Label142.Text = "Boot. Version"
        '
        'tbApmVerApp
        '
        Me.tbApmVerApp.BackColor = System.Drawing.Color.Snow
        Me.tbApmVerApp.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmVerApp.Location = New System.Drawing.Point(82, 15)
        Me.tbApmVerApp.Name = "tbApmVerApp"
        Me.tbApmVerApp.ReadOnly = True
        Me.tbApmVerApp.Size = New System.Drawing.Size(108, 21)
        Me.tbApmVerApp.TabIndex = 182
        Me.tbApmVerApp.Text = "-"
        Me.tbApmVerApp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmMode
        '
        Me.tbApmMode.BackColor = System.Drawing.Color.Snow
        Me.tbApmMode.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmMode.Location = New System.Drawing.Point(2, 15)
        Me.tbApmMode.Name = "tbApmMode"
        Me.tbApmMode.ReadOnly = True
        Me.tbApmMode.Size = New System.Drawing.Size(68, 21)
        Me.tbApmMode.TabIndex = 182
        Me.tbApmMode.Text = "-"
        Me.tbApmMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label150
        '
        Me.Label150.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label150.BackColor = System.Drawing.Color.Transparent
        Me.Label150.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label150.Location = New System.Drawing.Point(82, 1)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(68, 22)
        Me.Label150.TabIndex = 183
        Me.Label150.Text = "App. Version"
        '
        'Label153
        '
        Me.Label153.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label153.BackColor = System.Drawing.Color.Transparent
        Me.Label153.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label153.Location = New System.Drawing.Point(-1, 1)
        Me.Label153.Name = "Label153"
        Me.Label153.Size = New System.Drawing.Size(80, 22)
        Me.Label153.TabIndex = 183
        Me.Label153.Text = "Working Mode"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.Control
        Me.Panel3.Controls.Add(Me.tbApmProxVolt)
        Me.Panel3.Controls.Add(Me.tbApmProxState)
        Me.Panel3.Controls.Add(Me.tbApmPilState)
        Me.Panel3.Controls.Add(Me.tbApmCPVolt)
        Me.Panel3.Controls.Add(Me.tbApmCPFreq)
        Me.Panel3.Controls.Add(Me.tbApmCPDuty)
        Me.Panel3.Controls.Add(Me.Label152)
        Me.Panel3.Controls.Add(Me.Label143)
        Me.Panel3.Controls.Add(Me.Label155)
        Me.Panel3.Controls.Add(Me.Label156)
        Me.Panel3.Controls.Add(Me.Label144)
        Me.Panel3.Controls.Add(Me.Label158)
        Me.Panel3.Location = New System.Drawing.Point(1, 289)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(236, 76)
        Me.Panel3.TabIndex = 185
        '
        'tbApmProxVolt
        '
        Me.tbApmProxVolt.BackColor = System.Drawing.Color.Snow
        Me.tbApmProxVolt.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmProxVolt.Location = New System.Drawing.Point(162, 17)
        Me.tbApmProxVolt.Name = "tbApmProxVolt"
        Me.tbApmProxVolt.ReadOnly = True
        Me.tbApmProxVolt.Size = New System.Drawing.Size(68, 21)
        Me.tbApmProxVolt.TabIndex = 182
        Me.tbApmProxVolt.Text = "-"
        Me.tbApmProxVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmProxState
        '
        Me.tbApmProxState.BackColor = System.Drawing.Color.Snow
        Me.tbApmProxState.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmProxState.Location = New System.Drawing.Point(82, 17)
        Me.tbApmProxState.Name = "tbApmProxState"
        Me.tbApmProxState.ReadOnly = True
        Me.tbApmProxState.Size = New System.Drawing.Size(68, 21)
        Me.tbApmProxState.TabIndex = 182
        Me.tbApmProxState.Text = "-"
        Me.tbApmProxState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmPilState
        '
        Me.tbApmPilState.BackColor = System.Drawing.Color.Snow
        Me.tbApmPilState.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmPilState.Location = New System.Drawing.Point(2, 17)
        Me.tbApmPilState.Name = "tbApmPilState"
        Me.tbApmPilState.ReadOnly = True
        Me.tbApmPilState.Size = New System.Drawing.Size(68, 21)
        Me.tbApmPilState.TabIndex = 182
        Me.tbApmPilState.Text = "-"
        Me.tbApmPilState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmCPVolt
        '
        Me.tbApmCPVolt.BackColor = System.Drawing.Color.Snow
        Me.tbApmCPVolt.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmCPVolt.Location = New System.Drawing.Point(2, 51)
        Me.tbApmCPVolt.Name = "tbApmCPVolt"
        Me.tbApmCPVolt.ReadOnly = True
        Me.tbApmCPVolt.Size = New System.Drawing.Size(68, 21)
        Me.tbApmCPVolt.TabIndex = 182
        Me.tbApmCPVolt.Text = "-"
        Me.tbApmCPVolt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmCPFreq
        '
        Me.tbApmCPFreq.BackColor = System.Drawing.Color.Snow
        Me.tbApmCPFreq.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmCPFreq.Location = New System.Drawing.Point(82, 51)
        Me.tbApmCPFreq.Name = "tbApmCPFreq"
        Me.tbApmCPFreq.ReadOnly = True
        Me.tbApmCPFreq.Size = New System.Drawing.Size(68, 21)
        Me.tbApmCPFreq.TabIndex = 182
        Me.tbApmCPFreq.Text = "-"
        Me.tbApmCPFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tbApmCPDuty
        '
        Me.tbApmCPDuty.BackColor = System.Drawing.Color.Snow
        Me.tbApmCPDuty.Font = New System.Drawing.Font("Times New Roman", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbApmCPDuty.Location = New System.Drawing.Point(162, 51)
        Me.tbApmCPDuty.Name = "tbApmCPDuty"
        Me.tbApmCPDuty.ReadOnly = True
        Me.tbApmCPDuty.Size = New System.Drawing.Size(68, 21)
        Me.tbApmCPDuty.TabIndex = 182
        Me.tbApmCPDuty.Text = "-"
        Me.tbApmCPDuty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label152
        '
        Me.Label152.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label152.BackColor = System.Drawing.Color.Transparent
        Me.Label152.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label152.Location = New System.Drawing.Point(82, 3)
        Me.Label152.Name = "Label152"
        Me.Label152.Size = New System.Drawing.Size(68, 22)
        Me.Label152.TabIndex = 183
        Me.Label152.Text = "Prox. State"
        '
        'Label143
        '
        Me.Label143.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label143.BackColor = System.Drawing.Color.Transparent
        Me.Label143.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label143.Location = New System.Drawing.Point(159, 3)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(75, 22)
        Me.Label143.TabIndex = 183
        Me.Label143.Text = "Prox. Volt (V)"
        '
        'Label155
        '
        Me.Label155.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label155.BackColor = System.Drawing.Color.Transparent
        Me.Label155.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label155.Location = New System.Drawing.Point(79, 37)
        Me.Label155.Name = "Label155"
        Me.Label155.Size = New System.Drawing.Size(79, 22)
        Me.Label155.TabIndex = 183
        Me.Label155.Text = "CP Freq. (Hz)"
        '
        'Label156
        '
        Me.Label156.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label156.BackColor = System.Drawing.Color.Transparent
        Me.Label156.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label156.Location = New System.Drawing.Point(2, 3)
        Me.Label156.Name = "Label156"
        Me.Label156.Size = New System.Drawing.Size(68, 22)
        Me.Label156.TabIndex = 183
        Me.Label156.Text = "Pilot State"
        '
        'Label144
        '
        Me.Label144.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label144.BackColor = System.Drawing.Color.Transparent
        Me.Label144.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label144.Location = New System.Drawing.Point(162, 37)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(68, 22)
        Me.Label144.TabIndex = 183
        Me.Label144.Text = "CP Duty (%)"
        '
        'Label158
        '
        Me.Label158.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.Label158.BackColor = System.Drawing.Color.Transparent
        Me.Label158.Font = New System.Drawing.Font("Times New Roman", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label158.Location = New System.Drawing.Point(2, 37)
        Me.Label158.Name = "Label158"
        Me.Label158.Size = New System.Drawing.Size(68, 22)
        Me.Label158.TabIndex = 183
        Me.Label158.Text = "CP Volt (V)"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.tbCanLog)
        Me.TabPage4.Font = New System.Drawing.Font("Times New Roman", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(1193, 495)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "CAN Log"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'tbCanLog
        '
        Me.tbCanLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbCanLog.Font = New System.Drawing.Font("Times New Roman", 7.5!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCanLog.Location = New System.Drawing.Point(6, 7)
        Me.tbCanLog.Name = "tbCanLog"
        Me.tbCanLog.ReadOnly = True
        Me.tbCanLog.Size = New System.Drawing.Size(545, 497)
        Me.tbCanLog.TabIndex = 155
        Me.tbCanLog.Text = ""
        '
        'TabPage5
        '
        Me.TabPage5.Location = New System.Drawing.Point(4, 29)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1193, 495)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Calibration"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Location = New System.Drawing.Point(4, 29)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1193, 495)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Event Log"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Location = New System.Drawing.Point(4, 29)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(1193, 495)
        Me.TabPage7.TabIndex = 4
        Me.TabPage7.Text = "Bootloader"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'lbModel
        '
        Me.lbModel.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.lbModel.Font = New System.Drawing.Font("Times New Roman", 28.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbModel.Location = New System.Drawing.Point(901, -7)
        Me.lbModel.Name = "lbModel"
        Me.lbModel.Size = New System.Drawing.Size(127, 56)
        Me.lbModel.TabIndex = 132
        Me.lbModel.Text = "11KW"
        Me.lbModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbMode
        '
        Me.lbMode.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.lbMode.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMode.Location = New System.Drawing.Point(953, 40)
        Me.lbMode.Name = "lbMode"
        Me.lbMode.Size = New System.Drawing.Size(98, 25)
        Me.lbMode.TabIndex = 132
        Me.lbMode.Text = "Forward"
        Me.lbMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox9
        '
        Me.PictureBox9.ErrorImage = Nothing
        Me.PictureBox9.Image = Global.LOS_EVPS_11_22KW_OBC_Combo.My.Resources.Resources.LITEON_LOGO
        Me.PictureBox9.InitialImage = Nothing
        Me.PictureBox9.Location = New System.Drawing.Point(1069, 8)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(137, 36)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox9.TabIndex = 115
        Me.PictureBox9.TabStop = False
        '
        'tmrDisplay
        '
        '
        'TxTimer
        '
        Me.TxTimer.Enabled = True
        Me.TxTimer.Interval = 25
        '
        'lbPhase
        '
        Me.lbPhase.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.lbPhase.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbPhase.Location = New System.Drawing.Point(883, 42)
        Me.lbPhase.Name = "lbPhase"
        Me.lbPhase.Size = New System.Drawing.Size(63, 25)
        Me.lbPhase.TabIndex = 132
        Me.lbPhase.Text = "3Φ"
        Me.lbPhase.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1209, 705)
        Me.Controls.Add(Me.chCanFD)
        Me.Controls.Add(Me.tbCANConfiginfo)
        Me.Controls.Add(Me.chDebugMode)
        Me.Controls.Add(Me.lbMode)
        Me.Controls.Add(Me.rbCANStatus)
        Me.Controls.Add(Me.lbPhase)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.lbModel)
        Me.Controls.Add(Me.cbBaudrate)
        Me.Controls.Add(Me.btStartCAN)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.cbDeviceList)
        Me.Controls.Add(Me.laBaudrate)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.lbDevice)
        Me.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EVPS 11/22KW OBC Combo A3 - GUI Rev 1.0a  20 Apr 2023"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.gbAPMCtrl.ResumeLayout(False)
        Me.pnApmModeCtrl.ResumeLayout(False)
        Me.pnApmModeCtrl.PerformLayout()
        CType(Me.nudAPMCurr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudAPMVolt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbOBCCtrl.ResumeLayout(False)
        Me.pnModeCtrl.ResumeLayout(False)
        Me.pnModeCtrl.PerformLayout()
        CType(Me.nudOBCPower, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudOBCCurr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudOBCVolt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.gbSecDebCtrl.ResumeLayout(False)
        Me.gbSecDebCtrl.PerformLayout()
        CType(Me.nudBurstDty, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPhaseShift, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudFrequency, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbPriDebCtrl.ResumeLayout(False)
        Me.gbPriDebCtrl.PerformLayout()
        CType(Me.nudKi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.gbOBCInfo.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.pnSecDeb.ResumeLayout(False)
        Me.pnSecDeb.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.pnPriDeb.ResumeLayout(False)
        Me.pnPriDeb.PerformLayout()
        Me.gbAPMinfo.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents cbDeviceList As ComboBox
    Private WithEvents lbDevice As Label
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents chDebugMode As CheckBox
    Friend WithEvents btStartCAN As Button
    Private WithEvents chCanFD As CheckBox
    Private WithEvents cbBaudrate As ComboBox
    Private WithEvents laBaudrate As Label
    Private WithEvents tbCANConfiginfo As TextBox
    Friend WithEvents rbCANStatus As RadioButton
    Friend WithEvents ComTmr As Timer
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents gbOBCCtrl As GroupBox
    Friend WithEvents nudOBCCurr As NumericUpDown
    Friend WithEvents nudOBCVolt As NumericUpDown
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents gbAPMCtrl As GroupBox
    Friend WithEvents nudAPMCurr As NumericUpDown
    Friend WithEvents nudAPMVolt As NumericUpDown
    Friend WithEvents VoltUnit As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents CurrentUnit As Label
    Friend WithEvents gbOBCInfo As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents gbAPMinfo As GroupBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents tbCanLog As RichTextBox
    Friend WithEvents lbModel As Label
    Friend WithEvents chAPMCtrlmsg As CheckBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lbMode As Label
    Friend WithEvents chOBCCtrlmsg As CheckBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents rbSleep As RadioButton
    Private WithEvents cbObcBcCyTime As ComboBox
    Private WithEvents Label11 As Label
    Friend WithEvents rbReverse As RadioButton
    Friend WithEvents rbForward As RadioButton
    Friend WithEvents rbStandby As RadioButton
    Private WithEvents tmrDisplay As Timer
    Friend WithEvents sBit07 As Panel
    Friend WithEvents Label209 As Label
    Friend WithEvents sBit10 As Panel
    Friend WithEvents sBit14 As Panel
    Friend WithEvents sBit04 As Panel
    Friend WithEvents sBit12 As Panel
    Friend WithEvents sBit16 As Panel
    Friend WithEvents sBit06 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents sBit11 As Panel
    Friend WithEvents sBit15 As Panel
    Friend WithEvents sBit05 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents sBit13 As Panel
    Friend WithEvents sBit17 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents pnSecDeb As Panel
    Friend WithEvents tbIout1 As TextBox
    Friend WithEvents tbIout As TextBox
    Friend WithEvents tbVbulk As TextBox
    Friend WithEvents tbVout As TextBox
    Friend WithEvents tbVauxSec As TextBox
    Friend WithEvents tbIpri2 As TextBox
    Friend WithEvents tbTRes2 As TextBox
    Friend WithEvents tbIpri1 As TextBox
    Friend WithEvents tbTRes1 As TextBox
    Friend WithEvents tbIpriTot As TextBox
    Friend WithEvents tbTClllcS2 As TextBox
    Friend WithEvents tbIout2 As TextBox
    Friend WithEvents tbTClllcS1 As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label127 As Label
    Friend WithEvents tbFreq2 As TextBox
    Friend WithEvents tbFreq1 As TextBox
    Friend WithEvents tbPS2 As TextBox
    Friend WithEvents tbPS1 As TextBox
    Friend WithEvents tbBurstDty2 As TextBox
    Friend WithEvents tbBurstDty1 As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents tbIshareStat As TextBox
    Friend WithEvents tbSRStat As TextBox
    Friend WithEvents tbCCorCV As TextBox
    Friend WithEvents tbCtrlMode As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents tbSecFwRev As TextBox
    Friend WithEvents sBit20 As Panel
    Friend WithEvents sBit22 As Panel
    Friend WithEvents sBit21 As Panel
    Friend WithEvents sBit23 As Panel
    Friend WithEvents tbSDeb6 As TextBox
    Friend WithEvents sBit30 As Panel
    Friend WithEvents tbSDeb3 As TextBox
    Friend WithEvents sBit32 As Panel
    Friend WithEvents sBit31 As Panel
    Friend WithEvents sBit33 As Panel
    Friend WithEvents Label75 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents sBit24 As Panel
    Friend WithEvents sBit26 As Panel
    Friend WithEvents tbSDeb5 As TextBox
    Friend WithEvents sBit25 As Panel
    Friend WithEvents sBit27 As Panel
    Friend WithEvents tbSDeb2 As TextBox
    Friend WithEvents Label70 As Label
    Friend WithEvents tbSDeb4 As TextBox
    Friend WithEvents Label69 As Label
    Friend WithEvents tbIshareAdj As TextBox
    Friend WithEvents Label68 As Label
    Friend WithEvents tbSDeb1 As TextBox
    Friend WithEvents Label67 As Label
    Friend WithEvents sBit34 As Panel
    Friend WithEvents tbIshareErr As TextBox
    Friend WithEvents Label66 As Label
    Friend WithEvents sBit36 As Panel
    Friend WithEvents sBit35 As Panel
    Friend WithEvents Label65 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents sBit37 As Panel
    Friend WithEvents Label59 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents chSecDeb2 As CheckBox
    Friend WithEvents chSecDeb1 As CheckBox
    Friend WithEvents Label77 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents tbSecState As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents chOBCSafetymsg As CheckBox
    Friend WithEvents Label27 As Label
    Private WithEvents TxTimer As Timer
    Friend WithEvents tbPriState As TextBox
    Friend WithEvents pnPriDeb As Panel
    Friend WithEvents tbPTclllcP2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents sPBit20 As Panel
    Friend WithEvents tbPTclllcP1 As TextBox
    Friend WithEvents sPBit22 As Panel
    Friend WithEvents tbPriFwRev As TextBox
    Friend WithEvents tbIphaseC As TextBox
    Friend WithEvents sPBit21 As Panel
    Friend WithEvents tbPVaux As TextBox
    Friend WithEvents sPBit23 As Panel
    Friend WithEvents tbPDeb6 As TextBox
    Friend WithEvents sPBit30 As Panel
    Friend WithEvents tbPDeb3 As TextBox
    Friend WithEvents sPBit32 As Panel
    Friend WithEvents sPBit31 As Panel
    Friend WithEvents sPBit33 As Panel
    Friend WithEvents tbPTnpcC As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents tbIphaseB As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents tbPVbulk As TextBox
    Friend WithEvents Label79 As Label
    Friend WithEvents tbIphaseA As TextBox
    Friend WithEvents Label80 As Label
    Friend WithEvents tbPIacC As TextBox
    Friend WithEvents Label81 As Label
    Friend WithEvents sPBit24 As Panel
    Friend WithEvents tbPVacC As TextBox
    Friend WithEvents sPBit26 As Panel
    Friend WithEvents tbPDeb5 As TextBox
    Friend WithEvents sPBit25 As Panel
    Friend WithEvents Label83 As Label
    Friend WithEvents sPBit27 As Panel
    Friend WithEvents tbPDeb2 As TextBox
    Friend WithEvents Label84 As Label
    Friend WithEvents tbPDeb4 As TextBox
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents tbPDeb1 As TextBox
    Friend WithEvents Label87 As Label
    Friend WithEvents sPBit34 As Panel
    Friend WithEvents Label88 As Label
    Friend WithEvents sPBit36 As Panel
    Friend WithEvents tbPTnpcB As TextBox
    Friend WithEvents sPBit35 As Panel
    Friend WithEvents tbPTnpcA As TextBox
    Friend WithEvents Label89 As Label
    Friend WithEvents tbPIacB As TextBox
    Friend WithEvents Label90 As Label
    Friend WithEvents sPBit37 As Panel
    Friend WithEvents Label92 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents tbPVacB As TextBox
    Friend WithEvents Label97 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Label113 As Label
    Friend WithEvents Label115 As Label
    Friend WithEvents Label116 As Label
    Friend WithEvents Label117 As Label
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents Label120 As Label
    Friend WithEvents Label121 As Label
    Friend WithEvents Label138 As Label
    Friend WithEvents tbPVbulkMid As TextBox
    Friend WithEvents Label122 As Label
    Friend WithEvents tbPIacA As TextBox
    Friend WithEvents Label137 As Label
    Friend WithEvents Label124 As Label
    Friend WithEvents Label136 As Label
    Friend WithEvents sPBit11 As Panel
    Friend WithEvents sPBit17 As Panel
    Friend WithEvents Label125 As Label
    Friend WithEvents Label135 As Label
    Friend WithEvents Label126 As Label
    Friend WithEvents Label128 As Label
    Friend WithEvents tbPVacA As TextBox
    Friend WithEvents Label129 As Label
    Friend WithEvents sPBit16 As Panel
    Friend WithEvents Label130 As Label
    Friend WithEvents sPBit10 As Panel
    Friend WithEvents sPBit07 As Panel
    Friend WithEvents Label134 As Label
    Friend WithEvents Label131 As Label
    Friend WithEvents sPBit14 As Panel
    Friend WithEvents sPBit05 As Panel
    Friend WithEvents sPBit15 As Panel
    Friend WithEvents sPBit12 As Panel
    Friend WithEvents sPBit04 As Panel
    Friend WithEvents sPBit13 As Panel
    Friend WithEvents Label133 As Label
    Friend WithEvents Label132 As Label
    Friend WithEvents sPBit06 As Panel
    Friend WithEvents Label123 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents chPriDeb2 As CheckBox
    Friend WithEvents Label91 As Label
    Friend WithEvents chPriDeb1 As CheckBox
    Friend WithEvents buGetPriFwRev As Button
    Friend WithEvents buGetSecFwRev As Button
    Friend WithEvents rbTestmode As RadioButton
    Friend WithEvents gbPriDebCtrl As GroupBox
    Friend WithEvents gbSecDebCtrl As GroupBox
    Friend WithEvents rbSecPwmOn2 As RadioButton
    Friend WithEvents rbSecPwmOn1 As RadioButton
    Friend WithEvents rbSecPwmOff As RadioButton
    Friend WithEvents buSecOLCmd As Button
    Friend WithEvents chPriFutMode As CheckBox
    Friend WithEvents nudBurstDty As NumericUpDown
    Friend WithEvents nudPhaseShift As NumericUpDown
    Friend WithEvents nudFrequency As NumericUpDown
    Friend WithEvents Label106 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label114 As Label
    Friend WithEvents Label112 As Label
    Friend WithEvents Label109 As Label
    Friend WithEvents lbPhase As Label
    Friend WithEvents pnModeCtrl As Panel
    Friend WithEvents Label140 As Label
    Friend WithEvents nudOBCPower As NumericUpDown
    Friend WithEvents Label139 As Label
    Friend WithEvents chSecDebInDec As CheckBox
    Friend WithEvents Label141 As Label
    Friend WithEvents chPriDebInDec As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents pnApmModeCtrl As Panel
    Friend WithEvents rbApmTest As RadioButton
    Friend WithEvents rbApmStby As RadioButton
    Friend WithEvents rbApmOff As RadioButton
    Friend WithEvents rbApmDcdc As RadioButton
    Friend WithEvents Label148 As Label
    Friend WithEvents tbApmCPVolt As TextBox
    Friend WithEvents tbApmCPDuty As TextBox
    Friend WithEvents tbApmCPFreq As TextBox
    Friend WithEvents tbApmPilState As TextBox
    Friend WithEvents tbApmHvdcCurr As TextBox
    Friend WithEvents tbApmProxVolt As TextBox
    Friend WithEvents tbApmProxState As TextBox
    Friend WithEvents tbApmHvdcVolt As TextBox
    Friend WithEvents Label158 As Label
    Friend WithEvents Label144 As Label
    Friend WithEvents Label156 As Label
    Friend WithEvents Label155 As Label
    Friend WithEvents Label143 As Label
    Friend WithEvents Label151 As Label
    Friend WithEvents Label152 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents tbApmVerBoot As TextBox
    Friend WithEvents Label142 As Label
    Friend WithEvents tbApmVerApp As TextBox
    Friend WithEvents tbApmMode As TextBox
    Friend WithEvents Label150 As Label
    Friend WithEvents Label153 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents tbApmIcmd As TextBox
    Friend WithEvents tbApmVcmd As TextBox
    Friend WithEvents Label146 As Label
    Friend WithEvents Label147 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents tbApmEvseImax As TextBox
    Friend WithEvents Label159 As Label
    Friend WithEvents tbApmHVAux As TextBox
    Friend WithEvents Label149 As Label
    Friend WithEvents tbApmLVIcmd As TextBox
    Friend WithEvents tbApmLVAux As TextBox
    Friend WithEvents Label154 As Label
    Friend WithEvents Label157 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents tbApmTcool As TextBox
    Friend WithEvents Label168 As Label
    Friend WithEvents tbApmTsr As TextBox
    Friend WithEvents tbApmTpcb As TextBox
    Friend WithEvents Label169 As Label
    Friend WithEvents Label170 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents tbApmBattVolt As TextBox
    Friend WithEvents Label145 As Label
    Friend WithEvents tbApmLVDCCurr As TextBox
    Friend WithEvents tbApmLVDCVolt As TextBox
    Friend WithEvents Label166 As Label
    Friend WithEvents Label167 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents sABit20 As Panel
    Friend WithEvents sABit10 As Panel
    Friend WithEvents sABit24 As Panel
    Friend WithEvents sABit14 As Panel
    Friend WithEvents sABit04 As Panel
    Friend WithEvents sABit22 As Panel
    Friend WithEvents sABit12 As Panel
    Friend WithEvents sABit26 As Panel
    Friend WithEvents sABit16 As Panel
    Friend WithEvents sABit06 As Panel
    Friend WithEvents sABit21 As Panel
    Friend WithEvents sABit11 As Panel
    Friend WithEvents sABit25 As Panel
    Friend WithEvents sABit15 As Panel
    Friend WithEvents sABit05 As Panel
    Friend WithEvents sABit23 As Panel
    Friend WithEvents sABit13 As Panel
    Friend WithEvents sABit27 As Panel
    Friend WithEvents sABit17 As Panel
    Friend WithEvents sABit07 As Panel
    Friend WithEvents Label196 As Label
    Friend WithEvents Label188 As Label
    Friend WithEvents Label195 As Label
    Friend WithEvents Label204 As Label
    Friend WithEvents Label194 As Label
    Friend WithEvents Label200 As Label
    Friend WithEvents Label187 As Label
    Friend WithEvents Label193 As Label
    Friend WithEvents Label203 As Label
    Friend WithEvents Label192 As Label
    Friend WithEvents Label199 As Label
    Friend WithEvents Label186 As Label
    Friend WithEvents Label191 As Label
    Friend WithEvents Label190 As Label
    Friend WithEvents Label198 As Label
    Friend WithEvents Label185 As Label
    Friend WithEvents Label189 As Label
    Friend WithEvents Label201 As Label
    Friend WithEvents Label197 As Label
    Friend WithEvents sABit40 As Panel
    Friend WithEvents sABit30 As Panel
    Friend WithEvents sABit44 As Panel
    Friend WithEvents sABit34 As Panel
    Friend WithEvents sABit42 As Panel
    Friend WithEvents sABit32 As Panel
    Friend WithEvents sABit46 As Panel
    Friend WithEvents sABit36 As Panel
    Friend WithEvents sABit41 As Panel
    Friend WithEvents sABit31 As Panel
    Friend WithEvents sABit45 As Panel
    Friend WithEvents sABit35 As Panel
    Friend WithEvents sABit43 As Panel
    Friend WithEvents sABit33 As Panel
    Friend WithEvents sABit47 As Panel
    Friend WithEvents sABit37 As Panel
    Friend WithEvents Label180 As Label
    Friend WithEvents Label179 As Label
    Friend WithEvents Label178 As Label
    Friend WithEvents Label177 As Label
    Friend WithEvents Label174 As Label
    Friend WithEvents Label173 As Label
    Friend WithEvents Label172 As Label
    Friend WithEvents Label171 As Label
    Friend WithEvents Label165 As Label
    Friend WithEvents Label164 As Label
    Friend WithEvents Label163 As Label
    Friend WithEvents Label161 As Label
    Friend WithEvents Label160 As Label
    Friend WithEvents sABit50 As Panel
    Friend WithEvents sABit54 As Panel
    Friend WithEvents sABit52 As Panel
    Friend WithEvents sABit56 As Panel
    Friend WithEvents sABit51 As Panel
    Friend WithEvents sABit55 As Panel
    Friend WithEvents sABit53 As Panel
    Friend WithEvents sABit57 As Panel
    Friend WithEvents Label208 As Label
    Friend WithEvents Label206 As Label
    Friend WithEvents Label205 As Label
    Friend WithEvents Label184 As Label
    Friend WithEvents Label183 As Label
    Friend WithEvents Label182 As Label
    Friend WithEvents Label181 As Label
    Friend WithEvents Label176 As Label
    Friend WithEvents Label202 As Label
    Friend WithEvents Label162 As Label
    Friend WithEvents Label175 As Label
    Friend WithEvents Label207 As Label
    Friend WithEvents nudKi As NumericUpDown
    Friend WithEvents nudKp As NumericUpDown
    Friend WithEvents Label211 As Label
    Friend WithEvents Label210 As Label
    Friend WithEvents buSetKi As Button
    Friend WithEvents buSetKp As Button
    Friend WithEvents btUpdateOBCCmd As Button
End Class
