﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class StartupForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btStartGui = New System.Windows.Forms.Button()
        Me.rbModel11kw = New System.Windows.Forms.RadioButton()
        Me.rbModel22kw = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbModeReverse = New System.Windows.Forms.RadioButton()
        Me.rbModeForward = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.rbGrid1Ph = New System.Windows.Forms.RadioButton()
        Me.rbGrid3Ph = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.rbAllLeg = New System.Windows.Forms.RadioButton()
        Me.rbLegA = New System.Windows.Forms.RadioButton()
        Me.rbLegB = New System.Windows.Forms.RadioButton()
        Me.rbLegC = New System.Windows.Forms.RadioButton()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'btStartGui
        '
        Me.btStartGui.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btStartGui.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btStartGui.Location = New System.Drawing.Point(183, 164)
        Me.btStartGui.Name = "btStartGui"
        Me.btStartGui.Size = New System.Drawing.Size(116, 43)
        Me.btStartGui.TabIndex = 119
        Me.btStartGui.Text = "Start GUI"
        '
        'rbModel11kw
        '
        Me.rbModel11kw.AutoSize = True
        Me.rbModel11kw.BackColor = System.Drawing.Color.PapayaWhip
        Me.rbModel11kw.Checked = True
        Me.rbModel11kw.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbModel11kw.Location = New System.Drawing.Point(28, 49)
        Me.rbModel11kw.Name = "rbModel11kw"
        Me.rbModel11kw.Size = New System.Drawing.Size(74, 24)
        Me.rbModel11kw.TabIndex = 120
        Me.rbModel11kw.TabStop = True
        Me.rbModel11kw.Text = "11 KW"
        Me.rbModel11kw.UseVisualStyleBackColor = False
        '
        'rbModel22kw
        '
        Me.rbModel22kw.AutoSize = True
        Me.rbModel22kw.BackColor = System.Drawing.Color.PapayaWhip
        Me.rbModel22kw.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbModel22kw.Location = New System.Drawing.Point(137, 49)
        Me.rbModel22kw.Name = "rbModel22kw"
        Me.rbModel22kw.Size = New System.Drawing.Size(74, 24)
        Me.rbModel22kw.TabIndex = 120
        Me.rbModel22kw.Text = "22 KW"
        Me.rbModel22kw.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.PapayaWhip
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(220, 60)
        Me.GroupBox1.TabIndex = 121
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Model"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.PapayaWhip
        Me.GroupBox2.Controls.Add(Me.rbModeReverse)
        Me.GroupBox2.Controls.Add(Me.rbModeForward)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(8, 80)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(220, 78)
        Me.GroupBox2.TabIndex = 121
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Mode"
        '
        'rbModeReverse
        '
        Me.rbModeReverse.AutoSize = True
        Me.rbModeReverse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbModeReverse.Location = New System.Drawing.Point(121, 25)
        Me.rbModeReverse.Name = "rbModeReverse"
        Me.rbModeReverse.Size = New System.Drawing.Size(86, 24)
        Me.rbModeReverse.TabIndex = 120
        Me.rbModeReverse.Text = "Reverse"
        Me.rbModeReverse.UseVisualStyleBackColor = True
        '
        'rbModeForward
        '
        Me.rbModeForward.AutoSize = True
        Me.rbModeForward.Checked = True
        Me.rbModeForward.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbModeForward.Location = New System.Drawing.Point(12, 25)
        Me.rbModeForward.Name = "rbModeForward"
        Me.rbModeForward.Size = New System.Drawing.Size(85, 24)
        Me.rbModeForward.TabIndex = 120
        Me.rbModeForward.TabStop = True
        Me.rbModeForward.Text = "Forward"
        Me.rbModeForward.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PapayaWhip
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.btStartGui)
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox4)
        Me.Panel1.Location = New System.Drawing.Point(6, 7)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(473, 218)
        Me.Panel1.TabIndex = 122
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.PapayaWhip
        Me.GroupBox3.Controls.Add(Me.rbGrid1Ph)
        Me.GroupBox3.Controls.Add(Me.rbGrid3Ph)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(234, 14)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(220, 60)
        Me.GroupBox3.TabIndex = 121
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Grid Type Selection"
        '
        'rbGrid1Ph
        '
        Me.rbGrid1Ph.AutoSize = True
        Me.rbGrid1Ph.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbGrid1Ph.Location = New System.Drawing.Point(117, 28)
        Me.rbGrid1Ph.Name = "rbGrid1Ph"
        Me.rbGrid1Ph.Size = New System.Drawing.Size(85, 24)
        Me.rbGrid1Ph.TabIndex = 120
        Me.rbGrid1Ph.Text = "1 Phase"
        Me.rbGrid1Ph.UseVisualStyleBackColor = True
        '
        'rbGrid3Ph
        '
        Me.rbGrid3Ph.AutoSize = True
        Me.rbGrid3Ph.Checked = True
        Me.rbGrid3Ph.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbGrid3Ph.Location = New System.Drawing.Point(20, 28)
        Me.rbGrid3Ph.Name = "rbGrid3Ph"
        Me.rbGrid3Ph.Size = New System.Drawing.Size(85, 24)
        Me.rbGrid3Ph.TabIndex = 120
        Me.rbGrid3Ph.TabStop = True
        Me.rbGrid3Ph.Text = "3 Phase"
        Me.rbGrid3Ph.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.PapayaWhip
        Me.GroupBox4.Controls.Add(Me.rbAllLeg)
        Me.GroupBox4.Controls.Add(Me.rbLegA)
        Me.GroupBox4.Controls.Add(Me.rbLegB)
        Me.GroupBox4.Controls.Add(Me.rbLegC)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(234, 80)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(220, 78)
        Me.GroupBox4.TabIndex = 121
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Select 1 Phase Leg"
        Me.GroupBox4.Visible = False
        '
        'rbAllLeg
        '
        Me.rbAllLeg.AutoSize = True
        Me.rbAllLeg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbAllLeg.Location = New System.Drawing.Point(103, 49)
        Me.rbAllLeg.Name = "rbAllLeg"
        Me.rbAllLeg.Size = New System.Drawing.Size(96, 24)
        Me.rbAllLeg.TabIndex = 120
        Me.rbAllLeg.Text = "All 3 Legs"
        Me.rbAllLeg.UseVisualStyleBackColor = True
        '
        'rbLegA
        '
        Me.rbLegA.AutoSize = True
        Me.rbLegA.Checked = True
        Me.rbLegA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbLegA.Location = New System.Drawing.Point(6, 23)
        Me.rbLegA.Name = "rbLegA"
        Me.rbLegA.Size = New System.Drawing.Size(69, 24)
        Me.rbLegA.TabIndex = 120
        Me.rbLegA.TabStop = True
        Me.rbLegA.Text = "Leg A"
        Me.rbLegA.UseVisualStyleBackColor = True
        '
        'rbLegB
        '
        Me.rbLegB.AutoSize = True
        Me.rbLegB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbLegB.Location = New System.Drawing.Point(103, 23)
        Me.rbLegB.Name = "rbLegB"
        Me.rbLegB.Size = New System.Drawing.Size(69, 24)
        Me.rbLegB.TabIndex = 120
        Me.rbLegB.Text = "Leg B"
        Me.rbLegB.UseVisualStyleBackColor = True
        '
        'rbLegC
        '
        Me.rbLegC.AutoSize = True
        Me.rbLegC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbLegC.Location = New System.Drawing.Point(6, 49)
        Me.rbLegC.Name = "rbLegC"
        Me.rbLegC.Size = New System.Drawing.Size(69, 24)
        Me.rbLegC.TabIndex = 120
        Me.rbLegC.Text = "Leg C"
        Me.rbLegC.UseVisualStyleBackColor = True
        '
        'StartupForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btStartGui
        Me.ClientSize = New System.Drawing.Size(484, 228)
        Me.ControlBox = False
        Me.Controls.Add(Me.rbModel22kw)
        Me.Controls.Add(Me.rbModel11kw)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "StartupForm"
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select Model & Mode"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btStartGui As Button
    Friend WithEvents rbModel11kw As RadioButton
    Friend WithEvents rbModel22kw As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbModeReverse As RadioButton
    Friend WithEvents rbModeForward As RadioButton
    Friend WithEvents Panel1 As Panel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents rbAllLeg As RadioButton
    Friend WithEvents rbLegC As RadioButton
    Friend WithEvents rbLegB As RadioButton
    Friend WithEvents rbLegA As RadioButton
    Friend WithEvents rbGrid1Ph As RadioButton
    Friend WithEvents rbGrid3Ph As RadioButton
    Friend WithEvents GroupBox4 As GroupBox
End Class
