﻿Imports System.Text
Imports System.Threading

Imports VB = Microsoft.VisualBasic

' Inclusion of PEAK PCAN-Basic namespace
'
Imports LOS_EVPS_11_22KW_OBC_Combo.Peak.Can.Basic
Imports TPCANHandle = System.UInt16
Imports TPCANBitrateFD = System.String
Imports TPCANTimestampFD = System.UInt64

Public Class Form1

#Region "Delegates"
    ''' Read-Delegate Handler
    Private Delegate Sub ReadDelegateHandler()
#End Region

#Region "Constant Declaration"
    Public Const MODEL_11KW = &H0
    Public Const MODEL_22KW = &H1

    Public Const GRID_PHASE_3 = &H0
    Public Const GRID_PHASE_1 = &H1

    Public Const PHASE_LEG_A = &H0
    Public Const PHASE_LEG_B = &H1
    Public Const PHASE_LEG_C = &H2
    Public Const PHASE_LEG_ALL = &H3

    Public Const VOUT_TARGET_MIN_11KW = 50 '250
    Public Const VOUT_TARGET_MAX_11KW = 470
    Public Const VOUT_TARGET_DEF_11KW = 450
    Public Const IOUT_TARGET_MAX_11KW = 37
    Public Const IOUT_TARGET_DEF_11KW = 24.44
    Public Const POUT_TARGET_MAX_11KW = 11.0
    Public Const POUT_TARGET_DEF_11KW = 1.0

    Public Const VOUT_TARGET_MIN_22KW = 400
    Public Const VOUT_TARGET_MAX_22KW = 920
    Public Const VOUT_TARGET_DEF_22KW = 900
    Public Const IOUT_TARGET_MAX_22KW = 37
    Public Const IOUT_TARGET_DEF_22KW = 24.44
    Public Const POUT_TARGET_MAX_22KW = 22.0
    Public Const POUT_TARGET_DEF_22KW = 2.0

    Public Const MODE_FORWARD = &H0
    Public Const MODE_REVERSE = &H1

    Public Const DISABLE = &H0
    Public Const ENABLE = &H1

    Public Const MAX_DEVICE_COUNT = &H8

    Public Const CLLLC_FREQ_FRWD_MAX = 300      '300kHz in 1000 hz Resolution
    Public Const CLLLC_FREQ_FRWD_MIN = 50       '35Khz in 1000Hz Resolution
    Public Const CLLLC_FREQ_REV_MAX = 300       '300Khz in 1000Hz Resolution
    Public Const CLLLC_FREQ_REV_MIN = 50       '35Khz in 1000Hz Resolution

    'CAN Port State's
    Public Const NO_DEVICE_FOUND = &H0
    Public Const DEVICES_FOUND = &H1
    Public Const DEVICE_CONNECTED = &H2
    Public Const DEVICE_DISCONNECTED = &H3
    Public Const DEVICE_REMOVED = &H4

#End Region

#Region "CAN Message Data Structure"
    Public Const MAX_OBC_BROADCAST_MSGS = 7

    'APM Rx Message ID's
    Public Const ID_APM_STATE_00 = &H210
    Public Const ID_APM_STATE_01 = &H211
    Public Const ID_APM_STATE_02 = &H212
    Public Const ID_APM_STATE_03 = &H213
    Public Const ID_APM_STATE_04 = &H214
    Public Const ID_APM_STATE_05 = &H215
    Public Const ID_APM_STATE_06 = &H216

    Public Const ID_APM_HVDC_DATA = &H11C
    Public Const ID_APM_VER_APPL = &H600
    Public Const ID_APM_VER_BOOT = &H601

    'APM Tx Message ID's
    Public Const ID_APM_CONTROL = &H200

    'OBC Common Tx Message ID's
    Public Const ID_OBC_CONTROL = &H100
    Public Const ID_OBC_SAFETY_CTRL = &H102

    'Primary Rx Message ID's
    Public Const ID_OBC_PRI_MAIN = &H110
    Public Const ID_OBC_PRI_DATA1 = &H130
    Public Const ID_OBC_PRI_DATA2 = &H131
    Public Const ID_OBC_PRI_DATA3 = &H132
    Public Const ID_OBC_PRI_DATA4 = &H133
    Public Const ID_OBC_PRI_FWREV = &H134
    Public Const ID_OBC_PRI_CALDATA = &H135
    Public Const ID_OBC_PRI_DEBDATA1 = &H136
    Public Const ID_OBC_PRI_DEBDATA2 = &H137

    'Primary Tx Message ID's
    Public Const ID_OBC_PRI_CTRL = &H108

    'Secondary Rx Message ID's
    Public Const ID_OBC_SEC_MAIN = &H120
    Public Const ID_OBC_SEC_DATA1 = &H140
    Public Const ID_OBC_SEC_DATA2 = &H141
    Public Const ID_OBC_SEC_DATA3 = &H142
    Public Const ID_OBC_SEC_DATA4 = &H143
    Public Const ID_OBC_SEC_FWREV = &H144
    Public Const ID_OBC_SEC_CALDATA = &H145
    Public Const ID_OBC_SEC_DEBDATA1 = &H146
    Public Const ID_OBC_SEC_DEBDATA2 = &H147

    'Secondary Tx Message ID's
    Public Const ID_OBC_SEC_CTRL = &H10A

    'Message Data Length
    Public Const STD_MSG_LENGTH = &H8

    'Message Data Types
    Public Const STATUS = &H0
    Public Const uDATA = &H1
    Public Const sDATA = &H2
    Public Const sTEMP = &H3
    Public Const FWREV = &H4
    Public Const DECDATA = &H5
    Public Const HEX8 = &H6
    Public Const HEX16 = &H7
    Public Const FREQDATA = &H8
    Public Const HEX16PRI = &H9
    Public Const HEX16SEC = &H10
    Public Const FWREVAPM = &H11

    'Tx Message Control Message Types
    Public Const CONTROL_READ = &H0
    Public Const CONTROL_WRITE = &H1
    Public Const CONTROL_COMMAND = &H2

    'Tx Message APM Control MODE Command
    Public Const CMD_APM_INVALID = &H0
    Public Const CMD_APM_OFF = &H1
    Public Const CMD_APM_STANDBY = &H2
    Public Const CMD_APM_DCDC = &H3
    Public Const CMD_APM_TEST = &HFF

    'Tx Message Control MODE Command
    Public Const CMD_SLEEP = &HA0
    Public Const CMD_STANDBY = &HA1
    Public Const CMD_FORWARD = &HA2
    Public Const CMD_REVERSE = &HA3
    Public Const CMD_TEST_FRWD = &HA4
    Public Const CMD_TEST_REV = &HA5

    'Tx Message Control MODE Command - Safety Reduntant 
    Public Const CMD_SAFETY_SLEEP = &HB0
    Public Const CMD_SAFETY_STANDBY = &HB1
    Public Const CMD_SAFETY_FORWARD = &HB2
    Public Const CMD_SAFETY_REVERSE = &HB3

    'Tx Message Pri Deb Message ID Pointer 
    Public Const ID_RD_PNTR_FWREV = &HF0
    Public Const ID_RD_PNTR_CALIB = &HD0
    Public Const ID_RD_PNTR_DEB1 = &HD1
    Public Const ID_RD_PNTR_DEB2 = &HD2

    Public Const ID_CMD_PNTR_DEB_EN = &HDA
    Public Const ID_CMD_PNTR_TEST_EN = &HDB

    Public Const ID_WR_NPC_KP = &HAA
    Public Const ID_WR_NPC_KI = &HAB

    Public Structure DataInfo
        Public Desc As String
        Public StartAddr As Byte
        Public Len As Byte
        Public Type As Byte
        Public Resol As Single
        Public UnitString As String
        Public DataString As String
    End Structure

    Public Structure CAN_MsgInfo

        Public Tstamp As String
        Public DataBuf() As Byte
        Public Id As UInteger
        Public IdDesc As String
        Public MsgCount As UInteger
        Public bDataChanged As Boolean
        Public bMsbFirst As Boolean

        Public DataGroupCount As Byte
        Public DataGroup() As DataInfo

        Public Sub New(ByVal first As String, ByVal second() As Byte, ByVal third As UInteger, ByVal fourth As String, ByVal fifth As UInteger, ByVal sixth As Boolean, ByVal seventh As Boolean, ByVal eighth As Byte, ByVal ninth() As DataInfo)
            Tstamp = first
            DataBuf(9) = second(9)
            Id = third
            IdDesc = fourth
            MsgCount = fifth
            bDataChanged = sixth
            bMsbFirst = seventh
            DataGroupCount = eighth
            DataGroup(6) = ninth(6)
        End Sub
    End Structure
    Dim CanMsg_DataStruct() As CAN_MsgInfo = {
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_MAIN, .IdDesc = "OBC SEC MAIN STATUS", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Sec. Status", .StartAddr = 0, .Len = 2, .Type = HEX16, .Resol = 0.0, .UnitString = "h", .DataString = ""},
                                            New DataInfo With {.Desc = "VOUT", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "IOUT", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "VBulk", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DATA1, .IdDesc = "OBC SEC DATA1", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 2,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Sec. Fault", .StartAddr = 0, .Len = 2, .Type = HEX16, .Resol = 0.0, .UnitString = "h", .DataString = ""},
                                            New DataInfo With {.Desc = "IPri Total", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "Aux Voltage Sec.", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DATA2, .IdDesc = "OBC SEC DATA2", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "IOUT1", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "IOUT2", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "IPri1", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "IPri2", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DATA3, .IdDesc = "OBC SEC DATA3", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 6,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "TClllc1", .StartAddr = 0, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "TClllc2", .StartAddr = 1, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "TClllc3", .StartAddr = 2, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "TClllc4", .StartAddr = 3, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "Ishare Error", .StartAddr = 4, .Len = 2, .Type = sDATA, .Resol = 0.1, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Ishare Adj", .StartAddr = 6, .Len = 2, .Type = sDATA, .Resol = 0.1, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DATA4, .IdDesc = "OBC SEC DATA4", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 6,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Control State", .StartAddr = 0, .Len = 1, .Type = HEX8, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Burst Duty", .StartAddr = 1, .Len = 1, .Type = uDATA, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Phase Shift 1", .StartAddr = 2, .Len = 1, .Type = uDATA, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Phase Shift 2", .StartAddr = 3, .Len = 1, .Type = uDATA, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Frequency 1", .StartAddr = 4, .Len = 2, .Type = FREQDATA, .Resol = 0.1, .UnitString = "khz", .DataString = ""},
                                            New DataInfo With {.Desc = "Frequency 2", .StartAddr = 6, .Len = 2, .Type = FREQDATA, .Resol = 0.1, .UnitString = "khz", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_FWREV, .IdDesc = "OBC SEC FW REV", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 1,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Firmware Rev.", .StartAddr = 0, .Len = 8, .Type = FWREV, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DEBDATA1, .IdDesc = "OBC SEC Debug Data 1", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Debug Data 1", .StartAddr = 0, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 2", .StartAddr = 2, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 3", .StartAddr = 4, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_SEC_DEBDATA2, .IdDesc = "OBC SEC Debug Data 2", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Debug Data 4", .StartAddr = 0, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 5", .StartAddr = 2, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 6", .StartAddr = 4, .Len = 2, .Type = HEX16SEC, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_MAIN, .IdDesc = "OBC PRI MAIN STATUS", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Pri. Status", .StartAddr = 0, .Len = 2, .Type = HEX16, .Resol = 0.0, .UnitString = "h", .DataString = ""},
                                            New DataInfo With {.Desc = "Vac A", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Iac A", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "VBulk Mid", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DATA1, .IdDesc = "OBC PRI DATA1", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Pri. Fault", .StartAddr = 0, .Len = 2, .Type = HEX16, .Resol = 1.0, .UnitString = "h", .DataString = ""},
                                            New DataInfo With {.Desc = "Pri T Fault", .StartAddr = 2, .Len = 1, .Type = HEX8, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Aux Voltage", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DATA2, .IdDesc = "OBC PRI DATA2", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Vac B", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Vac C", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Iac B", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "Iac C", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DATA3, .IdDesc = "OBC PRI DATA3", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "I Phase A", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "I Phase B", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "I Phase C", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "VBulk", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DATA4, .IdDesc = "OBC PRI DATA4", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 5,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "T_NPC_A", .StartAddr = 0, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T_NPC_B", .StartAddr = 1, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T_NPC_C", .StartAddr = 2, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T_Clllc S1", .StartAddr = 3, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T_Clllc S2", .StartAddr = 4, .Len = 1, .Type = sTEMP, .Resol = 1.0, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_FWREV, .IdDesc = "OBC PRI FW REV", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 1,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Firmware Rev.", .StartAddr = 0, .Len = 8, .Type = FWREV, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DEBDATA1, .IdDesc = "OBC PRI Debug Data 1", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Debug Data 1", .StartAddr = 0, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 2", .StartAddr = 2, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 3", .StartAddr = 4, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_OBC_PRI_DEBDATA2, .IdDesc = "OBC PRI Debug Data 2", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = False, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Debug Data 4", .StartAddr = 0, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 5", .StartAddr = 2, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "Debug Data 6", .StartAddr = 4, .Len = 2, .Type = HEX16PRI, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_00, .IdDesc = "APM STATUS 0", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "APM Status", .StartAddr = 0, .Len = 1, .Type = HEX8, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "APM Status 0", .StartAddr = 1, .Len = 1, .Type = HEX8, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "APM Error 0", .StartAddr = 2, .Len = 2, .Type = HEX16, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "APM Error 1", .StartAddr = 4, .Len = 2, .Type = HEX16, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_01, .IdDesc = "APM STATUS 1", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 5,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Proximity Voltage", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Pilot Voltage", .StartAddr = 3, .Len = 1, .Type = uDATA, .Resol = 0.1, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Pilot Duty", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "%", .DataString = ""},
                                            New DataInfo With {.Desc = "Pilot Frequency", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "Hz", .DataString = ""},
                                            New DataInfo With {.Desc = "CP PP State", .StartAddr = 2, .Len = 1, .Type = HEX8, .Resol = 1.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_02, .IdDesc = "APM STATUS 2", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "LVDC Rem. Voltage", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "LVDC Voltage", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "LVDC Current", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "Battery Voltage", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_03, .IdDesc = "APM STATUS 3", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 2,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "HVDC Voltage", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "HVDC Voltage", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.001, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_04, .IdDesc = "APM STATUS 4", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 3,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "T PCB", .StartAddr = 0, .Len = 2, .Type = sDATA, .Resol = 0.01, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T SR", .StartAddr = 2, .Len = 2, .Type = sDATA, .Resol = 0.01, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "T Coolant", .StartAddr = 4, .Len = 2, .Type = sDATA, .Resol = 0.01, .UnitString = "'C", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_05, .IdDesc = "APM STATUS 5", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "HV Aux Volt", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "EVSE Imax", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "LVDC ICmd Adj", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.1, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "LV Aux Volt", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_STATE_06, .IdDesc = "APM STATUS 6", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 4,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Boost Volt", .StartAddr = 0, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "Boost Current", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "LV Vcmd Duty", .StartAddr = 4, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "%", .DataString = ""},
                                            New DataInfo With {.Desc = "LV Icmd Duty", .StartAddr = 6, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "%", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_HVDC_DATA, .IdDesc = "APM HVDC DATA INFO", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 2,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "HVDC Current", .StartAddr = 0, .Len = 1, .Type = uDATA, .Resol = 0.01, .UnitString = "V", .DataString = ""},
                                            New DataInfo With {.Desc = "HVDC Voltage", .StartAddr = 2, .Len = 2, .Type = uDATA, .Resol = 0.01, .UnitString = "A", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_VER_APPL, .IdDesc = "APM Version App.", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 1,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Application Rev.", .StartAddr = 0, .Len = 8, .Type = FWREVAPM, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             },
        New CAN_MsgInfo With {.Tstamp = "", .DataBuf = {0, 0, 0, 0, 0, 0, 0, 0}, .Id = ID_APM_VER_BOOT, .IdDesc = "APM Version Boot.", .MsgCount = 0, .bDataChanged = False, .bMsbFirst = True, .DataGroupCount = 1,
                              .DataGroup = {
                                            New DataInfo With {.Desc = "Bootloader Rev.", .StartAddr = 0, .Len = 8, .Type = FWREVAPM, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""},
                                            New DataInfo With {.Desc = "", .StartAddr = 0, .Len = 0, .Type = 0, .Resol = 0.0, .UnitString = "", .DataString = ""}
                                           }
                             }
    }

#End Region

#Region "CAN Message Status Class"
    ''' <summary>
    ''' Message Status structure used to Update CAN Messages to Array List
    ''' </summary>
    Private MsgIndexCount As UInteger = 0

    Private Class MessageStatus
        Private MsgIndex As UInteger
        Private TimeStamp As TPCANTimestampFD
        Private Msg As TPCANMsgFD
        Private MsgCount As UInteger
        Private CANStructIndex As UInteger
        Private bDataChanged As Boolean

        Public Sub New(ByVal cantimestamp As TPCANTimestampFD, ByVal canmsg As TPCANMsgFD, ByVal msglistindex As Integer)
            MsgIndex = msglistindex
            TimeStamp = cantimestamp
            Msg = canmsg
            MsgCount = 1
            bDataChanged = True
        End Sub

        Public Sub Update(ByVal cantimestamp As TPCANTimestampFD, ByVal canmsg As TPCANMsgFD)
            TimeStamp = cantimestamp
            Msg = canmsg
            MsgCount += 1
            bDataChanged = True
        End Sub
        Public ReadOnly Property CANMsg() As TPCANMsgFD
            Get
                Return Msg
            End Get
        End Property
    End Class
#End Region

#Region "Variable Declaration"
    Public Model As UInteger = MODEL_11KW     ' 0 - 11KW, 1 - 22KW
    Public Mode As UInteger = MODE_FORWARD    ' 0 - Forward ,  1- Reverse

    Public GridPhase As UInteger = GRID_PHASE_3     '0 - 3 Ph, 1 - 1 Ph
    Public SinglePhLeg As UInteger = PHASE_LEG_A    '0 - Leg A, 1 - Leg B, 2 - Leg C, 3 - All 3 Legs

    Public Ready As Boolean = False

    Public CANFDMode As Boolean = False

    Dim ScannedDeviceList(MAX_DEVICE_COUNT) As String
    Dim DeviceList(MAX_DEVICE_COUNT) As String

    Public Structure candevice_t
        Public State As UInteger
        Public DeviceCount As UInteger
        Public Connected As Boolean
    End Structure

    Dim CANdevice As candevice_t

    Dim CanLogLineNo As UInteger

    'Tx Variables
    Dim SendDebCtrlCmd As Boolean = False
    Dim CANTxMsg As TPCANMsgFD

    Dim ObcBcCycleTimeCount As Byte = 0
    Dim TxBrdcstMcuPntr As Byte = 0
    Dim TxBroadcastPntr As Byte = 0
    Dim TxBroadcast As Boolean = False
    Dim TxBrdcstMsgCount As Byte = 0
    Dim TxBroadcastState(MAX_OBC_BROADCAST_MSGS) As Boolean

    Dim ObcVtarget As Single = 0.0
    Dim ObcItarget As Single = 0.0
    Dim ObcPtarget As Single = 0.0

    Dim TxBcApmControl As Boolean = False
    Dim TxBcOBCControl As Boolean = False
    Dim TxBcOBCSafety As Boolean = False
    Dim TxBcOBCPriDeb1 As Boolean = False
    Dim TxBcOBCPriDeb2 As Boolean = False
    Dim TxBcOBCSecDeb1 As Boolean = False
    Dim TxBcOBCSecDeb2 As Boolean = False

    Dim TxAliveCounter As UInteger = 0

    Dim TxPriFWRevReq As Boolean = False
    Dim TxSecFWRevReq As Boolean = False

    Dim TxPriFutCmdReq As Boolean = False
    Dim TxSecOLCmdReq As Boolean = False

    Dim TxPriSetReqKp As Boolean = False
    Dim TxPriSetReqKi As Boolean = False

    Dim ClllcFreqMax As UInteger = 140    '140kHz in 1000 hz Resolution
    Dim ClllcFreqMin As UInteger = 50     '50kHz in 1000 hz Resolution

    Dim NpcParamByte As Byte() = {0, 0, 0, 0, 0, 0}

    'Members 
    Private PcanHandle As TPCANHandle
    Private Baudrate As TPCANBaudrate

    'Threads 
    ''' Thread for message reading (using events)
    Private CANReadThread As System.Threading.Thread
    ''' Receive-Event
    Private ReceiveEvent As System.Threading.AutoResetEvent
    ''' Read Delegate for calling the function "SelectModeAndRead"
    Private ReadDelegate As ReadDelegateHandler


#End Region

#Region "System Functions"
    Public Sub New()

        ' Initializes Form's component
        '
        InitializeComponent()

        ' Initializes specific components
        '                '
        InitializeBasicComponents()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Model = MODEL_11KW Then
            lbModel.Text = "11KW"
            nudOBCVolt.Minimum = VOUT_TARGET_MIN_11KW
            nudOBCVolt.Maximum = VOUT_TARGET_MAX_11KW
            nudOBCCurr.Maximum = IOUT_TARGET_MAX_11KW
            nudOBCPower.Maximum = POUT_TARGET_MAX_11KW
            nudOBCVolt.Value = VOUT_TARGET_DEF_11KW
            nudOBCCurr.Value = IOUT_TARGET_DEF_11KW
            nudOBCPower.Value = POUT_TARGET_DEF_11KW
        ElseIf Model = MODEL_22KW Then
            lbModel.Text = "22KW"
            nudOBCVolt.Minimum = VOUT_TARGET_MIN_22KW
            nudOBCVolt.Maximum = VOUT_TARGET_MAX_22KW
            nudOBCCurr.Maximum = IOUT_TARGET_MAX_22KW
            nudOBCPower.Maximum = POUT_TARGET_MAX_22KW
            nudOBCVolt.Value = VOUT_TARGET_DEF_22KW
            nudOBCCurr.Value = IOUT_TARGET_DEF_22KW
            nudOBCPower.Value = POUT_TARGET_DEF_22KW
        End If

        If Mode = MODE_FORWARD Then
            lbMode.Text = "Forward"
            rbForward.Visible = True
            rbReverse.Visible = False

            nudFrequency.Maximum = CLLLC_FREQ_FRWD_MAX
            nudFrequency.Minimum = CLLLC_FREQ_FRWD_MIN

            ClllcFreqMax = CLLLC_FREQ_FRWD_MAX
            ClllcFreqMin = CLLLC_FREQ_FRWD_MIN
        ElseIf Mode = MODE_REVERSE Then
            lbMode.Text = "Reverse"
            rbForward.Visible = False
            rbReverse.Visible = True
            nudOBCVolt.Enabled = False
            nudOBCCurr.Enabled = False

            nudFrequency.Maximum = CLLLC_FREQ_REV_MAX
            nudFrequency.Minimum = CLLLC_FREQ_REV_MIN

            ClllcFreqMax = CLLLC_FREQ_REV_MAX
            ClllcFreqMin = CLLLC_FREQ_REV_MIN
        End If

        If GridPhase = GRID_PHASE_3 Then
            lbPhase.Text = "3Φ"
        Else
            If SinglePhLeg = PHASE_LEG_A Then
                lbPhase.Text = "1Φ A"
            ElseIf SinglePhLeg = PHASE_LEG_B Then
                lbPhase.Text = "1Φ B"
            ElseIf SinglePhLeg = PHASE_LEG_C Then
                lbPhase.Text = "1Φ C"
            ElseIf SinglePhLeg = PHASE_LEG_ALL Then
                lbPhase.Text = "1Φ All"
            End If
        End If

        cbObcBcCyTime.SelectedIndex = 10

        ObcVtarget = nudOBCVolt.Value
        ObcItarget = nudOBCCurr.Value
        ObcPtarget = nudOBCPower.Value

    End Sub

    Private Sub InitializeBasicComponents()
        'Initialize CAN Device Status
        CANdevice.State = NO_DEVICE_FOUND
        CANdevice.Connected = False
        UpdateDeviceList(0)

        ' Creates the event used for signalize incomming messages 
        ReceiveEvent = New System.Threading.AutoResetEvent(False)

        ' Creates the delegate used for message reading
        ReadDelegate = New ReadDelegateHandler(AddressOf SelectModeAndRead)

        'Init CAN Tx Messages
        CANTxMsg = New TPCANMsgFD()
        CANTxMsg.DATA = CType(Array.CreateInstance(GetType(Byte), 64), Byte())
    End Sub

#End Region

#Region "UI Control Handler"
    Private Sub btStartCAN_Click(sender As Object, e As EventArgs) Handles btStartCAN.Click
        Dim stsResult As TPCANStatus

        If btStartCAN.Text = "Start CAN" Then
            If chCanFD.Checked = True Then
                ' Flexible Data Rate  Mode Selected
                stsResult = PCANBasic.InitializeFD(PcanHandle, tbCANConfiginfo.Text)

                tbCANConfiginfo.Text = "Flexible Data (CAN FD) Rate :- " & tbCANConfiginfo.Text
            Else
                ' Fixed Data Rate Mode Selected
                stsResult = PCANBasic.Initialize(PcanHandle, Baudrate, 0, 0, 0)

                tbCANConfiginfo.Text = "Fixed Data Rate :- " & cbBaudrate.Text
            End If


            If stsResult <> TPCANStatus.PCAN_ERROR_OK Then
                If stsResult <> TPCANStatus.PCAN_ERROR_CAUTION Then
                    MessageBox.Show(GetFormatedError(stsResult))
                    AppendLog("Error : -" & GetFormatedError(stsResult), True)
                Else
                    AppendLog("******************************************************", False)
                    AppendLog("The bitrate being used is different than the given one", True)
                    AppendLog("******************************************************", False)
                    stsResult = TPCANStatus.PCAN_ERROR_OK
                End If
            Else
                AppendLog("Connected to a selected PCAN-Basic channel", True)

                'Enable Controls and Status data's
                EnDisCANdataControls(ENABLE)
                CANdevice.Connected = True
                rbCANStatus.Checked = True
                rbCANStatus.Text = "CAN Online"
                rbCANStatus.BackColor = Color.LightGreen
                btStartCAN.Text = "Stop CAN"
                btStartCAN.BackColor = Color.Yellow

                'Start CAN Receive Thread
                Dim threadDelegate As New System.Threading.ThreadStart(AddressOf Me.CANReceiveThread)
                CANReadThread = New System.Threading.Thread(threadDelegate)
                CANReadThread.IsBackground = True
                CANReadThread.Start()

                'Enable UI Update Timer
                tmrDisplay.Enabled = True
            End If
        Else
            PCANBasic.Uninitialize(PcanHandle)
            EnDisCANdataControls(DISABLE)
            CANdevice.Connected = False
            rbCANStatus.Text = "CAN Offline"
            rbCANStatus.BackColor = Color.Red
            rbCANStatus.Checked = True
            btStartCAN.Text = "Start CAN"
            btStartCAN.BackColor = Color.Transparent

            'Stop CAN Receive Thread
            If CANReadThread IsNot Nothing Then
                CANReadThread.Abort()
                CANReadThread.Join()
                CANReadThread = Nothing
            End If

            'Disable UI Update Timer
            tmrDisplay.Enabled = False
        End If

    End Sub

    Private Sub chCanFD_CheckedChanged(sender As Object, e As EventArgs) Handles chCanFD.CheckedChanged
        If chCanFD.Checked = True Then
            cbBaudrate.Enabled = False
            CANFDMode = True
            tbCANConfiginfo.Text = "f_clock_mhz=20, nom_brp=5, nom_tseg1=2, nom_tseg2=1, nom_sjw=1, data_brp=2, data_tseg1=3, data_tseg2=1, data_sjw=1"
        Else
            cbBaudrate.Enabled = True
            tbCANConfiginfo.Text = ""
            CANFDMode = False
        End If
    End Sub

    Private Sub cbDeviceList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbDeviceList.SelectedIndexChanged
        Dim strTemp As String

        If Not cbDeviceList.Text = "NO Devices Found" Then
            strTemp = cbDeviceList.Text
            strTemp = strTemp.Substring(strTemp.IndexOf("("c) + 1, 3)
            strTemp = strTemp.Replace("h", " ").Trim(" ")
            PcanHandle = Convert.ToUInt16(strTemp, 16)
        End If
    End Sub
    Private Sub cbBaudrate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbBaudrate.SelectedIndexChanged
        ' Saves the current selected baudrate register code
        '
        Select Case cbBaudrate.SelectedIndex
            Case 0
                Baudrate = TPCANBaudrate.PCAN_BAUD_1M
                Exit Select
            Case 1
                Baudrate = TPCANBaudrate.PCAN_BAUD_800K
                Exit Select
            Case 2
                Baudrate = TPCANBaudrate.PCAN_BAUD_500K
                Exit Select
            Case 3
                Baudrate = TPCANBaudrate.PCAN_BAUD_250K
                Exit Select
            Case 4
                Baudrate = TPCANBaudrate.PCAN_BAUD_125K
                Exit Select
            Case 5
                Baudrate = TPCANBaudrate.PCAN_BAUD_100K
                Exit Select
            Case 6
                Baudrate = TPCANBaudrate.PCAN_BAUD_95K
                Exit Select
            Case 7
                Baudrate = TPCANBaudrate.PCAN_BAUD_83K
                Exit Select
            Case 8
                Baudrate = TPCANBaudrate.PCAN_BAUD_50K
                Exit Select
            Case 9
                Baudrate = TPCANBaudrate.PCAN_BAUD_47K
                Exit Select
            Case 10
                Baudrate = TPCANBaudrate.PCAN_BAUD_33K
                Exit Select
            Case 11
                Baudrate = TPCANBaudrate.PCAN_BAUD_20K
                Exit Select
            Case 12
                Baudrate = TPCANBaudrate.PCAN_BAUD_10K
                Exit Select
            Case 13
                Baudrate = TPCANBaudrate.PCAN_BAUD_5K
                Exit Select
        End Select
    End Sub
    Private Sub chDebugMode_CheckedChanged(sender As Object, e As EventArgs) Handles chDebugMode.CheckedChanged
        If chDebugMode.Checked = True Then
            pnSecDeb.Visible = True
            pnPriDeb.Visible = True
            gbSecDebCtrl.Visible = True
            gbPriDebCtrl.Visible = True
        Else
            pnSecDeb.Visible = False
            pnPriDeb.Visible = False
            gbSecDebCtrl.Visible = False
            gbPriDebCtrl.Visible = False
        End If

        SendDebCtrlCmd = True   'Start Sending Command For Debug Control
    End Sub

    Private Sub chAPMCtrlmsg_CheckedChanged(sender As Object, e As EventArgs) Handles chAPMCtrlmsg.CheckedChanged
        If chAPMCtrlmsg.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBcApmControl = True
            TxBroadcast = True

            pnApmModeCtrl.Enabled = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcApmControl = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If

            pnApmModeCtrl.Enabled = False
        End If
    End Sub

    Private Sub cbOBCCtrlmsg_CheckedChanged(sender As Object, e As EventArgs) Handles chOBCCtrlmsg.CheckedChanged
        If chOBCCtrlmsg.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCControl = True
            pnModeCtrl.Enabled = True

            If rbTestmode.Checked = True Then
                'Enable Open Loop/FUT Mode Controls
                chPriFutMode.Enabled = True

                rbSecPwmOff.Enabled = True
                rbSecPwmOn1.Enabled = True
                rbSecPwmOn2.Enabled = True
                nudBurstDty.Enabled = True
                nudPhaseShift.Enabled = True
                nudFrequency.Enabled = True
                buSecOLCmd.Enabled = True
            End If

        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCControl = False

            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If

            pnModeCtrl.Enabled = False

            'Enable Open Loop/FUT Mode Controls
            chPriFutMode.Enabled = False

            rbSecPwmOff.Enabled = False
            rbSecPwmOn1.Enabled = False
            rbSecPwmOn2.Enabled = False
            nudBurstDty.Enabled = False
            nudPhaseShift.Enabled = False
            nudFrequency.Enabled = False
            buSecOLCmd.Enabled = False
        End If
    End Sub

    Private Sub btUpdateOBCCmd_Click(sender As Object, e As EventArgs) Handles btUpdateOBCCmd.Click

        If Model = MODEL_11KW Then
            If nudOBCVolt.Value * nudOBCCurr.Value >= 12000 Then
                nudOBCCurr.Value = 12000 / nudOBCVolt.Value
            End If
        Else
            If nudOBCVolt.Value * nudOBCCurr.Value >= 24000 Then
                nudOBCCurr.Value = 24000 / nudOBCVolt.Value
            End If
        End If

        ObcVtarget = nudOBCVolt.Value
        ObcItarget = nudOBCCurr.Value
        ObcPtarget = nudOBCPower.Value

    End Sub

    Private Sub cbOBCSafetymsg_CheckedChanged(sender As Object, e As EventArgs) Handles chOBCSafetymsg.CheckedChanged
        If chOBCSafetymsg.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCSafety = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCSafety = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If
        End If
    End Sub
    Private Sub chPriDeb1_CheckedChanged(sender As Object, e As EventArgs) Handles chPriDeb1.CheckedChanged
        If chPriDeb1.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCPriDeb1 = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCPriDeb1 = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If
        End If
    End Sub

    Private Sub chPriDeb2_CheckedChanged(sender As Object, e As EventArgs) Handles chPriDeb2.CheckedChanged
        If chPriDeb2.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCPriDeb2 = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCPriDeb2 = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If
        End If
    End Sub

    Private Sub cbSecDeb1_CheckedChanged(sender As Object, e As EventArgs) Handles chSecDeb1.CheckedChanged
        If chSecDeb1.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCSecDeb1 = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCSecDeb1 = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If
        End If
    End Sub
    Private Sub cbSecDeb2_CheckedChanged(sender As Object, e As EventArgs) Handles chSecDeb2.CheckedChanged
        If chSecDeb2.Checked = True Then
            TxBrdcstMsgCount += 1
            TxBroadcast = True
            TxBcOBCSecDeb2 = True
        Else
            TxBrdcstMsgCount -= 1
            TxBcOBCSecDeb2 = False
            If TxBrdcstMsgCount = 0 Then
                TxBroadcast = False
            End If
        End If
    End Sub
    Private Sub buGetPriFwRev_Click(sender As Object, e As EventArgs) Handles buGetPriFwRev.Click
        TxPriFWRevReq = True
    End Sub

    Private Sub buGetSecFwRev_Click(sender As Object, e As EventArgs) Handles buGetSecFwRev.Click
        TxSecFWRevReq = True
    End Sub

    Private Sub buSetKp_Click(sender As Object, e As EventArgs) Handles buSetKp.Click
        Dim ByteArray() As Byte

        ByteArray = BitConverter.GetBytes(Convert.ToSingle(nudKp.Text))
        '  ByteArray = BitConverter.GetBytes(Convert.ToSingle("-2.0"))
        NpcParamByte(0) = ByteArray(0)
        NpcParamByte(1) = ByteArray(1)
        NpcParamByte(2) = ByteArray(2)
        NpcParamByte(3) = ByteArray(3)

        TxPriSetReqKp = True
    End Sub

    Private Sub buSetKi_Click(sender As Object, e As EventArgs) Handles buSetKi.Click
        Dim ByteArray() As Byte

        ByteArray = BitConverter.GetBytes(Convert.ToSingle(nudKi.Text))
        '  ByteArray = BitConverter.GetBytes(Convert.ToSingle("-2.0"))
        NpcParamByte(0) = ByteArray(0)
        NpcParamByte(1) = ByteArray(1)
        NpcParamByte(2) = ByteArray(2)
        NpcParamByte(3) = ByteArray(3)

        TxPriSetReqKi = True
    End Sub

    Private Sub rbForward_CheckedChanged(sender As Object, e As EventArgs) Handles rbForward.CheckedChanged, rbApmDcdc.CheckedChanged
        If rbForward.Checked = True Then
            rbTestmode.Enabled = False
        Else
            rbTestmode.Enabled = True
        End If
    End Sub
    Private Sub rbReverse_CheckedChanged(sender As Object, e As EventArgs) Handles rbReverse.CheckedChanged
        If rbReverse.Checked = True Then
            rbTestmode.Enabled = False
        Else
            rbTestmode.Enabled = True
        End If
    End Sub
    Private Sub rbTestmode_CheckedChanged(sender As Object, e As EventArgs) Handles rbTestmode.CheckedChanged, rbApmTest.CheckedChanged
        If rbTestmode.Checked = True Then
            If Mode = MODE_FORWARD Then
                rbForward.Enabled = False
            Else
                rbReverse.Enabled = False
            End If

            'Enable Open Loop/FUT Mode Controls
            chPriFutMode.Enabled = True

            rbSecPwmOff.Enabled = True
            rbSecPwmOn1.Enabled = True
            rbSecPwmOn2.Enabled = True
            nudBurstDty.Enabled = True
            nudPhaseShift.Enabled = True
            nudFrequency.Enabled = True
            buSecOLCmd.Enabled = True
        Else
            If Mode = MODE_FORWARD Then
                rbForward.Enabled = True
            Else
                rbReverse.Enabled = True
            End If

            'Disable Open Loop/FUT Mode Controls
            chPriFutMode.Enabled = False

            rbSecPwmOff.Enabled = False
            rbSecPwmOn1.Enabled = False
            rbSecPwmOn2.Enabled = False
            nudBurstDty.Enabled = False
            nudPhaseShift.Enabled = False
            nudFrequency.Enabled = False

            buSecOLCmd.Enabled = False
            If chPriFutMode.Checked = True Then
                chPriFutMode.Checked = False
                TxPriFutCmdReq = True
            End If
            If rbSecPwmOff.Checked = False Then
                rbSecPwmOff.Checked = True
                nudBurstDty.Value = 100
                nudPhaseShift.Value = 0
                nudFrequency.Value = ClllcFreqMax
                TxSecOLCmdReq = True
            End If
        End If
    End Sub

    Private Sub chPriFutMode_CheckedChanged(sender As Object, e As EventArgs) Handles chPriFutMode.CheckedChanged
        TxPriFutCmdReq = True
    End Sub

    Private Sub buSecOLCmd_Click(sender As Object, e As EventArgs) Handles buSecOLCmd.Click
        If rbSecPwmOff.Checked = False Then
            If rbSecPwmOn1.Checked = True Then
                rbSecPwmOn2.Enabled = False
            Else
                rbSecPwmOn1.Enabled = False
            End If
        Else
            rbSecPwmOn1.Enabled = True
            rbSecPwmOn2.Enabled = True
        End If

        TxSecOLCmdReq = True
    End Sub

#End Region

#Region "UI Data Handler"
    Private Sub UpdateSecMain(ByVal ArrPointer As UInteger)
        Dim IntAct As Integer
        Dim IntTemp As Integer

        ' OBC Module State
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(0) And &HF
        Select Case (IntTemp)
            Case &H0
                tbSecState.Text = "Sleep"
            Case &H1
                tbSecState.Text = "Standby"
            Case &H2
                tbSecState.Text = "G2V Start"
            Case &H3
                tbSecState.Text = "G2V Run"
            Case &H4
                tbSecState.Text = "V2G Start"
            Case &H5
                tbSecState.Text = "V2G Run"
            Case &H6
                tbSecState.Text = "Fault Reset"
            Case &H7
                tbSecState.Text = "Fault Latch"
            Case &H8
                tbSecState.Text = "Test Mode"
        End Select

        'Update OBC Main Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sBit04.BackColor = Color.Maroon
        Else
            sBit04.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sBit05.BackColor = Color.Maroon
        Else
            sBit05.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sBit06.BackColor = Color.Maroon
        Else
            sBit06.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sBit07.BackColor = Color.Maroon
        Else
            sBit07.BackColor = Color.Beige
        End If

        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(1)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sBit10.BackColor = Color.Maroon
        Else
            sBit10.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sBit11.BackColor = Color.Maroon
        Else
            sBit11.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sBit12.BackColor = Color.Maroon
        Else
            sBit12.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sBit13.BackColor = Color.Maroon
        Else
            sBit13.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sBit14.BackColor = Color.Maroon
        Else
            sBit14.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sBit15.BackColor = Color.Maroon
        Else
            sBit15.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sBit16.BackColor = Color.Maroon
        Else
            sBit16.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sBit17.BackColor = Color.Maroon
        Else
            sBit17.BackColor = Color.Beige
        End If

        tbVout.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbIout.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbVbulk.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdateSecData1(ByVal ArrPointer As UInteger)
        Dim IntAct As Integer
        Dim IntTemp As Integer

        'Update OBC Fault Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sBit20.BackColor = Color.Maroon
        Else
            sBit20.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sBit21.BackColor = Color.Maroon
        Else
            sBit21.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sBit22.BackColor = Color.Maroon
        Else
            sBit22.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sBit23.BackColor = Color.Maroon
        Else
            sBit23.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sBit24.BackColor = Color.Maroon
        Else
            sBit24.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sBit25.BackColor = Color.Maroon
        Else
            sBit25.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sBit26.BackColor = Color.Maroon
        Else
            sBit26.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sBit27.BackColor = Color.Maroon
        Else
            sBit27.BackColor = Color.Beige
        End If

        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(1)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sBit30.BackColor = Color.Maroon
        Else
            sBit30.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sBit31.BackColor = Color.Maroon
        Else
            sBit31.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sBit32.BackColor = Color.Maroon
        Else
            sBit32.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sBit33.BackColor = Color.Maroon
        Else
            sBit33.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sBit34.BackColor = Color.Maroon
        Else
            sBit34.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sBit35.BackColor = Color.Maroon
        Else
            sBit35.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sBit36.BackColor = Color.Maroon
        Else
            sBit36.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sBit37.BackColor = Color.Maroon
        Else
            sBit37.BackColor = Color.Beige
        End If

        'Total Primary Current
        tbIpriTot.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString

        'Secondray Auxilary Supply Voltage
        tbVauxSec.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString

    End Sub
    Private Sub UpdateSecData2(ByVal ArrPointer As UInteger)

        tbIout1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbIout2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbIpri1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbIpri2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString

    End Sub
    Private Sub UpdateSecData3(ByVal ArrPointer As UInteger)

        tbTClllcS1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbTClllcS2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbIshareErr.Text = CanMsg_DataStruct(ArrPointer).DataGroup(4).DataString
        tbIshareAdj.Text = CanMsg_DataStruct(ArrPointer).DataGroup(5).DataString

    End Sub
    Private Sub UpdateSecData4(ByVal ArrPointer As UInteger)

        Dim IntAct As Integer
        Dim IntTemp As Integer

        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H3
        Select Case IntTemp
            Case 0
                tbCtrlMode.Text = "Burst"
                Exit Select
            Case 1
                tbCtrlMode.Text = "PS+PFM"
                Exit Select
            Case 2
                tbCtrlMode.Text = "PFM"
                Exit Select
            Case 3
                tbCtrlMode.Text = "Inv"
                Exit Select
        End Select

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            tbCCorCV.Text = "CV"
        Else
            tbCCorCV.Text = "CC"
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            tbSRStat.Text = "SR Enabled"
        Else
            tbSRStat.Text = "SR Disabled"
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H8 Then
            tbIshareStat.Text = "Ishare EN"
        Else
            tbIshareStat.Text = "Ishare DIS"
        End If

        ' Clllc Burst Duty 
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(1) 'And &HF
        tbBurstDty1.Text = IntTemp.ToString

        'IntTemp = (CanMsg_DataStruct(ArrPointer).DataBuf(1) And &HF0) \ &H10
        'tbBurstDty2.Text = IntTemp.ToString

        tbPS1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbPS2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
        tbFreq1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(4).DataString
        tbFreq2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(5).DataString

    End Sub
    Private Sub UpdateSecFwRev(ByVal ArrPointer As UInteger)
        tbSecFwRev.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
    End Sub
    Private Sub UpdateSecDeb1(ByVal ArrPointer As UInteger)
        tbSDeb1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbSDeb2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbSDeb3.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
    End Sub
    Private Sub UpdateSecDeb2(ByVal ArrPointer As UInteger)
        tbSDeb4.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbSDeb5.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbSDeb6.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
    End Sub
    Private Sub UpdatePriMain(ByVal ArrPointer As UInteger)
        Dim IntAct As Integer
        Dim IntTemp As Integer

        ' OBC Module State
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(0) And &HF
        Select Case (IntTemp)
            Case &H0
                tbPriState.Text = "Sleep"
            Case &H1
                tbPriState.Text = "Standby"
            Case &H2
                tbPriState.Text = "Rectifier Start"
            Case &H3
                tbPriState.Text = "Rectifier Run"
            Case &H4
                tbPriState.Text = "Inverter Start"
            Case &H5
                tbPriState.Text = "Inverter Run"
            Case &H6
                tbPriState.Text = "Fault Reset"
            Case &H7
                tbPriState.Text = "Fault Latch"
            Case &H8
                tbPriState.Text = "Test Mode"
        End Select

        'Update OBC Main Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sPBit04.BackColor = Color.Maroon
        Else
            sPBit04.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sPBit05.BackColor = Color.Maroon
        Else
            sPBit05.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sPBit06.BackColor = Color.Maroon
        Else
            sPBit06.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sPBit07.BackColor = Color.Maroon
        Else
            sPBit07.BackColor = Color.Beige
        End If

        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(1)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sPBit10.BackColor = Color.Maroon
        Else
            sPBit10.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sPBit11.BackColor = Color.Maroon
        Else
            sPBit11.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sPBit12.BackColor = Color.Maroon
        Else
            sPBit12.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sPBit13.BackColor = Color.Maroon
        Else
            sPBit13.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sPBit14.BackColor = Color.Maroon
        Else
            sPBit14.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sPBit15.BackColor = Color.Maroon
        Else
            sPBit15.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sPBit16.BackColor = Color.Maroon
        Else
            sPBit16.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sPBit17.BackColor = Color.Maroon
        Else
            sPBit17.BackColor = Color.Beige
        End If

        tbPVacA.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbPIacA.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbPVbulkMid.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdatePriData1(ByVal ArrPointer As UInteger)
        Dim IntAct As Integer
        Dim IntTemp As Integer

        'Update OBC Fault Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sPBit20.BackColor = Color.Maroon
        Else
            sPBit20.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sPBit21.BackColor = Color.Maroon
        Else
            sPBit21.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sPBit22.BackColor = Color.Maroon
        Else
            sPBit22.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sPBit23.BackColor = Color.Maroon
        Else
            sPBit23.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sPBit24.BackColor = Color.Maroon
        Else
            sPBit24.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sPBit25.BackColor = Color.Maroon
        Else
            sPBit25.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sPBit26.BackColor = Color.Maroon
        Else
            sPBit26.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sPBit27.BackColor = Color.Maroon
        Else
            sPBit27.BackColor = Color.Beige
        End If

        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(1)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sPBit30.BackColor = Color.Maroon
        Else
            sPBit30.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sPBit31.BackColor = Color.Maroon
        Else
            sPBit31.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sPBit32.BackColor = Color.Maroon
        Else
            sPBit32.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sPBit33.BackColor = Color.Maroon
        Else
            sPBit33.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sPBit34.BackColor = Color.Maroon
        Else
            sPBit34.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sPBit35.BackColor = Color.Maroon
        Else
            sPBit35.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sPBit36.BackColor = Color.Maroon
        Else
            sPBit36.BackColor = Color.Beige
        End If
        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sPBit37.BackColor = Color.Maroon
        Else
            sPBit37.BackColor = Color.Beige
        End If

        'Primary Aux Voltages
        tbPVaux.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString

    End Sub
    Private Sub UpdatePriData2(ByVal ArrPointer As UInteger)
        tbPVacB.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbPVacC.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbPIacB.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbPIacC.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdatePriData3(ByVal ArrPointer As UInteger)
        tbIphaseA.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbIphaseB.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbIphaseC.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbPVbulk.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdatePriData4(ByVal ArrPointer As UInteger)
        tbPTnpcA.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbPTnpcB.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbPTnpcC.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbPTclllcP1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
        tbPTclllcP2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(4).DataString
    End Sub
    Private Sub UpdatePriFwRev(ByVal ArrPointer As UInteger)
        tbPriFwRev.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
    End Sub
    Private Sub UpdatePriDeb1(ByVal ArrPointer As UInteger)
        tbPDeb1.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbPDeb2.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbPDeb3.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
    End Sub
    Private Sub UpdatePriDeb2(ByVal ArrPointer As UInteger)
        tbPDeb4.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbPDeb5.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbPDeb6.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
    End Sub
    Private Sub UpdateApmState00(ByVal ArrPointer As UInteger)
        Dim IntAct As Integer
        Dim IntTemp As Integer

        ' APM Module State
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(0) And &HF
        Select Case (IntTemp)
            Case &H0
                tbApmMode.Text = "Invalid"
                Exit Select
            Case &H1
                tbApmMode.Text = "PowerON"
                Exit Select
            Case &H2
                tbApmMode.Text = "Standby"
                Exit Select
            Case &H3
                tbApmMode.Text = "Fault"
                Exit Select
            Case &H4
                tbApmMode.Text = "Idle"
                Exit Select
            Case &H5
                tbApmMode.Text = "SoftStart"
                Exit Select
            Case &H6
                tbApmMode.Text = "Active"
                Exit Select
            Case &H7
                tbApmMode.Text = "Precharge"
                Exit Select
            Case &H8
                tbApmMode.Text = "Discharge"
                Exit Select
            Case &H9
                tbApmMode.Text = "Flash"
                Exit Select
            Case &HA
                tbApmMode.Text = "Latch"
                Exit Select
            Case &HB
                tbApmMode.Text = "Sleep"
                Exit Select
            Case &HC
                tbApmMode.Text = "Diag"
                Exit Select
            Case &HF
                tbApmMode.Text = "Test"
                Exit Select
        End Select

        'Update APM Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(0)

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit04.BackColor = Color.Maroon
        Else
            sABit04.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit05.BackColor = Color.Maroon
        Else
            sABit05.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit06.BackColor = Color.Maroon
        Else
            sABit06.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit07.BackColor = Color.Maroon
        Else
            sABit07.BackColor = Color.Beige
        End If

        'Update APM Status Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(1)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sABit10.BackColor = Color.Maroon
        Else
            sABit10.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sABit11.BackColor = Color.Maroon
        Else
            sABit11.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sABit12.BackColor = Color.Maroon
        Else
            sABit12.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sABit13.BackColor = Color.Maroon
        Else
            sABit13.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit14.BackColor = Color.Maroon
        Else
            sABit14.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit15.BackColor = Color.Maroon
        Else
            sABit15.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit16.BackColor = Color.Maroon
        Else
            sABit16.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit17.BackColor = Color.Maroon
        Else
            sABit17.BackColor = Color.Beige
        End If

        'Update APM Error Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(2)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sABit20.BackColor = Color.Maroon
        Else
            sABit20.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sABit21.BackColor = Color.Maroon
        Else
            sABit21.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sABit22.BackColor = Color.Maroon
        Else
            sABit22.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sABit23.BackColor = Color.Maroon
        Else
            sABit23.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit24.BackColor = Color.Maroon
        Else
            sABit24.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit25.BackColor = Color.Maroon
        Else
            sABit25.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit26.BackColor = Color.Maroon
        Else
            sABit26.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit27.BackColor = Color.Maroon
        Else
            sABit27.BackColor = Color.Beige
        End If

        'Update APM Error Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(3)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sABit30.BackColor = Color.Maroon
        Else
            sABit30.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sABit31.BackColor = Color.Maroon
        Else
            sABit31.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sABit32.BackColor = Color.Maroon
        Else
            sABit32.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sABit33.BackColor = Color.Maroon
        Else
            sABit33.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit34.BackColor = Color.Maroon
        Else
            sABit34.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit35.BackColor = Color.Maroon
        Else
            sABit35.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit36.BackColor = Color.Maroon
        Else
            sABit36.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit37.BackColor = Color.Maroon
        Else
            sABit37.BackColor = Color.Beige
        End If

        'Update APM Error Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(4)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sABit40.BackColor = Color.Maroon
        Else
            sABit40.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sABit41.BackColor = Color.Maroon
        Else
            sABit41.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sABit42.BackColor = Color.Maroon
        Else
            sABit42.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sABit43.BackColor = Color.Maroon
        Else
            sABit43.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit44.BackColor = Color.Maroon
        Else
            sABit44.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit45.BackColor = Color.Maroon
        Else
            sABit45.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit46.BackColor = Color.Maroon
        Else
            sABit46.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit47.BackColor = Color.Maroon
        Else
            sABit47.BackColor = Color.Beige
        End If

        'Update APM Error Bits
        IntAct = CanMsg_DataStruct(ArrPointer).DataBuf(5)

        IntTemp = IntAct And &H1
        If IntTemp = &H1 Then
            sABit50.BackColor = Color.Maroon
        Else
            sABit50.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H2
        If IntTemp = &H2 Then
            sABit51.BackColor = Color.Maroon
        Else
            sABit51.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H4
        If IntTemp = &H4 Then
            sABit52.BackColor = Color.Maroon
        Else
            sABit52.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H8
        If IntTemp = &H8 Then
            sABit53.BackColor = Color.Maroon
        Else
            sABit53.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H10
        If IntTemp = &H10 Then
            sABit54.BackColor = Color.Maroon
        Else
            sABit54.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H20
        If IntTemp = &H20 Then
            sABit55.BackColor = Color.Maroon
        Else
            sABit55.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H40
        If IntTemp = &H40 Then
            sABit56.BackColor = Color.Maroon
        Else
            sABit56.BackColor = Color.Beige
        End If

        IntTemp = IntAct And &H80
        If IntTemp = &H80 Then
            sABit57.BackColor = Color.Maroon
        Else
            sABit57.BackColor = Color.Beige
        End If

    End Sub
    Private Sub UpdateApmState01(ByVal ArrPointer As UInteger)

        tbApmProxVolt.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbApmCPVolt.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbApmCPDuty.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbApmCPFreq.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString

        Dim IntTemp As Integer
        ' CP State
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(2) And &H7
        Select Case (IntTemp)
            Case &H0
                tbApmPilState.Text = "State A"
                Exit Select
            Case &H1
                tbApmPilState.Text = "State B"
                Exit Select
            Case &H2
                tbApmPilState.Text = "State C"
                Exit Select
            Case &H3
                tbApmPilState.Text = "State D"
                Exit Select
            Case &H4
                tbApmPilState.Text = "State E"
                Exit Select
            Case &H5
                tbApmPilState.Text = "State F"
                Exit Select
        End Select

        ' PP State
        IntTemp = CanMsg_DataStruct(ArrPointer).DataBuf(2) And &H18
        IntTemp >>= 3

        Select Case (IntTemp)
            Case &H0
                tbApmPilState.Text = "Discon."
                Exit Select
            Case &H1
                tbApmPilState.Text = "Depressed"
                Exit Select
            Case &H2
                tbApmPilState.Text = "Released"
                Exit Select
        End Select
    End Sub
    Private Sub UpdateApmState02(ByVal ArrPointer As UInteger)
        tbApmLVDCVolt.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbApmLVDCCurr.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbApmBattVolt.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdateApmState03(ByVal ArrPointer As UInteger)
        tbApmHvdcVolt.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbApmHvdcCurr.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
    End Sub
    Private Sub UpdateApmState04(ByVal ArrPointer As UInteger)
        tbApmTpcb.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbApmTsr.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbApmTcool.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
    End Sub
    Private Sub UpdateApmState05(ByVal ArrPointer As UInteger)
        tbApmHVAux.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
        tbApmEvseImax.Text = CanMsg_DataStruct(ArrPointer).DataGroup(1).DataString
        tbApmLVIcmd.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbApmLVAux.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdateApmState06(ByVal ArrPointer As UInteger)
        tbApmVcmd.Text = CanMsg_DataStruct(ArrPointer).DataGroup(2).DataString
        tbApmIcmd.Text = CanMsg_DataStruct(ArrPointer).DataGroup(3).DataString
    End Sub
    Private Sub UpdateApmHvdcData(ByVal ArrPointer As UInteger)
        'Not Defined Yet
    End Sub
    Private Sub UpdateApmVerAppl(ByVal ArrPointer As UInteger)
        tbApmVerApp.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
    End Sub
    Private Sub UpdateApmVerBoot(ByVal ArrPointer As UInteger)
        tbApmVerBoot.Text = CanMsg_DataStruct(ArrPointer).DataGroup(0).DataString
    End Sub
    Private Sub tmrDisplay_Tick(sender As Object, e As EventArgs) Handles tmrDisplay.Tick
        'Update Front Panel Components
        If CANdevice.Connected = True Then
            For ArrLoc As Integer = 0 To CanMsg_DataStruct.Length - 1
                If CanMsg_DataStruct(ArrLoc).bDataChanged = True Then
                    Select Case CanMsg_DataStruct(ArrLoc).Id
                        Case ID_OBC_SEC_MAIN
                            UpdateSecMain(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DATA1
                            UpdateSecData1(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DATA2
                            UpdateSecData2(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DATA3
                            UpdateSecData3(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DATA4
                            UpdateSecData4(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_FWREV
                            UpdateSecFwRev(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DEBDATA1
                            UpdateSecDeb1(ArrLoc)
                            Exit Select
                        Case ID_OBC_SEC_DEBDATA2
                            UpdateSecDeb2(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_MAIN
                            UpdatePriMain(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DATA1
                            UpdatePriData1(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DATA2
                            UpdatePriData2(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DATA3
                            UpdatePriData3(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DATA4
                            UpdatePriData4(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_FWREV
                            UpdatePriFwRev(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DEBDATA1
                            UpdatePriDeb1(ArrLoc)
                            Exit Select
                        Case ID_OBC_PRI_DEBDATA2
                            UpdatePriDeb2(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_00
                            UpdateApmState00(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_01
                            UpdateApmState01(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_02
                            UpdateApmState02(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_03
                            UpdateApmState03(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_04
                            UpdateApmState04(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_05
                            UpdateApmState05(ArrLoc)
                            Exit Select
                        Case ID_APM_STATE_06
                            UpdateApmState06(ArrLoc)
                            Exit Select
                        Case ID_APM_HVDC_DATA
                            UpdateApmHvdcData(ArrLoc)
                            Exit Select
                        Case ID_APM_VER_APPL
                            UpdateApmVerAppl(ArrLoc)
                            Exit Select
                        Case ID_APM_VER_BOOT
                            UpdateApmVerBoot(ArrLoc)
                            Exit Select
                    End Select
                End If
            Next
        End If
    End Sub

#End Region

#Region "UI Control Functions"
    Private Function GetOBCCycleTime(ByVal NUlldata As Integer) As Byte
        Dim CycTime As Byte

        Dim BaseClock As UInt16 = TxTimer.Interval

        Dim str As String = cbObcBcCyTime.Text
        str = str.Remove((str.Length - 2), 2)
        Dim SelTime As UInt16 = Convert.ToUInt16(str)

        CycTime = SelTime / BaseClock

        If CycTime < 0 Then
            CycTime = 1
        End If

        Return CycTime
    End Function

    Private Sub UpdateApmCtrlMsg(ByVal NUlldata As Integer)
        CANTxMsg.ID = ID_APM_CONTROL
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        'Apm Mode Selection
        If rbApmOff.Checked = True Then
            CANTxMsg.DATA(0) = CMD_APM_OFF
        ElseIf rbApmStby.Checked = True Then
            CANTxMsg.DATA(0) = CMD_APM_STANDBY
        ElseIf rbApmDcdc.Checked = True Then
            CANTxMsg.DATA(0) = CMD_APM_DCDC
        ElseIf rbApmTest.Checked = True Then
            CANTxMsg.DATA(0) = CMD_APM_TEST
        Else
            CANTxMsg.DATA(0) = CMD_APM_INVALID
        End If

        Dim temp As UShort = nudAPMVolt.Value * 10 ' in 100mV Resolution
        CANTxMsg.DATA(1) = "&H" + VB.Right(Hex(temp), 2)

        temp = nudAPMCurr.Value * 10 ' in 100mA Resolution
        CANTxMsg.DATA(3) = "&H" + VB.Right(Hex(temp), 2)
        CANTxMsg.DATA(2) = "&H" + VB.Right(Hex((temp) >> 8), 2)

    End Sub

    Private Sub UpdateObcCtrlMsg(ByVal NUlldata As Integer)
        CANTxMsg.ID = ID_OBC_CONTROL
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        'Mode Selection
        If rbSleep.Checked = True Then
            CANTxMsg.DATA(0) = CMD_SLEEP
        ElseIf rbStandby.Checked = True Then
            CANTxMsg.DATA(0) = CMD_STANDBY
        ElseIf rbForward.Checked = True And Mode = MODE_FORWARD Then
            CANTxMsg.DATA(0) = CMD_FORWARD
        ElseIf rbReverse.Checked = True And Mode = MODE_REVERSE Then
            CANTxMsg.DATA(0) = CMD_REVERSE
        ElseIf rbTestmode.Checked = True And Mode = MODE_FORWARD Then
            CANTxMsg.DATA(0) = CMD_TEST_FRWD
        ElseIf rbTestmode.Checked = True And Mode = MODE_REVERSE Then
            CANTxMsg.DATA(0) = CMD_TEST_REV
        Else
            CANTxMsg.DATA(0) = CMD_STANDBY
        End If

        'Phase Selction
        If GridPhase = GRID_PHASE_3 Then
            CANTxMsg.DATA(1) = &H0
        ElseIf SinglePhLeg = PHASE_LEG_A Then
            CANTxMsg.DATA(1) = &H3
        ElseIf SinglePhLeg = PHASE_LEG_B Then
            CANTxMsg.DATA(1) = &H5
        ElseIf SinglePhLeg = PHASE_LEG_C Then
            CANTxMsg.DATA(1) = &H7
        ElseIf SinglePhLeg = PHASE_LEG_ALL Then
            CANTxMsg.DATA(1) = &H9
        End If

        Dim temp As UShort = ObcVtarget * 10 ' in 100mV Resolution

        CANTxMsg.DATA(2) = "&H" + VB.Right(Hex(temp), 2)
        CANTxMsg.DATA(3) = "&H" + VB.Right(Hex((temp) >> 8), 2)

        temp = ObcItarget * 100 ' in 10mA Resolution

        CANTxMsg.DATA(4) = "&H" + VB.Right(Hex(temp), 2)
        CANTxMsg.DATA(5) = "&H" + VB.Right(Hex((temp) >> 8), 2)

        temp = ObcPtarget * 1000 ' in 1W Resolution

        CANTxMsg.DATA(6) = "&H" + VB.Right(Hex(temp), 2)
        CANTxMsg.DATA(7) = "&H" + VB.Right(Hex((temp) >> 8), 2)
    End Sub
    Private Sub UpdateObcSafetyMsg(ByVal NUlldata As Integer)
        CANTxMsg.ID = ID_OBC_SAFETY_CTRL
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        TxAliveCounter += 1
        If TxAliveCounter > 15 Then
            TxAliveCounter = 0
        End If

        CANTxMsg.DATA(0) = TxAliveCounter

        If rbSleep.Checked = True Then
            CANTxMsg.DATA(1) = CMD_SAFETY_SLEEP
        ElseIf rbStandby.Checked = True Then
            CANTxMsg.DATA(1) = CMD_SAFETY_STANDBY
        ElseIf rbForward.Checked = True And Mode = MODE_FORWARD Then
            CANTxMsg.DATA(1) = CMD_SAFETY_FORWARD
        ElseIf rbReverse.Checked = True And Mode = MODE_REVERSE Then
            CANTxMsg.DATA(1) = CMD_SAFETY_REVERSE
        Else
            CANTxMsg.DATA(1) = CMD_SAFETY_STANDBY
        End If

        CANTxMsg.DATA(2) = 0
        CANTxMsg.DATA(3) = 0

        CANTxMsg.DATA(4) = 0
        CANTxMsg.DATA(5) = 0

        CANTxMsg.DATA(6) = 0
        CANTxMsg.DATA(7) = 0
    End Sub
    Private Sub UpdateObcRdReqMsg(ByVal TxMsgIId As UInteger, ByVal MsgPointer As Byte)
        CANTxMsg.ID = TxMsgIId
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        CANTxMsg.DATA(0) = CONTROL_READ
        CANTxMsg.DATA(1) = MsgPointer

        CANTxMsg.DATA(2) = 0
        CANTxMsg.DATA(3) = 0

        CANTxMsg.DATA(4) = 0
        CANTxMsg.DATA(5) = 0

        CANTxMsg.DATA(6) = 0
        CANTxMsg.DATA(7) = 0
    End Sub
    Private Sub UpdateObcWrMsg(ByVal TxMsgIId As UInteger, ByVal MsgPointer As Byte, ByVal Data As Byte())
        CANTxMsg.ID = TxMsgIId
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        CANTxMsg.DATA(0) = CONTROL_WRITE
        CANTxMsg.DATA(1) = MsgPointer

        CANTxMsg.DATA(2) = Data(0)
        CANTxMsg.DATA(3) = Data(1)

        CANTxMsg.DATA(4) = Data(2)
        CANTxMsg.DATA(5) = Data(3)

        CANTxMsg.DATA(6) = Data(4)
        CANTxMsg.DATA(7) = Data(5)
    End Sub

    Private Sub UpdateObcCmdMsg(ByVal TxMsgIId As UInteger, ByVal MsgPointer As Byte)
        CANTxMsg.ID = TxMsgIId
        CANTxMsg.DLC = STD_MSG_LENGTH
        CANTxMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD

        CANTxMsg.DATA(0) = CONTROL_COMMAND
        CANTxMsg.DATA(1) = MsgPointer
        CANTxMsg.DATA(2) = 0
        CANTxMsg.DATA(3) = 0
        CANTxMsg.DATA(4) = 0
        CANTxMsg.DATA(5) = 0
        CANTxMsg.DATA(6) = 0
        CANTxMsg.DATA(7) = 0

        If MsgPointer = ID_CMD_PNTR_DEB_EN Then
            If chDebugMode.Checked = True Then
                CANTxMsg.DATA(2) = &HAA
            Else
                CANTxMsg.DATA(2) = &H55
            End If
        ElseIf MsgPointer = ID_CMD_PNTR_TEST_EN Then
            If TxMsgIId = ID_OBC_PRI_CTRL Then 'Primary
                If chPriFutMode.Checked = True Then
                    CANTxMsg.DATA(2) = &HBB
                Else
                    CANTxMsg.DATA(2) = &H44
                End If
            ElseIf TxMsgIId = ID_OBC_SEC_CTRL Then 'Secondary
                If rbSecPwmOff.Checked = True Then
                    CANTxMsg.DATA(2) = &H44
                Else
                    CANTxMsg.DATA(2) = &HBB
                    If rbSecPwmOn1.Checked = True Then
                        CANTxMsg.DATA(3) = &H1
                    ElseIf rbSecPwmOn2.Checked = True Then
                        CANTxMsg.DATA(3) = &H2
                    End If
                    CANTxMsg.DATA(4) = nudBurstDty.Value
                    CANTxMsg.DATA(5) = nudPhaseShift.Value

                    Dim PeriodTemp As Integer = Convert.ToUInt16(60000000.0 / (nudFrequency.Value * 100)) ' Period in 0.1 Resolution

                    CANTxMsg.DATA(6) = "&H" + VB.Right(Hex(Val(PeriodTemp)), 2)
                    CANTxMsg.DATA(7) = "&H" + VB.Right(Hex(Val(PeriodTemp) >> 8), 2)
                End If
            End If
        End If
    End Sub

    Private Sub PrepareObcBrdCstMsgs(ByVal TxPointer As Integer)
        Select Case TxPointer
            Case 1
                If TxBcApmControl = True And TxBroadcastState(0) = True Then
                    UpdateApmCtrlMsg(0)
                    TxBroadcastState(0) = False
                ElseIf TxBcOBCControl = True And TxBroadcastState(1) = True Then
                    UpdateObcCtrlMsg(0)
                    TxBroadcastState(1) = False
                ElseIf TxBcOBCSafety = True And TxBroadcastState(2) = True Then
                    UpdateObcSafetyMsg(0)
                    TxBroadcastState(2) = False
                ElseIf TxBcOBCPriDeb1 = True And TxBroadcastState(3) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(3) = False
                ElseIf TxBcOBCPriDeb2 = True And TxBroadcastState(4) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(4) = False
                ElseIf TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 2
                If TxBcOBCControl = True And TxBroadcastState(1) = True Then
                    UpdateObcCtrlMsg(0)
                    TxBroadcastState(1) = False
                ElseIf TxBcOBCSafety = True And TxBroadcastState(2) = True Then
                    UpdateObcSafetyMsg(0)
                    TxBroadcastState(2) = False
                ElseIf TxBcOBCPriDeb1 = True And TxBroadcastState(3) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(3) = False
                ElseIf TxBcOBCPriDeb2 = True And TxBroadcastState(4) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(4) = False
                ElseIf TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 3
                If TxBcOBCSafety = True And TxBroadcastState(2) = True Then
                    UpdateObcSafetyMsg(0)
                    TxBroadcastState(2) = False
                ElseIf TxBcOBCPriDeb1 = True And TxBroadcastState(3) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(3) = False
                ElseIf TxBcOBCPriDeb2 = True And TxBroadcastState(4) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(4) = False
                ElseIf TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 4
                If TxBcOBCPriDeb1 = True And TxBroadcastState(3) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(3) = False
                ElseIf TxBcOBCPriDeb2 = True And TxBroadcastState(4) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(4) = False
                ElseIf TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 5
                If TxBcOBCPriDeb2 = True And TxBroadcastState(4) = True Then
                    UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(4) = False
                ElseIf TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 6
                If TxBcOBCSecDeb1 = True And TxBroadcastState(5) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB1)
                    TxBroadcastState(5) = False
                ElseIf TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case 7
                If TxBcOBCSecDeb2 = True And TxBroadcastState(6) = True Then
                    UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_DEB2)
                    TxBroadcastState(6) = False
                End If
            Case Else
                'Nil
        End Select
    End Sub
    Private Sub SetBroadcastState(ByVal NullData As Integer)
        For i As UInteger = 0 To MAX_OBC_BROADCAST_MSGS
            TxBroadcastState(i) = True
        Next
    End Sub
    Private Sub TxTimer_Tick(sender As Object, e As EventArgs) Handles TxTimer.Tick
        Dim stsResult As TPCANStatus
        Dim WriteReady As Boolean = False
        'For CAN Log
        Dim str As String = "0x0000000000000 TX PCAN STD "
        Dim tmpstr As String

        If CANdevice.Connected = True Then
            If SendDebCtrlCmd = True Then
                If TxBrdcstMcuPntr = 0 Then
                    UpdateObcCmdMsg(ID_OBC_PRI_CTRL, ID_CMD_PNTR_DEB_EN)
                    TxBrdcstMcuPntr = 1
                ElseIf TxBrdcstMcuPntr = 1 Then
                    UpdateObcCmdMsg(ID_OBC_SEC_CTRL, ID_CMD_PNTR_DEB_EN)
                    SendDebCtrlCmd = False
                    TxBrdcstMcuPntr = 0
                End If
                WriteReady = True
            ElseIf TxPriFWRevReq = True Then
                UpdateObcRdReqMsg(ID_OBC_PRI_CTRL, ID_RD_PNTR_FWREV)
                WriteReady = True
                TxPriFWRevReq = False
            ElseIf TxSecFWRevReq = True Then
                UpdateObcRdReqMsg(ID_OBC_SEC_CTRL, ID_RD_PNTR_FWREV)
                WriteReady = True
                TxSecFWRevReq = False
            ElseIf TxPriFutCmdReq = True Then
                UpdateObcCmdMsg(ID_OBC_PRI_CTRL, ID_CMD_PNTR_TEST_EN)
                WriteReady = True
                TxPriFutCmdReq = False
            ElseIf TxPriSetReqKp = True Then
                UpdateObcWrMsg(ID_OBC_PRI_CTRL, ID_WR_NPC_KP, NpcParamByte)
                WriteReady = True
                TxPriSetReqKp = False
            ElseIf TxPriSetReqKi = True Then
                UpdateObcWrMsg(ID_OBC_PRI_CTRL, ID_WR_NPC_KI, NpcParamByte)
                WriteReady = True
                TxPriSetReqKi = False
            ElseIf TxSecOLCmdReq = True Then
                UpdateObcCmdMsg(ID_OBC_SEC_CTRL, ID_CMD_PNTR_TEST_EN)
                WriteReady = True
                TxSecOLCmdReq = False
            ElseIf TxBroadcast = True Then
                ObcBcCycleTimeCount += 1
                If ObcBcCycleTimeCount >= GetOBCCycleTime(0) Then
                    TxBroadcastPntr += 1
                    PrepareObcBrdCstMsgs(TxBroadcastPntr)
                    If TxBroadcastPntr >= TxBrdcstMsgCount Then
                        TxBroadcastPntr = 0
                        SetBroadcastState(0)
                    End If
                    WriteReady = True
                    ObcBcCycleTimeCount = 0
                End If
            End If

            If WriteReady = True Then
                stsResult = If(CANFDMode, WriteFrameFD(), WriteFrame())
                'Update CAN Log
                'Update Msg ID
                tmpstr = "  ID:0x" + Hex(CANTxMsg.ID)
                str = str + tmpstr

                'Update 8 Bytes of Data
                str = str + "   Data:"
                For i = 0 To 7
                    If Hex(CANTxMsg.DATA(i)).ToString.Length = 1 Then
                        tmpstr = "0" + Hex(CANTxMsg.DATA(i)) + " "
                    Else
                        tmpstr = Hex(CANTxMsg.DATA(i)) + " "
                    End If

                    str = str + tmpstr
                Next

                If (stsResult = TPCANStatus.PCAN_ERROR_OK) Then
                    str = str + " Success"
                Else
                    ' An error occurred.  We show the error.
                    '
                    str = str + " Failed " + stsResult.ToString
                    MessageBox.Show(GetFormatedError(stsResult))
                End If

                AppendLog(str, True)
            End If
        Else
            'Reset All Broadcast Message request
            'SendDebCtrlCmd = False
            'TxPriFWRevReq = False
            'TxSecFWRevReq = False

            'TxBroadcast = False
            'TxBcOBCControl = False
            'TxBcOBCSafety = False
            'TxBcOBCPriDeb1 = False
            'TxBcOBCPriDeb2 = False
            'TxBcOBCSecDeb1 = False
            'TxBcOBCSecDeb2 = False

            'chOBCCtrlmsg.Checked = False
            'chOBCSafetymsg.Checked = False
            'chPriDeb1.Checked = False
            'chPriDeb2.Checked = False
            'chSecDeb1.Checked = False
            'chSecDeb2.Checked = False
        End If

    End Sub

#End Region

#Region "Support Functions"
    Private Sub AppendLog(ByVal Str_Data As String, ByVal AppendTime As Boolean)
        Dim time As DateTime = DateTime.Now
        Dim format As String = "d MMM yyyy HH:mm:ss.fff"

        If (CanLogLineNo > 10000) Then
            tbCanLog.ReadOnly = True
            CanLogLineNo = 0
            tbCanLog.Text = ""
        End If


        If AppendTime = True Then
            tbCanLog.AppendText(time.ToString(format) + " :" & Str_Data & vbCrLf)
        Else
            tbCanLog.AppendText(Str_Data & vbCrLf)
        End If

        tbCanLog.SelectionStart = tbCanLog.Text.Length
        tbCanLog.ScrollToCaret()
        CanLogLineNo += 1
    End Sub

    Private Function FormatChannelName(ByVal handle As TPCANHandle, ByVal isFD As Boolean) As String
        ' <summary>
        ' Gets the formated text for a CPAN-Basic channel handle
        ' </summary>
        ' <param name="handle">PCAN-Basic Handle to format</param>
        ' <param name="isFD">If the channel is FD capable</param>
        ' <returns>The formatted text for a channel</returns>

        Dim devDevice As TPCANDevice
        Dim byChannel As Byte

        ' Gets the owner device and channel for a 
        ' PCAN-Basic handle
        '
        If CType(handle, UShort) < &H100 Then
            devDevice = DirectCast(CType(handle >> 4, Byte), TPCANDevice)
            byChannel = CByte((handle And &HF))
        Else
            devDevice = DirectCast(CType(handle >> 8, Byte), TPCANDevice)
            byChannel = CByte((handle And &HFF))
        End If

        ' Constructs the PCAN-Basic Channel name and return it
        '
        If (isFD) Then
            Return String.Format("{0}:FD {1} ({2:X2}h)", devDevice, byChannel, handle)
        Else
            Return String.Format("{0} {1} ({2:X2}h)", devDevice, byChannel, handle)
        End If
    End Function

    Private Function GetFormatedError(ByVal [error] As TPCANStatus) As String
        ' <summary>
        ' Help Function used to get an error as text
        ' </summary>
        ' <param name="error">Error code to be translated</param>
        ' <returns>A text with the translated error</returns>
        '

        Dim strTemp As StringBuilder

        ' Creates a buffer big enough for a error-text
        '
        strTemp = New StringBuilder(256)
        ' Gets the text using the GetErrorText API function
        ' If the function success, the translated error is returned. If it fails,
        ' a text describing the current error is returned.
        '
        If PCANBasic.GetErrorText([error], 0, strTemp) <> TPCANStatus.PCAN_ERROR_OK Then
            Return String.Format("An error occurred. Error-code's text ({0:X}) couldn't be retrieved", [error])
        Else
            Return strTemp.ToString()
        End If
    End Function

    ''' <summary>
    ''' Convert a CAN DLC value into the actual data length of the CAN/CAN-FD frame.
    ''' </summary>
    ''' <param name="dlc">A value between 0 and 15 (CAN and FD DLC range)</param>
    ''' <param name="isSTD">A value indicating if the msg is a standard CAN (FD Flag not checked)</param>
    ''' <returns>The length represented by the DLC</returns>
    Public Shared Function GetLengthFromDLC(ByVal dlc As Integer, ByVal isSTD As Boolean)
        If dlc <= 8 Then
            Return dlc
        End If

        If (isSTD) Then
            Return 8
        End If

        Select Case dlc
            Case 9
                Return 12
            Case 10
                Return 16
            Case 11
                Return 20
            Case 12
                Return 24
            Case 13
                Return 32
            Case 14
                Return 48
            Case 15
                Return 64
            Case Else
                Return dlc
        End Select
    End Function
#End Region

#Region "CAN COM Handler"
    Private Sub ComTmr_Tick(sender As Object, e As EventArgs) Handles ComTmr.Tick
        Dim TempDevCount As UInteger = ScanPorts(0)

        If CANdevice.State = NO_DEVICE_FOUND Then
            If TempDevCount > 0 Then
                'Devices Found and Update the List
                CANdevice.State = DEVICES_FOUND
                If TempDevCount > MAX_DEVICE_COUNT Then
                    'Clamp Number of Devices
                    CANdevice.DeviceCount = MAX_DEVICE_COUNT
                Else
                    CANdevice.DeviceCount = TempDevCount
                End If
                ComTmr.Interval = 500
                UpdateDeviceList(1)
                EnDisDeviceControls(ENABLE)
            End If

        ElseIf CANdevice.State = DEVICES_FOUND Then
            If Not TempDevCount = CANdevice.DeviceCount Then
                If TempDevCount = 0 Then
                    If CANdevice.Connected = True Then
                        'Reset Connection

                    End If

                    CANdevice.State = NO_DEVICE_FOUND
                    CANdevice.DeviceCount = 0
                    ComTmr.Interval = 200
                    UpdateDeviceList(0)
                    EnDisDeviceControls(DISABLE)
                Else
                    If CANdevice.Connected = False Then
                        If TempDevCount > MAX_DEVICE_COUNT Then
                            'Clamp Number of Devices
                            CANdevice.DeviceCount = MAX_DEVICE_COUNT
                        Else
                            CANdevice.DeviceCount = TempDevCount
                        End If
                        UpdateDeviceList(1)
                    Else
                        'If Connected already Wait for it to Disconnect
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub UpdateDeviceList(ByVal cleardata As Integer)
        Dim i As UInteger = 0
        cbDeviceList.Items.Clear()

        If cleardata = 1 Then
            For i = 0 To CANdevice.DeviceCount - 1
                DeviceList(i) = ScannedDeviceList(i)
                cbDeviceList.Items.Add(ScannedDeviceList(i))
            Next

            cbDeviceList.SelectedIndex = 0
            lbDevice.BackColor = Color.LightGreen
        Else
            cbDeviceList.Items.Add("NO Devices Found")
            cbDeviceList.SelectedIndex = 0
            lbDevice.BackColor = Color.Red
        End If

    End Sub

    Private Sub EnDisDeviceControls(ByVal ENorDis As Integer)
        If ENorDis = ENABLE Then
            btStartCAN.Enabled = True
            'chCanFD.Enabled = True         'will be enabled after APM Implementation
            cbBaudrate.Enabled = True
            cbBaudrate.SelectedIndex = 0    '1MBits
            tbCANConfiginfo.Enabled = True
            rbCANStatus.Enabled = True
        Else
            btStartCAN.Enabled = False
            chCanFD.Enabled = False
            cbBaudrate.Enabled = False
            tbCANConfiginfo.Enabled = False
            rbCANStatus.Enabled = False
        End If
    End Sub

    Private Sub EnDisCANdataControls(ByVal ENorDis As Integer)
        If ENorDis = ENABLE Then

            cbDeviceList.Enabled = False
            chCanFD.Enabled = False
            cbBaudrate.Enabled = False
            tbCANConfiginfo.Enabled = False

            TabControl1.Enabled = True
            TabControl2.Enabled = True
            chDebugMode.Enabled = True
            gbAPMCtrl.Enabled = True
            gbOBCCtrl.Enabled = True
            gbAPMinfo.Enabled = True
            gbOBCInfo.Enabled = True
        Else

            cbDeviceList.Enabled = True
            chCanFD.Enabled = True
            cbBaudrate.Enabled = True
            tbCANConfiginfo.Enabled = True

            TabControl1.Enabled = False
            'TabControl2.Enabled = False
            gbAPMCtrl.Enabled = False
            gbOBCCtrl.Enabled = False
            gbAPMinfo.Enabled = False
            gbOBCInfo.Enabled = False
        End If
    End Sub

    Private Function ScanPorts(ByVal NUlldata As Integer) As UInt32

        Dim stsResult As TPCANStatus
        Dim RdDeviceCount As UInt32
        Dim bIsFD As Boolean
        Dim i As UInteger = 0

        Try
            ' Checks for available Plug&Play channels
            stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS_COUNT, RdDeviceCount, CType(System.Runtime.InteropServices.Marshal.SizeOf(RdDeviceCount), UInteger))
            If (stsResult = TPCANStatus.PCAN_ERROR_OK) Then
                Dim info(RdDeviceCount - 1) As TPCANChannelInformation

                stsResult = PCANBasic.GetValue(PCANBasic.PCAN_NONEBUS, TPCANParameter.PCAN_ATTACHED_CHANNELS, info)

                If (stsResult = TPCANStatus.PCAN_ERROR_OK) Then
                    ' Include only connectable channels
                    For Each channel As TPCANChannelInformation In info
                        bIsFD = (channel.device_features And PCANBasic.FEATURE_FD_CAPABLE) = PCANBasic.FEATURE_FD_CAPABLE
                        ScannedDeviceList(i) = FormatChannelName(channel.channel_handle, bIsFD)
                        i += 1
                    Next
                End If
            End If

        Catch ex As Exception
            MessageBox.Show("Unable to find the library: PCANBasic.dll !", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Environment.Exit(-1)
            RdDeviceCount = 0
        End Try

        Return RdDeviceCount
    End Function

#End Region

#Region "CAN Transmit Data Handler"
    Private Function WriteFrame()
        Dim CANMsg As TPCANMsg

        ' We create a TPCANMsg message structure 
        CANMsg = New TPCANMsg()
        CANMsg.DATA = CType(Array.CreateInstance(GetType(Byte), 8), Byte())

        ' We configurate the Message.  The ID,
        ' Length of the Data, Message Type
        ' and die data
        CANMsg.ID = CANTxMsg.ID
        CANMsg.LEN = CANTxMsg.DLC
        CANMsg.MSGTYPE = CANTxMsg.MSGTYPE

        For I As Integer = 0 To GetLengthFromDLC(CANMsg.LEN, True) - 1
            CANMsg.DATA(I) = CANTxMsg.DATA(I)
        Next

        ' The message is sent to the configured hardware
        Return PCANBasic.Write(PcanHandle, CANMsg)
    End Function

    Private Function WriteFrameFD()
        Dim CANMsg As TPCANMsgFD

        ' We create a TPCANMsg message structure 
        CANMsg = New TPCANMsgFD()
        CANMsg.DATA = CType(Array.CreateInstance(GetType(Byte), 64), Byte())

        ' We configurate the Message.  The ID,
        ' Length of the Data, Message Type
        ' and die data
        CANMsg.ID = CANTxMsg.ID
        CANMsg.DLC = CANTxMsg.DLC
        CANMsg.MSGTYPE = CANTxMsg.MSGTYPE

        For I As Integer = 0 To GetLengthFromDLC(CANMsg.DLC, True) - 1
            CANMsg.DATA(I) = CANTxMsg.DATA(I)
        Next

        ' The message is sent to the configured hardware
        Return PCANBasic.WriteFD(PcanHandle, CANMsg)
    End Function

#End Region

#Region "CAN Receive Data Handler"
    Private Sub UpdateMessage(ByVal itstimestamp As TPCANTimestampFD, ByVal newmsg As TPCANMsgFD)
        Dim ArrLen As Byte = CanMsg_DataStruct.Length
        Dim Dataact As UInteger = 0
        Dim Datafl As Single
        Dim temp As Integer
        Dim i As Byte

        For ArrLoc As Integer = 0 To ArrLen - 1
            If CanMsg_DataStruct(ArrLoc).Id = newmsg.ID Then
                'Update Data Structure
                CanMsg_DataStruct(ArrLoc).Tstamp = itstimestamp

                For i = 0 To 7
                    CanMsg_DataStruct(ArrLoc).DataBuf(i) = newmsg.DATA(i)
                Next
                CanMsg_DataStruct(ArrLoc).MsgCount += 1
                CanMsg_DataStruct(ArrLoc).bDataChanged = True

                'Update data Group info
                For j As Integer = 0 To CanMsg_DataStruct(ArrLoc).DataGroupCount - 1
                    'Get Integer Value
                    If CanMsg_DataStruct(ArrLoc).DataGroup(j).Len = 1 Then
                        Dataact = CanMsg_DataStruct(ArrLoc).DataBuf(CanMsg_DataStruct(ArrLoc).DataGroup(j).StartAddr)
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Len = 2 Then 'Length 2
                        If CanMsg_DataStruct(ArrLoc).bMsbFirst = False Then
                            Dataact = CanMsg_DataStruct(ArrLoc).DataBuf(CanMsg_DataStruct(ArrLoc).DataGroup(j).StartAddr) +
                                (CanMsg_DataStruct(ArrLoc).DataBuf(CanMsg_DataStruct(ArrLoc).DataGroup(j).StartAddr + 1) * 256)
                        Else
                            Dataact = (CanMsg_DataStruct(ArrLoc).DataBuf(CanMsg_DataStruct(ArrLoc).DataGroup(j).StartAddr) * 256) +
                                CanMsg_DataStruct(ArrLoc).DataBuf(CanMsg_DataStruct(ArrLoc).DataGroup(j).StartAddr + 1)
                        End If
                    End If

                    'Convert to Float value with given Conversion Type and Update Datastring
                    If CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = uDATA Then 'Unsigned Data
                        Datafl = Math.Round(Dataact * CanMsg_DataStruct(ArrLoc).DataGroup(j).Resol, 2)
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Datafl.ToString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = sDATA Then 'signed Data
                        If Dataact < 32766 Then
                            Datafl = Math.Round(Dataact * CanMsg_DataStruct(ArrLoc).DataGroup(j).Resol, 2)
                        Else
                            temp = Dataact
                            temp = (Not temp)
                            temp = temp And &HFFFF
                            temp += 1
                            Datafl = Math.Round((temp) * CanMsg_DataStruct(ArrLoc).DataGroup(j).Resol * -1.0, 2)
                        End If
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Datafl.ToString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = FREQDATA Then 'Frequency Period Data
                        Datafl = Math.Round(Dataact * CanMsg_DataStruct(ArrLoc).DataGroup(j).Resol, 2)
                        Datafl = Math.Round(60000.0 / Datafl, 2)
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Datafl.ToString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = sTEMP Then 'signed Temperature Data
                        'Process if Required
                        Datafl = Math.Round(Dataact * CanMsg_DataStruct(ArrLoc).DataGroup(j).Resol, 2)
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Datafl.ToString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = HEX8 Then 'Hex Data - Byte
                        Dim RawDataString As String = Convert.ToString(Dataact, 16)

                        If RawDataString.Length = 1 Then
                            RawDataString = "0" + RawDataString
                        End If

                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = RawDataString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = HEX16 Then 'Hex Data - Word
                        Dim RawDataString As String = Convert.ToString(Dataact, 16)

                        If RawDataString.Length = 1 Then
                            RawDataString = "000" + RawDataString
                        ElseIf RawDataString.Length = 2 Then
                            RawDataString = "00" + RawDataString
                        ElseIf RawDataString.Length = 3 Then
                            RawDataString = "0" + RawDataString
                        End If

                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = RawDataString + " " + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = HEX16PRI Then 'Hex Data
                        Dim temptype As Integer = 16
                        Dim tempstr As String = "h"
                        If chPriDebInDec.Checked = True Then
                            temptype = 10
                            tempstr = ""
                        End If

                        Dim RawDataString As String = Convert.ToString(Dataact, temptype)

                        If temptype = 16 Then
                            If RawDataString.Length = 1 Then
                                RawDataString = "000" + RawDataString
                            ElseIf RawDataString.Length = 2 Then
                                RawDataString = "00" + RawDataString
                            ElseIf RawDataString.Length = 3 Then
                                RawDataString = "0" + RawDataString
                            End If
                        End If

                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = RawDataString + tempstr + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = HEX16SEC Then 'Hex Data
                        Dim temptype As Integer = 16
                        Dim tempstr As String = "h"
                        If chSecDebInDec.Checked = True Then
                            temptype = 10
                            tempstr = ""
                        End If

                        Dim RawDataString As String = Convert.ToString(Dataact, temptype)

                        If temptype = 16 Then
                            If RawDataString.Length = 1 Then
                                RawDataString = "000" + RawDataString
                            ElseIf RawDataString.Length = 2 Then
                                RawDataString = "00" + RawDataString
                            ElseIf RawDataString.Length = 3 Then
                                RawDataString = "0" + RawDataString
                            End If
                        End If

                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = RawDataString + tempstr + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = DECDATA Then 'Dec Data
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Convert.ToString(Dataact, 10) + "" + CanMsg_DataStruct(ArrLoc).DataGroup(j).UnitString
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = FWREV Then 'Firmware Revision For OBC
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = Chr(CanMsg_DataStruct(ArrLoc).DataBuf(0)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(1)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(2)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(3)) +
                                                                            Chr(CanMsg_DataStruct(ArrLoc).DataBuf(4)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(5)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(6)) + Chr(CanMsg_DataStruct(ArrLoc).DataBuf(7))
                    ElseIf CanMsg_DataStruct(ArrLoc).DataGroup(j).Type = FWREVAPM Then 'Firmware Revision For APM
                        CanMsg_DataStruct(ArrLoc).DataGroup(j).DataString = CanMsg_DataStruct(ArrLoc).DataBuf(0).ToString + "." + CanMsg_DataStruct(ArrLoc).DataBuf(1).ToString + "." + CanMsg_DataStruct(ArrLoc).DataBuf(2).ToString +
                                                                            CanMsg_DataStruct(ArrLoc).DataBuf(3).ToString + "." + ((CanMsg_DataStruct(ArrLoc).DataBuf(4) * 256) + CanMsg_DataStruct(ArrLoc).DataBuf(5)).ToString + "." +
                                                                            CanMsg_DataStruct(ArrLoc).DataBuf(6).ToString + "." + CanMsg_DataStruct(ArrLoc).DataBuf(7).ToString
                    End If
                Next
            End If
        Next

        'Update CAN Log
        Dim str As String
        Dim tmpstr As String

        ' Update TimeStamp
        str = "0x" + Convert.ToInt64(itstimestamp, 16).ToString

        'Update Message Type
        If newmsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD Then
            tmpstr = " RX PCAN STD "
        Else
            tmpstr = " RX "
        End If
        str = str + tmpstr

        'Update Msg ID
        tmpstr = "  ID:0x" + Hex(newmsg.ID)
        str = str + tmpstr

        'Update 8 Bytes of Data
        str = str + "   Data:"
        For i = 0 To 7
            If Hex(newmsg.DATA(i)).ToString.Length = 1 Then
                tmpstr = "0" + Hex(newmsg.DATA(i)) + " "
            Else
                tmpstr = Hex(newmsg.DATA(i)) + " "
            End If

            str = str + tmpstr
        Next

        AppendLog(str, True)

        'If rbCANStatus.BackColor = Color.LightGreen Then
        '    rbCANStatus.BackColor = Color.DarkSeaGreen
        'ElseIf rbCANStatus.BackColor = Color.DarkSeaGreen Then
        '    rbCANStatus.BackColor = Color.LightGreen
        'End If

        If rbCANStatus.Checked = True Then
            rbCANStatus.Checked = False
        Else
            rbCANStatus.Checked = True
        End If
    End Sub

    Private Sub CANReceiveThread()

        Dim iBuffer As UInt32
        Dim stsResult As TPCANStatus

        iBuffer = Convert.ToUInt32(ReceiveEvent.SafeWaitHandle.DangerousGetHandle().ToInt32())
        ' Sets the handle of the Receive-Event.
        '
        stsResult = PCANBasic.SetValue(PcanHandle, TPCANParameter.PCAN_RECEIVE_EVENT, iBuffer, CType(System.Runtime.InteropServices.Marshal.SizeOf(iBuffer), UInteger))

        If stsResult <> TPCANStatus.PCAN_ERROR_OK Then
            MessageBox.Show(GetFormatedError(stsResult), "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' While this mode is selected
        While CANdevice.Connected
            ' Waiting for Receive-Event
            ' 
            If ReceiveEvent.WaitOne(50) Then
                Me.Invoke(ReadDelegate)
            End If
        End While
    End Sub

    Private Sub SelectModeAndRead()
        Dim stsResult As TPCANStatus

        ' We read at least one time the queue looking for messages.
        ' If a message is found, we look again trying to find more.
        ' If the queue is empty or an error occurr, we get out from
        ' the dowhile statement.
        '			
        Do
            ' We execute the "Read" or "ReadFD" function of the PCANBasic
            '
            stsResult = If(CANFDMode, ReadMessageFD(), ReadMessage())
            If (stsResult = TPCANStatus.PCAN_ERROR_ILLOPERATION) Then
                Exit Do
            End If
        Loop While CANdevice.Connected AndAlso (Not Convert.ToBoolean(stsResult And TPCANStatus.PCAN_ERROR_QRCVEMPTY))
    End Sub

    Private Function ReadMessageFD() As TPCANStatus
        Dim CANMsg As TPCANMsgFD = Nothing
        Dim CANTimeStamp As TPCANTimestampFD
        Dim stsResult As TPCANStatus

        ' execute the "Read" function of the PCANBasic 
        stsResult = PCANBasic.ReadFD(PcanHandle, CANMsg, CANTimeStamp)
        If (stsResult <> TPCANStatus.PCAN_ERROR_QRCVEMPTY) Then
            ' process the received message
            ProcessMessage(CANMsg, CANTimeStamp)
        End If

        Return stsResult
    End Function

    Private Function ReadMessage() As TPCANStatus
        Dim CANMsg As TPCANMsg = Nothing
        Dim CANTimeStamp As TPCANTimestamp
        Dim stsResult As TPCANStatus

        ' execute the "Read" function of the PCANBasic 
        stsResult = PCANBasic.Read(PcanHandle, CANMsg, CANTimeStamp)
        If (stsResult <> TPCANStatus.PCAN_ERROR_QRCVEMPTY) Then
            ' process the received message
            ConvAndProcessMessage(CANMsg, CANTimeStamp)
        End If

        Return stsResult
    End Function
    Private Sub ConvAndProcessMessage(ByVal theMsg As TPCANMsg, ByVal itsTimeStamp As TPCANTimestamp)
        Dim newMsg As TPCANMsgFD
        Dim newTimestamp As TPCANTimestampFD

        newMsg = New TPCANMsgFD()
        newMsg.DATA = CType(Array.CreateInstance(GetType(Byte), 64), Byte())
        newMsg.ID = theMsg.ID
        newMsg.DLC = theMsg.LEN
        For i As Integer = 0 To If(theMsg.LEN > 8, 7, theMsg.LEN - 1)
            newMsg.DATA(i) = theMsg.DATA(i)
        Next
        newMsg.MSGTYPE = theMsg.MSGTYPE

        newTimestamp = Convert.ToUInt64(itsTimeStamp.micros + 1000 * itsTimeStamp.millis + &H100000000 * 1000 * itsTimeStamp.millis_overflow)
        ProcessMessage(newMsg, newTimestamp)
    End Sub

    Private Sub ProcessMessage(ByVal theMsg As TPCANMsgFD, ByVal itsTimeStamp As TPCANTimestampFD)
        'Update Message
        UpdateMessage(itsTimeStamp, theMsg)

        'Any Other Processing

    End Sub


#End Region

End Class
