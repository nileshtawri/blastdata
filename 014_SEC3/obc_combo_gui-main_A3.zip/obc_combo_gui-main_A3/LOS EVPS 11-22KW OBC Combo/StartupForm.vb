﻿Public Class StartupForm

#Region "UI Handler"
    Private Sub rbModel11kw_CheckedChanged(sender As Object, e As EventArgs) Handles rbModel11kw.CheckedChanged
        Form1.Model = Form1.MODEL_11KW
    End Sub

    Private Sub rbModel22kw_CheckedChanged(sender As Object, e As EventArgs) Handles rbModel22kw.CheckedChanged
        Form1.Model = Form1.MODEL_22KW
    End Sub

    Private Sub rbModeForward_CheckedChanged(sender As Object, e As EventArgs) Handles rbModeForward.CheckedChanged
        Form1.Mode = Form1.MODE_FORWARD
    End Sub

    Private Sub rbModeReverse_CheckedChanged(sender As Object, e As EventArgs) Handles rbModeReverse.CheckedChanged
        Form1.Mode = Form1.MODE_REVERSE
    End Sub

    Private Sub rbGrid3Ph_CheckedChanged(sender As Object, e As EventArgs) Handles rbGrid3Ph.CheckedChanged
        Form1.GridPhase = Form1.GRID_PHASE_3

        GroupBox4.Visible = False
    End Sub

    Private Sub rbGrid1Ph_CheckedChanged(sender As Object, e As EventArgs) Handles rbGrid1Ph.CheckedChanged
        Form1.GridPhase = Form1.GRID_PHASE_1

        GroupBox4.Visible = True
    End Sub

    Private Sub rbLegA_CheckedChanged(sender As Object, e As EventArgs) Handles rbLegA.CheckedChanged
        Form1.SinglePhLeg = Form1.PHASE_LEG_A
    End Sub

    Private Sub rbLegB_CheckedChanged(sender As Object, e As EventArgs) Handles rbLegB.CheckedChanged
        Form1.SinglePhLeg = Form1.PHASE_LEG_B
    End Sub

    Private Sub rbLegC_CheckedChanged(sender As Object, e As EventArgs) Handles rbLegC.CheckedChanged
        Form1.SinglePhLeg = Form1.PHASE_LEG_C
    End Sub

    Private Sub rbAllLeg_CheckedChanged(sender As Object, e As EventArgs) Handles rbAllLeg.CheckedChanged
        Form1.SinglePhLeg = Form1.PHASE_LEG_ALL
    End Sub

    Private Sub btStartGui_Click(sender As Object, e As EventArgs) Handles btStartGui.Click
        Form1.Show()
        Me.Close()
    End Sub

#End Region

End Class