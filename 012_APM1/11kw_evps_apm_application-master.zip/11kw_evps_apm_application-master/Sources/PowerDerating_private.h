/*
 * File: PowerDerating_private.h
 *
 * Code generated for Simulink model 'PowerDerating'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Tue May 31 09:19:32 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PowerDerating_private_h_
#define RTW_HEADER_PowerDerating_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_PowerDerating_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
