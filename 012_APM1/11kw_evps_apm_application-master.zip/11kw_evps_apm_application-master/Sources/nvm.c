/**
 * @file        nvm.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include "cpu.h"
#include "type.h"
#include "nvm.h"
#include "user_config.h"
#include "common_types.h"
#include "autolibc.h"
#include "adc.h"
#include "pwm.h"
#include "housekeep.h"
#include "devassert.h"
#include "networkManagement.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif



//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define NVM_DATA_CONF_ADDR          (0x0007E000U)
#define NVM_DATA_BLOCK_SIZE         (FEATURE_FLS_PF_BLOCK_SECTOR_SIZE)
#define NVM_DATA_CALI_ADDR          (NVM_DATA_CONF_ADDR + NVM_DATA_BLOCK_SIZE)
#define NVM_DATA_CRC_OFFSET         14U
#define NVM_DATA_WRITE_TIME_LIMIT   1000U

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
static void sNvmHeaderCrc16(const u8* pbBuf, u16 wLen, u16* pwCrc);
static bool sblNvmHeaderIsEmpty(const data_header_t* pxHead);
static u8 sbNvmConfDataLoad(void);
static u8 sbNvmCaliDataLoad(void);

//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static x_cali_data_t xCaliData;
static x_conf_data_t xConfCopy;
static flash_ssd_config_t flashSSDConfig = {0};

static const x_cali_data_t xCaliDataDefault = 
{
    {                                           // Header
        {0x55U, 0xAAU},                         // tag
        (u16)sizeof(x_cali_data_t),             // block length (bytes)
        (u8)NVM_DATA_TYPE_CALI,                 // type
        1970U,                                  // year
        1U,                                     // month
        1U,                                     // day
        0U,                                     // hour
        0U,                                     // minute
        0U,                                     // second
        CALI_DATA_VERSION,                      // data format version
        0U,                                     // write count
        0xFFFFU,                                // CRC16-CCITT
    },
    {{                                          // CALI_ITEM_LVDC_VOLT_ADC
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_LVDC_CURR_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_LVDC_VOLT_PWM,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_LVDC_CURR_PWM,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_BAT_VOLT_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_HVDC_VOLT_APM_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_HVDC_CURR_APM_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_HVDC_VOLT_OBC_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_HVDC_CURR_OBC_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_GRID_VOLT_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_GRID_CURR_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_BULK_VOLT_ADC,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_RESERVED_0,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_RESERVED_1,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_RESERVED_2,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_RESERVED_3,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },
    {                                           // CALI_ITEM_RESERVED_4,
        0.0F,                                   // measure value by equipments
        0.0F,                                   // measure value by equipments
        0.0F,                                   // native value form MCU
        0.0F,                                   // native value form MCU
        1.0F,                                   // gain value for calibration
        0.0F,                                   // offset value for calibration
    },},
};

static const x_conf_data_t xConfDataDefault = 
{
    {                                           // Header
        {0x55U, 0xAAU},                         // tag
        (u16)sizeof(x_conf_data_t),             // block length (bytes)
        (u8)NVM_DATA_TYPE_CONF,                 // type
        1970U,                                  // year
        1U,                                     // month
        1U,                                     // day
        0U,                                     // hour
        0U,                                     // minute
        0U,                                     // second
        CONF_DATA_VERSION,                      // data format version
        0U,                                     // write count
        0xFFFFU,                                // CRC16-CCITT
    },
    {                                           // baDisa[ 11 ], 'T':disable
        (u8)'T',                                // CONF_DISA_J1772
        0,                                      // CONF_DISA_DERATING
        (u8)'T',                                // CONF_DISA_PRECHARGE
        (u8)'T',                                // CONF_DISA_DISCHARGE
        (u8)'T',                                // CONF_DISA_NM
        (u8)'T',                                // CONF_DISA_CAN_WAKEUP
        0,                                      // CONF_DISA_RESERVED_1
        0,                                      // CONF_DISA_RESERVED_2
        0,                                      // CONF_DISA_RESERVED_3
        0,                                      // CONF_DISA_RESERVED_4
        0,                                      // CONF_DISA_RESERVED_5
    },                      
    {                                           // xaItem[ 58 ]
        /* ---------- HV and AC side protection parameter items  ------------ */
        {                                       // CONF_ITEM_DSP_CAN_LOSS_MCU
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            1000U,                              // wResponseTime
            0.0F,                               // flRecoveryPoint
            500U,                               // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_HV_OVP_SW
            0,                                  // bDisableSetting, 'T':disable
            530.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            480.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_HV_OVP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_HV_UVP
            0,                                  // bDisableSetting, 'T':disable
            185.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_HV_OCP_SW
            0,                                  // bDisableSetting, 'T':disable
            24.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            22.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_HV_OCP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_GRID_OVP
            0,                                  // bDisableSetting, 'T':disable
            390.0F,                             // flTriggerPoint
            10U,                                // wResponseTime
            370.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_RMS_GRID_OVP
            0,                                  // bDisableSetting, 'T':disable
            275.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            265.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_RMS_GRID_UVP
            0,                                  // bDisableSetting, 'T':disable
            80.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            90.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_GRID_UFP
            0,                                  // bDisableSetting, 'T':disable
            43.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            45.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_GRID_OFP
            0,                                  // bDisableSetting, 'T':disable
            67.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            65.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_PFC_MOS_OCP
            0,                                  // bDisableSetting, 'T':disable
            20.0F,                              // flTriggerPoint
            10U,                                // wResponseTime
            10.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_LLC_OCP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_PFC_OVP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_BULK_OVP_SW
            0,                                  // bDisableSetting, 'T':disable
            430.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            410.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_BULK_UVP
            0,                                  // bDisableSetting, 'T':disable
            370.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0U,                                 // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_PFC_AUX_UVP
            0,                                  // bDisableSetting, 'T':disable
            9.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_PFC_AUX_OVP
            0,                                  // bDisableSetting, 'T':disable
            18.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            16.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_OTP_1
            0,                                  // bDisableSetting, 'T':disable
            80.0F,                              // flTriggerPoint
            3000U,                              // wResponseTime
            70.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_LLC_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            3000U,                              // wResponseTime
            90.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_PFC_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            3000U,                              // wResponseTime
            90.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_DIAG_HV_OVP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_DIAG_LLC_OCP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_DIAG_HV_SCP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_DIAG_PFC_OVP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_HV_OCP
            0,                                  // bDisableSetting, 'T':disable
            24.0F,                              // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_HV_OVP
            0,                                  // bDisableSetting, 'T':disable
            530.0F,                             // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP
            0,                                  // bDisableSetting, 'T':disable
            20.0F,                              // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP
            0,                                  // bDisableSetting, 'T':disable
            16.0F,                              // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_DSP_CMPSS_PFC_OVP
            0,                                  // bDisableSetting, 'T':disable
            440.0F,                             // flTriggerPoint
            0,                                  // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        /* ------------   LV side protection parameter items   -------------- */
        {                                       // CONF_ITEM_MCU_HV_AUX_UVP
            (u8)'T',                            // bDisableSetting, 'T':disable
            9.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_HV_AUX_OVP
            (u8)'T',                            // bDisableSetting, 'T':disable
            16.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_OVP_SW
            0,                                  // bDisableSetting, 'T':disable
            18.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            16.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_OVP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_UVP
            0,                                  // bDisableSetting, 'T':disable
            8.5F,                               // flTriggerPoint
            100U,                               // wResponseTime
            9.5F,                               // flRecoveryPoint
            50U,                                // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_AUX_UVP
            0,                                  // bDisableSetting, 'T':disable
            9.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_AUX_OVP
            0,                                  // bDisableSetting, 'T':disable
            16.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            15.5F,                              // flRecoveryPoint
            100U,                               // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            1000U,                              // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_OCP_HW
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_OCP_SW
            0,                                  // bDisableSetting, 'T':disable
            240.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            220.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_LV_OPP
            0,                                  // bDisableSetting, 'T':disable
            2350.0F,                            // flTriggerPoint
            100U,                               // wResponseTime
            0.0F,                               // flRecoveryPoint
            0,                                  // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_HV_OVP
            0,                                  // bDisableSetting, 'T':disable
            530.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            480.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_HV_UVP
            0,                                  // bDisableSetting, 'T':disable
            185.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            200.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_HV_OCP
            0,                                  // bDisableSetting, 'T':disable
            10.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            8.0F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_PCB_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            3000U,                              // wResponseTime
            90.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_SR_OTP
            0,                                  // bDisableSetting, 'T':disable
            110.0F,                             // flTriggerPoint
            3000U,                              // wResponseTime
            90.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_COOLANT_OTP
            0,                                  // bDisableSetting, 'T':disable
            100.0F,                             // flTriggerPoint
            3000U,                              // wResponseTime
            70.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_BAT_OVP
            0,                                  // bDisableSetting, 'T':disable
            18.0F,                              // flTriggerPoint
            100U,                               // wResponseTime
            16.0F,                              // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_BAT_UVP
            0,                                  // bDisableSetting, 'T':disable
            6.0F,                               // flTriggerPoint
            100U,                               // wResponseTime
            6.2F,                               // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_EVSE_OFP
            0,                                  // bDisableSetting, 'T':disable
            1020.0F,                            // flTriggerPoint
            100U,                               // wResponseTime
            1010.0F,                            // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_EVSE_UFP
            0,                                  // bDisableSetting, 'T':disable
            980.0F,                             // flTriggerPoint
            100U,                               // wResponseTime
            990.0F,                             // flRecoveryPoint
            1000U,                              // wRecoveryTime
            0,                                  // bEnableRetry, 'T':enable
            0,                                  // wRetryLimit
            0,                                  // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_DIAG_OVP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0U,                                 // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            500U,                               // wRetryInterval
        },
        {                                       // CONF_ITEM_MCU_DIAG_SCP
            0,                                  // bDisableSetting, 'T':disable
            0.0F,                               // flTriggerPoint
            20U,                                // wResponseTime
            0.0F,                               // flRecoveryPoint
            0U,                                 // wRecoveryTime
            (u8)'T',                            // bEnableRetry, 'T':enable
            3U,                                 // wRetryLimit
            500U,                               // wRetryInterval
        },
        /* polyspace-begin MISRA-C3:9.3 "partially initialized" */
        {0},                                    // CONF_ITEM_RESERVED_0                                    
        {0},                                    // CONF_ITEM_RESERVED_1
        {0},                                    // CONF_ITEM_RESERVED_2
        {0},                                    // CONF_ITEM_RESERVED_3
        {0},                                    // CONF_ITEM_RESERVED_4
        /* polyspace-end MISRA-C3:9.3 "partially initialized" */
    },
    0,                                          // bPadding for C28 decode
    {                                           // faParam[DSP_PARAM_NUMBER]
        0.18F,                                  // DSP_PARAM_PFC_V_KP
        0.00025F,                               // DSP_PARAM_PFC_V_KI
        0.015F,                                 // DSP_PARAM_PFC_I_KP
        0.005F,                                 // DSP_PARAM_PFC_I_KI
        100.0F,                                 // DSP_PARAM_PFC_MAX
        0.0F,                                   // DSP_PARAM_PFC_MIN
        0.0F,                                   // DSP_PARAM_PFC_GAIN
        0.0F,                                   // DSP_PARAM_PFC_IO
        0.003375F,                              // DSP_PARAM_LLC_V_KP
        0.1192F,                                // DSP_PARAM_LLC_V_KI
        0.01F,                                  // DSP_PARAM_LLC_I_KP
        0.35F,                                  // DSP_PARAM_LLC_I_KI
        0.0F,                                   // DSP_PARAM_RESERVED_0
        0.0F,                                   // DSP_PARAM_RESERVED_1
        0.0F,                                   // DSP_PARAM_RESERVED_2
        0.0F,                                   // DSP_PARAM_RESERVED_3
    }
};

const static net_conf_t xNetConfDefault = 
{
    {                                           // Header
        {0x55U, 0xAAU},                         // tag
        (u16)sizeof(net_conf_t),                // block length (bytes)
        (u8)NVM_DATA_TYPE_NET,                  // type
        1970U,                                  // year
        1U,                                     // month
        1U,                                     // day
        0U,                                     // hour
        0U,                                     // minute
        0U,                                     // second
        0U,                                     // data version
        0U,                                     // write count
        0xFFFFU,                                // CRC16-CCITT
    },
    {                                           // NM_PARAM_S
        NM_EDU_ID,                              // bEcuId
        NM_REPEAT_MESSAGE_TIME,                 // wRepeatMsgTimer (ms)
        NM_TIMEOUT_TIME,                        // wNmTimeoutTimer (ms)
        NM_WAIT_BUS_SLEEP_TIME,                 // wWaitBusSleepTimer (ms)
        NM_START_APPL_FRAME_DELAY,              // w1stFrameDelayTimer (ms)
        NM_CYCLE_TIME,                          // wNmCycleTimer (ms)
        NM_IMMEDIATE_CYCLE_TIME,                // wNmImmediateCycleTimer (ms)
        NM_IMMEDIATE_NM_TIMES,                  // wImmediateNmTimes (count)
        0,                                      // wNmReserve0;
        0,                                      // wNmReserve1;
        0,                                      // wNmReserve2;
        0,                                      // wNmReserve3;
        0,                                      // wNmReserve4;
    },
    {                                           // TP_PARAM_S
        0
    },
    {                                           // UDS_PARAM_S
        0
    },
};

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------
/**
 * @brief       calculates the CRC16 of a NVM data block, it exclude the CRC16
 *              word (the 14th and 15th bytes) of the data buffer
 * @param[in]   pbBuf       point to the data black address
 * @param[in]   wLen        length (bytes) of the data block
 * @param[out]  pwCrc       return CRC16 value, 0 if error
 * @note        this function will skip 14th and 15th byte
 */
static void sNvmHeaderCrc16(const u8* pbBuf, u16 wLen, u16* pwCrc)
{
    u32 dwCrcResult;
    crc_user_config_t xCrcConf;
    const u8* pbData;
    u16 wDataLen = wLen;
    u16 wHeadSize = (u16)sizeof(data_header_t);

    DEV_ASSERT((wHeadSize - 2U) == NVM_DATA_CRC_OFFSET);

    (void)CRC_DRV_GetDefaultConfig(&xCrcConf);
    (void)CRC_DRV_Configure(INST_DRVCRC, &xCrcConf);

    CRC_DRV_WriteData(INST_DRVCRC, (const u8*)pbBuf, NVM_DATA_CRC_OFFSET);

    pbData = &pbBuf[wHeadSize];
    wDataLen = (wDataLen > wHeadSize) ? (wDataLen - wHeadSize) : 0;
    CRC_DRV_WriteData(INST_DRVCRC, (const u8*)pbData, wDataLen);

    dwCrcResult = CRC_DRV_GetCrcResult(INST_DRVCRC);
    *pwCrc = (u16)dwCrcResult;
}


/**
 * @brief       vefity one data block of the NVM
 * @param[in]   pData   point to the data black address
 * @retval      0 is PASS
 * @retval      1 header is empty, no data
 * @retval      2 header's tag error
 * @retval      3 data type error
 * @retval      4 CRC check fail
 * @retval      5 data version is not match
 */
static u8 sbNvmDataVerify(const void* pData)
{
    u8 bRet = 0;
    bool blIsEmpty;
    const data_header_t* pHead;
    u16 wLen;
    const u8* pbBuf;
    u16 wCrc16;
    u8 bDataVer;

    pHead = (const data_header_t*)pData;

    bDataVer = pHead->bVersion;

    blIsEmpty = sblNvmHeaderIsEmpty(pHead);       // check if empty
    if(blIsEmpty == true)
    {
        bRet = 1U;
    }
    /* polyspace-begin MISRA-C3:18.1 "read array via pointer" */
    else if(   (pHead->baTag[0] != xCaliDataDefault.xHead.baTag[0])
            || (pHead->baTag[1] != xCaliDataDefault.xHead.baTag[1]))
    /* polyspace-end MISRA-C3:18.1 "read array via pointer" */
    {
        bRet = 2U;
    }
    else
    {
        switch(pHead->bType)
        {
            case (u8)NVM_DATA_TYPE_CALI:
                bRet = (bDataVer == CALI_DATA_VERSION) ? 0 : 5U;
                if (bRet == 0)
                {
                    wLen = sizeof(x_cali_data_t);
                    pbBuf = (const u8*)pData;
                    sNvmHeaderCrc16(pbBuf, wLen, &wCrc16);
                    bRet = (wCrc16 == pHead->wCrc16Ccitt) ? 0 : 4U;
                }
                break;

            case (u8)NVM_DATA_TYPE_CONF:
                bRet = (bDataVer == CONF_DATA_VERSION) ? 0 : 5U;
                if (bRet == 0)
                {
                    wLen = sizeof(x_conf_data_t);
                    pbBuf = (const u8*)pData;
                    sNvmHeaderCrc16(pbBuf, wLen, &wCrc16);
                    bRet = (wCrc16 == pHead->wCrc16Ccitt) ? 0 : 4U;
                }
                break;

            default:
                bRet = 3U;
                break;
        }
    }

    return bRet;
}


/**
 * \brief   check the header of calibration data area are all 0xFF
 * \return  true if empty (all data are 0xFF), else false
 */
static bool sblNvmHeaderIsEmpty(const data_header_t* pxHead)
{
    bool blRet = true;
    const u8 *pbHead;
    u16 i;

    pbHead = (const u8*)pxHead;

    for(i=0; i<sizeof(data_header_t); i++)
    {
        if(pbHead[i] != 0xFFU)    /* polyspace MISRA-C3:18.1 "read array via pointer" */
        {
            blRet = false;
            break;
        }
    }

    return blRet;
}


/**
 * @brief   write configuration data to \var xConfCopy
 * @param[in]  pxData point to input buffer
 * @param[in]  blKeepWrCnt true keep \var xConfCopy's write count, false otherwise
 * @param[in]  blUpdateCrc  to update the CRC value
 */
static void sNvmConfDataWrite(  const x_conf_data_t* pxData, 
                                bool blKeepWrCnt,
                                bool blUpdateCrc)
{
    void* pDest;
    const void* pSrc;
    u32 dwLen;
    u8 bWriteCntTemp;

    if(blKeepWrCnt == true)
    {
        bWriteCntTemp = xConfCopy.xHead.bWriteCounter;
    }

    dwLen = sizeof(x_conf_data_t);
    pDest = (void*)&xConfCopy;
    pSrc = (const void*)pxData;

    (void)fsl_memcpy(pDest, pSrc, dwLen);
    
    if(blKeepWrCnt == true)
    {
        xConfCopy.xHead.bWriteCounter = bWriteCntTemp;
    }

    if(blUpdateCrc == true)
    {
        u16 wCrc16;
        const u8 *pbBuf; 

        pbBuf = (const u8*)&xConfCopy;
        sNvmHeaderCrc16(pbBuf, (u16)dwLen, &wCrc16);
        xConfCopy.xHead.wCrc16Ccitt = wCrc16;
    }
}


/**
 * @brief   write input calibration data to \var xCaliData
 * @param[in]  pxData return point to input buffer
 * @param[in]  blKeepWrCnt to keep \var xConfCopy's write count
 * @param[in]  blUpdateCrc  to update the CRC value
 */
static void sNvmCaliDataWrite(  const x_cali_data_t* pxData, 
                                bool blKeepWrCnt,
                                bool blUpdateCrc)
{
    void* pDest;
    const void* pSrc;
    u32 dwLen;
    u8 bWriteCntTemp;

    if(blKeepWrCnt == true)
    {
        bWriteCntTemp = xCaliData.xHead.bWriteCounter;
    }

    dwLen = sizeof(x_cali_data_t);
    pDest = (void*)&xCaliData;
    pSrc = (const void*)pxData;

    (void)fsl_memcpy(pDest, pSrc, dwLen);

    if(blKeepWrCnt == true)
    {
        xCaliData.xHead.bWriteCounter = bWriteCntTemp;
    }

    if(blUpdateCrc == true)
    {
        u16 wCrc16;
        const u8 *pbBuf; 

        pbBuf = (const u8*)&xCaliData;
        sNvmHeaderCrc16(pbBuf, (u16)dwLen, &wCrc16);
        xCaliData.xHead.wCrc16Ccitt = wCrc16;
    }
}


/**
 * @brief   load EEPROM's configuration data to \var xConfCopy
 * @retval      0 is PASS
 * @retval      1 header is empty, no data
 * @retval      2 header's tag error
 * @retval      3 data type error
 * @retval      4 CRC check fail
 */
static u8 sbNvmConfDataLoad(void)
{
    u8 bRet;
    const x_conf_data_t* pxData = (const x_conf_data_t*)NVM_DATA_CONF_ADDR;  

    bRet = sbNvmDataVerify(pxData);             // check EEPROM data
    if(bRet == 0)
    {
        sNvmConfDataWrite(pxData, false, false);// copy EEPROM data to SRAM
    }
    else
    {
        sNvmConfDataWrite(  &xConfDataDefault,  // copy default data to SRAM
                            false, 
                            true);
    }
 
    return bRet;
}

/**
 * @brief   load EEPROM's calibration data to \var xCaliData
 * @return  0 if PASS, else otherwise
 */
static u8 sbNvmCaliDataLoad(void)
{
    u8 bRet;
    const x_cali_data_t* pxData = (const x_cali_data_t*)NVM_DATA_CALI_ADDR;

    bRet = sbNvmDataVerify(pxData);              // check EEPROM data
    if(bRet == 0)
    { 
        bRet = sPwmGainOffsetUpdate(pxData);    // apply cali data to PWM
        bRet |= sAdcGainOffsetUpdate(pxData);   // apply cali data to ADC
        if(bRet == 0)
        {                                       // copy EEPROM data to SRAM
            sNvmCaliDataWrite(pxData, false, false);
        }
    }
    
    if(bRet != 0)
    {
        sNvmCaliDataWrite(  &xCaliDataDefault,  // copy default data to SRAM
                            false,
                            true);
    }
 
    return bRet;   
}

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief       Initialize the internal NVM (Flash and EEPROM) driver
 */
void sNvmInit(void)
{
    status_t xRet;
    u8 bRet;

    DEV_ASSERT(sizeof(x_cali_data_t) <= NVM_DATA_BLOCK_SIZE);
    DEV_ASSERT(sizeof(x_conf_data_t) <= NVM_DATA_BLOCK_SIZE);

    xRet = FLASH_DRV_Init(&DrvFlash_InitConfig0, &flashSSDConfig);
    if(xRet == STATUS_SUCCESS)
    {
        /* Config FlexRAM as EEPROM if it is currently used as traditional RAM */
        if (flashSSDConfig.EEESize != 0x1000U)         /* if EEEPROM not 4KB */
        {
            /* Configure FlexRAM as EEPROM and FlexNVM as EEPROM backup region,
             * DEFlashPartition will be failed if the IFR region isn't blank.
             * Refer to the device document for valid EEPROM Data Size Code
             * and FlexNVM Partition Code. For example on S32K144: */
            xRet = FLASH_DRV_DEFlashPartition(  &flashSSDConfig, 
                                                0x02U,  /* EEPROM size = 4 Kbytes */
                                                0x04U,  /* EEPROM backup size = 64 Kbytes */
                                                0x02U,  /* 0=No key, 1=5 keys, 2=10 keys, 3=20 keys */
                                                false,  /* SFE */
                                                true);  /* FlexRAM load after reset */

            if(xRet == STATUS_SUCCESS)
            {
                /* Re-initialize the driver to update the new EEPROM configuration */
                xRet = FLASH_DRV_Init(&DrvFlash_InitConfig0, &flashSSDConfig);
            }
        }
    }
#if(0)
    if(xRet == STATUS_SUCCESS)
    {
        /* Make FlexRAM available for EEPROM */
        xRet = FLASH_DRV_SetFlexRamFunction( &flashSSDConfig, 
                                            EEE_ENABLE, 
                                            0x00u, 
                                            NULL);
    }
#endif
    if(xRet != STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_NVM, xRet));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }
    else
    {
        MSCM->OCMDR[1] |= MSCM_OCMDR_OCM1(0x03);    /* disable D_Flash prefetch buffer */

                                                /* init CRC module */
        xRet = CRC_DRV_Init(INST_DRVCRC, &DrvCrc_InitConfig0);
        if(xRet != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_CRC, xRet));
            #else
            for(;;)                             /* NOTE! stop if init fail */
            {
                ;
            }
            #endif
        }
        else
        {
            bRet = sbNvmConfDataLoad();
            if(bRet == 0)
            {
                ;
            }
            else if(bRet == 1)
            {
                sEventFlagSet(MASK_CONF_EMPTY);
            }
            else
            {
                #if 1                        
                sEventFlagSet(MASK_CONF_ERR);
                #else
                sEventFlagSet(MASK_CONF_EMPTY);// take default value if NVM err
                #endif
            }

            bRet = sbNvmCaliDataLoad();
            if(bRet == 0)
            {
                ;
            }
            else if(bRet == 1)
            {
                sEventFlagSet(MASK_CALI_EMPTY);
            }
            else
            {
                #if 1                        
                sEventFlagSet(MASK_CALI_ERR);
                #else
                sEventFlagSet(MASK_NVM_EMPTY);// take default value if NVM err
                #endif
            }
        }
    }
}


#if 0
/**
 * @brief   save current \var xConfCopy to EEPROM
 * @return  0 if PASS, else otherwise
 */
u8 sbNvmConfDataSave(void)
{
    const u8* pbBuf;
    u16 wLen;
    u16 wCrc16;
    status_t xRet;
    u8 bRet;
    u16 wWriteCntTemp;
    u16 wRemainBytes;

    wWriteCntTemp = xConfCopy.xHead.wWriteCounter;

    bRet = (wWriteCntTemp >= NVM_DATA_WRITE_TIME_LIMIT) ? 1U : 0;

    if(bRet == 0)
    {
        xConfCopy.xHead.wWriteCounter++;

        wLen = sizeof(x_conf_data_t);
        pbBuf = (const u8*)&xConfCopy;
        sNvmHeaderCrc16(pbBuf, wLen, &wCrc16);
        xConfCopy.xHead.wCrc16Ccitt = wCrc16;

        xRet = FLASH_DRV_EraseSector(   (const flash_ssd_config_t*)&flashSSDConfig,
                                        NVM_DATA_CONF_ADDR,
                                        NVM_DATA_BLOCK_SIZE);

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 2U;

        if(bRet != 0)
        {
            xConfCopy.xHead.wWriteCounter = wWriteCntTemp;
        }
    }

    if(bRet == 0)
    {
        u8 pbFinalSector[FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE] = {0};
        u8 i;

        wRemainBytes = wLen % FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE;

        if(wRemainBytes != 0)
        {
            wLen -= wRemainBytes;

            for(i=0; i<wRemainBytes; i++)
            {
                pbFinalSector[i] = pbBuf[wLen+i];
            }
        }

        xRet = FLASH_DRV_Program(   (const flash_ssd_config_t*)&flashSSDConfig,
                                    NVM_DATA_CONF_ADDR,
                                    (u32)wLen,
                                    pbBuf);

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 3U;

        if(bRet == 0)
        {
            xRet = FLASH_DRV_Program((const flash_ssd_config_t*)&flashSSDConfig,
                                    (NVM_DATA_CONF_ADDR + wLen),
                                    FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE,
                                    pbFinalSector);
        }

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 4U;
    }
    
    #if (HAVE_DEBUG_UART != 0)
    if(bRet != 0)
    {
        DebugPrintf("sbNvmConfDataSave error %d (0x%X)\n", bRet, xRet);
    }
    #endif
    
    return bRet;
}

/**
 * @brief   get the address current configuration data \var xConfCopy
 * @param   pxAddr[in,out] return point to xConfCopy
 */
void sNvmConfDataAddrGet(const x_conf_data_t *pxAddr)
{
    pxAddr = &xConfCopy;
}
#endif


/**
 * @brief   read (copy) current configuration data \var xConfCopy to input buffer
 * @param   pxData[in,out] return point to input buffer
 */
void sNvmConfDataRead(x_conf_data_t* pxData)
{
    void* pDest;
    const void* pSrc;
    u32 dwLen;

    dwLen = sizeof(x_conf_data_t);
    pDest = (void*)pxData;
    pSrc = (const void*)&xConfCopy;

    (void)fsl_memcpy(pDest, pSrc, dwLen);
}

#if 0
/**
 * @brief   save current \var xCaliData to EEPROM
 * @return  0 if PASS, else otherwise
 */
u8 sbNvmCaliDataSave(void)
{
    const u8* pbBuf;
    u16 wLen;
    u16 wCrc16;
    status_t xRet;
    u8 bRet;
    u16 wWriteCntTemp;
    u16 wRemainBytes = 0;

    wWriteCntTemp = xCaliData.xHead.wWriteCounter;

    bRet = (wWriteCntTemp >= NVM_DATA_WRITE_TIME_LIMIT) ? 1U : 0;

    if(bRet == 0)
    {
        xCaliData.xHead.wWriteCounter++;

        wLen = sizeof(x_cali_data_t);
        pbBuf = (const u8*)&xCaliData;
        sNvmHeaderCrc16(pbBuf, wLen, &wCrc16);
        xCaliData.xHead.wCrc16Ccitt = wCrc16;   // update CRC

                                                // erase D-Flash sectors
        xRet = FLASH_DRV_EraseSector((const flash_ssd_config_t*)&flashSSDConfig,
                                     NVM_DATA_CALI_ADDR,
                                     NVM_DATA_BLOCK_SIZE);

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 2U;

        if(bRet != 0)
        {
            xCaliData.xHead.wWriteCounter = wWriteCntTemp;
        }
    }

    if(bRet == 0)
    {
        u8 pbFinalSector[FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE] = {0};
        u8 i;

        wRemainBytes = wLen % FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE;

        if(wRemainBytes != 0)
        {
            wLen -= wRemainBytes;

            for(i=0; i<wRemainBytes; i++)
            {
                pbFinalSector[i] = pbBuf[wLen+i];
            }
        }
                                                // write D-Flash
        xRet = FLASH_DRV_Program(   (const flash_ssd_config_t*)&flashSSDConfig,
                                    NVM_DATA_CALI_ADDR,
                                    (u32)wLen,
                                    pbBuf);

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 3U;

        if(bRet == 0)
        {                                       // write final sector
            xRet = FLASH_DRV_Program((const flash_ssd_config_t*)&flashSSDConfig,
                                    (NVM_DATA_CALI_ADDR + wLen),
                                    FEATURE_FLS_PF_BLOCK_WRITE_UNIT_SIZE,
                                    pbFinalSector);
        }

        bRet = (xRet == STATUS_SUCCESS) ? 0 : 4U;
    }
    
    #if (HAVE_DEBUG_UART != 0)
    if(bRet != 0)
    {
        DebugPrintf("sbNvmCaliDataSave error %d (0x%X)\n", bRet, xRet);
    }
    #endif

    return bRet;
}
#endif

/**
 * @brief   read (copy) current calibration data \var xCaliData to input buffer
 * @param   pxData[in,out] return point to input buffer
 */
void sNvmCaliDataRead(x_cali_data_t* pxData)
{
    void* pDest;
    const void* pSrc;
    u32 dwLen;

    dwLen = sizeof(x_cali_data_t);
    pDest = (void*)pxData;
    pSrc = (const void*)&xCaliData;

    (void)fsl_memcpy(pDest, pSrc, dwLen);
}

/**
 * @brief   get the pointer to currnet calibration data \var xCaliData
 * @param   ppxData[out] return the pointer to \var xCaliData
 */
void sNvmCaliDataPtrGet(x_cali_data_t** ppxData)
{
    *ppxData = &xCaliData;
}

/**
 * @brief   get the pointer to currnet configuration data \var xConfData
 * @param   ppxData[out] return the pointer to \var xConfData
 */
void sNvmConfDataPtrGet(x_conf_data_t** ppxData)
{
    *ppxData = &xConfCopy;
}

/**
 * @brief   get the pointer to net_conf_t data \var xNetConfDefault
 * @param   pxData[out] return the pointer to \var xNetConfDefault
 */
void sNvmNetConfDefaultPtrGet(const net_conf_t** ppxData)
{
    *ppxData = &xNetConfDefault;
}



/**
 * @brief   clear PWM and ADC gain/offset to default value,
 *          it will not touch the EEPROM    
 */
void sNvmCaliDataReset(void)
{
    sPwmGainOffsetClear();
    sAdcGainOffsetClear();
}

void sNvmGetSSDConfig(flash_ssd_config_t * const pSSDConfig)
{
    *pSSDConfig = flashSSDConfig;
}
