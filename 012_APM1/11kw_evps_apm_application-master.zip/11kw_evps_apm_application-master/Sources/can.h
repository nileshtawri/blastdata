/**
 * @file        can.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_CAN_H
#define         DEF_CAN_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "can_tp_cfg.h"


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum APM_MODE_CMD_E
{
    APM_MODE_CMD_INVALID        = 0,
    APM_MODE_CMD_IDLE           = 1U,
    APM_MODE_CMD_STANDBY        = 2U,
    APM_MODE_CMD_DCDC           = 3U,
    APM_MODE_CMD_PRECHARGE      = 4U,
    APM_MODE_CMD_DISCHARGE      = 5U,
    APM_MODE_CMD_TEST           = 0xFFU,
}apm_mode_cmd_t;


typedef enum OBC_MODE_CMD_E
{
    OBC_MODE_CMD_STANDBY = 0,
    OBC_MODE_CMD_RUN,
    OBC_MODE_CMD_OFF,
    OBC_MODE_CMD_START,
    OBC_MODE_CMD_UNKNOW,
}obc_mode_cmd_t;


typedef enum OBC_WORK_MODE_E
{
    OBC_WORK_MODE_START = 0,
    OBC_WORK_MODE_IDLE,
    OBC_WORK_MODE_STANDBY,
    OBC_WORK_MODE_RUN,
    OBC_WORK_MODE_OFF,
    OBC_WORK_MODE_FAIL,                         // temporary failure
    OBC_WORK_MODE_LATCH,                        // critical failure
    OBC_WORK_MODE_UNKNOW,
}obc_work_mode_t;


typedef struct PACKED CAN0_IF_DATA_S
{
    apm_mode_cmd_t eApmModeCmd;
    f32 flApmVcmd;
    f32 flApmIcmd;
    obc_mode_cmd_t eObcModeCmd;
    f32 flObcVcmd;
    f32 flObcIcmd;
    e_bool_t eRxApmCmdTimeout;
    e_bool_t eRxObcCmdTimeout;
    e_bool_t eRxSysTimeTimeout;
    u16 wYear;
    u8 bMonth;
    u8 bDay;
    u8 bHour;
    u8 bMinute;
    u8 bSec;
    u8 b100ms;
}x_if_ci0_t;

typedef struct PACKED CAN2_IF_DATA_S
{
    obc_work_mode_t eObcWorkMode;
    u64 qwObcErrorFlag;
    f32 flObcPfcAuxVolt;
    f32 flObcPfcCurrA;
    f32 flObcPfcCurrB;
    f32 flObcPfcCurrC;
    f32 flObcPfcCurrD;
    f32 flObcGridVolt;
    f32 flObcGridCurr;
    f32 flObcGridFreq;
    f32 flObcHvdcVolt;
    f32 flObcHvdcCurr;
    f32 flObcBulkVolt;
    f32 flObcHvVoltRef;
    f32 flObcHvCurrRef;
    f32 flObcCtrlTheta;
    f32 flObcCtrlFreq;
    f32 flObcTempLlc;
    f32 flObcTempPfc;


    e_bool_t eRxTimeout;
}x_if_ci2_t;

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sCanIfInit(void);

extern void sCan0Init(void);
extern void sCan0Task(void);

#if 0                                           // unused code
extern bool sblIsCan0Loss(void);
extern apm_mode_cmd_t sxCanApmModeCmdGet(void);
extern f32 sflCanApmVcmdGet(void);
extern f32 sflCanApmIcmdGet(void);

#endif

extern void sIsoTpSendMsg(void);


extern void sCan2IsoTp(void);
extern void sCan2Task(void);

extern void sCan2Init_100k(void);
extern void sCan2Init(void);
extern bool sblIsC2kBootromFinish(void);

extern void sCanTxNmDebug(u8 bDbg0, u8 bDbg1, u8 bDbg2, u8 bDbg3);


#endif

