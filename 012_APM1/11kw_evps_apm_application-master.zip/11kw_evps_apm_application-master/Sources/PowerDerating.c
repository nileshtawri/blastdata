/*
 * File: PowerDerating.c
 *
 * Code generated for Simulink model 'PowerDerating'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Tue May 31 17:10:46 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PowerDerating.h"
#include "PowerDerating_private.h"

/* External inputs (root inport signals with default storage) */
ExtU_PowerDerating_T PowerDerating_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_PowerDerating_T PowerDerating_Y;

/* Model step function */
void AMP_Vin_Derating_Trigger(void)
{
  /* RootInportFunctionCallGenerator generated from: '<Root>/AMP_Vin_Derating_Trigger' incorporates:
   *  SubSystem: '<S1>/Subsystem1'
   */
  /* Gain: '<S3>/Gain' incorporates:
   *  Constant: '<S3>/Constant4'
   *  Inport: '<Root>/AMP_Vin'
   *  Product: '<S3>/Product'
   */
  PowerDerating_Y.APM_Derating_Vin = 0.94F * (PowerDerating_U.AMP_Vin * 8.0F);

  /* Switch: '<S3>/Switch2' incorporates:
   *  Constant: '<S3>/Constant5'
   *  RelationalOperator: '<S3>/Relational Operator2'
   */
  if (PowerDerating_Y.APM_Derating_Vin > 2200.0F) {
    /* Outport: '<Root>/APM_Derating_Vin' */
    PowerDerating_Y.APM_Derating_Vin = 2200.0F;
  }

  /* End of Switch: '<S3>/Switch2' */
  /* End of Outputs for RootInportFunctionCallGenerator generated from: '<Root>/AMP_Vin_Derating_Trigger' */
}

/* Model step function */
void APM_Temperature_Derating_Trigger(void)
{
  /* RootInportFunctionCallGenerator generated from: '<Root>/APM_Temperature_Derating_Trigger' incorporates:
   *  SubSystem: '<S1>/Subsystem'
   */
  /* If: '<S2>/If' incorporates:
   *  Constant: '<S2>/Constant3'
   *  Inport: '<Root>/APM_Temperature'
   *  RelationalOperator: '<S2>/Relational Operator'
   */
  if (PowerDerating_U.APM_Temperature >= 65.0F) {
    /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem' incorporates:
     *  ActionPort: '<S5>/Action Port'
     */
    /* Outport: '<Root>/APM_Derating_Temperature' incorporates:
     *  Constant: '<S5>/Constant'
     *  Constant: '<S5>/Constant1'
     *  Product: '<S5>/Product'
     *  Sum: '<S5>/Add'
     */
    PowerDerating_Y.APM_Derating_Temperature = 9566.66699F -
      (PowerDerating_U.APM_Temperature * 113.334F);

    /* End of Outputs for SubSystem: '<S2>/If Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S6>/Action Port'
     */
    /* Outport: '<Root>/APM_Derating_Temperature' incorporates:
     *  Constant: '<S6>/Constant'
     *  SignalConversion generated from: '<S6>/flMaxPower'
     */
    PowerDerating_Y.APM_Derating_Temperature = 2200.0F;

    /* End of Outputs for SubSystem: '<S2>/If Action Subsystem1' */
  }

  /* End of If: '<S2>/If' */
  /* End of Outputs for RootInportFunctionCallGenerator generated from: '<Root>/APM_Temperature_Derating_Trigger' */
}

/* Model step function */
void APM_Volt_Derating_Trigger(void)
{
  /* RootInportFunctionCallGenerator generated from: '<Root>/APM_Volt_Derating_Trigger' incorporates:
   *  SubSystem: '<S1>/Subsystem2'
   */
  /* Product: '<S4>/Product1' incorporates:
   *  Constant: '<S4>/Constant2'
   *  Inport: '<Root>/APM_Volt'
   */
  PowerDerating_Y.APM_Derating_Vo = PowerDerating_U.APM_Volt * 185.0F;

  /* Switch: '<S4>/Switch1' incorporates:
   *  Constant: '<S4>/Constant1'
   *  RelationalOperator: '<S4>/Relational Operator1'
   */
  if (PowerDerating_Y.APM_Derating_Vo > 2200.0F) {
    /* Outport: '<Root>/APM_Derating_Vo' */
    PowerDerating_Y.APM_Derating_Vo = 2200.0F;
  }

  /* End of Switch: '<S4>/Switch1' */
  /* End of Outputs for RootInportFunctionCallGenerator generated from: '<Root>/APM_Volt_Derating_Trigger' */
}

/* Model initialize function */
void PowerDerating_initialize(void)
{
  /* SystemInitialize for RootInportFunctionCallGenerator generated from: '<Root>/APM_Temperature_Derating_Trigger' incorporates:
   *  SubSystem: '<S1>/Subsystem'
   */
  /* SystemInitialize for Outport: '<Root>/APM_Derating_Temperature' incorporates:
   *  Merge: '<S2>/Merge'
   */
  PowerDerating_Y.APM_Derating_Temperature = 0.0F;

  /* End of SystemInitialize for RootInportFunctionCallGenerator generated from: '<Root>/APM_Temperature_Derating_Trigger' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

