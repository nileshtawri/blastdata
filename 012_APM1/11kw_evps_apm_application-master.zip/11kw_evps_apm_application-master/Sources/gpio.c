/**
 * @file        Gpio.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------


#include "type.h"
#include "config.h"
#include "gpio.h"
#include "cpu.h"
#include "housekeep.h"
#include "if.h"
#include "sbc.h"
#include "evse.h"
#include "obc.h"
#include "adc.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif



//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static bool blIgnState = false;
static bool blScpTriggered = false;
static bool blOvpTriggered = false;
static bool blSbcUvInt = false;


static x_if_di_t xIfDiData = 
{
    .eLvdcScpDih        = BOOL_FALSE,
    .eLvdcOvpDih        = BOOL_FALSE,
    .eBoostOvpDih       = BOOL_FALSE,
    .eDspOkDih          = BOOL_FALSE,
    .eObcOkDih          = BOOL_FALSE,
    .eSbcIgnDih         = BOOL_FALSE,
    .eHwScpTriggered    = BOOL_FALSE,
    .eHwOvpTriggered    = BOOL_FALSE,
    .eHwSbcIntTriggered = BOOL_FALSE,
};

static const x_if_ho_t *pxIfHoData = NULL;
static const x_if_oo_t *pxIfObc = NULL;
static const x_if_eo_t *pxIfEoData = NULL;

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/**
 * @brief       get the Ignition signal status from the SBC
 */
static void sIgnSignalRead(void)
{
    static bool blIgnLast = false;

    bool blPinIgn = false;
    status_t xRet;

	xRet = sSbcReadIoPin(SBC_PIN_MASK_IGN, &blPinIgn); //Get IG Pin Status
    if (xRet == STATUS_SUCCESS)
    {
        blIgnState = blPinIgn;

        if(blPinIgn != blIgnLast)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("IGN = %d\n", blPinIgn);
            #endif
        }

        blIgnLast = blPinIgn;
    }
    else
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sSbcReadIoPin err 0x%X\n", xRet);
        #endif
    }
}



/**
 * @brief       read IF_DO data to update all GPIO output pins
 */
static void sGpioDoUpdate(void)
{
    if (pxIfHoData->eLvdcEnDol == BOOL_TRUE)
    {
        PINS_DRV_ClearPins(LVDC_EN_DOL_PORT, (1UL << LVDC_EN_DOL_PIN));
    }

    if (pxIfHoData->eLvdcEnDol == BOOL_FALSE)
    {
        PINS_DRV_SetPins(LVDC_EN_DOL_PORT, (1UL << LVDC_EN_DOL_PIN));
    }

    #if (HVAE_BOOST_FUNC != 0)
    if (pxIfHoData->eBoostEnDol == BOOL_TRUE)
    {
        PINS_DRV_ClearPins(BOOST_EN_DOL_PORT, (1UL << BOOST_EN_DOL_PIN));
    }

    if (pxIfHoData->eBoostEnDol == BOOL_FALSE)
    {
        PINS_DRV_SetPins(BOOST_EN_DOL_PORT, (1UL << BOOST_EN_DOL_PIN));
    }
    #endif

    if (pxIfHoData->eApmAuxEnDoh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(APM_AUX_EN_DOH_PORT, (1UL << APM_AUX_EN_DOH_PIN));
    }

    if (pxIfHoData->eApmAuxEnDoh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(APM_AUX_EN_DOH_PORT, (1UL << APM_AUX_EN_DOH_PIN));
    }

    
    if (pxIfHoData->eDiagApmDoh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(DIAG_APM_DOH_PORT, (1UL << DIAG_APM_DOH_PIN));
    }

    if (pxIfHoData->eDiagApmDoh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(DIAG_APM_DOH_PORT, (1UL << DIAG_APM_DOH_PIN));
    }
    

    if (pxIfHoData->eLatchUnlockDoh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(LATCH_UNLOCK_DOH_PORT, (1UL << LATCH_UNLOCK_DOH_PIN));
    }

    if (pxIfHoData->eLatchUnlockDoh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(LATCH_UNLOCK_DOH_PORT, (1UL << LATCH_UNLOCK_DOH_PIN));
    }


    if (pxIfObc->eObcAuxEnDoh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));
    }

    if (pxIfObc->eObcAuxEnDoh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));
    }

    if (pxIfObc->eDspBootModeDol == BOOL_TRUE)
    {
        PINS_DRV_ClearPins(DSP_BOOT_DOH_PORT, (1UL << DSP_BOOT_DOH_PIN));
    }

    if (pxIfObc->eDspBootModeDol == BOOL_FALSE)
    {
        PINS_DRV_SetPins(DSP_BOOT_DOH_PORT, (1UL << DSP_BOOT_DOH_PIN));
    }


    if (pxIfEoData->eCpState_D_Doh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(CP_STATE_D_DOH_PORT, (1UL << CP_STATE_D_DOH_PIN));
    }

    if (pxIfEoData->eCpState_D_Doh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(CP_STATE_D_DOH_PORT, (1UL << CP_STATE_D_DOH_PIN));
    }


    if (pxIfEoData->eCpState_C_Doh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(CP_STATE_C_DOH_PORT, (1UL << CP_STATE_C_DOH_PIN));
    }

    if (pxIfEoData->eCpState_C_Doh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(CP_STATE_C_DOH_PORT, (1UL << CP_STATE_C_DOH_PIN));
    }

    
    if (pxIfObc->eDspResetDol == BOOL_TRUE)
    {
        PINS_DRV_ClearPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));
    }

    if (pxIfObc->eDspResetDol == BOOL_FALSE)
    {
        PINS_DRV_SetPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));
    }


    if (pxIfEoData->eCpReadyDoh == BOOL_TRUE)
    {
        PINS_DRV_SetPins(CP_READY_DOH_PORT, (1UL << CP_READY_DOH_PIN));
    }

    if (pxIfEoData->eCpReadyDoh == BOOL_FALSE)
    {
        PINS_DRV_ClearPins(CP_READY_DOH_PORT, (1UL << CP_READY_DOH_PIN));
    }
    
}

/**
 * @brief       read all GPIO input signal
 */
static void sGpioDiUpdate(void)
{
    pins_channel_type_t xPins;

    xPins = PINS_DRV_ReadPins(LVDC_OVP_DIH_PORT);
    if ((xPins & (1UL << LVDC_OVP_DIH_PIN)) != 0)
    {
        xIfDiData.eLvdcOvpDih = BOOL_TRUE;
    }
    else
    {
        xIfDiData.eLvdcOvpDih = BOOL_FALSE;
    }

    xPins = PINS_DRV_ReadPins(LVDC_SCP_DIH_PORT);
    if ((xPins & (1UL << LVDC_SCP_DIH_PIN)) != 0)
    {
        xIfDiData.eLvdcScpDih = BOOL_TRUE;
    }
    else
    {
        xIfDiData.eLvdcScpDih = BOOL_FALSE;
    }

    #if (HVAE_BOOST_FUNC != 0)
    xPins = PINS_DRV_ReadPins(BOOST_OVP_DIH_PORT);
    if ((xPins & (1UL << BOOST_OVP_DIH_PIN)) != 0)
    {
        xIfDiData.eBoostOvpDih = BOOL_TRUE;
    }
    else
    {
        xIfDiData.eBoostOvpDih = BOOL_FALSE;
    }
    #endif

    xPins = PINS_DRV_ReadPins(OBC_OK_DIH_PORT);
    if ((xPins & (1UL << OBC_OK_DIH_PIN)) != 0)
    {
        xIfDiData.eObcOkDih = BOOL_TRUE;
    }
    else
    {
        xIfDiData.eObcOkDih = BOOL_FALSE;
    }

    xPins = PINS_DRV_ReadPins(DSP_OK_DIH_PORT);
    if ((xPins & (1UL << DSP_OK_DIH_PIN)) != 0)
    {
        xIfDiData.eDspOkDih = BOOL_TRUE;
    }
    else
    {
        xIfDiData.eDspOkDih = BOOL_FALSE;
    }

    if ((pxIfHoData->eApmWorkMode == APM_MODE_SOFTSTART)
        || (pxIfHoData->eApmWorkMode == APM_MODE_ACTIVE))
    {
        if (blOvpTriggered == true)
        {
            xIfDiData.eHwOvpTriggered = BOOL_TRUE;

            INT_SYS_DisableIRQ(PORTC_IRQn);
            blOvpTriggered = false;
            INT_SYS_EnableIRQ(PORTC_IRQn);
        }

        if (blScpTriggered == true)
        {
            xIfDiData.eHwScpTriggered = BOOL_TRUE;

            INT_SYS_DisableIRQ(PORTC_IRQn);
            blScpTriggered = false;
            INT_SYS_EnableIRQ(PORTC_IRQn);
        }
    }
    else
    {
        xIfDiData.eHwOvpTriggered = BOOL_FALSE;
        xIfDiData.eHwScpTriggered = BOOL_FALSE;

        INT_SYS_DisableIRQ(PORTC_IRQn);
        blOvpTriggered = false;
        blScpTriggered = false;
        INT_SYS_EnableIRQ(PORTC_IRQn);
    }

    if (blSbcUvInt == true)
    {
        xIfDiData.eHwSbcIntTriggered = BOOL_TRUE;

        INT_SYS_DisableIRQ(PORTC_IRQn);
        blSbcUvInt = false;
        INT_SYS_EnableIRQ(PORTC_IRQn);
    }

    xIfDiData.eSbcIgnDih = blIgnState ? BOOL_TRUE : BOOL_FALSE;
}

static void GpioEmergencyShutdown(void)
{
    // pxIfHoData->eLvdcEnDol = BOOL_FALSE
    PINS_DRV_SetPins(LVDC_EN_DOL_PORT, (1UL << LVDC_EN_DOL_PIN));

    // pxIfHoData->eApmAuxEnDoh = BOOL_FALSE
    PINS_DRV_ClearPins(APM_AUX_EN_DOH_PORT, (1UL << APM_AUX_EN_DOH_PIN));

    // pxIfObc->eObcAuxEnDoh = BOOL_FALSE
    PINS_DRV_ClearPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));

    // pxIfEoData->eCpState_D_Doh = BOOL_FALSE
    PINS_DRV_ClearPins(CP_STATE_D_DOH_PORT, (1UL << CP_STATE_D_DOH_PIN));

    // pxIfEoData->eCpState_C_Doh = BOOL_FALSE
    PINS_DRV_ClearPins(CP_STATE_C_DOH_PORT, (1UL << CP_STATE_C_DOH_PIN));

    // pxIfObc->eDspResetDol = BOOL_FALSE
    PINS_DRV_SetPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));

    // pxIfEoData->eCpReadyDoh = BOOL_FALSE
    PINS_DRV_ClearPins(CP_READY_DOH_PORT, (1UL << CP_READY_DOH_PIN));
}

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief       PORTC ISR, trigger by rising edge of LVDC_OVP, LVDC_SCP and 
 *              SBC_INTb (VBAT_UV)
 */
void PORTC_IRQHandler(void)
{
    u32 dwIntFlags;

    dwIntFlags = PINS_DRV_GetPortIntFlag(PORTC);

    PINS_DRV_ClearPortIntFlagCmd(PORTC);

    if((dwIntFlags & (1UL << SBC_INT_DIL_PIN)) != 0)    /* check Vbat UV event */
    {                                      
        bool blBatUv = sblAdcBatIsUv();                 /* double check ADC value */

        if (blBatUv == true)
        {
            GpioEmergencyShutdown();                    /* emergency shutdown */

            blSbcUvInt = true;
        }

    }

    if((dwIntFlags & (1UL << LVDC_OVP_DIH_PIN)) != 0)
    {
    	blOvpTriggered = true;
    }
    
    if((dwIntFlags & (1UL << LVDC_SCP_DIH_PIN)) != 0)
    {
    	blScpTriggered = true;
    }
}

/**
 * @brief: init IF_DI data pointer
 */
void sGpioIfInit(void)
{
    (void)sbIfSet(IF_DI, &xIfDiData);           // init IF_DI data pointer
}

void sGpioEnableInterrupt(void)
{
    
}


/**
 * @brief: init GPIO
 */
void sGpioInit(void)
{
    status_t xRet;

    xRet = PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
    if(xRet != STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_GIO, xRet));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }

    PINS_DRV_ClearPortIntFlagCmd(PORTC);

//    INT_SYS_EnableIRQ(PORTC_IRQn);

    #if (HAVE_DEBUG_GPIO != 0)

    PINS_DRV_SetMuxModeSel( TEST_PIN0_PTMUX,
                            TEST_PIN0_INDEX, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   TEST_PIN0_PORT, 
                                TEST_PIN0_INDEX, 
                                (u8)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetPins(TEST_PIN0_PORT, (1UL << TEST_PIN0_INDEX));

    PINS_DRV_SetMuxModeSel( TEST_PIN1_PTMUX,
                            TEST_PIN1_INDEX, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   TEST_PIN1_PORT, 
                                TEST_PIN1_INDEX,
                                (u8)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetPins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));

    PINS_DRV_SetMuxModeSel( TEST_PIN2_PTMUX,
                            TEST_PIN2_INDEX, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   TEST_PIN2_PORT, 
                                TEST_PIN2_INDEX,
                                (u8)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetPins(TEST_PIN2_PORT, (1UL << TEST_PIN2_INDEX));

    PINS_DRV_SetMuxModeSel( TEST_PIN3_PTMUX,
                            TEST_PIN3_INDEX, 
                            PORT_MUX_AS_GPIO);
    
    PINS_DRV_SetPinDirection(   TEST_PIN3_PORT, 
                                TEST_PIN3_INDEX,
                                (u8)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetPins(TEST_PIN3_PORT, (1UL << TEST_PIN3_INDEX));
    #endif
}





/**
 * \brief       GPIO task, execution cycle time should be 1 ms
 */
void sGpioTask(void)
{
    static u16 w1msTickTo100 = 0;
    bool blIsTimeToReadIgn;

    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_HO, false, (const void**)&pxIfHoData);
    (void)sbIfGet(IF_OO, false, (const void**)&pxIfObc);
    (void)sbIfGet(IF_EO, false, (const void**)&pxIfEoData);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */

    blIsTimeToReadIgn = ((w1msTickTo100 % 10U) == 0);

    if (blIsTimeToReadIgn == true)
    {
        sIgnSignalRead();                       // get IGN state from the SBC
    }

    if ((xIfDiData.eHwSbcIntTriggered == BOOL_FALSE)
        && (blSbcUvInt == false))
    {
        sGpioDoUpdate();
    }

    sGpioDiUpdate();

    (void)sbIfSet(IF_DI, &xIfDiData);           // update GPIO input signals

    //#if (HAVE_DEBUG_GPIO != 0)
    //PINS_DRV_TogglePins(TEST_PIN2_PORT, (1UL << TEST_PIN2_INDEX));
    //#endif

    w1msTickTo100++;
    w1msTickTo100 %= 100U;
}

#if 0                                           // unused code
/**
 * \brief       HW SCP or OVP triggered flag is confirmed, clear it
 */
void sGpioHwTriggerConfirm(void)
{
    xIfDiData.eHwScpTriggered = BOOL_FALSE;
    xIfDiData.eHwOvpTriggered = BOOL_FALSE;

    (void)sbIfSet(IF_DI, &xIfDiData);           // update GPIO input signals
}
#endif



