/**
 * @file        timer.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "config.h"
#include "cpu.h"
#include "timer.h"
#include "gpio.h"
#include "type.h"
#include "can.h"
#include "housekeep.h"
#include "tp.h"
#include "uds_app.h"
#include "SafetyMeasure.h"
#include "obc.h"
#include "adc.h"
#include "pwm.h"
#include "evse.h"
#include "NetworkManagement.h"
#include "eeprom.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#define UART_TASK       sUartTask
#else
#define UART_TASK       NULL
#endif



//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------

static void s1msIsr(void);
static void s100usIsr(void);


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------


static volatile u32 dwTick = 0;
static volatile u32 dwTickCouter = 0;


static timer_t pTimers[TIMER_ID_END] = 
{   /*     ID     ,             enable, once,   period, remain, function    */
    {TIMER_ID_IDLE,             true,   false,  7U,     7U,     sIdleTask},
    {TIMER_ID_ADC,              true,   false,  1U,     1U,     sAdcTask},
    {TIMER_ID_PWM,              true,   false,  1U,     10U,    sPwmTask},
    {TIMER_ID_GPIO,             true,   false,  1U,     1U,     sGpioTask},
    {TIMER_ID_CAN0_TASK,        false,  false,  10U,    10U,    sCan0Task},
    {TIMER_ID_CAN2_TASK,        true,   false,  1U,     500U,   sCan2Task},
    {TIMER_ID_UART,             true,   false,  100U,   10U,    UART_TASK},
    {TIMER_ID_OBC,              false,  false,  10U,    1U,     sObcTask},
    {TIMER_ID_EVSE,             true,   false,  10U,    10U,    sEvseTask},
    {TIMER_ID_HOUSE,            false,  false,  0U,     0U,     sHuoseKeepTask},
    {TIMER_ID_TEST,             true,   false,  5U,     5U,     sTestTask},
    {TIMER_ID_EEP,              true,   false,  1U,     1U,     sEEP_Task},
    {TIMER_ID_ISOTP,            true,   false,  1U,     1U,     TP_SystemTickCtl},
    {TIMER_ID_UDS,              true,   false,  1U,     1U,     UDS_SystemTickCtl},
    {TIMER_ID_TP_MAINFUN,       true,   false,  1,      1U,     TP_MainFun},
    {TIMER_ID_ISO_TP_SEND_MSG,  true,   false,  1,      1U,     sIsoTpSendMsg},
    {TIMER_ID_UDS_MAINFUN,      true,   false,  1,      1U,     UDS_MainFun},
    {TIMER_ID_SOFTSTART,        false,  false,  1U,     1U,     sSoftStart},
    {TIMER_ID_CAN2_TP,          false,  false,  1U,     1U,     sCan2IsoTp},
    {TIMER_ID_NM,               true,   false,  10,     1U,     sNmTask},
    {TIMER_ID_NM_TIMEOUT,       false,  false,  1000U,  1U,     sNmFrameTimeoutProcess},
    {TIMER_ID_REPEAT_MESSAGE,   false,  true,   1500U,  1U,     sNmTimerProcess},
    {TIMER_ID_WAIT_BUS_SLEEP,   false,  true,   2000U,  1U,     sNmTimerProcess},
    {TIMER_ID_APPL_FRAME_DELAY, false,  true,   20U,    1U,     sNmApplFrameEnable},
};

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------


/**
 * @brief: LPIT0 channel1 interrupt handler.
 *         tick the internal timer counter
 */
static void s1msIsr(void)
{
    /* Clear LPIT channel1 flag */
    LPIT_DRV_ClearInterruptFlagTimerChannels(INST_DRVTIMER, 
                                            (1UL << LPIT_CHANNEL_1));

    dwTick += 1U;
    dwTickCouter += 1U;

    sFlushBuffer();
}


/**
 * @brief: LPIT0 channel0 interrupt handler.
 *         this timer generates trigger signal for ADC sampling,
 *         do nothing in this ISR, for debug only
 */
static void s100usIsr(void)
{
    /* Clear LPIT channel1 flag */
    LPIT_DRV_ClearInterruptFlagTimerChannels(INST_DRVTIMER, 
                                            (1UL << LPIT_CHANNEL_0));

    sFlushBuffer();
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief: initial system clock, watchdog and LPIT0 timers.
 *
 * @note : stop execution if timer initial failed
 */
void sTimerInit(void)
{
    u16 wRet;
    
    #if 1
    wRet = (u16)WDOG_DRV_Init(INST_DRVWDOG, &DrvWdog_Config0);

    if(wRet != (u16)STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_DOG, wRet));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }
    else
    {
        INT_SYS_InstallHandler(WDOG_EWM_IRQn, &WDOG_EWM_IRQHandler, NULL);
    }
    #endif

    LPIT_DRV_Init(INST_DRVTIMER, &DrvTimer_InitConfig);

    wRet = (u16)LPIT_DRV_InitChannel(INST_DRVTIMER,
                                    LPIT_CHANNEL_0, 
                                    &DrvTimer_AdcTrigger);

    wRet |= (u16)LPIT_DRV_InitChannel(   INST_DRVTIMER,
                                        LPIT_CHANNEL_1, 
                                        &DrvTimer_1msTick);

    if(wRet != (u16)STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_PIT, wRet));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }

    INT_SYS_InstallHandler(LPIT_Channel_0_IRQ, &s100usIsr, NULL);
    INT_SYS_InstallHandler(LPIT_Channel_1_IRQ, &s1msIsr, NULL/*(isr_t *)0*/);

    LPIT_DRV_StartTimerChannels(INST_DRVTIMER, (1UL << LPIT_CHANNEL_0));
    LPIT_DRV_StartTimerChannels(INST_DRVTIMER, (1UL << LPIT_CHANNEL_1));

    OSIF_TimeDelay(0);
}

/**
 * @brief: check and perform each timer function.
 *         this function should be call in background loop, and frequency should
 *         faster than the timer tick
 */
void sTimerRun(void)
{
    u32 i;
    u32 dwTimer;
    
    if(dwTick != 0)
    {
        LPIT_DRV_DisableTimerChannelInterrupt(  INST_DRVTIMER, 
                                                (1UL << LPIT_CHANNEL_1));
        dwTimer = dwTick;
        LPIT_DRV_EnableTimerChannelInterrupt(   INST_DRVTIMER, 
                                                (1UL << LPIT_CHANNEL_1));

        for(i=0; i<(u32)TIMER_ID_END; i++)
        {
            if(pTimers[i].blEnable == true)
            {
                if(dwTimer >= pTimers[i].dwRemain)
                {
                    if(pTimers[i].pFunc != NULL)
                    {
                        pTimers[i].pFunc();     /* perform the timer function */
                    }

                    pTimers[i].dwRemain = 0;

                    if(pTimers[i].blOneShot == true)
                    {
                        pTimers[i].blEnable = false;
                    }
                    else
                    {
                        pTimers[i].dwRemain = pTimers[i].dwPeriod;
                    }
                }
                else
                {
                    LPIT_DRV_DisableTimerChannelInterrupt(  INST_DRVTIMER, 
                                                            (1UL << LPIT_CHANNEL_1));
                    dwTimer = dwTick;
                    LPIT_DRV_EnableTimerChannelInterrupt(   INST_DRVTIMER, 
                                                            (1UL << LPIT_CHANNEL_1));

                    if(dwTimer > 1)             /* if timer delayed over 1ms */
                    {
                        if(pTimers[i].dwRemain >= dwTimer)
                        {
                            pTimers[i].dwRemain -= dwTimer;
                        }
                        else if(pTimers[i].dwRemain < dwTimer)
                        {
                            pTimers[i].dwRemain = 0;
                        }
                    }
                    else
                    {
                        pTimers[i].dwRemain -= dwTimer;
                    }
                }
            }
        }

        LPIT_DRV_DisableTimerChannelInterrupt(  INST_DRVTIMER, 
                                                (1UL << LPIT_CHANNEL_1));
        dwTick = 0;
        LPIT_DRV_EnableTimerChannelInterrupt(   INST_DRVTIMER,
                                                (1UL << LPIT_CHANNEL_1));

    }
}

/**
 * @brief:  reset a timer, it only reset the timer counter, 
 *          it will not tounch the enable flag
 *
 * @param[in] eTid  timer ID
 */
void sTimerReset(timer_id_t eTid)
{
    if(eTid < TIMER_ID_END)
    {
        pTimers[eTid].dwRemain = pTimers[eTid].dwPeriod;
    }
}

/**
 * @brief:  enable/start a timer,
 *          enable and re-start a timer
 *
 * @param[in] eTid  timer ID
 */
void sTimerStart(timer_id_t eTid)
{
    if(eTid < TIMER_ID_END)
    {
        pTimers[eTid].blEnable = true;
        pTimers[eTid].dwRemain = pTimers[eTid].dwPeriod;
    }
}

/**
 * @brief: disable/stop a timer
 *
 * @param[in] eTid  timer ID
 */
void sTimerStop(timer_id_t eTid)
{
    if(eTid < TIMER_ID_END)
    {
        pTimers[eTid].blEnable = false;
    }
}

/**
 * @brief: change the period time of a timer
 * @param[in] eTid  timer ID
 * @param[in] swTime new timer counter value
 */
void sTimerPeriodSet(timer_id_t eTid, u32 dwTime)
{
    if(eTid < TIMER_ID_END)
    {
        pTimers[eTid].dwPeriod = dwTime;
    }
}

/**
 * @brief: change the remain time of a timer
 * @param[in] eTid  timer ID
 * @param[in] swTime new timer counter value
 */
void sTimerRemainSet(timer_id_t eTid, u32 dwTime)
{
    if(eTid < TIMER_ID_END)
    {
        pTimers[eTid].dwRemain = dwTime;
    }
}

/**
 * @brief: return the timer is enable or not
 * @return true or false
 */
bool sblTimerIsEnable(timer_id_t eTid)
{
    return pTimers[eTid].blEnable;
}

/**
 * @brief: return the timer couter which is never clear
 * @return dwTickCouter
 */
u32 sdwTimerTickGet(void)
{
    return dwTickCouter;
}


