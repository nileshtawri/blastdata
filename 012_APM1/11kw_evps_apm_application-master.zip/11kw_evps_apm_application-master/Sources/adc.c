/**
 * @file        ADC.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "Cpu.h"
#include "adc.h"
#include "nvm.h"
#include "if.h"
#include "user_config.h"
#include "gpio.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define     ADC_BITS                    12U
#define     ADC_VREF                    5.0F
#define     ADC_MAX                     (s32)((1UL << ADC_BITS) - 1U)
#define     ADC_SELF_1V                 (ADC_MAX / 5)
#define     ADC_SELF_1V_MAX             (ADC_SELF_1V + 50)
#define     ADC_SELF_1V_MIN             (ADC_SELF_1V - 50)

#define     ADC_CALI_GAIN_MAX           1.5F
#define     ADC_CALI_GAIN_MIN           0.5F
#define     ADC_CALI_GAIN_DEFAULT       1.0F
#define     ADC_CALI_OFFSET_MAX         100.0F
#define     ADC_CALI_OFFSET_MIN         (-100.0F)
#define     ADC_CALI_OFFSET_DEFAULT     0.0F

#define     PTC_COFF_A0                 -5.119587E+02F
#define     PTC_COFF_A1                 4.357398E+02F
#define     PTC_COFF_A2                 -1.531109E+02F
#define     PTC_COFF_A3                 2.991921E+01F
#define     PTC_COFF_A4                 -1.633023E+00F

#define     ADC_VAL_BAT_8V              ((u16)((10.0/25.0)*ADC_MAX))

enum        ADC_CTRL_E                      // ADC controller instance
{
    ADC_0,
    ADC_1,
    ADC_NUM
};

enum        ADC0_CH_E
{                                           // ADC0 input channel buffer index
    ADC0_CH_AUX_HV_VOLT = 0,
    ADC0_CH_AUX_LV_VOLT,
    ADC0_CH_NTC_1_TEMP,                     // NTC_PCB
    ADC0_CH_PD_VOLT,
    ADC0_CH_CP_VOLT,
    ADC0_CH_SBC_MUX,
    ADC0_CH_SELF_1V,
    ADC0_CH_NUM,
};

enum        ADC1_CH_E
{                                           // ADC1 input channel buffer index
    ADC1_CH_LVDC_CURR = 0,
    ADC1_CH_NTC_3_TEMP,                     // NTC_COOLANT
    ADC1_CH_REMOTE_VOLT,
    ADC1_CH_HVDC_VOLT,
    ADC1_CH_NTC_2_TEMP,                     // NTC_SR
    ADC1_CH_APM_CURR,                       // HV input current
    ADC1_CH_SELF_1V,
    ADC1_CH_NUM,
};

enum        AI_ID_E                         // Analog Input signal ID
{
    AI_AUX_HV = 0,                          // for ADC0_CH_AUX_HV_VOLT,
    AI_AUX_LV,                              // for ADC0_CH_AUX_LV_VOLT,
    AI_TEMP_PCB,                            // for ADC0_CH_NTC_1_TEMP,
    AI_PD_VOLT,                             // for ADC0_CH_PD_VOLT,
    AI_CP_VOLT,                             // for ADC0_CH_CP_VOLT,
    AI_BAT_VOLT,                            // for ADC0_CH_SBC_MUX,
    AI_LV_CURR,                             // for ADC1_CH_LVDC_CURR,
    AI_TEMP_COOL,                           // for ADC1_CH_NTC_3_TEMP,
    AI_LV_VOLT,                             // for ADC1_CH_REMOTE_VOLT,
    AI_HV_VOLT,                             // for ADC1_CH_HVDC_VOLT,
    AI_TEMP_SR,                             // for ADC1_CH_NTC_2_TEMP,
    AI_HV_CURR,                             // for ADC1_CH_APM_CURR,
    AI_NUM
};

//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

typedef struct ANALOG_INPUT_SIGNAL_S
{
    u8  bAiCh;                              // analag input signal ID of AI_CH_E
    u8  bAdcInst;                           // enum of ADC_CTRL_E
    u8  bAdcCh;                             // enum of ADC0_CH_E or ADC1_CH_E
    s32 diAdcCntMin;                        // mininum value of ADC count
    s32 diAdcCntMax;                        // maxinum value of ADC count
    f32 flHwGainVal;                        // hardware native gain value
    f32 flHwOffsetVal;                      // hardware native offset value
    f32 flSwGainVal;                        // software adjust gain value
    f32 flSwOffsetVal;                      // software adjust offset value
    f32 flPhyValFast;                       // physical converted value, before filter
    f32 flPhyValMax;                        // maxinum value in physical
    f32 flPhyValMin;                        // mininum value in physical
    u16 wAvgCycle;                          // average cycle time
    u16 wAvgCnt;                            // average counter
    f32 flAvgSum;                           // sum for average
    f32 flPhyValFilted;                     // physical converted value, after filter
    u32 dwErrorCnt;                         // error counter
}x_ai_signal;

//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static u16 waAdc0Val[ADC0_CH_NUM];          // ADC0 sample buffer, index of ADC0_CH_E
static u16 waAdc1Val[ADC1_CH_NUM];          // ADC1 sample buffer, index of ADC1_CH_E

static x_if_ai_t xIfAiData = {0};           // IF_AI data

static bool blIsVbatUv = false;             // a special flag to detect BAT UV

#if 0                                       // unused code
static f32 flVoutGain =     ADC_CALI_GAIN_DEFAULT;
static f32 flVoutOffset =   ADC_CALI_OFFSET_DEFAULT;
static f32 flIoutGain =     ADC_CALI_GAIN_DEFAULT;
static f32 flIoutOffset =   ADC_CALI_OFFSET_DEFAULT;
static f32 flVinGain =      ADC_CALI_GAIN_DEFAULT;
static f32 flVinOffset =    ADC_CALI_OFFSET_DEFAULT;
static f32 flIinGain =      ADC_CALI_GAIN_DEFAULT;
static f32 flIinOffset =    ADC_CALI_OFFSET_DEFAULT;
static f32 flVbatGain =     ADC_CALI_GAIN_DEFAULT;
static f32 flVbatOffset =   ADC_CALI_OFFSET_DEFAULT;
#endif

static x_ai_signal xaAi[AI_NUM] =           // analag input signal sample by ADC
{
    {
        (u8)AI_AUX_HV,                      // ID = AI_AUX_HV
        (u8)ADC_0,                          // sample by ADC0
        (u8)ADC0_CH_AUX_HV_VOLT,            // sampled value buffer index
        0,                                  // ADC minimal sample value
        ADC_MAX,                            // ADC maximal sample value
        18.66716445772F,                    // hardware native gain value
        -26.880716819F,                     // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter        
        30.0F,                              // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_AUX_LV,                      // ID = AI_AUX_LV
        (u8)ADC_0,                          // sample by ADC0
        (u8)ADC0_CH_AUX_LV_VOLT,            // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        4.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        20.0F,                              // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_TEMP_PCB,                    // ID = AI_TEMP_PCB
        (u8)ADC_0,                          // sample by ADC0
        (u8)ADC0_CH_NTC_1_TEMP,             // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        0.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        0.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        150.0F,                             // maxinum value in physical
        -40.0F,                             // mininum value in physical
        100U,                               // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_PD_VOLT,                     // ID = AI_PD_VOLT
        (u8)ADC_0,                          // sample by ADC0
        (u8)ADC0_CH_PD_VOLT,                // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        1.122222359382733F,                 // hardware native gain value
        0.0F,                               // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        5.0F,                               // maxinum value in physical
        0.0F,                               // mininum value in physical
        100U,                               // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_CP_VOLT,                     // ID = AI_CP_VOLT
        (u8)ADC_0,                          // sample by ADC1
        (u8)ADC0_CH_CP_VOLT,                // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        5.128205128205128F,                 // hardware native gain value
        -12.82051282051282F,                // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        12.7F,                              // maxinum value in physical
        -12.8F,                             // mininum value in physical
        10U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_BAT_VOLT,                    // ID = AI_BAT_VOLT
        (u8)ADC_0,                          // sample by ADC0
        (u8)ADC0_CH_SBC_MUX,                // sampled value buffer index
        0,                                  // ADC minimal sample value
        ADC_MAX,                            // ADC maximal sample value
        5.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        20.0F,                              // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_LV_CURR,                     // ID = AI_LV_CURR
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_LVDC_CURR,              // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        66.66666666666667F,                 // hardware native gain value
        -33.33333333333333F,                // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        300.0F,                             // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_TEMP_COOL,                   // ID = AI_TEMP_COOL
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_NTC_3_TEMP,             // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        0.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        0.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        150.0F,                             // maxinum value in physical
        -40.0F,                             // mininum value in physical
        100U,                               // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_LV_VOLT,                     // ID = AI_LV_VOLT
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_REMOTE_VOLT,            // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        4.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        20.0F,                              // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_HV_VOLT,                     // ID = AI_HV_VOLT
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_HVDC_VOLT,              // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        502.0080321285F,                    // hardware native gain value
        -722.891566265F,                    // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        600.0F,                             // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_TEMP_SR,                     // ID = AI_TEMP_SR
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_NTC_2_TEMP,             // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        0.0F,                               // hardware native gain value
        0.0F,                               // hardware native offset value
        0.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        150.0F,                             // maxinum value in physical
        -40.0F,                             // mininum value in physical
        100U,                               // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
    {
        (u8)AI_HV_CURR,                     // ID = AI_HV_CURR
        (u8)ADC_1,                          // sample by ADC1
        (u8)ADC1_CH_APM_CURR,               // sampled value buffer index
        0,                                  // ADC minimal sample value  
        ADC_MAX,                            // ADC maximal sample value
        6.0F,                               // hardware native gain value
        -15.0F,                             // hardware native offset value
        1.0F,                               // software adjust gain value
        0.0F,                               // software adjust offset value
        0.0F,                               // physical converted value, before filter
        30.0F,                              // maxinum value in physical
        0.0F,                               // mininum value in physical
        50U,                                // average cycle time
        0,                                  // average counter
        0.0F,                               // sum for average
        0.0F,                               // physical converted value, after filter
        0,                                  // error counter
    },
};

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------
/**
 * @brief       ADC0 interrupt service routine
 */
static void ADC0_IRQHandler(void)
{
    u8 i;

    for(i=0; i<(u8)ADC0_CH_NUM; i++)                // Read ADC0 sample value
    {
        ADC_DRV_GetChanResult(INST_DRVADC0, i,  &waAdc0Val[i]);
    }

    for(i=0; i<(u8)ADC1_CH_NUM; i++)                // Read ADC1 sample value
    {
        ADC_DRV_GetChanResult(INST_DRVADC1, i,  &waAdc1Val[i]);
    }

    blIsVbatUv = (waAdc0Val[ADC0_CH_SBC_MUX] < ADC_VAL_BAT_8V) ? true : false;
}

/**
 * @brief       Initialize the PDB modules,
 *              PDB0 trigger ADC0, 6 channels with back-to-back mode,
 *              PDB1 trigger ADC1, 5 channels with back-to-back mode.
 */
static void sPDBInitial(void)
{
    PDB_DRV_Init(INST_DRVADC0TRIG, &DrvAdc0Trig_InitConfig0);

    PDB_DRV_Enable(INST_DRVADC0TRIG);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig0);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig1);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig2);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig3);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig4);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig5);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC0TRIG,
                                0,
                                &DrvAdc0Trig_AdcTrigInitConfig6);

    PDB_DRV_Init(INST_DRVADC1TRIG, &DrvAdc1Trig_InitConfig0);


    PDB_DRV_Enable(INST_DRVADC1TRIG);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig0);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig1);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig2);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig3);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig4);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig5);

    PDB_DRV_ConfigAdcPreTrigger(INST_DRVADC1TRIG,
                                0,
                                &DrvAdc1Trig_AdcTrigInitConfig6);
}

/**
 * \brief   convert ADC sample value to physical signal
 *
 * \param[in]   Analog input signal ID, enum in \AI_ID_E
 *
 * \retval  0   PASS
 * \retval  1   ADC internal reference voltage error
 * \retval  2   ADC controller instance ID out of range
 * \retval  3   ADC sample count out of range
 * \retval  4   input param \bAiChId out of range
 */
static u8 sflAdcConvToPhy(u8 bAiChId)
{
    s32 diVal;
    f32 flVal;
    u8 bCh;
    u8 bRet = 0;
    
    if(bAiChId < (u8)AI_NUM)
    {
        bCh = xaAi[bAiChId].bAdcCh;             // input channel buffer ID of a ADC

        if (xaAi[bAiChId].bAdcInst == (u8)ADC_0)// get the sample count of a ADC
        {
            diVal = (s32)waAdc0Val[bCh];        // reserved for differential ADC

            if( (waAdc0Val[ADC0_CH_SELF_1V] > ADC_SELF_1V_MAX) 
                || (waAdc0Val[ADC0_CH_SELF_1V] < ADC_SELF_1V_MIN))
            {
                bRet = 1U;
                goto lAdcExit;
            }
        }
        else if (xaAi[bAiChId].bAdcInst == (u8)ADC_1)
        {
            diVal = (s32)waAdc1Val[bCh];        // reserved for differential ADC

            if( (waAdc1Val[ADC1_CH_SELF_1V] > ADC_SELF_1V_MAX) 
                || (waAdc1Val[ADC1_CH_SELF_1V] < ADC_SELF_1V_MIN))
            {
                bRet = 1U;
                goto lAdcExit;
            }
        }
        else
        {
            bRet = 2U;
            goto lAdcExit;
        }

        if ((diVal < xaAi[bAiChId].diAdcCntMin)  // check value range of the count
            || (diVal > xaAi[bAiChId].diAdcCntMax))
        {
            bRet = 3U;
            goto lAdcExit;
        }

        /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
        flVal = (f32)diVal;
        flVal /= (f32)ADC_MAX;
        /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
        flVal *= ADC_VREF;
        flVal *= xaAi[bAiChId].flHwGainVal;     // convert to physical signal
        flVal += xaAi[bAiChId].flHwOffsetVal;

        flVal *= xaAi[bAiChId].flSwGainVal;     // calibrate with gain/offset
        flVal += xaAi[bAiChId].flSwOffsetVal;

        if (flVal < xaAi[bAiChId].flPhyValMin)  // check value range
        {
            flVal = xaAi[bAiChId].flPhyValMin;
        }

        if (flVal > xaAi[bAiChId].flPhyValMax)  // check value range
        {
            flVal = xaAi[bAiChId].flPhyValMax;
        }

        xaAi[bAiChId].flPhyValFast = flVal;     // output value without filter
        
        if(xaAi[bAiChId].wAvgCnt < xaAi[bAiChId].wAvgCycle)
        {
            xaAi[bAiChId].flAvgSum += flVal;
        }
        else                                    // average filter
        {
            xaAi[bAiChId].flPhyValFilted = xaAi[bAiChId].flAvgSum;
            xaAi[bAiChId].flPhyValFilted /= (f32)xaAi[bAiChId].wAvgCycle;

            xaAi[bAiChId].flAvgSum = flVal;
            xaAi[bAiChId].wAvgCnt = 0;
        }
        xaAi[bAiChId].wAvgCnt++;

    }
    else
    {
        bRet = 4U;
    }

lAdcExit:

    if(bRet != 0)
    {
        xaAi[bAiChId].dwErrorCnt++;

        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sflAdcConv [%d] err %d\n", bAiChId, bRet);
        #endif
    }

    return bRet;
}


/**
 * \brief   convert ADC sample value to temperature (degree C),
 *          Coefficients in TI_Thermistor_Design_Tool-Voltage_Bias V1.51
 *
 * \param[in]   Analog input signal ID, enum in \AI_ID_E
 *
 * \retval  0   PASS
 * \retval  1   ADC internal reference voltage error
 * \retval  2   ADC controller instance ID out of range
 * \retval  3   ADC sample count out of range
 * \retval  4   input param \bAiChId out of range
 */
static u8 sflAdcConvToTemp(u8 bAiChId)
{
    s32 diVal;
    f32 flVal;
    u8 bCh;
    u8 bRet = 0;
    
    if(bAiChId < (u8)AI_NUM)
    {
        f32 flVal2;
        f32 flVal3;
        f32 flVal4;
        f32 flTemp;

        bCh = xaAi[bAiChId].bAdcCh;             // input channel buffer ID of a ADC

        if (xaAi[bAiChId].bAdcInst == (u8)ADC_0)// get the sample count of a ADC
        {
            diVal = (s32)waAdc0Val[bCh];        // reserved for differential ADC

            if( (waAdc0Val[ADC0_CH_SELF_1V] > ADC_SELF_1V_MAX) 
                || (waAdc0Val[ADC0_CH_SELF_1V] < ADC_SELF_1V_MIN))
            {
                bRet = 1U;
                goto lAdcExit;
            }
        }
        else if (xaAi[bAiChId].bAdcInst == (u8)ADC_1)
        {
            diVal = (s32)waAdc1Val[bCh];        // reserved for differential ADC

            if( (waAdc1Val[ADC1_CH_SELF_1V] > ADC_SELF_1V_MAX) 
                || (waAdc1Val[ADC1_CH_SELF_1V] < ADC_SELF_1V_MIN))
            {
                bRet = 1U;
                goto lAdcExit;
            }
        }
        else
        {
            bRet = 2U;
            goto lAdcExit;
        }

        if ((diVal < xaAi[bAiChId].diAdcCntMin) // check value range of the count
            || (diVal > xaAi[bAiChId].diAdcCntMax))
        {
            bRet = 3U;
            goto lAdcExit;
        }

        /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
        flVal = (f32)diVal;
        flVal /= (f32)ADC_MAX;
        /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
        flVal *= ADC_VREF;                      // PTC sensor voltage

	    flVal2 = flVal * flVal;
	    flVal3 = flVal2 * flVal;
	    flVal4 = flVal3 * flVal;

	    flTemp =  (PTC_COFF_A4 * flVal4)        // voltage to temperature
				+ (PTC_COFF_A3 * flVal3)
				+ (PTC_COFF_A2 * flVal2)
				+ (PTC_COFF_A1 * flVal)
				+  PTC_COFF_A0;


        if (flTemp < xaAi[bAiChId].flPhyValMin) // check value range
        {
            flTemp = xaAi[bAiChId].flPhyValMin;
        }

        if (flTemp > xaAi[bAiChId].flPhyValMax) // check value range
        {
            flTemp = xaAi[bAiChId].flPhyValMax;
        }

        xaAi[bAiChId].flPhyValFast = flTemp;    // output value without filter
        
        if(xaAi[bAiChId].wAvgCnt < xaAi[bAiChId].wAvgCycle)
        {
            xaAi[bAiChId].flAvgSum += flTemp;
        }
        else                                    // average filter
        {
            xaAi[bAiChId].flPhyValFilted = xaAi[bAiChId].flAvgSum;
            xaAi[bAiChId].flPhyValFilted /= (f32)xaAi[bAiChId].wAvgCycle;

            xaAi[bAiChId].flAvgSum = flTemp;
            xaAi[bAiChId].wAvgCnt = 0;
        }
        xaAi[bAiChId].wAvgCnt++;

    }
    else
    {
        bRet = 4U;
    }

lAdcExit:

    if(bRet != 0)
    {
        xaAi[bAiChId].dwErrorCnt++;

        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sflAdcConv [%d] err %d\n", bAiChId, bRet);
        #endif
    }

    return bRet;
}

static void sAdcDataUpdate(void)
{
    xIfAiData.flAuxHvVolt = xaAi[AI_AUX_HV].flPhyValFast;
    xIfAiData.flLvdcCurr = xaAi[AI_LV_CURR].flPhyValFast;
    xIfAiData.flLvdcVolt = xaAi[AI_LV_VOLT].flPhyValFast;
    xIfAiData.flCoolTemp = xaAi[AI_TEMP_COOL].flPhyValFilted;
    xIfAiData.flAuxLvVolt = xaAi[AI_AUX_LV].flPhyValFast;
    xIfAiData.flLvdcRemoteVolt = xaAi[AI_LV_VOLT].flPhyValFast;
    xIfAiData.flPcbTemp = xaAi[AI_TEMP_PCB].flPhyValFilted;
    xIfAiData.flProxiVolt = xaAi[AI_PD_VOLT].flPhyValFast;
    xIfAiData.flHvdcVolt = xaAi[AI_HV_VOLT].flPhyValFilted;
    xIfAiData.flPilotVolt = xaAi[AI_CP_VOLT].flPhyValFast;
    xIfAiData.flLvBatVolt = xaAi[AI_BAT_VOLT].flPhyValFast;
    xIfAiData.flSrTemp = xaAi[AI_TEMP_SR].flPhyValFilted;
    xIfAiData.flHvdcCurr = xaAi[AI_HV_CURR].flPhyValFast;

    #if (HVAE_BOOST_FUNC != 0)
    xIfAiData.flBoostVolt = xaAi[AI_BST_VOLT].flPhyValFast;
    #endif

    (void)sbIfSet(IF_AI, &xIfAiData);           // update output interface
}

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief       initial IF_AI data pointer, it should be call before call IfGet
 */
void sAdcIfInit(void)
{
    (void)sbIfSet(IF_AI, &xIfAiData);           // initial IF_AI data pointer
}

/**
 * @brief       Initialize ADC
 */
void sAdcInit(void)
{
    ADC_DRV_ConfigConverter(INST_DRVADC0, &DrvAdc0_ConvConfig0);
    ADC_DRV_ConfigHwAverage(INST_DRVADC0, &DrvAdc0_HwAvgConfig0);
    ADC_DRV_AutoCalibration(INST_DRVADC0);
    ADC_DRV_ConfigConverter(INST_DRVADC1, &DrvAdc1_ConvConfig0);
    ADC_DRV_ConfigHwAverage(INST_DRVADC1, &DrvAdc1_HwAvgConfig0);
    ADC_DRV_AutoCalibration(INST_DRVADC1);

    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_AUX_HV_VOLT,   &ADC0_AUX_HV_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_AUX_LV_VOLT,   &ADC0_AUX_LV_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_NTC_1_TEMP,    &ADC0_TEMP1);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_PD_VOLT,       &ADC0_PD_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_CP_VOLT,       &ADC0_CP_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_SBC_MUX,       &ADC0_SBC_MUX);
    ADC_DRV_ConfigChan(INST_DRVADC0, (u8)ADC0_CH_SELF_1V,       &ADC0_SELF_1V);

    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_LVDC_CURR,     &ADC1_LVDC_CURR);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_NTC_3_TEMP,    &ADC1_TEMP3);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_REMOTE_VOLT,   &ADC1_LVDC_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_APM_CURR,      &ADC1_BOOST_CURR);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_HVDC_VOLT,     &ADC1_HVDC_VOLT);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_NTC_2_TEMP,    &ADC1_TEMP2);
    ADC_DRV_ConfigChan(INST_DRVADC1, (u8)ADC1_CH_SELF_1V,       &ADC1_SELF_1V);

    INT_SYS_InstallHandler(ADC0_IRQn, &ADC0_IRQHandler, NULL);
    INT_SYS_EnableIRQ(ADC0_IRQn);

    //Initialize hardware trigger mux for PIT -> PDB -> ADC
    (void)TRGMUX_DRV_Init( INST_DRVTRGMUX, &DrvTrgMux_InitConfig0);
    sPDBInitial();
}

/**
 * @brief       reload ADC calibration data parameters
 * @param[in]   pxData point to new calibration data
 * @return      0 if PASS, else otherwise
 */
u8 sAdcGainOffsetUpdate(const x_cali_data_t* pxData)
{
    u8 i;
    f32 flGain;
    f32 flOffset;
    u8 bRet = 0;

    for (i = 0; i < (u8)CALI_ITEM_RESERVED_0; i++)
    {
        flGain = pxData->xaItem[i].flGain;
        flOffset = pxData->xaItem[i].flOffset;

        if((flGain < ADC_CALI_GAIN_MIN) 
            || (flGain > ADC_CALI_GAIN_MAX)
            || (flOffset < ADC_CALI_OFFSET_MIN)
            || (flOffset > ADC_CALI_OFFSET_MAX))
        {
            bRet = 0x80U | i;
        }
    }

    if(bRet == 0)
    {
        i = (u8)CALI_ITEM_BAT_VOLT_ADC;
        xaAi[AI_BAT_VOLT].flSwGainVal =     pxData->xaItem[i].flGain;
        xaAi[AI_BAT_VOLT].flSwOffsetVal =   pxData->xaItem[i].flOffset;

        i = (u8)CALI_ITEM_LVDC_CURR_ADC;
        xaAi[AI_LV_CURR].flSwGainVal =      pxData->xaItem[i].flGain;
        xaAi[AI_LV_CURR].flSwOffsetVal =    pxData->xaItem[i].flOffset;

        i = (u8)CALI_ITEM_LVDC_VOLT_ADC;
        xaAi[AI_LV_VOLT].flSwGainVal =      pxData->xaItem[i].flGain;
        xaAi[AI_LV_VOLT].flSwOffsetVal =    pxData->xaItem[i].flOffset;

        i = (u8)CALI_ITEM_HVDC_VOLT_APM_ADC;
        xaAi[AI_HV_VOLT].flSwGainVal =      pxData->xaItem[i].flGain;
        xaAi[AI_HV_VOLT].flSwOffsetVal =    pxData->xaItem[i].flOffset;

        i = (u8)CALI_ITEM_HVDC_CURR_APM_ADC;
        xaAi[AI_HV_CURR].flSwGainVal =      pxData->xaItem[i].flGain;
        xaAi[AI_HV_CURR].flSwOffsetVal =    pxData->xaItem[i].flOffset;
    }

    return bRet;
}

/**
 * @brief       clear ADC gain/offset to its default value
 */
void sAdcGainOffsetClear(void)
{
    xaAi[AI_BAT_VOLT].flSwGainVal =     ADC_CALI_GAIN_DEFAULT;
    xaAi[AI_BAT_VOLT].flSwOffsetVal =   ADC_CALI_OFFSET_DEFAULT;

    xaAi[AI_LV_CURR].flSwGainVal =      ADC_CALI_GAIN_DEFAULT;
    xaAi[AI_LV_CURR].flSwOffsetVal =    ADC_CALI_OFFSET_DEFAULT;

    xaAi[AI_LV_VOLT].flSwGainVal =      ADC_CALI_GAIN_DEFAULT;
    xaAi[AI_LV_VOLT].flSwOffsetVal =    ADC_CALI_OFFSET_DEFAULT;

    xaAi[AI_HV_VOLT].flSwGainVal =      ADC_CALI_GAIN_DEFAULT;
    xaAi[AI_HV_VOLT].flSwOffsetVal =    ADC_CALI_OFFSET_DEFAULT;

    xaAi[AI_HV_CURR].flSwGainVal =      ADC_CALI_GAIN_DEFAULT;
    xaAi[AI_HV_CURR].flSwOffsetVal =    ADC_CALI_OFFSET_DEFAULT;
}


/**
 * @brief       read the gain and offset value for Vout sense
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sVoutGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = xaAi[AI_LV_VOLT].flSwGainVal;
    *pflOffset = xaAi[AI_LV_VOLT].flSwOffsetVal;
}

/**
 * @brief       read the gain and offset value for Vin sense
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sVinGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = xaAi[AI_HV_VOLT].flSwGainVal;
    *pflOffset = xaAi[AI_HV_VOLT].flSwOffsetVal;
}

/**
 * @brief       read the gain and offset value for Iout sense
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sIoutGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = xaAi[AI_LV_CURR].flSwGainVal;
    *pflOffset = xaAi[AI_LV_CURR].flSwOffsetVal;
}

/**
 * @brief       read the gain and offset value for Iin sense
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sIinGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = ADC_CALI_GAIN_DEFAULT;
    *pflOffset = ADC_CALI_OFFSET_DEFAULT;
}

/**
 * @brief       read the gain and offset value for Vbat sense
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sVbatGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = xaAi[AI_BAT_VOLT].flSwGainVal;
    *pflOffset = xaAi[AI_BAT_VOLT].flSwOffsetVal;
}


/**
* \brief        PDB0 sequence error handling,
*               it should be clear error flags if PDB sequence error occured,
*               and the ADC COCO bit also need to be clear
*/
void PDB0_IRQHandler(void)
{
    u16 wSample;
    u8 i;

    ADC_DRV_WaitConvDone(INST_DRVADC0);

    ADC_DRV_ClearLatchedTriggers(INST_DRVADC0, ADC_LATCH_CLEAR_WAIT);

    for(i = 0; i < (u8)ADC0_CH_NUM; i++)        // Read ADC0 sample value
    {
        ADC_DRV_GetChanResult(INST_DRVADC0, i,  &wSample);
    }

    PDB_DRV_Disable(INST_DRVADC0TRIG);

    PDB_DRV_ClearAdcPreTriggerSeqErrFlags(INST_DRVADC0TRIG, 0, PDB_S_ERR_MASK);

    PDB_DRV_Enable(INST_DRVADC0TRIG);
}

/**
* \brief        PDB1 sequence error handling,
*               it should be clear error flags if PDB sequence error occured,
*               and the ADC COCO bit also need to be clear
*/
void PDB1_IRQHandler(void)
{
    u16 wSample;
    u8 i;

    ADC_DRV_WaitConvDone(INST_DRVADC1);

    ADC_DRV_ClearLatchedTriggers(INST_DRVADC1, ADC_LATCH_CLEAR_WAIT);

    for(i = 0; i < (u8)ADC1_CH_NUM; i++)        // Read ADC1sample value
    {
        ADC_DRV_GetChanResult(INST_DRVADC1, i,  &wSample);
    }

    PDB_DRV_Disable(INST_DRVADC1TRIG);

    PDB_DRV_ClearAdcPreTriggerSeqErrFlags(INST_DRVADC1TRIG, 0, PDB_S_ERR_MASK);

    PDB_DRV_Enable(INST_DRVADC1TRIG);
}

bool sblAdcBatIsUv(void)
{
    return blIsVbatUv;
}


/**
 * \brief   convert one analog input signal of a ADC controller
 */
void sAdcTask(void)
{
    static u8 b1msTickTo10 = 0;
    u8 bRet0 = 0;
    u8 bRet1 = 0;

    switch(b1msTickTo10)
    {
        case 0:
            bRet0 = sflAdcConvToPhy((u8)AI_AUX_HV);
            
            bRet1 = sflAdcConvToPhy((u8)AI_LV_CURR);
            break;

        case 1U:
            bRet0 = sflAdcConvToPhy((u8)AI_AUX_LV);

            bRet1 = sflAdcConvToTemp((u8)AI_TEMP_COOL);
            break;

        case 2U:
            bRet0 = sflAdcConvToTemp((u8)AI_TEMP_PCB);

            bRet1 = sflAdcConvToPhy((u8)AI_LV_VOLT);
            break;

        case 3U:
            bRet0 = sflAdcConvToPhy((u8)AI_PD_VOLT);
            
            bRet1 = sflAdcConvToPhy((u8)AI_HV_VOLT);
            break;

        case 4U:
            bRet0 = sflAdcConvToPhy((u8)AI_CP_VOLT);

            bRet1 = sflAdcConvToTemp((u8)AI_TEMP_SR);
            break;

        case 5U:
            bRet0 = sflAdcConvToPhy((u8)AI_BAT_VOLT);

            bRet1 = sflAdcConvToPhy((u8)AI_HV_CURR);
            break;

        case 6U:
            break;

        case 7U:
            break;

        case 8U:
            break;

        case 9U:
            sAdcDataUpdate();
            break;

        default:
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("sAdcTask deadcode\n");
            #else
            ;
            #endif
            break;
    }

    if (bRet0 != 0)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sAdcTask0 %d err %d\n", b1msTickTo10, bRet0);
        #endif
    }
    
    if (bRet1 != 0)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sAdcTask1 %d err %d\n", b1msTickTo10, bRet1);
        #endif
    }

    b1msTickTo10++;
    b1msTickTo10 %= 10U;
}


