/**
 * @file        uart.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include "config.h"


#if (HAVE_DEBUG_UART != 0)
#include "type.h"
#include "cpu.h"
#include "uart.h"
#include "gpio.h"
#include "shell.h"
#include "Util.h"
#include "RingBuf.h"
#include "tp.h"
#include "debug.h"
#include "uds_app.h"
#include "nvm.h"
#include "DrvScst.h"
#include "if.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------
/* Receive buffer size */
#define BUFFER_SIZE shell_CONFIG_DEFAULT_SHELL_BUFFER_SIZE

#define CPU_SCST_TEST_PASS_MAGIC_NUMBER     0x929940F1U


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
static void sShellCharRx(u8* bChar);
static void sShellCharTx(u8 bChar);
static bool sShellKeyPressed(void);

static void sUartRxCallback(void *driverState, 
                            uart_event_t event, 
                            void *userData);

static u8 sParseCommand(const u8 *cmd, bool *handled, const shell_StdIOType *io);
static void TXConfrimMsgCallback(uint8 i_status);

//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
/* Buffer used to receive data from UART */
static u8 pbRxBuf[BUFFER_SIZE];
static u8 bRxByte;

static shell_ConstStdIOType xShellStdio =
{
    (shell_StdIO_In_FctType)        sShellCharRx,       /* stdin */
    (shell_StdIO_OutErr_FctType)    sShellCharTx,       /* stdout */
    (shell_StdIO_OutErr_FctType)    sShellCharTx,       /* stderr */
    (shell_StdIO_KeyPressed_FctType)sShellKeyPressed    /* if input is not empty */
};


static const shell_ParseCommandCallback CmdParserTable[] =
{
    shell_ParseCommand,     /* default shell parser */
    sParseCommand,          /* my own shell parser */
    NULL                    /* Sentinel, must be last */
};

static u32 dwUartVal[UART_VAL_NUM] = {0};
static u8 pbCanIsoTpTxBuf[128] = {0};


//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------
static void sShellCharRx(u8* pbChar)
{
    (void)RingBuf_Get(pbChar);                  // pop a byte from ring buffer
}

static void sShellCharTx(u8 bChar)
{
    LPUART_DRV_SendDataBlocking(INST_DRVUART, &bChar, 1U, 1U);
}

static bool sShellKeyPressed(void)
{
    return (RingBuf_NofElements() != 0);
}

static void Util_Num32uToHexStr(u8 *buf, size_t dstSize, u32 val, s8 fill, u8 nofFill)
{
    buf[0] = '0';
    buf[1] = 'x';
    Util_Num32uToStrFormatted(&buf[2], dstSize-2U, val, fill, 8U);
}

static void TpTxTest(u16 wLen)
{
    u32 dwTxId = TP_GetConfigTxMsgID();
    u32 dwTxLen = wLen;
    bool blRet;
    u16 i;

    for(i=0; i<dwTxLen; i++)
    {
        pbCanIsoTpTxBuf[i] = i;
    }
    /* polyspace-begin MISRA-C3:1.3 [Not a defect] "unsued macro" */
    TPDebugPrintf("test iso-tp tx function");
    TPDebugPrintf("tp tx id : 0x%X\n", dwTxId);
    blRet = TP_WriteAFrameDataInTP( dwTxId,
			        				TXConfrimMsgCallback,
					        	    dwTxLen,
					                pbCanIsoTpTxBuf);

    if(blRet != true)
    {
        TPDebugPrintf("tp tx err\n");
    }
    /* polyspace-end MISRA-C3:1.3 [Not a defect] "unsued macro" */
}

static u8 sParseCommand(const u8 *cmd, bool *handled, const shell_StdIOType *io)
{
    u8 bRet = ERR_OK;
    s32 tmp;
    const u8 *p;
    u8 buf[16];

    if (Util_strcmp((char*)cmd, shell_CMD_HELP)==0 
        || Util_strcmp((char*)cmd, "app help")==0) 
    {
        shell_SendHelpStr(  (unsigned char*)"app",
                            (const unsigned char*)"Group of app commands\r\n", 
                            io->stdOut);

        shell_SendHelpStr(  (unsigned char*)"  test <number>", 
                            (const unsigned char*)"Set value\r\n", 
                            io->stdOut);
        *handled = TRUE;
    } 
    else if((Util_strcmp((char*)cmd, shell_CMD_STATUS)==0) 
            || (Util_strcmp((char*)cmd, "app status")==0)) 
    {
        shell_SendStatusStr((unsigned char*)"app", 
                            (const unsigned char*)"\r\n", 
                            io->stdOut);

        Util_Num32sToStr(buf, sizeof(buf), dwUartVal[UART_VAL_TEST]);
        Util_strcat(buf, sizeof(buf), (const u8*)"\r\n");
        shell_SendStatusStr((const u8*)"  test", buf, io->stdOut);

        Util_Num32uToHexStr(buf,
                            sizeof(buf), 
                            dwUartVal[UART_VAL_MCU_ERR_CODE],
                            '0',
                            8U);
        Util_strcat(buf, sizeof(buf), (const u8*)"\r\n");
        shell_SendStatusStr((const u8*)"  mcu_err", buf, io->stdOut);

        *handled = TRUE;
    }
    else if (Util_strncmp((char*)cmd, "app test", sizeof("app test")-1)==0)
    {
        p = cmd+sizeof("app test")-1;
        bRet = Util_xatoi(&p, &tmp);
        if (bRet==ERR_OK) 
        {
            dwUartVal[UART_VAL_TEST] = tmp;
            *handled = TRUE;
        }
    }
    else if (Util_strncmp((char*)cmd, "soc", sizeof("soc")-1)==0)
    {
        DebugPrintf("sizeof conf %d\n", sizeof(x_conf_data_t));
        DebugPrintf("sizeof cali %d\n", sizeof(x_cali_data_t));
        *handled = TRUE;
    }
    else if (Util_strncmp((char*)cmd, "if", sizeof("if")-1)==0)
    {
        u8 bRet;
        x_if_test_t xTestSet = {0x55U, 123.456F};
        const x_if_test_t *pxTestGet = NULL;

        bRet = sbIfSet(IF_TEST, &xTestSet);
        if (bRet != IF_ERR_NONE)
        {
            DebugPrintf("sbIfSet IF_TEST ERROR %d\n", bRet);
        }

        bRet = sbIfGet(IF_TEST, true, (const void **)&pxTestGet);
        if (bRet != IF_ERR_NONE)
        {
            DebugPrintf("sbIfGet IF_TEST error %d\n", bRet);
        }
        else
        {
            DebugPrintf("IF_TEST = %d, %f\n", 
                        pxTestGet->bTest,
                        pxTestGet->flTest);

            *handled = TRUE;
        }
    }
    else if (Util_strncmp((char*)cmd, "tp 10", sizeof("tp 10")-1)==0)
    {
        TpTxTest(10);

        *handled = TRUE;
    }
    else if (Util_strncmp((char*)cmd, "tp 32", sizeof("tp 32")-1)==0)
    {
        TpTxTest(32);

        *handled = TRUE;
    }
    else if (Util_strncmp((char*)cmd, "tp 64", sizeof("tp 64")-1)==0)
    {
        TpTxTest(64);

        *handled = TRUE;
    }
    #if 0
    else if (Util_strncmp((char*)cmd, "wcon", sizeof("wcon")-1)==0)
    {
        bRet = sbNvmConfDataSave();

        if(bRet == 0)
        {
            DebugPrintf("sbNvmConfDataSave PASS\n");
        }

        *handled = TRUE;
    }
    else if (Util_strncmp((char*)cmd, "wcal", sizeof("wcal")-1)==0)
    {
        bRet = sbNvmCaliDataSave();

        if(bRet == 0)
        {
            DebugPrintf("sbNvmCaliDataSave PASS\n");
        }

        *handled = TRUE;
    }
    #endif
    else if(Util_strncmp((char*)cmd, "erase", sizeof("erase")-1)==0)
    {
        flash_ssd_config_t xConf = {0};
        xConf.CallBack = NULL_CALLBACK;
        INT_SYS_DisableIRQGlobal();
        bRet = FLASH_DRV_EraseAllBlock(&xConf);
        INT_SYS_EnableIRQGlobal();
        *handled = (bRet == 0) ? TRUE : FALSE;
    }
    else if(Util_strncmp((char*)cmd, "scst", sizeof("scst")-1)==0)
    {
        if(m4_scst_accumulated_signature == CPU_SCST_TEST_PASS_MAGIC_NUMBER)
        {
            DebugPrintf("SCST last test is pass.\n");
        }
        else
        {
            DebugPrintf("SCST last test fail at %d\n", m4_scst_test_was_interrupted);
        }

        m4_scst_accumulated_signature = 0;
        m4_scst_test_was_interrupted = 0;
        (void)m4_scst_execute_core_tests(15U, 43U);

        if ((m4_scst_test_was_interrupted == 0) 
            && (m4_scst_last_executed_test_number == 43U))
        {
            DebugPrintf("SCST test is pass.\n");
        }
        else
        {
            DebugPrintf("SCST test fail at %d\n", m4_scst_test_was_interrupted);
        }
        *handled = TRUE;
    }
    return bRet;
}


/* UART Rx callback for continuous reception, byte by byte */
static void sUartRxCallback(void *driverState, 
                            uart_event_t event, 
                            void *userData)
{
    /* Unused parameters */
    (void)driverState;
    (void)userData;

    /* Check the event type */
    if (event == UART_EVENT_RX_FULL)
    {
        RingBuf_BufSizeType xNum = RingBuf_NofFreeElements();
        if(xNum == 0)
        {
            RingBuf_Clear();
        }
        else
        {
            if(bRxByte != '\r')
            {
                (void)RingBuf_Put(bRxByte);     /* put byte into ring buffer */
            }
        }

        LPUART_DRV_SetRxBuffer(INST_DRVUART, &bRxByte, 1U);
    }
}


/*transmitted confirm message callback*/
static void TXConfrimMsgCallback(uint8 i_status)
{
    if(TX_MSG_SUCCESSFUL == i_status)
    {
        //SetCurrentSession(PROGRAM_SESSION);
        //SetSecurityLevel(NONE_SECURITY);

        /*restart s3server time*/
        //RestartS3Server();
    }
}



//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief: initial UART1 for shell debug
 */
void sUartInit(void)
{
    pbRxBuf[0] = '\0';

    RingBuf_Init();
    
    (void)LPUART_DRV_Init(  INST_DRVUART, 
                            &DrvUart_State,
                            &DrvUart_InitConfig0);

    LPUART_DRV_InstallRxCallback(INST_DRVUART, sUartRxCallback, NULL);

    shell_SetStdio(&xShellStdio);

    (void)shell_ParseWithCommandTable(  (unsigned char*)shell_CMD_HELP, 
                                        shell_GetStdio(),
                                        CmdParserTable);
}

/**
 * @brief: shell console task
 */
void sUartTask(void)
{
    #if (HAVE_DEBUG_GPIO != 0)
    //PINS_DRV_TogglePins(TEST_PIN2_PORT, (1UL << TEST_PIN2_INDEX));
    #endif

    (void)LPUART_DRV_ReceiveData(INST_DRVUART, &bRxByte, 1U);

    (void)shell_ReadAndParseWithCommandTable(   pbRxBuf,
                                                sizeof(pbRxBuf), 
                                                shell_GetStdio(), 
                                                CmdParserTable);
}

/**
 * @brief: set a u32 value in the shell
 * @param[in] eValId set value id \uart_val_t
 * @param[in] dwVal new value
 */
void sUartValSet(uart_val_t eValId, u32 dwVal)
{
    if(eValId < UART_VAL_NUM)
    {
        dwUartVal[eValId] = dwVal;
    }
}

/**
 * @brief: get a u32 value in the sheel
 * @param[in] eValId set value id \uart_val_t
 * @param[out] pdwVal point to read buffer
 */
void sUartValGet(uart_val_t eValId, u32* pdwVal)
{
    if(eValId < UART_VAL_NUM)
    {
        *pdwVal = dwUartVal[eValId];
    }
}


#endif

