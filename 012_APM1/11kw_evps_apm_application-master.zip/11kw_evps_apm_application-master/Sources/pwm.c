/**
 * @file        pwm.c
 * @copyright   Lite-On Technology Corp.
 */
#include "type.h"
#include "Cpu.h"
#include "pwm.h"
#include "nvm.h"
#include "if.h"
#include "housekeep.h"
#include "config.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif



//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

#define     PWM_CH_VCMD                 5U
#define     PWM_CH_ICMD                 6U

#define     PWM_VCMD_GAIN_RANGE         (1.0F / 2.0F)
#define     PWM_VCMD_GAIN_MAX           (1.0F + PWM_VCMD_GAIN_RANGE)
#define     PWM_VCMD_GAIN_MIN           (1.0F - PWM_VCMD_GAIN_RANGE)
#define     PWM_VCMD_OFFSET_MAX         10.0F
#define     PWM_VCMD_OFFSET_MIN         (-10.0F)

#define     PWM_ILIM_GAIN_RANGE         (1.0F / 2.0F)
#define     PWM_ILIM_GAIN_MAX           (1.0F + PWM_ILIM_GAIN_RANGE)
#define     PWM_ILIM_GAIN_MIN           (1.0F - PWM_ILIM_GAIN_RANGE)
#define     PWM_ILIM_OFFSET_MAX         50.0F
#define     PWM_ILIM_OFFSET_MIN         (-50.0F)

//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static f32 flVcmdSwGain =               1.0F;
static f32 flVcmdSwOffset =             0.0F;
static f32 flIcmdSwGain =               1.0F;
static f32 flIcmdSwOffset =             0.0F;


static const x_if_ho_t *pxIfHo = NULL;


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------


/**
 * \brief       Set the LVDC output Voltage command
 */
static void sPwmLvdcVoltUpdate(void)
{
    u16 wDutyValue = pxIfHo->wVcmdDutyCnt;

    if (wDutyValue > (u16)PWM_VCMD_DUTY_MAX)
    {
        wDutyValue = (u16)PWM_VCMD_DUTY_MAX;
    }

    (void)PWM_UpdateDuty(&DrvPwmInstance, PWM_CH_VCMD, wDutyValue);
}

/**
 * \brief       Set the LVDC output current limit command
 */
static void sPwmLvdcCurrUpdate(void)
{
    u16 wDutyValue = pxIfHo->wIcmdDutyCnt;

    if (wDutyValue > (u16)PWM_ILIM_DUTY_MAX)
    {
        wDutyValue = (u16)PWM_ILIM_DUTY_MAX;
    }

    (void)PWM_UpdateDuty(&DrvPwmInstance, PWM_CH_ICMD, wDutyValue);
}


//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief       Initialize PWM
 */
void sPwmInit(void)
{
	status_t xStatus;
	
	xStatus = PWM_Init(&DrvPwmInstance, &DrvPwmConfigs);    // Initialize PWM
	if(xStatus == STATUS_SUCCESS)
	{
		(void)PWM_UpdateDuty(&DrvPwmInstance, PWM_CH_VCMD, 0);
		(void)PWM_UpdateDuty(&DrvPwmInstance, PWM_CH_ICMD, 0);
	}
    else
    {
        #if (HAVE_DEBUG_UART != 0)
		DebugPrint("PWM_Init failt %X\n", xStatus);
		#endif
    }
}

/**
 * @brief       reload PWM calibration data parameters
 * @param[in]   pxData point to new calibration data
 * @return      0 if PASS, else otherwise
 */
u8 sPwmGainOffsetUpdate(const x_cali_data_t* pxData)
{
    f32 flGain;
    f32 flOffset;
    u8 bRet = 0;

    flGain = pxData->xaItem[CALI_ITEM_LVDC_VOLT_PWM].flGain;   /* polyspace MISRA-C3:18.1 "no defect" */
    flOffset = pxData->xaItem[CALI_ITEM_LVDC_VOLT_PWM].flOffset;

    if((flGain < PWM_VCMD_GAIN_MIN) 
        || (flGain > PWM_VCMD_GAIN_MAX)
        || (flOffset < PWM_VCMD_OFFSET_MIN)
        || (flOffset > PWM_VCMD_OFFSET_MAX))
    {
        bRet |= 0x41U;
    }

    flGain = pxData->xaItem[CALI_ITEM_LVDC_CURR_PWM].flGain;
    flOffset = pxData->xaItem[CALI_ITEM_LVDC_CURR_PWM].flOffset;

    if((flGain < PWM_ILIM_GAIN_MIN) 
        || (flGain > PWM_ILIM_GAIN_MAX)
        || (flOffset < PWM_ILIM_OFFSET_MIN)
        || (flOffset > PWM_ILIM_OFFSET_MAX))
    {
        bRet |= 0x42U;
    }

    if(bRet == 0)
    {
        flIcmdSwGain = pxData->xaItem[CALI_ITEM_LVDC_CURR_PWM].flGain;
        flIcmdSwOffset = pxData->xaItem[CALI_ITEM_LVDC_CURR_PWM].flOffset;
        flVcmdSwGain = pxData->xaItem[CALI_ITEM_LVDC_VOLT_PWM].flGain;
        flVcmdSwOffset = pxData->xaItem[CALI_ITEM_LVDC_VOLT_PWM].flOffset;
    }

    return bRet;
}

/**
 * @brief       clear PWM gain/offset to its default value
 */
void sPwmGainOffsetClear(void)
{
    flIcmdSwGain =    1.0F;
    flIcmdSwOffset =  0.0F;
    flVcmdSwGain =    1.0F;
    flVcmdSwOffset =  0.0F;
}

/**
 * @brief       read the gain and offset value for Vcmd PWM duty
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sVcmdGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = flVcmdSwGain;
    *pflOffset = flVcmdSwOffset;
}

/**
 * @brief       read the gain and offset value for Icmd PWM duty
 * @param[out]  pflGain point to return gain value
 * @param[out]  pflOffset point to return offset value
 */
void sIcmdGainOffsetGet(f32 *pflGain, f32 *pflOffset)
{
    *pflGain = flIcmdSwGain;
    *pflOffset = flIcmdSwOffset;
}

#if 0
/**
 * \brief   return the native duty count value of the LVDC_CVCC_VOLT_PWM
 * \return  wOutputVoltageDuty
 */
u16 swPwmVcmdDutyGet(void)
{
    wOutputVoltageDuty = 1234U;
    return wOutputVoltageDuty;
}

/**
 * \brief   return the native duty count value of the LVDC_CVCC_CURR_PWM
 * \return  wOutputCurrentDuty
 */
u16 swPwmIcmdDutyGet(void)
{
    wOutputCurrentDuty = 4321U;
    return wOutputCurrentDuty;
}
#endif

/**
 * \brief   the function to update PWM output duty,
 *          and it read the input caputure period between two rising edge
 */
void sPwmTask(void)
{
    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_HO, false, (const void **)&pxIfHo);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */

    sPwmLvdcVoltUpdate();

    sPwmLvdcCurrUpdate();
}


