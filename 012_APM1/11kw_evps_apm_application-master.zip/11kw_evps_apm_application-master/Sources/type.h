/**
 * @file        BaseType.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_BASETYPE_H
#define         DEF_BASETYPE_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include        <stdint.h>
#include        <stdbool.h>
#include        <stddef.h>

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------
typedef int8_t s8;
typedef uint8_t u8;
typedef int16_t s16;
typedef uint16_t u16;
typedef int32_t s32;
typedef uint32_t u32;
typedef int64_t s64;
typedef uint64_t u64;
typedef float f32;
typedef double f64;

typedef volatile int8_t vs8;
typedef volatile uint8_t vu8;
typedef volatile int16_t vs16;
typedef volatile uint16_t vu16;
typedef volatile int32_t vs32;
typedef volatile uint32_t vu32;
typedef volatile int64_t vs64;
typedef volatile uint64_t vu64;
typedef volatile f32 vf32;
typedef volatile f64 vf64;

typedef enum BOOL_E
{
    BOOL_TRUE = 'T',
    BOOL_FALSE = 'F',
}e_bool_t;

//------------------------------------------------------------------------------
#endif          // DEF_BASETYPE_H