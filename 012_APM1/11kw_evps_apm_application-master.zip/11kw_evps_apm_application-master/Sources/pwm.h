/**
 * @file        pwm.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef PWM_H_
#define PWM_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "nvm.h"

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define     PWM_PERIOD                  (8000U)


#define     PWM_ILIM_HW_GAIN            0.3F
#define     PWM_ILIM_HW_OFFSET          10.0F

/* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
#define     PWM_ILIM_DUTY_MAX           ((0.9F * (f32)PWM_PERIOD) + 0.5F)
/* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */

#define     PWM_VCMD_HW_GAIN            4.55F
#define     PWM_VCMD_HW_OFFSET          0.0F

/* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
#define     PWM_VCMD_DUTY_MAX           ((0.9F * (f32)PWM_PERIOD) + 0.5F)
/* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
extern void sPwmInit(void);

extern u8 sPwmGainOffsetUpdate(const x_cali_data_t* pxData);
extern void sPwmGainOffsetClear(void);
extern void sVcmdGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sIcmdGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sPwmTask(void);

#endif /* PWM_H_ */
