/**
 * @file        csec.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef CSEC_H_
#define CSEC_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sCsecInit(void);
extern uint8_t sCsecGenerateRandomNumber(uint8_t *pbBuf);
extern uint8_t sCsecDecEcbByDefaultKey(const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout);

extern uint8_t sCsecEncEcbByDefaultKey(const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout);

extern uint8_t sCsecDecEcbByUserKey1(  const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout);

extern uint8_t sCsecEncEcbByUserKey1(  const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout);

#endif /* CSEC_H_ */
