#ifndef DTCMGR_H_
#define DTCMGR_H_

/** @brief Prefail counter max value */
#define PREFAIL_MAX     ((s8)0x7F)
/** @brief Prefail counter min value */
#define PREFAIL_MIN     ((s8)0x80)
/** @brief Prefail counter initial value */
#define PREFAIL_OFF     ((s8)0x00)
/** @brief Filter disable */
#define FILTER_DISABLE  ((u8)0xFF)
/** @brief Aging disable */
#define AGING_DISABLE   ((u8)0xFF)

/***************************DTC Format Identifier **************************/
/** @brief SAE_J2012-DA DTCF00 */
#define J2012_DADTCF00      0x00
/** @brief ISO 14229-1 DTCF */
#define ISO14229_1DTCF      0x01
/** @brief SAE_J1939-73 DTCF */
#define J1939_73DTCF        0x02
/** @brief ISO 11992-4 DTCF */
#define ISO11992_4DTCF      0x03
/** @brief SAE_J1939-73 DTCF04 */
#define J2012_DADTCF04      0x04


/**
 * This macro evaluates to the least significant byte of x.
 */
#define LOBYTE(x)       ((u8)(x & 0xffu))

/**
 * This macro evaluates to the most significant byte of x.
 */
#define HIBYTE(x)       ((u8)(((x)>>8u) & 0xffu))

/**
 * This macro evaluates to the least significant word (16bit) of x.
 */
#define LOWORD(x)       ((u16)(x & 0xffffu))

/**
 * This macro evaluates to the most significant word (16bit) of x.
 */
#define HIWORD(x)       ((u16)(((x)>>16) & 0xffffu)) 

typedef enum                                    /* Enum type define the DTC alias name */
{
    DTC_P100001 = 0,                            /** OBC DTC for Grid protection */
    DTC_P100002,                                /** OBC DTC for HVDC protection */
    DTC_P100003,                                /** OBC DTC for OT protection */
    DTC_P100004,                                /** OBC DTC for PFC protection */
    DTC_P100005,                                /** OBC DTC for AUX protection */
    DTC_P100006,                                /** OBC DTC for BULK protection */
    DTC_U100001,                                /** OBC DTC for SELF TEST protection */
    DTC_U100002,                                /** OBC DTC for CAN communication */
    DTC_U100003,                                /** OBC DTC for EVSE protection */
    DTC_P100101,                                /** APM DTC for LVDC protection */
    DTC_P100102,                                /** APM DTC for HVDC protection */
    DTC_P100103,                                /** APM DTC for OT protection */
    DTC_P100104,                                /** APM DTC for AUX protection */
    DTC_P100105,                                /** APM DTC for BAT protection */
    DTC_U100101,                                /** APM DTC for SELF TEST protection */
    DTC_U100102,                                /** APM DTC for CAN communication */
    NUMBER_OF_DTC
}DTC_CODE;

#define APM_FIRST_DTC_INDEX                     (u8)(DTC_P100101)
#define APM_LAST_DTC_INDEX                      (u8)(DTC_U100102)

#define OBC_FIRST_DTC_INDEX                     (u8)(DTC_P100001)
#define OBC_LAST_DTC_INDEX                      (u8)(DTC_U100003)


/**
 *  @brief Enum type define the DTC monitor type
 */
typedef enum
{
    Continuous,
    Cumulative,
	Disable
}MONITOR_TYPE;


/**
 * @brief Struct type defining the configuration parameters for a DTC
 *
 * @param DTC				Specifies the DTC number identifying DTC record.
 * @param PreIncr		    Specifies the step the prefail filter will be increased by when a test fails.
 *                          Allowed range 0 - 0x7F. If value is 0x7F, prefail-failed filter functionality is disabled. 
 * @param PreDecr		    Specifies the step the prefail filter will be decreased by when a test passes.
 *                          Allowed range 0 - 0x80. If value is 0x80, prefail-passed filter functionality is disabled. 
 * @param FilterIncr		Specifies the step the filter will be increased by when a test fails.
 * @param FilterDecr		Specifies the step the filter will be decreased by when a test passes.
 * @param FilterMax			Specifies the maximum value the filter can be incremented to. When reached, DTC is confirmed.
 *                          Value 0xFF will disable filter, i.e. it will not set status Confirmed to a DTC.
 * @param AgingMax			Specifies the minimum number of operation cycles without fail before clear of status Confirmed to a DTC.
 *                          Value 0xFF will disable aging, i.e. it will not clear status Confirmed to a DTC.
 * @param WarningIndicator	Specifies if a warning indicator is associated with the DTC.
 *
 */
typedef struct
{
    u32 dwDTC;
    u8 	bPreIncr;
    u8  bPreDecr;
    u8  bMonitorType;
    u8  bFilterIncr;
    u8  bFilterDecr;
    u8  bFilterMax;
    u8  bAgingMax;
    boolean blWarningIndicator;
}DTC_CONFIG;

typedef struct
{
	u16	wDataID;
	void	*pStart;
	u16	wLength;

}ID_TABLE;

typedef struct
{
	const void		*pNext;
	u8			bNumberOfDID;
	const ID_TABLE	*pxIdTable;
}RECORD_HEAD;

/**
 * @brief Struct type defining the configuration parameters for a record
 *
 * @param SnapshotMaxNum	Specifies the total number of DTC snapshot records.
 * @param ExtendedMaxNum	Specifies the total number of DTC extended records.
 * @param SnapshotID		Point to snapshot record data id table.
 * @param ExtednedData		Point to extended record data table.
 *
 */
typedef struct
{
	u8  	bSnapshotMaxNum;
	u8  	bExtendedMaxNum;
	const RECORD_HEAD *pxSnapshotID;
	const RECORD_HEAD *pxExtednedData;

}RECORD_CONFIG;

/**
 *  @brief This function reports that a test for a diagnostic trouble code has passed.
 *  
 *  @param Dtc	Contains the alias name of the DTC for which the test passed.
 *  @return DTC status byte
 *  
 *  @details 
 */
u8 DTCTestFailed(DTC_CODE eDtc);

/**
 * @brief This function starts a new operation cycle.
 *  
 * @return void
 *
 */
u8 DTCTestPassed(DTC_CODE eDtc);

/**
 * @brief This function starts a new operation cycle.
 *  
 * @return void
 *
 */
void StartApmDtcOperationCycle(void);

void StartObcDtcOperationCycle(void);


/**
 * @brief This function stops an operation cycle.
 *  
 * @return void
 *
 */
void StopApmDtcOperationCycle(void);

void StopObcDtcOperationCycle(void);

/**
 * @brief This function clears information stored for a specific DTC or group of DTCs.
 *  
 * @param groupOfDTC    Contains the DTC group or DTC number for which information should be cleared.
 *
 * @return FALSE if the DTC or group doesn't exist otherwise TRUE.
 *
 */
boolean DTCClearDiagInfo(u32 dwGroupOfDTC);

/**
 * @brief This function retreives the DTCStatusAvailabilityMask.
 *
 *        The retreived value defines which bits of the DTCStatus that are supported.
 *  
 * @return DTCStatusAvailabilityMask.
 *
 */
u8 GetStatusAvailabilityMask(void);

/**
 * @brief This function retreives a list of DTC and status information for the DTCs that match
 *        the status mask.
 *        
 * @param buffer        Contains the pointer to the buffer that receives the list of information.
 * @param numDTC        Contains maximum length of buffer (number of bytes)/number of DTC entries (4 bytes) copied to the buffer.
 * @param statusMask    Contains the status mask for which DTC information should be retreived.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 *
 */
boolean GetDTCByStatusMask(u8* pbBuffer, u16* pwNumDTC, u8 bStatusMask);

/**
 * @brief This function retreives a list of snapshot data records associated with a DTC.
 *        
 * @param dtc            Contains the DTC number.
 * @param recordNumber   Contains the record number (index).
 * @param statusDtc      Contains the pointer to DTC status byte information.
 * @param snapshotRecord Contains the pointer to the buffer that receives the list of data records.
 * @param recLength      Contains maximum length of buffer (number of bytes)/number of bytes copied to the record.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 *
 */
boolean GetDTCSnapshotRecordByDTCNumber(u32 dwDTCValue, u8 bRecordNumber, u8* pbStatusDtc, u8* pbBuffer, u16* pwRecLength);

/**
 * @brief This function retreives a list of extended data records associated with a DTC.
 *        
 * @param dtc           Contains the DTC number.
 * @param recordNumber  Contains the record number (index).
 * @param extDataRecord Contains the pointer to the buffer that receives the list of data records.
 * @param recLength     Contains maximum length of buffer (number of bytes)/number of bytes copied to the record.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 *
 */
boolean GetExtendedDataRecordByDTCNumber(u32 dwDTCValue, u8 bRecordNumber, u8* pbStatusDtc, u8* pbBuffer, u16* pwRecLength);

/**
 * @brief This function retreives a list of DTC and status information for the DTCs that is
 *        supported by the node.
 *        
 * @param buffer    Contains the pointer to the buffer that receives the list of information.
 * @param numDTC    Contains maximum length of buffer (number of bytes)/number of DTC entries (4 bytes) copied to the buffer.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 */
boolean GetSupportedDTCs(u8* pbBuffer, u16* wNumDTC);

/**
 * @brief       This function run the Aging algorithm to clear the DTC.
 *
 * @param
 *
 * @return      true: if any agingCounter is changed.
 */

boolean sApmDtcAging(void);

boolean sObcDtcAging(void);


void DTC_Init(void);
void DTC_Handle(void);
void DTC_EmergenyNotice(void);

extern const DTC_CONFIG xDTCConfig[NUMBER_OF_DTC];
extern const RECORD_CONFIG xRecordConfig[NUMBER_OF_DTC];
extern const ID_TABLE xSnapShotDataID;/* polyspace MISRA-C3:8.6 "already defined" */
extern const ID_TABLE xExtendedData;/* polyspace MISRA-C3:8.6 "already defined" */

#ifndef APP_DTC_CALLBACK
extern boolean CheckAppMeetDTCTestConditions(DTC_CODE eDtc);
extern void APP_DTCIsClearDTC(DTC_CODE eDtc);
#endif

#endif
