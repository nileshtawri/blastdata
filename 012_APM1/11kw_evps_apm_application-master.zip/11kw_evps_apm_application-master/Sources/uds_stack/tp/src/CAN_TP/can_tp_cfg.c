#include "user_config.h"
#include "debug.h"
#include "autolibc.h"


#ifdef EN_CAN_TP
#include "can_tp_cfg.h"
#include "multi_cyc_fifo.h"
//#include "can_driver.h"
static tpfAbortTxMsg gs_pfCANTPAbortTxMsg = NULL_PTR;
static tpfNetTxCallBack gs_pfTxMsgSuccessfulCallBack = NULL_PTR;
static u8 gs_ucIsTransmittedMsg = FALSE;        /*transmitted can message*/


static uint8 CANTP_TxMsg(   const tUdsId i_xTxId,
                            const uint16 i_DataLen, 
                            const uint8* i_pDataBuf, 
                            const tpfNetTxCallBack i_pfNetTxCallBack,
                            const uint32 txBlockingMaxtime);

static uint8 CANTP_RxMsg(   tUdsId * o_pxRxId,
                            uint8 * o_pRxDataLen,
                            uint8 *o_pRxBuf);

static void CANTP_AbortTxMsg(void);

/*clear CAN TP TX BUS FIFO*/
static boolean CANTP_ClearTXBUSFIFO(void);

/*uds netwrok layer cfg info */
const tUdsCANNetLayerCfg g_stCANUdsNetLayerCfgInfo = 
{
	1u,       /*called can tp period*/
	RX_FUN_ID,   /*can tp rx function ID*/
	RX_PHY_ID,   /*can tp rx phy ID*/
	TX_ID,   /*can tp tx ID*/
	0u,       /*BS = block size*/
	1u,      /*STmin*/
	25u,      /*N_As*/
	25u,      /*N_Ar*/
	75u,     /*N_Bs*/
	0u,       /*N_Br*/
	100u,       /*N_Cs < 0.9 N_Cr*/
	150u,     /*N_Cr*/
	0u,       /*max blocking time 0ms, > 0u mean waitting send successful. equal 0 is not waitting.*/
	CANTP_TxMsg, /*can tp tx*/
	CANTP_RxMsg, /*can tp rx*/
	CANTP_AbortTxMsg,
};

/*can tp tx message: there not use CAN driver TxFIFO, directly invoked CAN send function*/
static uint8 CANTP_TxMsg(   const tUdsId i_xTxId,
                            const uint16 i_DataLen, 
                            const uint8* i_pDataBuf, 
                            const tpfNetTxCallBack i_pfNetTxCallBack,
                            const uint32 txBlockingMaxtime)
{
    u8 bRet = TRUE;
	tLen xCanWriteDataLen = 0u;
	tErroCode eStatus;
	uint8 aMsgBuf[8] = {0};
	tTPTxMsgHeader TxMsgInfo;
	const uint32 msgInfoLen = sizeof(tTPTxMsgHeader) + sizeof(aMsgBuf);

	ASSERT(NULL_PTR == i_pDataBuf);

    (void)txBlockingMaxtime;

	if(i_DataLen > 8u)
	{
		bRet = FALSE;
        goto exit;
	}

	GetCanWriteLen(TX_BUS_FIFO, &xCanWriteDataLen, &eStatus);
	if((ERRO_NONE == eStatus) && (msgInfoLen <= xCanWriteDataLen))
	{
		TxMsgInfo.TxMsgID = i_xTxId;
		TxMsgInfo.TxMsgLength = sizeof(aMsgBuf);
		TxMsgInfo.TxMsgCallBack = i_pfNetTxCallBack;
		
		(void)fsl_memcpy(&aMsgBuf[0u], i_pDataBuf, i_DataLen);
		
		WriteDataInFifo(TX_BUS_FIFO, 
                        (const u8*)&TxMsgInfo, 
                        sizeof(tTPTxMsgHeader),
                        &eStatus);
		if(ERRO_NONE != eStatus)
		{
			ClearFIFO(TX_BUS_FIFO, &eStatus);
			bRet = FALSE;
            goto exit;
		}

		WriteDataInFifo(TX_BUS_FIFO, (const u8*)aMsgBuf, 8U, &eStatus);
		if(ERRO_NONE != eStatus)
		{
			ClearFIFO(TX_BUS_FIFO, &eStatus);
			bRet = FALSE;
            goto exit;
		}
	}

exit:
	return bRet;
}

/*can tp rx message: read rx msg from CAN driver RxFIFO*/
static uint8 CANTP_RxMsg(tUdsId * o_pxRxId,
					  	 uint8 * o_pRxDataLen,
						 uint8 *o_pRxBuf)
{
    u8 bRet = FALSE;
	tLen xCanRxDataLen = 0u;
	tLen xReadDataLen = 0u;
	tErroCode eStatus;
	tRxMsgInfo stRxCanMsg = {0u};
	uint8 ucIndex = 0u;
	const uint32 headerLen = sizeof(stRxCanMsg.rxDataId) + sizeof(stRxCanMsg.rxDataLen);

	ASSERT(NULL_PTR == o_pxRxId);
	ASSERT(NULL_PTR == o_pRxBuf);
	ASSERT(NULL_PTR == o_pRxDataLen);

	GetCanReadLen(RX_BUS_FIFO, &xCanRxDataLen, &eStatus);
	if((ERRO_NONE == eStatus) && (headerLen <= xCanRxDataLen))
	{
		ReadDataFromFifo(RX_BUS_FIFO, 
				        (u16)headerLen,
			            (uint8 *)&stRxCanMsg,
			            &xReadDataLen,
			            &eStatus);

		if((ERRO_NONE == eStatus) && (headerLen <= xCanRxDataLen))
		{
			ReadDataFromFifo(RX_BUS_FIFO, 
							(u16)stRxCanMsg.rxDataLen,
							(uint8 *)&stRxCanMsg.aucDataBuf,
							&xCanRxDataLen,
							&eStatus);

			if(TRUE != CANTP_IsReceivedMsgIDValid(stRxCanMsg.rxDataId))
			{
				bRet = FALSE;
                goto exit;
			}
			
			*o_pxRxId = stRxCanMsg.rxDataId;
			*o_pRxDataLen = (u8)stRxCanMsg.rxDataLen;

			for(ucIndex = 0u; ucIndex < stRxCanMsg.rxDataLen; ucIndex++)
			{
                /* polyspace-begin MISRA-C3:18.1 [Not a defect] "point to array" */
				o_pRxBuf[ucIndex] = stRxCanMsg.aucDataBuf[ucIndex];
                /* polyspace-end   MISRA-C3:18.1 [Not a defect] "point to array" */
			}

			bRet = TRUE;
            goto exit;
        }
		
	}
	else
	{
		if((0u != xCanRxDataLen) || (ERRO_NONE != eStatus))
		{
            /* polyspace-begin MISRA-C3:1.3 [Not a defect] "unsued macro" */
			TPDebugPrintf("\n %s write message in FIFO failed! status = %d, FIFO avaliable Length=%d\n",
                            __func__, 
                            eStatus, 
                            xCanRxDataLen);
            /* polyspace-end MISRA-C3:1.3 [Not a defect] "unsued macro" */
		}
	}
exit:
	return bRet;
}

/*get config CAN TP tx ID*/
tUdsId CANTP_GetConfigTxMsgID(void)
{
	return g_stCANUdsNetLayerCfgInfo.xTxId;
}

/*get config CAN TP recevie function message ID*/
tUdsId CANTP_GetConfigRxMsgFUNID(void)
{
	return g_stCANUdsNetLayerCfgInfo.xRxFunId;
}

/*Is received message valid?*/
boolean CANTP_IsReceivedMsgIDValid(const uint32 i_receiveMsgID)
{
	boolean result = FALSE;
	
	if(    (i_receiveMsgID == CANTP_GetConfigRxMsgFUNID())
        || (i_receiveMsgID == CANTP_GetConfigRxMsgPHYID()))
	{
		result = TRUE;
	}

	return result;
}


/*get config CAN TP recevie physical message ID*/
tUdsId CANTP_GetConfigRxMsgPHYID(void)
{
	return g_stCANUdsNetLayerCfgInfo.xRxPhyId;

}

/*Get CAN TP config Tx  handle*/
tNetTxMsg CANTP_GetConfigTxHandle(void)
{
	return g_stCANUdsNetLayerCfgInfo.pfNetTxMsg;
}

/*Get CAN TP config Rx  handle*/
tNetRx CANTP_GetConfigRxHandle(void)
{
	return g_stCANUdsNetLayerCfgInfo.pfNetRx;
}

/*abort CAN BUS tx message*/
static void CANTP_AbortTxMsg(void)
{
	TPDebugPrintf("CANTP_AbortTxMsg\n");        /* polyspace MISRA-C3:1.3 [Not a defect] "unsued macro" */
	
	if(NULL_PTR != gs_pfCANTPAbortTxMsg)
	{
		(gs_pfCANTPAbortTxMsg)();

		gs_pfTxMsgSuccessfulCallBack = NULL_PTR;
	}

	if(TRUE != CANTP_ClearTXBUSFIFO())
	{
        /* polyspace-begin MISRA-C3:1.3 [Not a defect] "unsued macro" */
		TPDebugPrintf("CANTP_AbortTxMsg: Clear TX BUS FIFO failed!\n");
        /* polyspace-end MISRA-C3:1.3 [Not a defect] "unsued macro" */
	}


}

/*register abort tx message to BUS*/
void CANTP_RegisterAbortTxMsg(const tpfAbortTxMsg i_pfAbortTxMsg)
{
	gs_pfCANTPAbortTxMsg = (tpfAbortTxMsg)i_pfAbortTxMsg;
}


/*write data in CAN TP*/
boolean CANTP_DriverWriteDataInCANTP(const uint32 i_RxID, const uint32 i_dataLen, const uint8 *i_pDataBuf)
{
    boolean blRet = TRUE;
	tLen xCanWriteDataLen = 0u;
	tErroCode eStatus;
	tRxMsgInfo stRxCanMsg;
	const uint32 headerLen = sizeof(stRxCanMsg.rxDataId) + sizeof(stRxCanMsg.rxDataLen);

	ASSERT(NULL_PTR == i_pDataBuf);

	if(i_dataLen > 8u)
	{
		blRet = FALSE;
        goto exit;
	}

	GetCanWriteLen(RX_BUS_FIFO, &xCanWriteDataLen, &eStatus);
	if((ERRO_NONE == eStatus) && ((i_dataLen + headerLen) <= xCanWriteDataLen))
	{
		stRxCanMsg.rxDataId = i_RxID;
		stRxCanMsg.rxDataLen = i_dataLen;

		WriteDataInFifo(RX_BUS_FIFO, 
                        (const u8*)&stRxCanMsg, 
                        (u16)headerLen, 
                        &eStatus);
		if(ERRO_NONE != eStatus)
		{
			blRet = FALSE;
            goto exit;
		}

		WriteDataInFifo(RX_BUS_FIFO, 
                        i_pDataBuf, 
                        (u16)stRxCanMsg.rxDataLen, 
                        &eStatus);
		if(ERRO_NONE != eStatus)
		{
			blRet = FALSE;
            goto exit;
		}		
	}
exit:
	return blRet;	
}

/*Driver read data from LINTP*/
boolean CANTP_DriverReadDataFromCANTP(  const uint32 i_readDataLen, 
                                        uint8 *o_pReadDataBuf,
                                        tTPTxMsgHeader *o_pstTxMsgHeader)
{
	boolean result = FALSE;
	tLen xCanRxDataLen = 0u;
	tErroCode eStatus;
	tTPTxMsgHeader TxMsgInfo = {0};
	const uint32 msgInfoLen = sizeof(tTPTxMsgHeader);

	ASSERT(NULL_PTR == o_pReadDataBuf);
	ASSERT(NULL_PTR == o_pstTxMsgHeader);	
	ASSERT(0u == i_readDataLen);
	
	GetCanReadLen(TX_BUS_FIFO, &xCanRxDataLen, &eStatus);
	if((ERRO_NONE == eStatus) && (xCanRxDataLen > msgInfoLen))
	{
    	/*read header an*/
    	ReadDataFromFifo(TX_BUS_FIFO, 
    					 sizeof(tTPTxMsgHeader),
    					(uint8 *)&TxMsgInfo,
    					&xCanRxDataLen,
    					&eStatus);

    	if((ERRO_NONE != eStatus) || (xCanRxDataLen != sizeof(tTPTxMsgHeader)))
    	{
            result = FALSE;
            goto exit;
        }

		ReadDataFromFifo(TX_BUS_FIFO, 
					    (u16)i_readDataLen,
					    o_pReadDataBuf,
						&xCanRxDataLen,
						&eStatus);

		if(    (ERRO_NONE == eStatus) 
            && (xCanRxDataLen == i_readDataLen) 
            && (i_readDataLen >= TxMsgInfo.TxMsgLength))
		{
			result = TRUE;

			*o_pstTxMsgHeader = TxMsgInfo;


			/*storage callback, if user want to TX message callback please call TP_DoTxMsgSuccesfulCallback or self call callback*/
			gs_pfTxMsgSuccessfulCallBack = TxMsgInfo.TxMsgCallBack;
		}
	}
exit:
	return result;
}


/*do tx message successful callback*/
void CANTP_DoTxMsgSuccessfulCallBack(void)
{
    gs_ucIsTransmittedMsg = TRUE;

	if(NULL_PTR != gs_pfTxMsgSuccessfulCallBack)
	{
		(gs_pfTxMsgSuccessfulCallBack)();

		gs_pfTxMsgSuccessfulCallBack = NULL_PTR;
	}
}

/*transmitted can message callback*/
void TransmittedCanMsgCallBack(void)
{
    gs_ucIsTransmittedMsg = TRUE;
}

/*set wait transmitted can message*/
void SetWaitTransmittedMsg(void)
{
    gs_ucIsTransmittedMsg = FALSE;
}

/*Is transmitted can messag? If transmitted return TRUE, else return FALSE.*/
u8 IsTransmittedMsg(void)
{
    return gs_ucIsTransmittedMsg;
}


/*clear CAN TP TX BUS FIFO*/
static boolean CANTP_ClearTXBUSFIFO(void)
{
	boolean result = FALSE;
	tErroCode eStatus = ERRO_NONE;

	ClearFIFO(TX_BUS_FIFO, &eStatus);
	if(ERRO_NONE == eStatus)
	{
		result = TRUE;
	}

	return result;
}

#endif /*#ifdef EN_CAN_TP*/

/***************************End file********************************/
