/**
 * @file        uart.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_UART_H
#define         DEF_UART_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
typedef enum uart_val_e
{
    UART_VAL_TEST,
    UART_VAL_MCU_ERR_CODE,

    UART_VAL_NUM
}uart_val_t;


typedef enum mcu_drv_e
{
    MCU_DRV_NONE,
    MCU_DRV_CLK,
    MCU_DRV_GIO,
    MCU_DRV_PIT,
    MCU_DRV_NVM,
    MCU_DRV_SPI,
    MCU_DRV_SBC,
    MCU_DRV_CAN,
    MCU_DRV_ADC,
    MCU_DRV_CRC,
    MCU_DRV_DOG,

    MCU_DRV_END
}mcu_drv_t;



//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define MCU_ERR_CODE(drv, code)      (u32)(((u32)drv << 16) | code)

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------

extern void sUartInit(void);
extern void sUartTask(void);
extern void sUartValSet(uart_val_t eValId, u32 dwVal);
extern void sUartValGet(uart_val_t eValId, u32* pdwVal);

#endif

