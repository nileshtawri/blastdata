/*
 * File: PowerDerating.h
 *
 * Code generated for Simulink model 'PowerDerating'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 9.3 (R2020a) 18-Nov-2019
 * C/C++ source code generated on : Tue May 31 09:19:32 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PowerDerating_h_
#define RTW_HEADER_PowerDerating_h_
#ifndef PowerDerating_COMMON_INCLUDES_
# define PowerDerating_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* PowerDerating_COMMON_INCLUDES_ */

#include "PowerDerating_types.h"

/* Macros for accessing real-time model data structure */

/* External inputs (root inport signals with default storage) */
typedef struct {
  real32_T APM_Temperature;            /* '<Root>/APM_Temperature' */
  real32_T AMP_Vin;                    /* '<Root>/AMP_Vin' */
  real32_T APM_Volt;                   /* '<Root>/APM_Volt' */
} ExtU_PowerDerating_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real32_T APM_Derating_Temperature;   /* '<Root>/APM_Derating_Temperature' */
  real32_T APM_Derating_Vin;           /* '<Root>/APM_Derating_Vin' */
  real32_T APM_Derating_Vo;            /* '<Root>/APM_Derating_Vo' */
} ExtY_PowerDerating_T;

/* External inputs (root inport signals with default storage) */
extern ExtU_PowerDerating_T PowerDerating_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_PowerDerating_T PowerDerating_Y;

/* Model entry point functions */
extern void PowerDerating_initialize(void);

/* Exported entry point function */
extern void AMP_Vin_Derating_Trigger(void);

/* Exported entry point function */
extern void APM_Temperature_Derating_Trigger(void);

/* Exported entry point function */
extern void APM_Volt_Derating_Trigger(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PowerDerating'
 * '<S1>'   : 'PowerDerating/Subsystem'
 * '<S2>'   : 'PowerDerating/Subsystem/Subsystem'
 * '<S3>'   : 'PowerDerating/Subsystem/Subsystem1'
 * '<S4>'   : 'PowerDerating/Subsystem/Subsystem2'
 * '<S5>'   : 'PowerDerating/Subsystem/Subsystem/If Action Subsystem'
 * '<S6>'   : 'PowerDerating/Subsystem/Subsystem/If Action Subsystem1'
 */

/*-
 * Requirements for '<Root>': PowerDerating
 */
#endif                                 /* RTW_HEADER_PowerDerating_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
