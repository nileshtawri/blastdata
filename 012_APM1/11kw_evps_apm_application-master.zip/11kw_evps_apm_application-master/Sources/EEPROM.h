#ifndef __EEP_H
#define __EEP_H


void sEEPROMInit(void);
void sEEP_Task(void);
u8 sEEP_IsIdle(void);
u8 sEEP_Emergency(u16 byteNumber);
u16 sEEP_GetFreeBufferSize(void);
u8 sEEP_Write(u32 dwDest, u16 wSize, const u8 * pbData);
u8 sEEP_ClearData(u32 dwDest, u16 wSize);
u8 sEEP_ClearAll(void);
#endif
