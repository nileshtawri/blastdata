/**
 * @file        can.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "config.h"
#include "type.h"
#include "cpu.h"
#include "can.h"
#include "gpio.h"
#include "housekeep.h"
#include "tp.h"
#include "adc.h"
#include "pwm.h"
#include "version.h"
#include "nvm.h"
#include "flexcan_irq.h"
#include "obc.h"
#include "evse.h"
#include "if.h"
#include "networkManagement.h"
#include "timer.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

#define APM_POWER_EFFICIENCY                    0.95F
#define APM_HVDC_CURR_MAX                       20.0F


enum    CAN0_MAILBOX_ID_LIST                    /* CAN_0 mailbox ID */
{
    CAN0_RX_APM_CMD_MAILBOX                     = 0U,
    CAN0_TX_APM_STATUS_MAILBOX                  = 1U,
    CAN0_TX_ISOTP_MAILBOX                       = 2U,
    CAN0_RX_ISOTP_PHY_MAILBOX                   = 3U,
    CAN0_RX_ISOTP_FUN_MAILBOX                   = 4U,
    CAN0_TX_OBC_STATE_MAILBOX                   = 5U,
    CAN0_RX_OBC_CMD_MAILBOX                     = 6U,
    CAN0_RX_NM_MAILBOX                          = 7U,
    CAN0_RX_SYSTIME_MAILBOX                     = 8U,
};

enum    CAN0_MESSAGE_ID_NUMBER                  /* CAN_0 message ID list */
{                                               
                                                /* APM CAN message */
    RX_HCU_APM_CTRL_MSG_ID                      = 0x200U,
    TX_APM_STATE_00_MSG_ID                      = 0x210U,
    TX_APM_STATE_01_MSG_ID                      = 0x211U,
    TX_APM_STATE_02_MSG_ID                      = 0x212U,
    TX_APM_STATE_03_MSG_ID                      = 0x213U,
    TX_APM_STATE_04_MSG_ID                      = 0x214U,
    TX_APM_STATE_05_MSG_ID                      = 0x215U,
    TX_APM_STATE_06_MSG_ID                      = 0x216U,
    TX_APM_APPL_VER_MSG_ID                      = 0x600U,
    TX_APM_BOOT_VER_MSG_ID                      = 0x601U,

                                                /* UDS CAN message */
    RX_UDS_PHY_ID                               = RX_PHY_ID,
    RX_UDS_FUN_ID                               = RX_FUN_ID,
    TX_UDS_RESP_ID                              = TX_ID,

    RX_VCU_TIME_ID                              = 0x400U,

                                                /* Network Management message */
    TX_NM_NMPDU_MSG_ID					        = 0x500U,

                                                /* route to/from CAN2 msg */
    RX_OBC_CTRL_MSG_ID                          = 0x100U,
    TX_DSP_STATE_MSG_ID                         = 0x110U,   // OBC_STATE
    TX_GRID_DATA_MSG_ID                         = 0x114U,   // PFC_DATA_INFO
    TX_HVDC_CTRL_MSG_ID                         = 0x116U,   // GRID_DATA_INFO
    TX_HVDC_DATA_MSG_ID                         = 0x118U,   // LLC_DATA_CTRL_INFO
    TX_OBC_ERROR_MSG_ID                         = 0x11AU,   // HVDC_CTRL_INFO
    TX_OBC_TEMP_MSG_ID                          = 0x11CU,   // HVDC_DATA_INFO
    TX_PFC_DATA_MSG_ID                          = 0x11EU,   // OBC_FAULT_INFO
    TX_OBC_TEMP_6K6_ID                          = 0x120U,   // OBC_TEMP
    TX_DSP_APPL_VER_MSG_ID                      = 0x602U,
    TX_DSP_BOOT_VER_MSG_ID                      = 0x603U,
};

enum    CAN2_MAILBOX_ID_LIST                    /* CAN_2 mailbox ID */
{
    CAN2_TX_OBC_CTRL_MAILBOX                    = 0U,
    CAN2_RX_OBC_STATE_MAILBOX                   = 1U,
    CAN2_RX_OBC_VERSION_MAILBOX                 = 2U,
    CAN2_RX_DSP_ISOTP_MAILBOX                   = 3U,
    CAN2_TX_DSP_ISOTP_MAILBOX                   = 4U,
};

enum    CAN2_MESSAGE_ID_NUMBER                  /* CAN_2 message ID list */
{
    TX_BOOTROM_MSG_ID                           = 0x001U,
    TX_OBC_CTRL_MSG_ID                          = 0x100U,
    TX_OBC_ICMD_MSG_ID                          = 0x101U,
    RX_DSP_STATE_MSG_ID                         = 0x110U,   // OBC_STATE
    RX_PFC_DATA_MSG_ID                          = 0x114U,   // PFC_DATA_INFO
    RX_GRID_DATA_MSG_ID                         = 0x116U,   // GRID_DATA_INFO
    RX_HVDC_CTRL_MSG_ID                         = 0x11AU,   // HVDC_CTRL_INFO
    RX_HVDC_DATA_MSG_ID                         = 0x11CU,   // HVDC_DATA_INFO
    RX_OBC_FAULT_MSG_ID                         = 0x11EU,   // OBC_FAULT_INFO
    RX_OBC_TEMP_MSG_ID                          = 0x120U,   // OBC_TEMP
    RX_DSP_APPL_VER_MSG_ID                      = 0x602U,
    RX_DSP_BOOT_VER_MSG_ID                      = 0x603U,

    TX_DSP_ISOTP_MSG_ID                         = 0x710U,
    RX_DSP_ISOTP_MSG_ID                         = 0x720U,
};

enum
{
    CAN0_TX_APM_STATE_00 = 0U,
    CAN0_TX_APM_STATE_01,
    CAN0_TX_APM_STATE_02,
    CAN0_TX_APM_STATE_03,
    CAN0_TX_APM_STATE_04,
    CAN0_TX_APM_STATE_05,
    CAN0_TX_APM_STATE_06,
    CAN0_TX_APM_APP_VER,
    CAN0_TX_APM_BOOT_VER,
};

/* Rx and Tx message ID, ID type, ID mask configure */
#define RX_FUN_ID_TYPE	FLEXCAN_MSG_ID_STD
#define RX_FUN_ID_MASK	0xFFFFFFFFu

#define	RX_PHY_ID_TYPE	FLEXCAN_MSG_ID_STD
#define RX_PHY_ID_MASK	0xFFFFFFFFu

#define BOOT_INFO_ADDR  0x0001FE00U             /* bootloader version info. */





#define APM_VCMD_MIN                9.0F
#define APM_VCMD_MAX                16.0F

#define APM_ICMD_MIN                0.01F

#define CAN2_RX_BUF_MAX             8U

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------
typedef void (*tpfTxSuccesfullCallBack)(void);

typedef struct
{
	uint32_t usTxID;                        /*tx can id*/
	uint8_t ucTxMailBox;                    /*used tx mail box*/
	flexcan_msgbuff_id_type_t TxID_Type;	/* tx mask ID type:  Standard ID or Extended ID*/
	tpfTxSuccesfullCallBack pfCallBack;
}tTxMsgConfig;

typedef struct
{
	uint8_t usRxMailBox;		            /*used rx mail box*/
	uint32_t usRxID;                        /*rx can id*/
	uint32_t usRxMask;                      /*rx mask*/
	flexcan_msgbuff_id_type_t RxID_Type;	/* rx mask ID type:  Standard ID or Extended ID*/
}tRxMsgConfig;

typedef struct
{
	uint32_t ucRxDataLen;                       /*RX can harware data len*/
	uint32_t usRxDataId;                        /*RX data ID*/
	uint8_t aucDataBuf[64u];                    /*RX data buf*/
}tRxCanMsg;

//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
static void sCanTpTxCheckStatus(void);
static void sCanTpRxCallback(void);
static void sCanTpTxCallback(void);

static uint8_t sCanTpTxMsg( const uint32_t i_usCANMsgID,
                            const uint8_t i_ucDataLen,
                            const uint8_t *i_pucDataBuf, 
                            const tpfNetTxCallBack i_pfNetTxCallBack,
                            const uint32_t i_txBlockingMaxtime);


static void sCan2IsrCallback(   uint32_t instance, 
                                can_event_t eventType, 
                                uint32_t objIdx, 
                                void *driverState);


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static const x_if_ai_t *pxIfAiInfo = NULL;
static const x_if_ho_t *pxIfHoInfo = NULL;
static const x_if_ei_t *pxIfEi = NULL;
static const x_if_eo_t *pxIfEoInfo = NULL;
static const x_if_oo_t *pxIfObcInfo = NULL;

static bool blCan0RxApmCtrlMsg = false;
static bool blCan0RxSysTimeMsg = false;
static bool blCan0RxObcCtrlMsg = false;
static bool blCan0RxNmMsg = false;

static can_message_t xCan0RxApmCmdBuf;
static can_message_t xCan0RxSysTimeBuf;
static can_message_t xCan0RxObcCmdBuf;
static can_message_t xCan0RxNmMsgBuf;

static u32 dwCan0TxFailCnt = 0;
static u32 dwCan0TxPassCnt = 0;
static u32 dwCan0RxFailCnt = 0;
static u32 dwCan0RxPassCnt = 0;

static u32 dwCan2TxFailCnt = 0;
static u32 dwCan2TxPassCnt = 0;
static u32 dwCan2RxFailCnt = 0;
static u32 dwCan2RxPassCnt = 0;

static u8 baSysTimeMsgBuf[8];
static u8 baApmCtrlMsgBuf[8];
static u8 baNmMsgBuf[8];

static u8 baObcCtrlMsgBuf[8];
static u32 dwObcCtrlMsgId;
//static u32 dwObcTxStateMsgId;
//static u8 baObcTxStateMsgBuf[8];

static u32 dwObcTxVersionMsgId;
static u8 baObcTxVersionMsgBuf[8];

//static bool blCan2RxObcStateMsg = false;
static can_message_t xaCan2RxObcStateBuf[CAN2_RX_BUF_MAX];
static u8 bRxIdxIn = 0;
static u8 bRxIdxOut = 0;
static bool blIsCan2RxRingBufFull = false;

static bool blCan2RxObcVersionMsg = false;
static can_message_t xCan2RxObcVersionBuf;

static bool blCan2RxIsoTpMsg = false;
static can_message_t xCan2RxIsoTpBuf;

/* ISO TP RX can message config*/
static const tRxMsgConfig pxCanTpRxMsgConfig[] =
{
    {
        (u8)CAN0_RX_ISOTP_FUN_MAILBOX, 
        RX_FUN_ID,                              /*UDS Rx function ID*/
        RX_FUN_ID_MASK, 
        RX_FUN_ID_TYPE,
    },
    {   
        (u8)CAN0_RX_ISOTP_PHY_MAILBOX,
        RX_PHY_ID,                              /*UDS RX physical ID*/
        RX_PHY_ID_MASK, 
        RX_PHY_ID_TYPE,
    }
};

/* ISO TP rx can message num*/
static const u8 bCanTpRxMsgIdNum = (u8)sizeof(pxCanTpRxMsgConfig) / (u8)sizeof(pxCanTpRxMsgConfig[0u]);

/* ISO TP TX can message config*/
static tTxMsgConfig g_stTxMsgConfig =
{
    TX_ID,                                      /*UDS tx can message id*/
    (u8)CAN0_TX_ISOTP_MAILBOX,                  /*UDS tx can message mail box*/
    FLEXCAN_MSG_ID_STD,	                        /* UDS tx can message id type */
    NULL
};

/* Define receive buffer */
static can_message_t xTpRecvMsg;

static u32 dwTpTxCanFail = 0U;
static u32 dwTpTxCanPass = 0U;

//Mailbox Config
static const can_buff_config_t xbuffCfg;
static const can_buff_config_t xbuffCfg =
{
    .enableFD = false,
    .enableBRS = false,
    .fdPadding = 0U,
    .idType = CAN_MSG_ID_STD,
    .isRemote = false
};


static x_if_ci0_t xIfCi0Data =                  // IF_CI0 data
{
    .eApmModeCmd = APM_MODE_CMD_INVALID,
    .flApmVcmd = APM_VCMD_DEFAULT,
    .flApmIcmd = APM_ICMD_DEFAULT,
    .eObcModeCmd = OBC_MODE_CMD_UNKNOW,
    .flObcVcmd = 0.0F,
    .flObcIcmd = 0.0F,
    .eRxApmCmdTimeout = BOOL_FALSE,
    .eRxObcCmdTimeout = BOOL_TRUE,
    .eRxSysTimeTimeout = BOOL_TRUE,
    .wYear = 0,
    .bMonth = 0,
    .bDay = 0,
    .bHour = 0,
    .bMinute = 0,
    .bSec = 0,
    .b100ms = 0,
};

static x_if_ci2_t xIfCi2Data =                  // IF_CI2 data
{
    .eObcWorkMode = OBC_WORK_MODE_UNKNOW,
    .eRxTimeout = BOOL_FALSE,
};

static bool blJ1772Enable = true;

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/**
 * @brief       Receive VCU System Time Message
 */
static void sCanRxSysTimeMsg(void)
{
    u16 wYear;
    u8 bMon;
    u8 bDay;
    u8 bHour;
    u8 bMin;
    u8 bSec;
    u8 b100ms;
    
    wYear = baSysTimeMsgBuf[0];
    wYear <<= 8U;
    wYear += baSysTimeMsgBuf[1];
    bMon = baSysTimeMsgBuf[2];
    bDay = baSysTimeMsgBuf[3];
    bHour = baSysTimeMsgBuf[4];
    bMin = baSysTimeMsgBuf[5];
    bSec = baSysTimeMsgBuf[6];
    b100ms = baSysTimeMsgBuf[7];

    xIfCi0Data.wYear = wYear;
    xIfCi0Data.bMonth = bMon;
    xIfCi0Data.bDay = bDay;
    xIfCi0Data.bHour = bHour;
    xIfCi0Data.bMinute = bMin;
    xIfCi0Data.bSec = bSec;
    xIfCi0Data.b100ms = b100ms;

    xIfCi0Data.eRxSysTimeTimeout = BOOL_FALSE;

    (void)sbIfSet(IF_CI0, &xIfCi0Data);
}

/**
 * @brief       Receive Can Message
 */
static void sCanRxApmCtrlMsg(void)
{
    u8 bAPM_CTRL;
    u16 wAPM_VCMD;
    u16 wAPM_ICMD;
    
    bAPM_CTRL = baApmCtrlMsgBuf[0];
    wAPM_VCMD = baApmCtrlMsgBuf[1];
    wAPM_ICMD = baApmCtrlMsgBuf[2];
	wAPM_ICMD <<= 8U;
	wAPM_ICMD += baApmCtrlMsgBuf[3];

    switch(bAPM_CTRL)
    {
        case 0:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_INVALID;
            break;

        case 1U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_IDLE;
            break;

        case 2U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_STANDBY;
            break;

        case 3U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_DCDC;
            break;

        case 4U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_PRECHARGE;
            break;

        case 5U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_DISCHARGE;
            break;

        #if (HAVE_TEST_MODE != 0)
        case 255U:
            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_TEST;
            break;
        #endif

        default:
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("APM RX INVALIDE MODE\n");
            #endif

            xIfCi0Data.eApmModeCmd = APM_MODE_CMD_INVALID;
            break;
    }	
	
    xIfCi0Data.flApmVcmd = (f32)wAPM_VCMD;
    xIfCi0Data.flApmVcmd /= 10.0F;

    if(xIfCi0Data.flApmVcmd > APM_VCMD_MAX)
    {
    	xIfCi0Data.flApmVcmd = APM_VCMD_MAX;
    }

    if(xIfCi0Data.flApmVcmd < APM_VCMD_MIN)
    {
    	xIfCi0Data.flApmVcmd = APM_VCMD_MIN;
    }


    xIfCi0Data.flApmIcmd = (f32)wAPM_ICMD;
    xIfCi0Data.flApmIcmd /= 10.0F;

    if(xIfCi0Data.flApmIcmd > APM_ICMD_MAX)
    {
    	xIfCi0Data.flApmIcmd = APM_ICMD_MAX;
    }

    if(xIfCi0Data.flApmIcmd < APM_ICMD_MIN)
    {
    	xIfCi0Data.flApmIcmd = 0.0F;
    }

    xIfCi0Data.eRxApmCmdTimeout = BOOL_FALSE;

    (void)sbIfSet(IF_CI0, &xIfCi0Data);
}

/*check can transmitted data successfull?*/
static void sCanTpTxCheckStatus(void)
{
    status_t Can_Tx_Statu;

    Can_Tx_Statu = CAN_GetTransferStatus(   &DrvCan0_instance, 
                                            g_stTxMsgConfig.ucTxMailBox);

    if(STATUS_SUCCESS == Can_Tx_Statu)
    {
        if(NULL != g_stTxMsgConfig.pfCallBack)
        {
            g_stTxMsgConfig.pfCallBack();
            g_stTxMsgConfig.pfCallBack = NULL;
        }
    }
}

/*Is Rx can message ID? If is rx can message id return TRUE, else return FALSE.*/
static uint8_t sbIsCanTpRxMsgId(uint32_t i_usRxMsgId)
{
    uint8_t i = 0u;
    u8 bRet = FALSE;

    while(i < bCanTpRxMsgIdNum)
    {
        if(i_usRxMsgId  == pxCanTpRxMsgConfig[i].usRxID )
        {
            bRet = TRUE;
            break;
        }

        i++;
    }

    return bRet;
}


/**
 * @brief       Can0 ISR
 */
static void sCan0IsrCallback(uint32_t instance, 
                            can_event_t eventType, 
                            uint32_t objIdx, 
                            void *driverState)  /* polyspace MISRA-C3:8.13 "should add const" */
{
    uint32_t i;
    (void)instance;
    (void)driverState;
    status_t xRet;

    DEV_ASSERT(driverState != NULL);

    switch(eventType)
    {
    case CAN_EVENT_RX_COMPLETE:
        if(objIdx == (u32)CAN0_RX_APM_CMD_MAILBOX)
        {
            blCan0RxApmCtrlMsg = true;

            for (i=0; i<8; i++)
            {
                baApmCtrlMsgBuf[i] = xCan0RxApmCmdBuf.data[i];
            }

            /* Enable MB interrupt*/
            xRet = CAN_Receive( &DrvCan0_instance, 
                                objIdx, 
                                &xCan0RxApmCmdBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan0RxFailCnt++;
            }
            else
            {
                dwCan0RxPassCnt++;
            }
        }

        else if(objIdx == (u32)CAN0_RX_SYSTIME_MAILBOX)
        {
            blCan0RxSysTimeMsg = true;

            for (i=0; i<8; i++)
            {
                baSysTimeMsgBuf[i] = xCan0RxSysTimeBuf.data[i];
            }

            /* Enable MB interrupt*/
            xRet = CAN_Receive( &DrvCan0_instance, 
                                objIdx, 
                                &xCan0RxSysTimeBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan0RxFailCnt++;
            }
            else
            {
                dwCan0RxPassCnt++;
            }
        }

        else if(objIdx == (u32)CAN0_RX_OBC_CMD_MAILBOX)
        {
            blCan0RxObcCtrlMsg = true;

            for (i=0; i<8; i++)
            {
                baObcCtrlMsgBuf[i] = xCan0RxObcCmdBuf.data[i];
                dwObcCtrlMsgId = xCan0RxObcCmdBuf.id;
            }

            /* Enable MB interrupt*/
            xRet = CAN_Receive( &DrvCan0_instance, 
                                objIdx, 
                                &xCan0RxObcCmdBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan0RxFailCnt++;
            }
            else
            {
                dwCan0RxPassCnt++;
            }
        }

        else if(objIdx == (u32)CAN0_RX_NM_MAILBOX)
        {
            blCan0RxNmMsg = true;

            for (i=0; i<8; i++)
            {
                baNmMsgBuf[i] = xCan0RxNmMsgBuf.data[i];
            }

            /* Enable MB interrupt*/
            xRet = CAN_Receive( &DrvCan0_instance, 
                                objIdx, 
                                &xCan0RxNmMsgBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan0RxFailCnt++;
            }
            else
            {
                dwCan0RxPassCnt++;
            }
        }

        else if(   (objIdx == (u32)CAN0_RX_ISOTP_PHY_MAILBOX)
                || (objIdx == (u32)CAN0_RX_ISOTP_FUN_MAILBOX))
        {
            sCanTpRxCallback();

            /* Enable MB interrupt*/
            for(i = 0u; i < bCanTpRxMsgIdNum; i++)
            {
                xRet = CAN_Receive( &DrvCan0_instance, 
                                    (u32)pxCanTpRxMsgConfig[i].usRxMailBox, 
                                    &xTpRecvMsg);
                if(xRet != STATUS_SUCCESS)
                {
                    dwCan0RxFailCnt++;
                }
                else
                {
                    dwCan0RxPassCnt++;
                }
            }
        }
        else
        {
            ;
        }
        break;

    case CAN_EVENT_TX_COMPLETE:
        if(objIdx == (u32)CAN0_TX_ISOTP_MAILBOX)
        {
            sCanTpTxCallback();
        }
        break;

    default:
        ;
        break;
    }
}

/**
 * @brief       Initialize Can IRQ
 */
static status_t sCAN0IRQInitial(void)
{
    /* Install CAN ISR */
    INT_SYS_InstallHandler( CAN0_ORed_IRQn, 
                            &CAN0_ORed_IRQHandler, 
                            NULL);

    INT_SYS_InstallHandler( CAN0_Error_IRQn,
                            &CAN0_Error_IRQHandler,
                            NULL);

    INT_SYS_InstallHandler( CAN0_ORed_0_15_MB_IRQn,
                            &CAN0_ORed_0_15_MB_IRQHandler,
                            NULL);

    INT_SYS_InstallHandler( CAN0_ORed_16_31_MB_IRQn,
                            &CAN0_ORed_16_31_MB_IRQHandler,
                            NULL);

    /* Enable CAN interrupt */
    INT_SYS_EnableIRQ(CAN0_ORed_IRQn);
    INT_SYS_EnableIRQ(CAN0_Error_IRQn);
    INT_SYS_EnableIRQ(CAN0_ORed_0_15_MB_IRQn);
    INT_SYS_EnableIRQ(CAN0_ORed_16_31_MB_IRQn);

    return CAN_InstallEventCallback(&DrvCan0_instance, sCan0IsrCallback, NULL);
}

static void sCanTpTxCallback(void)
{
    sCanTpTxCheckStatus();                      /* check CAN TP TX Mailbox status */
}


static void sCanTpRxCallback(void)
{
    tRxCanMsg stRxCANMsg = {0u};
    uint8_t CANDataIndex = 0u;
    u8 bIsRxTpMsg = FALSE;

    /* Read CAN massage data from recieve buffer xTpRecvMsg */
    stRxCANMsg.usRxDataId = xTpRecvMsg.id;
    stRxCANMsg.ucRxDataLen = xTpRecvMsg.length;

    bIsRxTpMsg = sbIsCanTpRxMsgId(stRxCANMsg.usRxDataId);

    if((0u != stRxCANMsg.ucRxDataLen) && (TRUE == bIsRxTpMsg))
    {
        /*read can message*/
        for(CANDataIndex = 0u; CANDataIndex < stRxCANMsg.ucRxDataLen; CANDataIndex++)
        {
            stRxCANMsg.aucDataBuf[CANDataIndex] = xTpRecvMsg.data[CANDataIndex];
        }

		if(TRUE != TP_DriverWriteDataInTP(stRxCANMsg.usRxDataId, stRxCANMsg.ucRxDataLen, stRxCANMsg.aucDataBuf))
		{
			/*here is TP driver write data in TP failed, TP will lost CAN message*/
			while(1)
			{
			}
		}		
    }
}


static uint8_t sCanTpTxMsg( const uint32_t i_usCANMsgID,
                            const uint8_t i_ucDataLen,
                            const uint8_t *i_pucDataBuf, 
                            const tpfNetTxCallBack i_pfNetTxCallBack,
                            const uint32_t i_txBlockingMaxtime)
{

    status_t CANTxStatus = STATUS_BUSY;
    uint8_t bRet = 0;
    
    uint8_t	i;
    can_message_t message;

    (void)i_txBlockingMaxtime;

    DEV_ASSERT(i_pucDataBuf != NULL);

    if(i_usCANMsgID != g_stTxMsgConfig.usTxID)
    {
        bRet = FALSE;
    }
    else
    {
        message.cs = 0u;
        message.id = i_usCANMsgID;
        message.length = i_ucDataLen;

        for(i = 0u; i < i_ucDataLen; i++)
        {   /* polyspace-begin MISRA-C3:18.1 "pointer to array" */
            message.data[i] = i_pucDataBuf[i];
        }   /* polyspace-end MISRA-C3:18.1 "pointer to array" */

        CANTxStatus = CAN_Send( &DrvCan0_instance, 
                                (u8)CAN0_TX_ISOTP_MAILBOX, 
                                &message);

        g_stTxMsgConfig.pfCallBack = i_pfNetTxCallBack;

        if(STATUS_SUCCESS == CANTxStatus)
        {
            dwCan0TxPassCnt++;
            bRet = TRUE;
        }
        else
        {
            dwCan0TxFailCnt++;
            bRet = FALSE;
        }
    }
        
    return bRet;
}

/**
 * \brief: transmit APM_STATE_00 message via CAN0
 */
static void sCanTxApmState00(void)
{
    can_message_t xMsg;
    status_t xRet;
    u64 qwErrorFlags;
    u8 bMode;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);

    qwErrorFlags = pxIfHoInfo->qwApmErrorFlag;
    xMsg.id = (u32)TX_APM_STATE_00_MSG_ID;

    bMode = (u8)pxIfHoInfo->eApmWorkMode;
    xMsg.data[0] = bMode & 0x0FU;               // APM state
    xMsg.data[0] |= (pxIfHoInfo->eIgnState == BOOL_TRUE) ? 0x80U : 0;  // Ignition state
    xMsg.data[0] |= (pxIfObcInfo->eObcAuxEnDoh == BOOL_TRUE) ? 0x40U : 0;  // HV AUX. state
    xMsg.data[0] |= (pxIfEoInfo->eCpReadyDoh == BOOL_TRUE) ? 0x20U : 0;  // S2 switch state
    xMsg.data[1] = (u8)qwErrorFlags;
    xMsg.data[2] = (u8)(qwErrorFlags >> 8U);
    xMsg.data[3] = (u8)(qwErrorFlags >> 16U);
    xMsg.data[4] = (u8)(qwErrorFlags >> 24U);
    xMsg.data[5] = (u8)(qwErrorFlags >> 32U);
    xMsg.data[6] = (u8)(qwErrorFlags >> 40U);
    xMsg.data[7] = (u8)(qwErrorFlags >> 48U);


    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);

    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}


/**
 * \brief: transmit APM_STATE_01 message via CAN0
 */
static void sCanTxApmState01(void)
{
    can_message_t xMsg;
    status_t xRet;
    f32 flTemp;
    u16 wTemp;
    s8 cTemp;
    u8 bTemp;
    pilot_state_t xCpState;
    prox_state_t xPpState;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
	xMsg.id = (u32)TX_APM_STATE_01_MSG_ID;

    flTemp = pxIfAiInfo->flProxiVolt;           // proximilyt voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wTemp = (u16)flTemp;
    xMsg.data[0] = (u8)(wTemp >> 8);
    xMsg.data[1] = (u8)wTemp;

    xCpState = pxIfEi->eCpState;            // control pilot state
    xPpState = pxIfEi->ePpState;            // proximity state
    bTemp = (u8)xPpState;
    bTemp <<= 3U;
    bTemp |= (u8)xCpState;
    xMsg.data[2] = bTemp;
    
    flTemp = pxIfAiInfo->flPilotVolt;            // control pilot voltage
    flTemp *= 10.0F;
    flTemp += 0.5F;
    cTemp = (s8)flTemp;
    xMsg.data[3] = (u8)cTemp;

    flTemp = pxIfEi->flCpDuty;              // control pilot duty
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wTemp = (u16)flTemp;
    xMsg.data[4] = (u8)(wTemp >> 8);
    xMsg.data[5] = (u8)wTemp;

    flTemp = pxIfEi->flCpFreq;              // control pilot frequency
    flTemp *= 10.0F;
    flTemp += 0.5F;
    wTemp = (u16)flTemp;
    xMsg.data[6] = (u8)(wTemp >> 8);
    xMsg.data[7] = (u8)wTemp;


    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);

    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_STATE_02 message via CAN0
 */
static void sCanTxApmState02(void)
{
    can_message_t xMsg;
    status_t xRet;
    u16 wLvdcVolt;
    s16 iLvdcCurr;
    u16 wLvBatVolt;
    u16 wLvdcRemoteVolt;
    f32 flTemp;
    u16 wTmp;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
	xMsg.id = (u32)TX_APM_STATE_02_MSG_ID;

    flTemp = pxIfAiInfo->flLvdcRemoteVolt;       // LVDC remote voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wLvdcRemoteVolt = (u16)flTemp;
    xMsg.data[0] = (u8)(wLvdcRemoteVolt >> 8);
    xMsg.data[1] = (u8)wLvdcRemoteVolt;

    flTemp = pxIfAiInfo->flLvdcVolt;             // LVDC output voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wLvdcVolt = (u16)flTemp;
    xMsg.data[2] = (u8)(wLvdcVolt >> 8);
    xMsg.data[3] = (u8)wLvdcVolt;

    flTemp = pxIfAiInfo->flLvdcCurr;             // LVDC output current
    flTemp *= 10.0F;
    flTemp += 0.5F;
    iLvdcCurr = (s16)flTemp;
    wTmp = (u16)iLvdcCurr;
    xMsg.data[4] = (u8)(wTmp >> 8);
    xMsg.data[5] = (u8)wTmp;

    flTemp = pxIfAiInfo->flLvBatVolt;            // LV side battery voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wLvBatVolt = (u16)flTemp;
    xMsg.data[6] = (u8)(wLvBatVolt >> 8);
    xMsg.data[7] = (u8)wLvBatVolt;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);

    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

#if 0
static f32 sflHvdcCurrGet(void)
{
    f32 flTmp;
    flTmp = pxIfAiInfo->flLvdcVolt * pxIfAiInfo->flLvdcCurr;
    flTmp /= APM_POWER_EFFICIENCY;
    flTmp /= pxIfAiInfo->flHvdcVolt;

    if (flTmp < 0)
    {
        flTmp = 0.0F;
    }

    if (flTmp > APM_HVDC_CURR_MAX)
    {
        flTmp = APM_HVDC_CURR_MAX;
    }

    return flTmp;
}
#endif

/**
 * \brief: transmit APM_STATE_03 message via CAN0
 */
static void sCanTxApmState03(void)
{
    can_message_t xMsg;
    status_t xRet;
    f32 flTemp;
    u16 wHvdcVolt;
    u16 wHvdcCurr;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
    xMsg.id = (u32)TX_APM_STATE_03_MSG_ID;

    flTemp = pxIfAiInfo->flHvdcVolt;            // HVDC input voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wHvdcVolt = (u16)flTemp;
    xMsg.data[0] = (u8)(wHvdcVolt >> 8);
    xMsg.data[1] = (u8)wHvdcVolt;

    flTemp = pxIfAiInfo->flHvdcCurr;            // HVDC input current
    flTemp *= 1000.0F;
    flTemp += 0.5F;
    wHvdcCurr = (u16)flTemp;
    xMsg.data[2] = (u8)(wHvdcCurr >> 8);
    xMsg.data[3] = (u8)wHvdcCurr;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_STATE_04 message via CAN0
 */
static void sCanTxApmState04(void)
{
    can_message_t xMsg;
    status_t xRet;
    f32 flTemp;
    s16 iTemp1;
    s16 iTemp2;
    s16 iTemp3;
    u16 wTmp;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
    xMsg.id = (u32)TX_APM_STATE_04_MSG_ID;

    flTemp = pxIfAiInfo->flPcbTemp;              // APM temperature 1 (PCB)
    flTemp *= 100.0F;
    flTemp += 0.5F;
    iTemp1 = (s16)flTemp;
    wTmp = (u16)iTemp1;
    xMsg.data[0] = (u8)(wTmp >> 8);
    xMsg.data[1] = (u8)wTmp;

    flTemp = pxIfAiInfo->flSrTemp;               // APM temperature 2 (SR)
    flTemp *= 100.0F;
    flTemp += 0.5F;
    iTemp2 = (s16)flTemp;
    wTmp = (u16)iTemp2;
    xMsg.data[2] = (u8)(wTmp >> 8);
    xMsg.data[3] = (u8)wTmp;

    flTemp = pxIfAiInfo->flCoolTemp;             // APM temperature 3 (COOLANT)
    flTemp *= 100.0F;
    flTemp += 0.5F;
    iTemp3 = (s16)flTemp;
    wTmp = (u16)iTemp3;
    xMsg.data[4] = (u8)(wTmp >> 8);
    xMsg.data[5] = (u8)wTmp;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_STATE_05 message via CAN0
 */
static void sCanTxApmState05(void)
{
    can_message_t xMsg;
    status_t xRet;
    f32 flTemp;
    u16 wEvseImax;
    u16 wApmIcmd;
    u16 wApmAux1;
    u16 wApmAux2;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
	xMsg.id = (u32)TX_APM_STATE_05_MSG_ID;

    flTemp = pxIfAiInfo->flAuxHvVolt;           // APM Aux. power 2 voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wApmAux2 = (u16)flTemp;
    xMsg.data[0] = (u8)(wApmAux2 >> 8);
    xMsg.data[1] = (u8)wApmAux2;

    flTemp = pxIfEoInfo->flEvseImax;            // EVSE maxima output current
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wEvseImax = (u16)flTemp;
    xMsg.data[2] = (u8)(wEvseImax >> 8);
    xMsg.data[3] = (u8)wEvseImax;

    flTemp = pxIfHoInfo->flLvdcIcmd;            // LVDC current limit command
    flTemp *= 10.0F;
    flTemp += 0.5F;
    wApmIcmd = (u16)flTemp;
    xMsg.data[4] = (u8)(wApmIcmd >> 8);
    xMsg.data[5] = (u8)wApmIcmd;

    flTemp = pxIfAiInfo->flAuxLvVolt;           // APM Aux. power 1 voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wApmAux1 = (u16)flTemp;
    xMsg.data[6] = (u8)(wApmAux1 >> 8);
    xMsg.data[7] = (u8)wApmAux1;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_STATE_06 message via CAN0
 */
static void sCanTxApmState06(void)
{
    can_message_t xMsg;
    status_t xRet;
    f32 flTemp;
    u16 wBstVolt;
    u16 wBstCurr;
    u16 wLvVcmdDuty;
    u16 wLvIcmdDuty;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
	xMsg.id = (u32)TX_APM_STATE_06_MSG_ID;

    flTemp = pxIfAiInfo->flBoostVolt;            // boost voltage
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wBstVolt = (u16)flTemp;
    xMsg.data[0] = (u8)(wBstVolt >> 8);
    xMsg.data[1] = (u8)wBstVolt;

    flTemp = pxIfAiInfo->flBoostCurr;            // boost current
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wBstCurr = (u16)flTemp;
    xMsg.data[2] = (u8)(wBstCurr >> 8);
    xMsg.data[3] = (u8)wBstCurr;

    flTemp = (f32)pxIfHoInfo->wVcmdDutyCnt;     // LVDC_CVCC_VOLT_PWM duty cnt
    /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
    flTemp = flTemp / (f32)PWM_PERIOD;
    /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
    flTemp *= 10000.0F;                         // unit is 0.01%
    flTemp += 0.5F;
    wLvVcmdDuty = (u16)flTemp;
    xMsg.data[4] = (u8)(wLvVcmdDuty >> 8);
    xMsg.data[5] = (u8)wLvVcmdDuty;

    flTemp = (f32)pxIfHoInfo->wIcmdDutyCnt;     // LVDC_CVCC_CURR_PWM duty cnt
    /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
    flTemp = flTemp / (f32)PWM_PERIOD;
    /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
    flTemp *= 10000.0F;                         // unit is 0.01%
    flTemp += 0.5F;
    wLvIcmdDuty = (u16)flTemp;
    xMsg.data[6] = (u8)(wLvIcmdDuty >> 8);
    xMsg.data[7] = (u8)wLvIcmdDuty;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_VER_APPL message via CAN0
 */
static void sCanTxApmVerAppl(void)
{
    can_message_t xMsg;
    status_t xRet;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
	xMsg.id = (u32)TX_APM_APPL_VER_MSG_ID;

	xMsg.data[0] = xApplVerInfo.bVerMajor;
	xMsg.data[1] = xApplVerInfo.bVerMinor;
	xMsg.data[2] = xApplVerInfo.bVerDebug;
    xMsg.data[3] = xApplVerInfo.bBuildHostId;
    xMsg.data[4] = (u8)(xApplVerInfo.wBuildYear >> 8);
    xMsg.data[5] = (u8)(xApplVerInfo.wBuildYear & 0x0FFU);
    xMsg.data[6] = xApplVerInfo.bBuildMonth;
    xMsg.data[7] = xApplVerInfo.bBuildDay;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit APM_VER_BOOT message via CAN0
 */
static void sCanTxApmVerBoot(void)
{
    can_message_t xMsg;
    status_t xRet;
    const ver_info_t *pxBootVerInfo = (const ver_info_t*)BOOT_INFO_ADDR;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
    xMsg.id = (u32)TX_APM_BOOT_VER_MSG_ID;

    xMsg.data[0] = pxBootVerInfo->bVerMajor;
    xMsg.data[1] = pxBootVerInfo->bVerMinor;
    xMsg.data[2] = pxBootVerInfo->bVerDebug;
    xMsg.data[3] = pxBootVerInfo->bBuildHostId;
    xMsg.data[4] = (u8)(pxBootVerInfo->wBuildYear >> 8);
    xMsg.data[5] = (u8)pxBootVerInfo->wBuildYear;
    xMsg.data[6] = pxBootVerInfo->bBuildMonth;
    xMsg.data[7] = pxBootVerInfo->bBuildDay;

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * \brief: transmit NM_NMPDU_MSG message via CAN0
 */
static void sCanTxNmMsg(void)
{
    can_message_t xMsg;
    status_t xRet;
    const net_conf_t *pxNetConf = NULL;
    u8 bEcuId;
    u8 bCtrlBit;

    sNvmNetConfDefaultPtrGet(&pxNetConf);
    bEcuId = pxNetConf->xNmConf.bEcuId;
    bCtrlBit = sbNmControlBitVectorGet();

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
    
    xMsg.id = (u32)TX_NM_NMPDU_MSG_ID;
    xMsg.id |= bEcuId;
	xMsg.data[0] = bEcuId;
	xMsg.data[1] = bCtrlBit;
    
    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}

/**
 * @brief       Initialize Can2 IRQ
 */
static status_t sCAN2IRQInitial(void)
{
    /* Install CAN2 ISR */
    INT_SYS_InstallHandler( CAN2_ORed_IRQn, 
                            &CAN2_ORed_IRQHandler, 
                            NULL);

    INT_SYS_InstallHandler( CAN2_Error_IRQn,
                            &CAN2_Error_IRQHandler,
                            NULL);

    INT_SYS_InstallHandler( CAN2_ORed_0_15_MB_IRQn,
                            &CAN2_ORed_0_15_MB_IRQHandler,
                            NULL);

    /* Enable CAN interrupt */
    INT_SYS_EnableIRQ(CAN2_ORed_IRQn);
    INT_SYS_EnableIRQ(CAN2_Error_IRQn);
    INT_SYS_EnableIRQ(CAN2_ORed_0_15_MB_IRQn);

    return CAN_InstallEventCallback(&DrvCan2_instance, sCan2IsrCallback, NULL);
}

/**
 * @brief       Can2 ISR
 */
static void sCan2IsrCallback(   uint32_t instance, 
                                can_event_t eventType, 
                                uint32_t objIdx, 
                                void *driverState)  /* polyspace MISRA-C3:8.13 "should add const" */
{
    (void)instance;
    (void)driverState;
    status_t xRet;
    u8 i;

    DEV_ASSERT(driverState != NULL);

    switch(eventType)
    {
    case CAN_EVENT_RX_COMPLETE:
        dwCan2RxPassCnt++;
        if(objIdx == (u32)CAN2_RX_OBC_STATE_MAILBOX)
        {
            i = bRxIdxIn + 1U;
            i %= CAN2_RX_BUF_MAX;
            if(i == bRxIdxOut)               // check if ring buffer fulll
            {
                blIsCan2RxRingBufFull = true;
                dwCan2RxFailCnt++;
            }
            else
            {
                bRxIdxIn = i;
                /* Enable CAN Rx MailBox interrupt again */
                (void)CAN_Receive(  &DrvCan2_instance, 
                                    objIdx, 
                                    &xaCan2RxObcStateBuf[bRxIdxIn]);
            }
        }
        else if(objIdx == (u32)CAN2_RX_DSP_ISOTP_MAILBOX)
        {
            blCan2RxIsoTpMsg = true;

            /* Enable CAN Rx MailBox interrupt again */
            xRet = CAN_Receive(&DrvCan2_instance, objIdx, &xCan2RxIsoTpBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan2RxFailCnt++;
            }
        }
        else if(objIdx == (u32)CAN2_RX_OBC_VERSION_MAILBOX)
        {
            blCan2RxObcVersionMsg = true;

            dwObcTxVersionMsgId = xCan2RxObcVersionBuf.id;
            for(i=0; i<8U; i++)
            {
                baObcTxVersionMsgBuf[i] = xCan2RxObcVersionBuf.data[i];
            }

            /* Enable CAN Rx MailBox interrupt again */
            xRet = CAN_Receive(&DrvCan2_instance, objIdx, &xCan2RxObcVersionBuf);
            if(xRet != STATUS_SUCCESS)
            {
                dwCan2RxFailCnt++;
            }
        }
        else
        {
            ;
        }
        break;
    case CAN_EVENT_TX_COMPLETE:
        if(objIdx == (u32)CAN2_TX_OBC_CTRL_MAILBOX)
        {
            dwCan2TxPassCnt++;
        }
        break;

    default:
        ;
        break;
    }
}


/**
 * \brief: transmit CURR_LIMIT_MSG command message to F280049 via CAN2
 */
static void sCanTxObcIcmd(void)
{
    can_message_t xMsg;
    status_t xRet;
    u16 wEvseImax;
    u16 wInputCurr;
    s16 iTemp;
    u16 wTmp;
    f32 flTemp;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);

    if (blJ1772Enable)
    {
        flTemp = pxIfEoInfo->flEvseImax;
        flTemp *= 100.0F;
        flTemp += 0.5F;
        wEvseImax = (u16)flTemp;
    }
    else
    {
        wEvseImax = 32.0F * 100U;
    }

    flTemp = pxIfAiInfo->flHvdcCurr;            // HVDC input current
    flTemp *= 100.0F;
    flTemp += 0.5F;
    wInputCurr = (u16)flTemp;
    
    xMsg.id = (u32)TX_OBC_ICMD_MSG_ID;
    xMsg.data[0] = (u8)(wEvseImax >> 8U);
    xMsg.data[1] = (u8)wEvseImax;
    xMsg.data[2] = (u8)(wInputCurr >> 8U);
    xMsg.data[3] = (u8)wInputCurr;

    flTemp = pxIfAiInfo->flCoolTemp;             // COOLANT temperature
    flTemp *= 100.0F;
    flTemp += 0.5F;
    iTemp = (s16)flTemp;
    wTmp = (u16)iTemp;
    xMsg.data[4] = (u8)(wTmp >> 8);
    xMsg.data[5] = (u8)wTmp;

    xRet = CAN_Send(&DrvCan2_instance, 
                    (u8)CAN2_TX_OBC_CTRL_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan2TxFailCnt++;
    }
    else
    {
        dwCan2TxPassCnt++;
    }
}


/**
 * \brief   route OBC's version message from CAN2 to CAN0
 */
static void sCanRouteObcVersionMsg(void)
{
    can_message_t xMsg;
    status_t xRet;
    u16 i;

    xMsg.length = 8U;
    xMsg.id = dwObcTxVersionMsgId;
    for(i=0; i<8U; i++)
    {
        xMsg.data[i] = baObcTxVersionMsgBuf[i];
    }

    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_OBC_STATE_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}


/**
 * \brief   route OBC's state message from CAN2 to CAN0
 */
static void sCanRouteObcStateMsg(void)
{
    can_message_t xMsg;
    status_t xRet;
    u16 i;
    u8 bIdx;

    xMsg.length = 8U;
    bIdx = bRxIdxOut;
    xMsg.id = xaCan2RxObcStateBuf[bIdx].id;
    for(i=0; i<8U; i++)
    {
        xMsg.data[i] = xaCan2RxObcStateBuf[bIdx].data[i];
    }
    bRxIdxOut++;
    bRxIdxOut %= CAN2_RX_BUF_MAX;

    if (blIsCan2RxRingBufFull == true)
    {
        bRxIdxIn = bIdx;
        blIsCan2RxRingBufFull = false;

        xRet = CAN_Receive( &DrvCan2_instance,  // reopen RxFIFO ring buffer
                            (u32)CAN2_RX_OBC_STATE_MAILBOX, 
                            &xaCan2RxObcStateBuf[bRxIdxIn]);

        if (xRet != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("reopen ring buf err 0x%08X\n", xRet);
            #endif
        }
    }


    xRet = CAN_SendBlocking(&DrvCan0_instance, 
                            (u32)CAN0_TX_OBC_STATE_MAILBOX, 
                            &xMsg, 
                            1U);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }

    if (xMsg.id == (u32)RX_DSP_STATE_MSG_ID)    // OBC DSP_STATE message
    {
        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_PFC_DATA_MSG_ID)
    {
        u16 wVal;
        f32 flVal;

        wVal = xMsg.data[0];
        wVal <<= 8U;
        wVal |= xMsg.data[1];
        flVal = (f32)wVal;
        flVal *= 0.1F;
        xIfCi2Data.flObcBulkVolt = flVal;

        flVal = (f32)xMsg.data[2];
        flVal *= 0.1F;
        xIfCi2Data.flObcPfcCurrA = flVal;

        flVal = (f32)xMsg.data[3];
        flVal *= 0.1F;
        xIfCi2Data.flObcPfcCurrB = flVal;

        flVal = (f32)xMsg.data[4];
        flVal *= 0.1F;
        xIfCi2Data.flObcPfcCurrC = flVal;

        flVal = (f32)xMsg.data[5];
        flVal *= 0.1F;
        xIfCi2Data.flObcPfcCurrD = flVal;

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_GRID_DATA_MSG_ID)
    {
        u16 wVal;
        s16 sVal;
        f32 flVal;

        wVal = xMsg.data[0];
        wVal <<= 8U;
        wVal |= xMsg.data[1];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcGridCurr = flVal;

        wVal = xMsg.data[2];
        wVal <<= 8U;
        wVal |= xMsg.data[3];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcGridFreq = flVal;
        
        wVal = xMsg.data[4];
        wVal <<= 8U;
        wVal |= xMsg.data[5];
        sVal = (s16)wVal;
        flVal = (f32)sVal;
        flVal *= 0.1F;
        xIfCi2Data.flObcGridVolt = flVal;

        flVal = (f32)xMsg.data[6];
        flVal *= 0.1F;
        xIfCi2Data.flObcPfcAuxVolt = flVal;

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_HVDC_CTRL_MSG_ID)
    {
        u16 wVal;
        f32 flVal;

        wVal = xMsg.data[0];
        wVal <<= 8U;
        wVal |= xMsg.data[1];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcCtrlFreq = flVal;

        wVal = xMsg.data[2];
        wVal <<= 8U;
        wVal |= xMsg.data[3];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcCtrlTheta = flVal;
        
        wVal = xMsg.data[4];
        wVal <<= 8U;
        wVal |= xMsg.data[5];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcHvCurrRef = flVal;

        wVal = xMsg.data[6];
        wVal <<= 8U;
        wVal |= xMsg.data[7];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcHvVoltRef = flVal;

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_HVDC_DATA_MSG_ID)
    {
        u16 wVal;
        f32 flVal;

        wVal = xMsg.data[0];
        wVal <<= 8U;
        wVal |= xMsg.data[1];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcHvdcCurr = flVal;

        wVal = xMsg.data[2];
        wVal <<= 8U;
        wVal |= xMsg.data[3];
        flVal = (f32)wVal;
        flVal *= 0.01F;
        xIfCi2Data.flObcHvdcVolt = flVal;

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_OBC_FAULT_MSG_ID)
    {
        u64 qwVal;

        qwVal = xMsg.data[0];
        qwVal |= (u64)xMsg.data[1] << 8U;
        qwVal |= (u64)xMsg.data[2] << 16U;
        qwVal |= (u64)xMsg.data[3] << 24U;
        qwVal |= (u64)xMsg.data[4] << 32U;
        qwVal |= (u64)xMsg.data[5] << 40U;
        qwVal |= (u64)xMsg.data[6] << 48U;
        xIfCi2Data.qwObcErrorFlag = qwVal;

        switch (xMsg.data[7])
        {
            case 0:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_START;
                break;
            case 1U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_IDLE;
                break;
            case 2U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_STANDBY;
                break;
            case 3U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_RUN;
                break;
            case 4U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_OFF;
                break;
            case 5U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_FAIL;
                break;
            case 6U:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_LATCH;
                break;
            default:
                xIfCi2Data.eObcWorkMode = OBC_WORK_MODE_UNKNOW;
                break;
        }

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else if (xMsg.id == (u32)RX_OBC_TEMP_MSG_ID)
    {
        u16 wVal;
        s16 sVal;
        f32 flVal;

        wVal = xMsg.data[2];
        wVal <<= 8U;
        wVal |= xMsg.data[3];
        sVal = (s16)wVal;
        flVal = (f32)sVal;
        flVal *= 0.1F;
        xIfCi2Data.flObcTempLlc = flVal;

        wVal = xMsg.data[4];
        wVal <<= 8U;
        wVal |= xMsg.data[5];
        sVal = (s16)wVal;
        flVal = (f32)sVal;
        flVal *= 0.1F;
        xIfCi2Data.flObcTempPfc = flVal;

        xIfCi2Data.eRxTimeout = BOOL_FALSE;

        (void)sbIfSet(IF_CI2, &xIfCi2Data);     // update CI2 interface data
    }
    else
    {
        ;
    }

}

/**
 * \brief   read and route OBC command message from CAN0 to CAN2
 */
static void sCanProcessObcCmdMsg(void)
{
    can_message_t xMsg;
    status_t xRet;
    u16 i;

    xMsg.length = 8U;
    xMsg.id = dwObcCtrlMsgId;
    for(i=0; i<8U; i++)
    {
        xMsg.data[i] = baObcCtrlMsgBuf[i];
    }

    if (dwObcCtrlMsgId == TX_OBC_CTRL_MSG_ID)
    {
        switch (xMsg.data[0])
        {
            case 0:
                xIfCi0Data.eObcModeCmd = OBC_MODE_CMD_STANDBY;
                sEvseObcEnableSet(false);
                break;
            case 1U:
                xIfCi0Data.eObcModeCmd = OBC_MODE_CMD_RUN;
                sEvseObcEnableSet(true);
                break;
            case 2U:
                xIfCi0Data.eObcModeCmd = OBC_MODE_CMD_OFF;
                sEvseObcEnableSet(false);
                break;
            case 3U:
                xIfCi0Data.eObcModeCmd = OBC_MODE_CMD_START;
                sEvseObcEnableSet(true);
                break;
            default:
                xIfCi0Data.eObcModeCmd = OBC_MODE_CMD_UNKNOW;
                sEvseObcEnableSet(false);
                break;
        }

        (void)sbIfSet(IF_CI0, &xIfCi0Data);
    }

    xRet = CAN_Send(&DrvCan2_instance, 
                    (u8)CAN2_TX_OBC_CTRL_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan2TxFailCnt++;
    }
    else
    {
        dwCan2TxPassCnt++;
    }
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief: initial IF_CI0 and IF_CI2 interfaces' data pointer
 */
void sCanIfInit(void)
{
    (void)sbIfSet(IF_CI0, &xIfCi0Data);         // initial IF_CI0 data pointer
    (void)sbIfSet(IF_CI2, &xIfCi2Data);         // initial IF_CI2 data pointer
}


/**
 * @brief: initial CAN peripheral
 */
void sCan0Init(void)
{
	u16 wStatus = 0U;
    x_conf_data_t *pxConf;

	wStatus = (u16)CAN_Init(&DrvCan0_instance, &DrvCan0_Config0);
    wStatus |= (u16)sCAN0IRQInitial();

    if(wStatus != (u16)STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_CAN, wStatus));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }

    sNvmConfDataPtrGet(&pxConf);
    blJ1772Enable = !(pxConf->baDisa[CONF_DISA_J1772] == (u8)'T');

    /* Configure RX buffer with index CAN0_RX_APM_CMD_MAILBOX */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_RX_APM_CMD_MAILBOX, 
                                        &xbuffCfg,
                                        (u32)RX_HCU_APM_CTRL_MSG_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_APM_CMD_MAILBOX,
								        0xFFFFFFFFU);   /* match all bits */

    /* Configure RX buffer with index CAN0_RX_SYSTIME_MAILBOX */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_RX_SYSTIME_MAILBOX, 
                                        &xbuffCfg,
                                        (u32)RX_VCU_TIME_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_SYSTIME_MAILBOX,
								        0xFFFFFFFFU);   /* match all bits */

    /* Configure RX buffer with index CAN0_RX_ISOTP_PHY_MAILBOX for ISO_TP physical address message */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_RX_ISOTP_PHY_MAILBOX, 
                                        &xbuffCfg,
                                        (u32)RX_UDS_PHY_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_ISOTP_PHY_MAILBOX,
								        0xFFFFFFFFU);   /* match all bits */

    /* Configure RX buffer with index CAN0_RX_ISOTP_FUN_MAILBOX for ISO_TP functional address message */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance, 
                                        (u32)CAN0_RX_ISOTP_FUN_MAILBOX, 
                                        &xbuffCfg,
                                        (u32)RX_UDS_FUN_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_ISOTP_FUN_MAILBOX,
								        0xFFFFFFFFU);   /* match all bits */

    /* Configure RX buffer with index CAN0_RX_OBC_CMD_MAILBOX for CAN2 output message */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_RX_OBC_CMD_MAILBOX,
                                        &xbuffCfg,
                                        (u32)RX_OBC_CTRL_MSG_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_OBC_CMD_MAILBOX,
								        0xFFFFFFE0U);   /* filter 0x10X~0x11X*/

    /* Configure RX buffer with index CAN0_RX_NM_MAILBOX for NM message */
    wStatus |= (u16)CAN_ConfigRxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_RX_NM_MAILBOX,
                                        &xbuffCfg,
                                        (u32)TX_NM_NMPDU_MSG_ID);

    wStatus |= (u16)CAN_SetRxFilter(    &DrvCan0_instance,
    							        CAN_MSG_ID_STD,
								        (u32)CAN0_RX_NM_MAILBOX,
								        0xFFFFFF00U);   /* filter ID 0x5?? */

    /* Configure TX buffer with index TX_MAILBOX */
    wStatus |= (u16)CAN_ConfigTxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_TX_APM_STATUS_MAILBOX,
                                        &xbuffCfg);

    /* Configure TX buffer with index CAN0_TX_ISOTP_MAILBOX for TP message */
    wStatus |= (u16)CAN_ConfigTxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_TX_ISOTP_MAILBOX,
                                        &xbuffCfg);

    /* Configure TX buffer with index CAN0_TX_OBC_STATE_MAILBOX for CAN2 input message */
    wStatus |= (u16)CAN_ConfigTxBuff(   &DrvCan0_instance,
                                        (u32)CAN0_TX_OBC_STATE_MAILBOX,
                                        &xbuffCfg);

    

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_APM_CMD_MAILBOX, 
                                &xCan0RxApmCmdBuf);

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_SYSTIME_MAILBOX, 
                                &xCan0RxSysTimeBuf);

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_OBC_CMD_MAILBOX, 
                                &xCan0RxObcCmdBuf);

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_ISOTP_PHY_MAILBOX, 
                                &xTpRecvMsg);

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_ISOTP_FUN_MAILBOX, 
                                &xTpRecvMsg);

    wStatus |= (u16)CAN_Receive(&DrvCan0_instance, 
                                (u32)CAN0_RX_NM_MAILBOX, 
                                &xCan0RxNmMsgBuf);

    if(wStatus != (u16)STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_CAN, wStatus));
        #else
        ;
        #endif
    }
}

#if 0                                           // unused code
/**
 * \brief   return the APM mode request command from CAN0
 * \return  xApmModeCmd, enum of \apm_mode_cmd_t
 */
apm_mode_cmd_t sxCanApmModeCmdGet(void)
{
    return xApmModeCmd;
}

/**
 * \brief   return the APM output voltage command from CAN0
 * \return  flApmVcmd
 */
f32 sflCanApmVcmdGet(void)
{
    return flApmVcmd;
}

/**
 * \brief   return the APM output current limit command from CAN0
 * \return  flApmIcmd
 */
f32 sflCanApmIcmdGet(void)
{
    return flApmIcmd;
}

/**
 * \brief   is timeout to receive the incoming message 'APM_CTRL_MSG'
 * \return  blCan0RxTimeout
 */
bool sblIsCan0Loss(void)
{
    return blCan0RxTimeout;
}
#endif

/**
 * @brief: CAN communication task, cycle time is 10ms
 */
void sCan0Task(void)
{
    static u16 w10msTickTo10 = 0;
    static u16 wVerApplTick = 0;
    static u16 wVerBootTick = 0;
    static u16 wApmCmdLossCnt = 0;
    static u16 wObcCmdLossCnt = 0;
    static u16 wSysTimeLossCnt = 0;
    //static u16 wNmTick = 0;
    static u8 bNMCounter = 0;
	static u32 dwTimeoutTriger = 0;
	static u16 wReturnStatus = 0;

    bool blApplMsgEnable = sblNmApplFrameEnableGet();
    bool blNmMsgEnable = sblNmFrameEnableGet();
    bool blNmImmediateTransmitEnable = sblNmImmediateTransmitEnableGet();
    u8 bNmTransmit = sbNmTransmitGet();

    #if (HAVE_DEBUG_GPIO != 0)
	PINS_DRV_TogglePins(TEST_PIN3_PORT, (1UL << TEST_PIN3_INDEX));
    #endif

    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_AI, false, (const void **)&pxIfAiInfo);
    (void)sbIfGet(IF_HO, false, (const void **)&pxIfHoInfo);
    (void)sbIfGet(IF_EI, false, (const void **)&pxIfEi);
    (void)sbIfGet(IF_EO, false, (const void **)&pxIfEoInfo);
    (void)sbIfGet(IF_OO, false, (const void **)&pxIfObcInfo);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */

    if(blNmMsgEnable)
    {
        if(bNMCounter >= bNmTransmit)
        {
            bNMCounter = 0;

            if(CAN_GetTransferStatus(&DrvCan0_instance, CAN0_TX_APM_STATUS_MAILBOX) 
                == STATUS_SUCCESS)
            {
                sCanTxNmMsg();
            }

            dwTimeoutTriger = 5U + sdwTimerTickGet();
            wReturnStatus = CAN_GetTransferStatus(  &DrvCan0_instance, 
                                                    CAN0_TX_APM_STATUS_MAILBOX);
            while(wReturnStatus == STATUS_BUSY)
            {
                wReturnStatus = CAN_GetTransferStatus(  &DrvCan0_instance, 
                                                    CAN0_TX_APM_STATUS_MAILBOX);
                if(sdwTimerTickGet() >= dwTimeoutTriger)
                {
                    break;
                }
            }

            if(wReturnStatus == STATUS_SUCCESS)
            {
                if(blApplMsgEnable == false)
                {
                    sTimerStart(TIMER_ID_APPL_FRAME_DELAY);
                }
                
                if(blNmImmediateTransmitEnable == true)
                {
                    sNmImmediateFrameCount();
                }

                sTimerRemainSet(TIMER_ID_NM_TIMEOUT, NM_TIMEOUT_TIME);
            }
        }
        bNMCounter++;
    }

    if (blApplMsgEnable)
    {
    	switch(w10msTickTo10)
    	{
    		case 0:
                sCanTxApmState00();
                break;

    		case 1U:
                if (blJ1772Enable)
                {
                    sCanTxApmState01();
                }
                break;

    		case 2U:
                sCanTxApmState02();
                break;

    		case 3U:
                sCanTxApmState03();
                break;

            case 4U:
                sCanTxApmState04();
                break;

            case 5U:
                sCanTxApmState05();
                break;

            case 6U:
                sCanTxApmState06();
                break;

    		case 7U:
                if (wVerApplTick == 0)
                {
    			    sCanTxApmVerAppl();
                }
                wVerApplTick++;
                wVerApplTick %= 10U;
    			break;

            case 8U:
                if (wVerBootTick == 0)
                {
                    sCanTxApmVerBoot();
                }
                wVerBootTick++;
                wVerBootTick %= 10U;
                break;

            case 9U:
                ;
                break;

            default:
                #if (HAVE_DEBUG_UART != 0)
                DebugPrintf("sCan0Task deadcode\n");
                #else
                ;
                #endif
    			break;
    	}

        w10msTickTo10++;
        w10msTickTo10 %= 10U;
    }

    if(blCan0RxApmCtrlMsg == true)	            // Received APM Control CMD
    {
        blCan0RxApmCtrlMsg = false;
    	
    	sCanRxApmCtrlMsg();

        wApmCmdLossCnt = 0;
    }
    else
    {
    	if ((xIfCi0Data.eRxApmCmdTimeout == BOOL_FALSE)
            && (wApmCmdLossCnt >= 50U))         // CAN0 50ms rx timeout 
    	{
    		xIfCi0Data.eRxApmCmdTimeout = BOOL_TRUE;

            (void)sbIfSet(IF_CI0, &xIfCi0Data);
    	}
        else
        {
            wApmCmdLossCnt++;
        }
    }

    if(blCan0RxSysTimeMsg == true)	            // Received APM Control CMD
    {
        blCan0RxSysTimeMsg = false;
    	
    	sCanRxSysTimeMsg();

        wSysTimeLossCnt = 0;
    }
    else
    {
        if ((xIfCi0Data.eRxSysTimeTimeout == BOOL_FALSE)
            && (wSysTimeLossCnt >= 1000U))       // CAN0 1000ms rx timeout 
    	{
    		xIfCi0Data.eRxSysTimeTimeout = BOOL_TRUE;

            (void)sbIfSet(IF_CI0, &xIfCi0Data);
    	}
        else
        {
            wSysTimeLossCnt++;
        }
    }
	
    if (blCan0RxObcCtrlMsg == true)	            // Received OBC Control CMD
    {
        blCan0RxObcCtrlMsg = false;

        if (xIfCi0Data.eRxObcCmdTimeout == BOOL_TRUE)
        {
            xIfCi0Data.eRxObcCmdTimeout = BOOL_FALSE;

            (void)sbIfSet(IF_CI0, &xIfCi0Data);
        }

        sCanProcessObcCmdMsg();                 // route CAN0 --> CAN2

        wObcCmdLossCnt = 0;
    }
    else
    {
        if ((xIfCi0Data.eRxObcCmdTimeout == BOOL_FALSE)
            && (wObcCmdLossCnt >= 50U))         // CAN0 50ms rx timeout 
    	{
    		xIfCi0Data.eRxObcCmdTimeout = BOOL_TRUE;

            (void)sbIfSet(IF_CI0, &xIfCi0Data);
    	}
        else
        {
            wObcCmdLossCnt++;
        }
    }

    if (blCan0RxNmMsg == true)                  // receive NM message
    {
        blCan0RxNmMsg = false;

        sNmRxEventSet();

        if((baNmMsgBuf[1] & REPEAT_MESSAGE_REQUEST_BIT) != 0)
    	{
    		sNmRepeatMessageReqSet();
    	}
    }
}

/**
 * @brief: pop a CAN frame from TP TX FIFO, and send the frame to CAN bus
 */
void sIsoTpSendMsg(void)
{
    u8 bRet;
	uint8 aucMsgBuf[8u];
	uint32 dwMsgId = 0;
	uint32 msgLength = 0u;
	
	/*get message from TP_TX_FIFO*/
	if(true == TP_DriverReadDataFromTP(8u,&aucMsgBuf[0u],&dwMsgId, &msgLength))
	{	
		bRet = sCanTpTxMsg( dwMsgId, 
                            (u8)msgLength, 
                            aucMsgBuf, 
                            &TP_DoTxMsgSuccesfulCallback, 
                            0u);
        if(bRet == true)
        {
            dwTpTxCanPass++;
        }
        else
        {
            dwTpTxCanFail++;
        }
	}

    #if 0                                       // unused code
    u32 dwRxId = 0UL;
    u32 dwRxLen = 0UL;
    u8 pbCanIsoTpRxBuf[128] = {0};
    /*read data from can tp*/
    if(TRUE == TP_ReadAFrameDataFromTP(&dwRxId, &dwRxLen, pbCanIsoTpRxBuf))
    {
        if((dwRxId == TP_GetConfigRxMsgPHYID())
            || (dwRxId == TP_GetConfigRxMsgFUNID()))
        {
            TPDebugPrintf("iso-tp rx from 0x%X\n", dwRxId);
            TPDebugPrintf("rx len: %d\n", dwRxLen);
        }
        else
        {
            TPDebugPrintf("iso-tp rx wrong id 0x%X\n", dwRxId);
        }
    }
    #endif
}

/**
 * @brief       init Can2 with 500kbps
 */
void sCan2Init(void)
{
    status_t xStatus;

    xStatus = CAN_Init(&DrvCan2_instance, &DrvCan2_Config500k);
    
    if(xStatus == STATUS_SUCCESS)
    {
        xStatus = sCAN2IRQInitial();
    }
    else
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("CAN_Init err 0x%X\n", xStatus);
        #endif
    }

    if(xStatus == STATUS_SUCCESS)
    {
        /* Configure TX buffer with index CAN2_TX_OBC_CTRL_MAILBOX */
        xStatus = CAN_ConfigTxBuff( &DrvCan2_instance,
                                    (u32)CAN2_TX_OBC_CTRL_MAILBOX,
                                    &xbuffCfg);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_ConfigTxBuff err 0x%X\n", xStatus);
            #endif
        }

        /* Configure TX buffer with index CAN2_TX_DSP_ISOTP_MAILBOX */
        xStatus = CAN_ConfigTxBuff( &DrvCan2_instance,
                                    (u32)CAN2_TX_DSP_ISOTP_MAILBOX,
                                    &xbuffCfg);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_ConfigTxBuff err 0x%X\n", xStatus);
            #endif
        }

        /* Configure RX buffer with index CAN2_RX_OBC_STATE_MAILBOX */
        xStatus = CAN_ConfigRxBuff( &DrvCan2_instance,
                                    (u32)CAN2_RX_OBC_STATE_MAILBOX, 
                                    &xbuffCfg,
                                    (u32)RX_DSP_STATE_MSG_ID);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_ConfigRxBuff err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_SetRxFilter(  &DrvCan2_instance,
        							CAN_MSG_ID_STD,
									(u32)CAN2_RX_OBC_STATE_MAILBOX,
									0xFFFFFFC0U);   /* filter 0x11?, 0x12? */

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_SetRxFilter err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_Receive(  &DrvCan2_instance, 
                                (u32)CAN2_RX_OBC_STATE_MAILBOX, 
                                &xaCan2RxObcStateBuf[0]);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN_Receive err 0x%X\n", xStatus);
            #endif
        }

        /* Configure RX buffer with index CAN2_RX_OBC_VERSION_MAILBOX */
        xStatus = CAN_ConfigRxBuff( &DrvCan2_instance,
                                    (u32)CAN2_RX_OBC_VERSION_MAILBOX, 
                                    &xbuffCfg,
                                    (u32)RX_DSP_APPL_VER_MSG_ID);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_ConfigRxBuff err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_SetRxFilter(  &DrvCan2_instance,
        							CAN_MSG_ID_STD,
									(u32)CAN2_RX_OBC_VERSION_MAILBOX,
									0xFFFFFFFCU);   /* filter 0x602, 0x603 */

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_SetRxFilter err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_Receive(  &DrvCan2_instance, 
                                (u32)CAN2_RX_OBC_VERSION_MAILBOX, 
                                &xCan2RxObcVersionBuf);


        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_Receive err 0x%X\n", xStatus);
            #endif
        }

        /* Configure RX buffer with index CAN2_RX_DSP_ISOTP_MAILBOX */
        xStatus = CAN_ConfigRxBuff( &DrvCan2_instance,
                                    (u32)CAN2_RX_DSP_ISOTP_MAILBOX, 
                                    &xbuffCfg,
                                    (u32)RX_DSP_ISOTP_MSG_ID);

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_ConfigRxBuff err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_SetRxFilter(  &DrvCan2_instance,
        							CAN_MSG_ID_STD,
									(u32)CAN2_RX_DSP_ISOTP_MAILBOX,
									0xFFFFFFFFU);   /* match all bits */

        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_SetRxFilter err 0x%X\n", xStatus);
            #endif
        }

        xStatus = CAN_Receive(  &DrvCan2_instance, 
                                (u32)CAN2_RX_DSP_ISOTP_MAILBOX, 
                                &xCan2RxIsoTpBuf);


        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("CAN2_Receive err 0x%X\n", xStatus);
            #endif
        }

    }
    else
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sCAN2IRQInitial err 0x%X\n", xStatus);
        #endif
    }
}

/**
 * \brief   CAN_2 ISO_TP task
 */
void sCan2IsoTp(void)
{
}

/**
 * \brief   CAN_2 communication task, cycle time is 1ms
 */
void sCan2Task(void)
{
    static u16 w1msTickTo1000 = 0;
    static u16 wCan2EmptyCycle = 0;
    bool blIsTimeToSendIcmd;

    blIsTimeToSendIcmd = ((w1msTickTo1000 % 50U) == 0);

    if(blIsTimeToSendIcmd == true)
    {
        sCanTxObcIcmd();
    }

    if (bRxIdxIn != bRxIdxOut)                  // ring buffer is not empty
    {
        sCanRouteObcStateMsg();                 // route CAN2 --> CAN0

        wCan2EmptyCycle = 0;
    }
    else
    {
        wCan2EmptyCycle++;

        if ((wCan2EmptyCycle >= 100U) && (xIfCi2Data.eRxTimeout == BOOL_FALSE))
        {
            wCan2EmptyCycle = 100U;

            xIfCi2Data.eRxTimeout = BOOL_TRUE;

            (void)sbIfSet(IF_CI2, &xIfCi2Data); // update CI2 interface data
        }
    }

    if (blCan2RxObcVersionMsg == true)
    {
        blCan2RxObcVersionMsg = false;

        sCanRouteObcVersionMsg();               // route CAN2 --> CAN0
    }

    if (blCan2RxIsoTpMsg == true)
    {
        blCan2RxIsoTpMsg = false;

        // TODO:               // process DSP's response msg
    }

    w1msTickTo1000++;
    w1msTickTo1000 %= 1000U;
}

#if (HVAE_DEGBU_NM != 0)
/**
 * \brief: transmit NM debug message via CAN0
 */
void sCanTxNmDebug(u8 bDbg0, u8 bDbg1, u8 bDbg2, u8 bDbg3)
{
    can_message_t xMsg;
    status_t xRet;

    xMsg.length = 8U;
    memset(xMsg.data, 0, xMsg.length);
    
    xMsg.id = (u32)TX_NM_NMPDU_MSG_ID | 0xF0U;
	xMsg.data[0] = bDbg0;
	xMsg.data[1] = bDbg1;
    xMsg.data[2] = bDbg2;
    xMsg.data[3] = bDbg3;
    
    xRet = CAN_Send(&DrvCan0_instance, 
                    (u8)CAN0_TX_APM_STATUS_MAILBOX, 
                    &xMsg);
    if(xRet != STATUS_SUCCESS)
    {
        dwCan0TxFailCnt++;
    }
    else
    {
        dwCan0TxPassCnt++;
    }
}
#endif

