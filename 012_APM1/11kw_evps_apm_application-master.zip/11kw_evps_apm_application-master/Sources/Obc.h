/**
 * @file        Obc.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_OBC_H
#define         DEF_OBC_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------







//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum OBC_FLAG_E                         /* bit position in OBC_FAULT_INFO message */
{
    BIT_PFC_C_OC        = 0,
    BIT_PFC_B_OC        = 1,
    BIT_PFC_A_OC        = 2,
    BIT_GRID_RMS_UV     = 3,
    BIT_GRID_RMS_OV     = 4,
    BIT_GRID_OV_SW      = 5,
    BIT_GRID_UF         = 6,
    BIT_GRID_OF         = 7,
    BIT_HV_SC_HW        = 8,
    BIT_HV_OC_SW        = 9,
    BIT_PFC_AUX_UV      = 10,
    BIT_PFC_AUX_OV      = 11,
    BIT_PFC_UV          = 12,
    BIT_PFC_OV_SW       = 13,
    BIT_PFC_OV_HW       = 14,
    BIT_PFC_D_OC        = 15,
    BIT_CALI_NG         = 16,
    BIT_SELF_TEST_ERR   = 17,
    BIT_OT_3            = 18,
    BIT_OT_LLC          = 19,
    BIT_OT_PFC          = 20,
    BIT_HVDC_UV         = 21,
    BIT_HV_OV_SW        = 22,
    BIT_HV_OV_HW        = 23,
    BIT_DIAG_HV_SC      = 24,
    BIT_DIAG_HV_OC      = 25,
    BIT_DIAG_HV_OV      = 26,
    BIT_HV_OC_HW        = 27,
    BIT_CAN_LOSS        = 28,
    BIT_CONF_NONE       = 29,
    BIT_CONF_NG         = 30,
    BIT_CALI_NONE       = 31,
    BIT_CMPSS_OT_LLC    = 32,
    BIT_CMPSS_OT_PFC    = 33,
    BIT_CMPSS_AUX_OV    = 34,
    BIT_CMPSS_PFC_C_OC  = 35,
    BIT_CMPSS_PFC_B_OC  = 36,
    BIT_CMPSS_HV_OV     = 37,
    BIT_CMPSS_HV_OC     = 38,
    BIT_DIAG_PFC_OV     = 39,
    BIT_CMPSS_PFC_OV    = 45,
    BIT_CMPSS_PFC_D_OC  = 46,
    BIT_CMPSS_PFC_A_OC  = 47,
}obc_flag_t;


typedef enum OBC_STATE_E
{
    OBC_SLEEP = 0,
    OBC_POWER_ON,
    OBC_BOOTROM_START,
    OBC_BOOTROM_RUN,
    OBC_BOOTROM_END,
    OBC_APPL_START,
    OBC_APPL_RUN,
    OBC_APPL_END,
    OBC_POWER_OFF,
    #if 0
    OBC_TP_START,
    OBC_TP_DATA,
    OBC_TP_END,
    #endif
    OBC_STATE_UNKONW,
}obc_state_t;

typedef struct PACKED IF_OO_DATA_S
{
    obc_state_t         eObcState;
    u64                 qwObcErrorFlag;
    e_bool_t            eObcAuxEnDoh;
    e_bool_t            eDspResetDol;
    e_bool_t            eObcAuxUvCheck;
    e_bool_t            eDspBootModeDol;
    e_bool_t            eDspOkCheck;
}x_if_oo_t;


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

#define         MASK_PFC_C_OC               (1ULL << (u8)BIT_PFC_C_OC)
#define         MASK_PFC_B_OC               (1ULL << (u8)BIT_PFC_B_OC)
#define         MASK_PFC_A_OC               (1ULL << (u8)BIT_PFC_A_OC)
#define         MASK_GRID_RMS_UV            (1ULL << (u8)BIT_GRID_RMS_UV)
#define         MASK_GRID_RMS_OV            (1ULL << (u8)BIT_GRID_RMS_OV)
#define         MASK_GRID_OV_SW             (1ULL << (u8)BIT_GRID_OV_SW)
#define         MASK_GRID_UF                (1ULL << (u8)BIT_GRID_UF)
#define         MASK_GRID_OF                (1ULL << (u8)BIT_GRID_OF)
#define         MASK_HV_SC_HW               (1ULL << (u8)BIT_HV_SC_HW)
#define         MASK_HV_OC_SW               (1ULL << (u8)BIT_HV_OC_SW)
#define         MASK_PFC_AUX_UV             (1ULL << (u8)BIT_PFC_AUX_UV)
#define         MASK_PFC_AUX_OV             (1ULL << (u8)BIT_PFC_AUX_OV)
#define         MASK_PFC_UV                 (1ULL << (u8)BIT_PFC_UV)
#define         MASK_PFC_OV_SW              (1ULL << (u8)BIT_PFC_OV_SW)
#define         MASK_PFC_OV_HW              (1ULL << (u8)BIT_PFC_OV_HW)
#define         MASK_PFC_D_OC               (1ULL << (u8)BIT_PFC_D_OC)
#define         MASK_CALI_NG                (1ULL << (u8)BIT_CALI_NG)
#define         MASK_SELF_TEST_ERR          (1ULL << (u8)BIT_SELF_TEST_ERR)
#define         MASK_OT_3                   (1ULL << (u8)BIT_OT_3)
#define         MASK_OT_LLC                 (1ULL << (u8)BIT_OT_LLC)
#define         MASK_OT_PFC                 (1ULL << (u8)BIT_OT_PFC)
#define         MASK_HVDC_UV                (1ULL << (u8)BIT_HVDC_UV)
#define         MASK_HV_OV_SW               (1ULL << (u8)BIT_HV_OV_SW)
#define         MASK_HV_OV_HW               (1ULL << (u8)BIT_HV_OV_HW)
#define         MASK_DIAG_HV_SC             (1ULL << (u8)BIT_DIAG_HV_SC)
#define         MASK_DIAG_HV_OC             (1ULL << (u8)BIT_DIAG_HV_OC)
#define         MASK_DIAG_HV_OV             (1ULL << (u8)BIT_DIAG_HV_OV)
#define         MASK_HV_OC_HW               (1ULL << (u8)BIT_HV_OC_HW)
#define         MASK_CAN_LOSS               (1ULL << (u8)BIT_CAN_LOSS)
#define         MASK_CONF_NONE              (1ULL << (u8)BIT_CONF_NONE)
#define         MASK_CONF_NG                (1ULL << (u8)BIT_CONF_NG)
#define         MASK_CALI_NONE              (1ULL << (u8)BIT_CALI_NONE)
#define         MASK_CMPSS_OT_LLC           (1ULL << (u8)BIT_CMPSS_OT_LLC)
#define         MASK_CMPSS_OT_PFC           (1ULL << (u8)BIT_CMPSS_OT_PFC)
#define         MASK_CMPSS_AUX_OV           (1ULL << (u8)BIT_CMPSS_AUX_OV)
#define         MASK_CMPSS_PFC_C_OC         (1ULL << (u8)BIT_CMPSS_PFC_C_OC)
#define         MASK_CMPSS_PFC_B_OC         (1ULL << (u8)BIT_CMPSS_PFC_B_OC)
#define         MASK_CMPSS_HV_OV            (1ULL << (u8)BIT_CMPSS_HV_OV)
#define         MASK_CMPSS_HV_OC            (1ULL << (u8)BIT_CMPSS_HV_OC)
#define         MASK_DIAG_PFC_OV            (1ULL << (u8)BIT_DIAG_PFC_OV)
#define         MASK_CMPSS_PFC_OV           (1ULL << (u8)BIT_CMPSS_PFC_OV)
#define         MASK_CMPSS_PFC_D_OC         (1ULL << (u8)BIT_CMPSS_PFC_D_OC)
#define         MASK_CMPSS_PFC_A_OC         (1ULL << (u8)BIT_CMPSS_PFC_A_OC)


#define         MASK_DTC_OBC_HVDC           ( MASK_HV_SC_HW \
                                            | MASK_HV_OC_SW \
                                            | MASK_HV_OC_HW \
                                            | MASK_HVDC_UV \
                                            | MASK_HV_OV_SW \
                                            | MASK_HV_OV_HW \
                                            | MASK_CMPSS_HV_OV \
                                            | MASK_CMPSS_HV_OC )

#define         MASK_DTC_OBC_GRID           ( MASK_GRID_RMS_UV \
                                            | MASK_GRID_RMS_OV \
                                            | MASK_GRID_OV_SW \
                                            | MASK_GRID_UF \
                                            | MASK_GRID_OF )

#define         MASK_DTC_OBC_OTP            ( MASK_OT_LLC \
                                            | MASK_OT_PFC \
                                            | MASK_OT_3 \
                                            | MASK_CMPSS_OT_LLC \
                                            | MASK_CMPSS_OT_PFC )

#define         MASK_DTC_OBC_PFC            ( MASK_PFC_A_OC \
                                            | MASK_PFC_B_OC \
                                            | MASK_PFC_C_OC \
                                            | MASK_PFC_D_OC \
                                            | MASK_CMPSS_PFC_A_OC \
                                            | MASK_CMPSS_PFC_B_OC \
                                            | MASK_CMPSS_PFC_C_OC \
                                            | MASK_CMPSS_PFC_D_OC )

#define         MASK_DTC_OBC_AUX            ( MASK_PFC_AUX_UV \
                                            | MASK_PFC_AUX_OV \
                                            | MASK_CMPSS_AUX_OV )

#define         MASK_DTC_OBC_BULK           ( MASK_PFC_UV \
                                            | MASK_CMPSS_PFC_OV \
                                            | MASK_PFC_OV_SW \
                                            | MASK_PFC_OV_HW )

#define         MASK_DTC_OBC_INIT           ( MASK_DIAG_HV_SC \
                                            | MASK_DIAG_HV_OC \
                                            | MASK_DIAG_HV_OV \
                                            | MASK_DIAG_PFC_OV \
                                            | MASK_CALI_NG \
                                            | MASK_CONF_NG \
                                            | MASK_SELF_TEST_ERR )

#define         MASK_DTC_OBC_CAN            (MASK_CAN_LOSS)

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sObcIfInit(void);
extern void sObcInit(void);
extern void sObcStart(void);
extern void sObcStop(void);
extern void sObcTask(void);

#endif






