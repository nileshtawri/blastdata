#include "bootloader_main.h"
#include "TP.h"
#include "can_driver.h"
#include "flash.h"
#include "sbc.h"
#include "version.h"
#include "she.h"
#include "obc.h"

volatile int exit_code = 0;

#define MAX_WAIT_TIME_MS (5000u)
unsigned short g_usMaxDelayUdsMsgTime = MAX_WAIT_TIME_MS;
unsigned char g_ucIsRxUdsMsg = FALSE;
static uint16_t wSbcInitState = 0;

static void BSP_init(void)
{
	/*clock init*/
	CLOCK_SYS_Init( g_clockManConfigsArr,
                    CLOCK_MANAGER_CONFIG_CNT,
                    g_clockManCallbacksArr, 
                    CLOCK_MANAGER_CALLBACK_CNT);

	CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

	/*GPIO init*/
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);

    wSbcInitState = sSBCInitial();

	/*CAN init*/
	InitCAN();

	/*init flash*/
	InitFlash();

    /*init SHE*/
    sbSheInit();
}

void SendMsgMainFun(void)
{
	uint8 aucMsgBuf[8u];
	uint32 msgId = 0u;
	uint32 msgLength = 0u;
	
	/*get message from TP*/
	if(TRUE == TP_DriverReadDataFromTP(8u,&aucMsgBuf[0u],&msgId, &msgLength))
	{
		TransmiteCANMsg(msgId, msgLength, aucMsgBuf, &TP_DoTxMsgSuccesfulCallback, 0u);
	}
}

int main(void)
{
    /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
#ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
#endif
    /*** End of Processor Expert internal initialization.                    ***/
    BOOTLOADER_MAIN_Init(&BSP_init, NULL_PTR);

    g_usMaxDelayUdsMsgTime = MAX_WAIT_TIME_MS;

    APPDebugPrintf("> OBC_6K6_LV BOOT mode, SBC state %d\n", wSbcInitState);

    sObcBootRomInit();                          /* init C2K BOOTROM protocol data */

    for(;;)
    {
    	BOOTLOADER_MAIN_Demo();

		SendMsgMainFun();

        sObcBootRomTask();

    } /* loop forever */

    /* please make sure that you never leave main */
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/


