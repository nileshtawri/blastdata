/**
 * @file        Obc.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "user_config.h"
#include "obc.h"
#include "DrvSci.h"
#include "timer_hal.h"
#include "watchdog_hal.h"
#include "can_driver.h"

#if 0 //def EN_DEBUG_PRINT
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define C2K_BOOTLOADER_ADDR                     0x00008000UL    /* bootloader target address */
#define C2K_CODE_DATA_ADDR                      0x0000A000UL    /* code or data target address */
#define C2K_BOOTROM_CODE_HAED_LEN               28U             /* 28 bytes */
#define C2K_BOOTROM_DATA_HEAD_LEN               6U             /* 6 bytes */


#define DELAY_MS_OBC_AUX                        10U
#define DELAY_MS_OBC_RST                        (DELAY_MS_OBC_AUX + 10U)
#define DELAY_MS_DSP_OK                         (DELAY_MS_OBC_RST + 10U)
#define DELAY_MS_BOOTROM                        (DELAY_MS_OBC_RST + 20U)
#define TIMEOUT_MS_BOOTROM                      3000U

#define SCI_RX_BUF_LEN                          16U
//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

typedef struct PACKED C2K_BOOTROM_DATA_S        /* C2000 BOOTROM struct */
{
    uint16_t wKey;                              /* key value */
    uint16_t waReserved[8];                     /* not used */
    uint32_t dwEntryPoint;                      /* bootloader's entry point */
    uint16_t wCodeWords;                        /* code or data length in byte */
    uint32_t dwCodeAddr;                        /* target address */
    uint8_t *pCodeBuf;                          /* point data buffer */
}c2k_bootrom_data_t;

//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


static void sObcPowerOn(void);
static void sObcPowerOff(void);
//static void sObcBootRun(void);
//static void sObcApplRun(void);



//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static obc_state_t eLastState = OBC_STATE_UNKONW;
static obc_state_t eCurrState = OBC_SLEEP;

static bool blC2kBootromFinish = false;
static bool blAutoBaudLocked = false;

static c2k_bootrom_data_t xC2kBootData;
static bool blC2kBootromFinish;
static uint16_t wSectorCnt;
static bool blDownloadOk = false;
static bool blDependencyOk = false;

static uint8_t pSciRxBuf[SCI_RX_BUF_LEN];
static uint8_t bRxIndex = 0;
static bool blGotString = false;
static uint8_t bSciRxBuf;

static uint8_t bImageVerMajor = 0;
static uint8_t bImageVerMinor = 0;
static uint8_t bImageVerDebug = 0;

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/* SCI (UART0) Rx callback for continuous reception */
static void sSciRxCallback( void *driverState, 
                            uart_event_t event, 
                            void *userData)
{
    /* Unused parameters */
    (void)driverState;
    (void)userData;

    if (event == UART_EVENT_RX_FULL)
    {
        (void)LPUART_DRV_ReceiveData(INST_DRVSCI, &bSciRxBuf, 1U);

        if (bSciRxBuf == '\n')
        {
            blGotString = true;
            bRxIndex = 0;
        }
        else
        {
            pSciRxBuf[bRxIndex] = bSciRxBuf;
            bRxIndex++;
            bRxIndex %= SCI_RX_BUF_LEN;
        }
    
        (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, &bSciRxBuf, 1U);
    }
}

/* to initial SCI (UART0) interface, 
   change PTC3 (CP_READY_DOH) as UART TX pin, pin mux function 3,
   change PTC2 (OBC_OK_DIH) as UART RX pin, pin mux function 3, */
static void sSciInit(void)
{
    status_t xRet;

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_ALT4);
    
    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_ALT4);
    
    xRet = LPUART_DRV_Init( INST_DRVSCI, 
                            &DrvSci_State,
                            &DrvSci_InitConfig0);
    
    if (xRet != STATUS_SUCCESS)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("SCI INIT FAIL %X\n", xRet);
        #endif
    }
}

/* disable SCI (UART0) interface, 
   change PTC3 (CP_READY_DOH) as GPIO, DO,
   change PTC2 (OBC_OK_DIH) as GPIO, DI */
static void sSciDeinit(void)
{
    (void)LPUART_DRV_Deinit(INST_DRVSCI);

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   CP_READY_DOH_PORT, 
                                CP_READY_DOH_PIN, 
                                (uint8_t)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   OBC_OK_DIH_PORT, 
                                OBC_OK_DIH_PIN, 
                                (uint8_t)GPIO_INPUT_DIRECTION);
}


/**
 * @brief   initial the xC2kBootData, it will send to C28x's BOOTROM
 */
static void sBootRomDataInit(void)
{
    uint16_t i;

    xC2kBootData.wKey = 0x08AAU;
    for(i=0; i<8U; i++)
    {
        xC2kBootData.waReserved[i] = 0;
    }

    xC2kBootData.dwEntryPoint = 0;              /* bootloader's entry point */
    xC2kBootData.wCodeWords = 0;                /* code/data length in words */
    xC2kBootData.dwCodeAddr = 0;                /* target address */

    wSectorCnt = 0;
    blAutoBaudLocked = false;
}


/**
 * \brief   to power on OBC sub-module, and reset the PFC's MCU (DSP, F280049).
 *          
 */
static void sObcPowerOn(void)
{
    static uint32_t dwTickStart = 0;
    uint32_t dwTickCurr;

    if (eLastState != OBC_POWER_ON)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("obc aux pwr on\n");
        #endif

        dwTickStart = TIMER_HAL_Get1msTick();
                                                // enable C28x's power
        PINS_DRV_SetPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));

                                                // select C28x's BOOTROM mode
        PINS_DRV_ClearPins(DSP_BOOT_DOH_PORT, (1UL << DSP_BOOT_DOH_PIN)); 

        sSciInit();                             // init UART0 for C28x SCI

        sBootRomDataInit();                     // init C28x SCI BOORTORM protocol data

        eLastState = eCurrState;
    }
    else
    {
        dwTickCurr = TIMER_HAL_Get1msTick();

        if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_AUX)
        {

            if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_RST)
            {
                PINS_DRV_SetPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));

                if ((dwTickCurr - dwTickStart) >= DELAY_MS_BOOTROM)
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("obc enter bootrom\n");
                    #endif

                    eCurrState = OBC_SLEEP;
                }
            }
        }
    }
}


/**
 * \brief   to power off OBC sub-module, and stop OBC state machine
 *          
 */
static void sObcPowerOff(void)
{
    if (eLastState != OBC_POWER_OFF)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("obc aux pwr off\n");
        #endif

        sSciDeinit();

        PINS_DRV_ClearPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));

        PINS_DRV_ClearPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));

        eCurrState = OBC_SLEEP;
    }
    else
    {
        eLastState = OBC_POWER_OFF;
    }
}

static void sWordSwap(uint32 *pdwVal)
{
    uint32_t dwTmp;
    
    dwTmp = *pdwVal >> 16U;
    dwTmp |= *pdwVal << 16U;

    *pdwVal = dwTmp;
}

#if 0
static void sByteSwap(uint16 *pwVal)
{
    uint16_t wTmp;
    
    wTmp = *pwVal >> 8U;
    wTmp |= *pwVal << 8U;

    *pwVal = wTmp;
}
#endif

/**
 * @brief       does calibration and configuration data send to C2K's BOOTROM?
 */
bool sblIsC2kBootromFinish(void)
{
    return blC2kBootromFinish;
}


#if 0
/**
 * \brief   send 1st 128byte sector to C28x SRAM by the BOOTROM protocol
 *          
 */
static void sObcBootromStart(void)
{
    //static uint32_t dwTickStart = 0;
    //uint32_t dwTickCurr;

    if (eLastState != OBC_BOOTROM_START)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("1st sector start\n");
        #endif

        //dwTickStart = TIMER_HAL_Get1msTick();

        wBootromDataTxCnt = 0;

        wSectorCnt = 1U;

        blC2kBootromFinish = false;

        eLastState = OBC_BOOTROM_START;
    }
    else
    {
        uint16_t *pwBuf;
        static uint16_t wTxBuf;                 // keep value for UART TX ISR
        bool blBootRomEchoFail = false;
        static uint16_t wLastSend = 0;

        //dwTickCurr = TIMER_HAL_Get1msTick();

        if(wBootromDataTxCnt >= wBootromDataLen)
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("1st sector done\n");
            #endif

            blC2kBootromFinish = true;

            eCurrState = OBC_SLEEP;
        }
        else if(blAutoBaudLocked == false)      // wait auto-baudrate lock
        {
            const uint8_t bChar = (uint8_t)'A';

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, &bSciRxBuf, 1U);
            
            (void)LPUART_DRV_SendData(INST_DRVSCI, &bChar, 1U);
        }
        else if(wBootromDataTxCnt < C2K_BOOTROM_HAEA_LEN)        // xfer BOOTROM header
        {
            pwBuf = (uint16_t*)&xC2kBootData;
            wTxBuf = pwBuf[wBootromDataTxCnt];
            pwBuf++;

            #ifdef EN_DEBUG_PRINT
            DebugPrintf("SCI TX 0x%04X\n", wTxBuf);
            #endif

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, (uint8_t*)&wSciRxBuf, 2U); 

            (void)LPUART_DRV_SendData(INST_DRVSCI, (const uint8_t*)&wTxBuf, 2U);

            if (wBootromDataTxCnt != 0)
            {
                if (wLastSend != wEchoData)          
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("SCI RX %d 0x%04X != 0x%04X\n", 
                                wBootromDataTxCnt, 
                                wEchoData, 
                                wLastSend);
                    #endif

                    blBootRomEchoFail = true;
                }
            }

            wLastSend = wTxBuf;

            if (blBootRomEchoFail == true)
            {
                #ifdef EN_DEBUG_PRINT
                DebugPrintf("1st header error !\n");
                #endif

                eCurrState = OBC_SLEEP;
            }
            else
            {
                wBootromDataTxCnt++;
            }
        }
        else                                    // xfer Code or Data
        {
            pwBuf = (uint16_t*)pBuffer;
            wTxBuf = pwBuf[wBootromDataTxCnt];

            #ifdef EN_DEBUG_PRINT
            DebugPrintf("SCI TX 0x%04X\n", wTxBuf);
            #endif

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, (uint8_t*)&wSciRxBuf, 2U); 

            (void)LPUART_DRV_SendData(INST_DRVSCI, (const uint8_t*)&wTxBuf, 2U);

            if (wLastSend != wEchoData)          
            {
                #ifdef EN_DEBUG_PRINT
                DebugPrintf("SCI RX %d 0x%04X != 0x%04X\n", 
                            wBootromDataTxCnt, 
                            wEchoData, 
                            wLastSend);
                #endif

                blBootRomEchoFail = true;
            }

            wLastSend = wTxBuf;

            if (blBootRomEchoFail == true)
            {
                #ifdef EN_DEBUG_PRINT
                DebugPrintf("1st sector error !\n");
                #endif

                eCurrState = OBC_SLEEP;
            }
            else
            {
                wBootromDataTxCnt++;

                if (wBootromDataTxCnt >= 
                   (xC2kBootData.wCodeLen + C2K_BOOTROM_HAEA_LEN))
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("1st sector done !\n");
                    #endif


                    eCurrState = OBC_SLEEP;
                }
            }
        }
    }
}

/**
 * \brief   send remain 128Byte sectors to C28x SRAM by the BOOTROM protocol
 *          
 */
static void sObcBootromXfer(void)
{
    //static uint32_t dwTickStart = 0;
    
    //uint32_t dwTickCurr;

    if (eLastState != OBC_BOOTROM_RUN)
    {
        wSectorCnt++;

        #ifdef EN_DEBUG_PRINT
        DebugPrintf("sector %d start\n", wSectorCnt);
        #endif

        //dwTickStart = TIMER_HAL_Get1msTick();
                
        wBootromDataTxCnt = 0;

        blC2kBootromFinish = false;

        eLastState = OBC_BOOTROM_RUN;
    }
    else
    {
        //dwTickCurr = TIMER_HAL_Get1msTick();

        if(wBootromDataTxCnt >= wBootromDataLen)
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("sector %d done\n", wSectorCnt);
            #endif

            blC2kBootromFinish = true;

            eCurrState = OBC_SLEEP;
        }
        else
        {
            uint16_t *pwBuf;
            static uint16_t wTxBuf;             // keep value for UART TX ISR
            bool blBootRomEchoFail = false;
            static uint16_t wLastSend = 0;

            pwBuf = (uint16_t*)pBuffer;
            wTxBuf = pwBuf[wBootromDataTxCnt];

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, (uint8_t*)&wSciRxBuf, 2U); 

            (void)LPUART_DRV_SendData(INST_DRVSCI, (const uint8_t*)&wTxBuf, 2U);
            
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("SCI TX 0x%04X\n", wTxBuf);
            #endif

            if (wBootromDataTxCnt != 0)
            {
                if (wLastSend != wEchoData)          
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("SCI RX %d 0x%04X != 0x%04X\n", 
                                wBootromDataTxCnt, 
                                wEchoData, 
                                wLastSend);
                    #endif

                    blBootRomEchoFail = true;
                }
            }

            wLastSend = wTxBuf;

            if (blBootRomEchoFail == true)
            {
                #ifdef EN_DEBUG_PRINT
                DebugPrintf("sector %d error !\n", wSectorCnt);
                #endif

                eCurrState = OBC_SLEEP;
            }
            else
            {
                wBootromDataTxCnt++;
            }
        }
    }
}

static void sObcBootromEnd(void)
{
    if (xC2kBootData.dwEntryPoint == 0xFFFFFFFFUL)  // if data or appl block finish,
    {                                               
        if (eLastState != OBC_BOOTROM_END)
        {
            static uint16_t wTxBuf = 0;

            #ifdef EN_DEBUG_PRINT
            DebugPrintf("data or appl finish\n");
            #endif
                                                    // send '0000' jump to bootloader
            (void)LPUART_DRV_SendData(INST_DRVSCI, (const uint8_t*)&wTxBuf, 2U);

            eLastState = OBC_BOOTROM_END;
        }
        else
        {
            if ((wEchoData == 0x4F4BU)              // if C28x Tx 'OK'
                || (wEchoData == 0x4B4FU))        
            {
                eCurrState = OBC_APPL_START;
            }
        }
    }
    else                                            // if bootloader block finish
    {                                               // donothing
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("bootloader end\n");
        #endif

        eLastState = OBC_BOOTROM_END;

        eCurrState = OBC_SLEEP;
    }
}



/**
 * \brief   to power on OBC sub-module, and reset the PFC's MCU (DSP, F280049).
 *          
 */
static void sObcApplStart(void)
{
    static uint32_t dwTickStart = 0;
    uint32_t dwTickCurr;

    if (eLastState != OBC_APPL_START)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("obc appl start\n");
        #endif

        dwTickStart = TIMER_HAL_Get1msTick();
                                                // give power to C28x
        PINS_DRV_SetPins(OBC_AUX_EN_DOH_PORT, (1UL << OBC_AUX_EN_DOH_PIN));

                                                // select C28x's flash boot
        PINS_DRV_SetPins(DSP_BOOT_DOH_PORT, (1UL << DSP_BOOT_DOH_PIN));

        eLastState = eCurrState;
    }
    else
    {
        dwTickCurr = TIMER_HAL_Get1msTick();

        if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_AUX)
        {
            // xIfOoData.eObcAuxUvCheck = BOOL_TRUE;

            if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_RST)
            {
                PINS_DRV_SetPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));

                if ((dwTickCurr - dwTickStart) >= DELAY_MS_DSP_OK)
                {
                    // xIfOoData.eDspOkCheck = BOOL_TRUE;

                    eCurrState = OBC_APPL_RUN;
                }
            }
        }
    }
}

static void sObcApplRun(void)
{
    // static uint32_t dwTickStart = 0;
    // uint32_t dwTickCurr;

    if (eLastState != OBC_APPL_RUN)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("obc appl run\n");
        #endif

        // dwTickStart = TIMER_HAL_Get1msTick();

        eLastState = eCurrState;
    }
    else
    {
        ;
    }
}

static void sObcApplEnd(void)
{
    #ifdef EN_DEBUG_PRINT
    DebugPrintf("obc appl end\n");
    #endif

    sSciDeinit();

    PINS_DRV_ClearPins(DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));

    eLastState = OBC_APPL_END;

    eCurrState = OBC_POWER_OFF;
}

#endif


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------


/**
 * \brief   init sObcBootRomTask internal data
 */
void sObcBootRomInit(void)
{
    #ifdef EN_DEBUG_PRINT
    DebugPrintf("obc init\n");
    #endif

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_AS_GPIO);
    
    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_AS_GPIO);

    eLastState = OBC_SLEEP;
    eCurrState = OBC_POWER_ON;
}



/**
 * \brief   to star OBC sub-module, turn on OBC sub-module and enable sObcBootRomTask
 */
void sObcBootRomPowerOn(void)
{
    eLastState = OBC_SLEEP;
    eCurrState = OBC_POWER_ON;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("ObcBootRomPowerOn\n");
    #endif
}

#if 0

void sObcBootRomStartXfer(void)
{
    eLastState = OBC_SLEEP;

    eCurrState = OBC_BOOTROM_START;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("ObcBootRomStartXfer\n");
    #endif
}

void sObcBootRomStop(void)
{
    eLastState = OBC_SLEEP;

    eCurrState = OBC_BOOTROM_END;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("ObcBootRomStop\n");
    #endif
}
#endif

/**
 * \brief   to stop OBC sub-module, turn off OBC sub-module and disable sObcBootRomTask
 */
void sObcBootRomPowerOff(void)
{
    eLastState = OBC_SLEEP;

    eCurrState = OBC_POWER_OFF;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("ObcBootRomPowerOff\n");
    #endif
}


/**
 * \brief   the main function to run OBC state machine
 */
void sObcBootRomTask(void)
{
    static uint32_t dwTickLast = 0;
    uint32_t dwTickCurr;

    dwTickCurr = TIMER_HAL_Get1msTick();

    if (dwTickCurr != dwTickLast)
    {
        switch(eCurrState)
        {
            case OBC_SLEEP:
                ;
                break;

            case OBC_POWER_ON:
                sObcPowerOn();
                break;

            //case OBC_BOOT_RUN:            
            //    sObcBootRun();
            //    break;

            //case OBC_APPL_RUN:
            //    sObcApplRun();
            //    break;

            case OBC_POWER_OFF:
                sObcPowerOff();
                break;

            default:
                ;
                break;
        }

        dwTickLast = TIMER_HAL_Get1msTick();
    }

}

void sObcBootromStateGet(obc_state_t* pState)
{
    *pState = eCurrState;
}

void sObcBootromEntryPointSet(uint32_t dwAddr)
{
    xC2kBootData.dwEntryPoint = dwAddr;
}

void sObcBootromTargetAddrSet(uint32_t dwAddr)
{
    xC2kBootData.dwCodeAddr = dwAddr;
}

void sObcBootromCodeSizeSet(uint32_t dwByteSize)
{
    xC2kBootData.wCodeWords = dwByteSize / 2;

    if ((dwByteSize % 2U) != 0)
    {
        xC2kBootData.wCodeWords += 1U;
    }
}

void sObcApplImageVerSet(uint8_t bMajor, uint8_t bMinor, uint8_t bDebug)
{
    bImageVerMajor = bMajor;
    bImageVerMinor = bMinor;
    bImageVerDebug = bDebug;
}

void sObcApplImageVerGet(uint8_t* pMajor, uint8_t* pMinor, uint8_t* pDebug)
{
    *pMajor = bImageVerMajor;
    *pMinor = bImageVerMinor;
    *pDebug = bImageVerDebug;
}


uint8_t sObcBootromXferHeader(void)
{
    uint16_t wRet;
    uint8_t i;
    uint8_t bRet;
    const uint8_t *pbBuf;
    const uint8_t bChar = (uint8_t)'A';
    uint8_t bRxBuf;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("BOOTROM head start\n");
    DebugPrintf("Entry Point = 0x%08X\n", xC2kBootData.dwEntryPoint);
    DebugPrintf("Code Size (words) = 0x%04X\n", xC2kBootData.wCodeWords);
    DebugPrintf("Dest Addr = 0x%08X\n", xC2kBootData.dwCodeAddr);
    #endif

    blDownloadOk = false;

    wRet = (uint16_t)LPUART_DRV_SendDataBlocking(INST_DRVSCI, &bChar, 1U, 1U);
    wRet |= (uint16_t)LPUART_DRV_ReceiveDataBlocking(INST_DRVSCI, &bRxBuf, 1U, 1U);
   // wRet = 0;
  //  bRxBuf = (uint8_t)'A';
    if ((wRet == 0) && (bChar == bRxBuf))
    {
        bRet = 0;
    }
    else
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("Echo Err wRet = 0x%X, Rx = %c\n", wRet, bRxBuf);
        #endif

        bRet = 1U;
    }

    if (bRet == 0)
    {
        wRet = 0;
        pbBuf = (uint8_t*)&xC2kBootData;

        sWordSwap(&xC2kBootData.dwEntryPoint);
        sWordSwap(&xC2kBootData.dwCodeAddr);

        DebugPrintf("Entry Point swaped = 0x%08X\n", xC2kBootData.dwEntryPoint);

        for (i=0; i<C2K_BOOTROM_CODE_HAED_LEN; i++)
        {
            wRet = (uint16_t)LPUART_DRV_SendDataBlocking(INST_DRVSCI, pbBuf, 1U, 1U);
            wRet |= (uint16_t)LPUART_DRV_ReceiveDataBlocking(INST_DRVSCI, &bRxBuf, 1U, 1U);

            if ((wRet != 0) || (bRxBuf != *pbBuf))
            {
                #ifdef EN_DEBUG_PRINT
                DebugPrintf("Echo Err (%d) 0x%02X != 0x%02X, wRet = 0x%X\n", 
                            i, bRxBuf, *pbBuf, wRet);
                #endif

                bRet = 2U;
                break;
            }
            
            pbBuf++;
        }
    }

    if (bRet == 0)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("BOOTROM header OK\n");
        #endif
    }
    else
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("BOOTROM header ERR, bRet %d\n", bRet);
        #endif
    }

    return bRet;
}

uint8_t sObcBootromXfer2ndHeader(void)
{
    uint16_t wRet;
    uint8_t i;
    uint8_t bRet = 0;
    const uint8_t *pbBuf;
    uint8_t bRxBuf;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("DATA head start\n");
    DebugPrintf("Data Size (words) = 0x%04X\n", xC2kBootData.wCodeWords);
    DebugPrintf("Dest Addr = 0x%08X\n", xC2kBootData.dwCodeAddr);
    #endif

    wRet = 0;
    pbBuf = (uint8_t*)&xC2kBootData.wCodeWords;

    sWordSwap(&xC2kBootData.dwCodeAddr);

    for (i=0; i<C2K_BOOTROM_DATA_HEAD_LEN; i++)
    {
        wRet = (uint16_t)LPUART_DRV_SendDataBlocking(INST_DRVSCI, pbBuf, 1U, 1U);
        wRet |= (uint16_t)LPUART_DRV_ReceiveDataBlocking(INST_DRVSCI, &bRxBuf, 1U, 1U);

        if ((wRet != 0) || (bRxBuf != *pbBuf))
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("Echo Err (%d) 0x%02X != 0x%02X, wRet = 0x%X\n", 
                        i, bRxBuf, *pbBuf, wRet);
            #endif

            bRet = 2U;
            break;
        }
        
        pbBuf++;
    }

    if (bRet == 0)
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("DATA header OK\n");
        #endif
    }
    else
    {
        #ifdef EN_DEBUG_PRINT
        DebugPrintf("DATA header ERR, bRet %d\n", bRet);
        #endif
    }

    return bRet;
}

uint8_t sObcBootromXferSector(const uint8_t* pBuf, uint16_t wBytes)
{
    uint16_t wRet;
    uint8_t i;
    uint8_t bRet = 0;
    uint8_t bRxBuf;

    wRet = 0;

    for (i=0; i<wBytes; i++)
    {
        wRet = (uint16_t)LPUART_DRV_SendDataBlocking(INST_DRVSCI, pBuf, 1U, 1U);
        wRet |= (uint16_t)LPUART_DRV_ReceiveDataBlocking(INST_DRVSCI, &bRxBuf, 1U, 1U);

        if ((wRet != 0) || (bRxBuf != *pBuf))
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("Echo Err (%d) 0x%02X != 0x%02X, wRet = 0x%X\n", 
                        i, bRxBuf, *pBuf, wRet);
            #endif

            bRet = 1U;
            break;
        }
        
        pBuf++;
    }

    return bRet;
}

uint8_t sObcBootromXferStop(void)
{
    #ifdef EN_DEBUG_PRINT
    DebugPrintf("BootRomXferStop\n");
    #endif

    static uint8_t bZero;

    uint16_t wRet;
    uint8_t i;
    uint8_t bRet = 0;
    uint8_t bRxBuf;

    wRet = 0;
    bZero = 0;

    for (i=0; i<2U; i++)
    {
        wRet = (uint16_t)LPUART_DRV_SendDataBlocking(INST_DRVSCI, &bZero, 1U, 1U);
        wRet |= (uint16_t)LPUART_DRV_ReceiveDataBlocking(INST_DRVSCI, &bRxBuf, 1U, 1U);

        if ((wRet != 0) || (bRxBuf != bZero))
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("Echo Err (%d) 0x%02X != 0x%02X, wRet = 0x%X\n", 
                        i, bRxBuf, bZero, wRet);
            #endif

            bRet = 1U;
            break;
        }
    }

    return bRet;
}

void sObcBootloaderRun(bool *pReflashStatus)
{
    uint32_t dwTickStart;
    uint32_t dwTickCurr;
    bool blTimeout = false;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("obc bootloader run\n");
    #endif

    blGotString = false;

    bRxIndex = 0;

    (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, &bSciRxBuf, 1U);

    (void)LPUART_DRV_InstallRxCallback(INST_DRVSCI, sSciRxCallback, NULL);

    (void)LPUART_DRV_ReceiveData(INST_DRVSCI, &bSciRxBuf, 1U);

    dwTickStart = TIMER_HAL_Get1msTick();

    blDownloadOk = false;
    
    do
    {
        dwTickCurr = TIMER_HAL_Get1msTick();

        WATCHDOG_HAL_Fed();

        if ((dwTickCurr - dwTickStart) >= TIMEOUT_MS_BOOTROM)
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("C28x reflash timeout\n");
            #endif
            blTimeout = true;
        }
        else
        {
            if (blGotString == true)
            {
                if ((pSciRxBuf[0] == 'O')
                    && (pSciRxBuf[1] == 'K'))
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("C28x reflash OK\n");
                    #endif

                    blDownloadOk = true;

                                                // reset C28X
                    PINS_DRV_ClearPins( DSP_RST_DOL_PORT, 
                                        (1UL << DSP_RST_DOL_PIN));

                                                // select C28x's flash boot
                    PINS_DRV_SetPins(   DSP_BOOT_DOH_PORT, 
                                        (1UL << DSP_BOOT_DOH_PIN));
                }
                
                blGotString = false;
            }            
        }
    }while((blTimeout == false) && (blDownloadOk == false));

    *pReflashStatus = blDownloadOk;
}



void sObcApplicationRun(bool *pDependenceStatus)
{
    uint32_t dwTickStart;
    uint32_t dwTickCurr;
    bool blTimeout = false;
    uint8_t bImgMajor;
    uint8_t bImgMinor;
    uint8_t bImgDebug;

    #ifdef EN_DEBUG_PRINT
    DebugPrintf("obc application run\n");
    #endif

    sObcApplImageVerGet(&bImgMajor, &bImgMinor, &bImgDebug);

    dwTickStart = TIMER_HAL_Get1msTick();

                                                // select C28x's flash boot
    PINS_DRV_SetPins(DSP_BOOT_DOH_PORT, (1UL << DSP_BOOT_DOH_PIN));

                                                // start C28X
    PINS_DRV_SetPins( DSP_RST_DOL_PORT, (1UL << DSP_RST_DOL_PIN));
    
    do
    {
        dwTickCurr = TIMER_HAL_Get1msTick();

        WATCHDOG_HAL_Fed();

        if ((dwTickCurr - dwTickStart) >= TIMEOUT_MS_BOOTROM)
        {
            #ifdef EN_DEBUG_PRINT
            DebugPrintf("check dep. timeout\n");
            #endif
            blTimeout = true;
        }
        else
        {
            uint8_t bGotApplVerMsg;
            uint8_t bMajor;
            uint8_t bMinor;
            uint8_t bDebug;

            bGotApplVerMsg = sC28xApplVerGet(&bMajor, &bMinor, &bDebug);

            if (bGotApplVerMsg == 0)
            {
                if ((bMajor == bImgMajor)
                    && (bMinor == bImgMinor)
                    && (bDebug == bImgDebug))
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("C28x dep. OK\n");
                    DebugPrintf("Appl Ver %d.%d.%d\n", bMajor, bMinor, bDebug);
                    #endif

                    blDependencyOk = true;
                }
                else
                {
                    #ifdef EN_DEBUG_PRINT
                    DebugPrintf("C28x dep. Err\n");
                    DebugPrintf("Appl Ver %d.%d.%d\n", bMajor, bMinor, bDebug);
                    DebugPrintf("Image Ver %d.%d.%d\n", bImgMajor, bImgMinor, bImgDebug);
                    #endif
                    break;
                    blDependencyOk = false;
                }
            }            
        }
    }while((blTimeout == false) && (blDependencyOk == false));

    *pDependenceStatus = blDependencyOk;

    eCurrState = OBC_POWER_OFF;                 // power off F280049 after dep. check
}



bool sObcDownloadStatusGet(void)
{
    return blDownloadOk;
}

bool sObcDependencyStatusGet(void)
{
    return blDependencyOk;
}



