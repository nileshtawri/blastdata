/*
 * Sbc.h
 *
 *  Created on: 2021�~1��25��
 *      Author: DamonHsieh
 */

#ifndef SBC_H_
#define SBC_H_

#include "cpu.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define         SBC_PIN_MASK_IGN            FS45_R_M_IO_0_MASK

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
extern status_t sSBCInitial(void);
extern status_t sSbcReadIoPin(uint8_t bPinMask, bool* pblPin);

#endif /* SBC_H_ */
