
/**
 * @file        she.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include <stdio.h>
#include "includes.h"
#include "DrvCsec.h"
#include "she.h"
#include "s32k144.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define CMD_FORMAT_COPY         0
#define CSEC_NO_ERROR           1U


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------
#define number_of_words(j_local, message_length) ((128*7*(j_local+1) > (message_length + 128))?((((message_length+128)-(128*7*j_local))/32) + 4):(32))


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
static void sShePrintBuf( const uint8_t* pBuf, uint32_t dwLen);

#if 0
static status_t sxSheDeriveKey( const uint8_t *pbKey, 
                                uint8_t *pbConstant, 
                                uint8_t *pbDerivedKey);

static status_t sxSheComputeM1M2M3( const uint8_t *authKey, 
                                    csec_key_id_t authId, 
                                    csec_key_id_t keyId, 
                                    const uint8_t *key, 
                                    uint32_t counter,
                                    const uint8_t *uid, 
                                    uint8_t *m1, 
                                    uint8_t *m2, 
                                    uint8_t *m3, 
                                    bool bootProtection);


static status_t sxSheComputeM4M5(   csec_key_id_t authId, 
                                    csec_key_id_t keyId, 
                                    const uint8_t *key, 
                                    uint32_t counter,
                                    const uint8_t *uid, 
                                    uint8_t *m4, 
                                    uint8_t *m5);
#endif


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static const uint8_t g_defaultKey[16] = {
    0x00U, 0x01U, 0x02U, 0x03U, 0x04U, 0x05U, 0x06U, 0x07U,
    0x08U, 0x09U, 0x0aU, 0x0bU, 0x0cU, 0x0dU, 0x0eU, 0x0fU};

#if 0
static const uint8_t g_emptyKey[16] = {
    0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU,
    0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU, 0xFFU};

static uint8_t g_authIdKey[16] = {0};
static csec_key_id_t g_authId = CSEC_MASTER_ECU;
#endif

static bool blSheMasterEcuKeyIsEmpty = true;


//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------
/**
 * \brief print data of a buffer
 * \param[in]   pBuf    point to the data buffer
 * \param[in]   dwLen   print length (bytes) of the buffer
 */
static void sShePrintBuf( const uint8_t* pBuf, uint32_t dwLen)
{
    if(dwLen > 128)
    {
        APPDebugPrintf("sShePrintBuf too long %d\n", dwLen);
    }
    else
    {
        uint8_t i;
        for(i = 0; i < dwLen; i++)
        {
            APPDebugPrintf("%02X", pBuf[i]);
            if(((i+1)%16) == 0)
            {
                APPDebugPrintf("\n");
            }
        }
        APPDebugPrintf("\n");
    }
}


/**
 * \brief   Generate the BOOT_MAC for the application to be protected
 *          data copy format feature is used. For this function, message_length 
 *          should be in multiple of 128 bits and greater than 0.
 *          Remember to put message length on PAGE[1] in the first loop. 
 *          So now message_length = message_length + 128 (ref. to AN5401)
 *
 * \param[out]  pbCmac  point to output CMAC buffer (16bytes)
 * \param[in]   key_id  specify the Auth. key ID
 * \param[in]   pdwData point to the intput data buffer
 * \param[in]   message_length   print length (bits) of the buffer
 * 
 * \retval  0 PASS
 * \retval  1 Error
 */
static uint8_t sbSheGenerateBootMac(uint8_t *pbCmac, 
                                    const uint32_t *pdwData, 
                                    uint8_t key_id, 
                                    uint32_t message_length)
{
    uint8_t bRet = 0;
	uint32_t j_local = 0;
    uint32_t number_of_pram_load_cyc;
    uint32_t i;
    uint32_t dwCmd;
    uint32_t dwSeq;
    uint16_t csec_error_bits;

                                                // Check for the ongoing FLASH command
	if((FTFC->FSTAT & FTFC_FSTAT_CCIF_MASK) != FTFC_FSTAT_CCIF_MASK)
    {
        APPDebugPrintf("GenerateBootMac FTFC buzy\n");
        bRet = 1;
        goto ERR_EXIT;
    }
                                                // Write 1 to clear error flags
	FTFC->FSTAT = (FTFC_FSTAT_FPVIOL_MASK | FTFC_FSTAT_ACCERR_MASK);  

	number_of_pram_load_cyc = ((message_length+128U)/(128U*7U)) + \
                              (((message_length+128U)%(128U*7U))?(1U):(0));

	while(j_local < number_of_pram_load_cyc)
	{
		if(j_local == 0)                        // the first data block, header
		{
			CSE_PRAM->RAMn[4].DATA_32 = 0;
			CSE_PRAM->RAMn[5].DATA_32 = 0;
			CSE_PRAM->RAMn[6].DATA_32 = 0;
			CSE_PRAM->RAMn[7].DATA_32 = message_length;
			for(i=8U; i<number_of_words(j_local, message_length); i++)
            {
				CSE_PRAM->RAMn[i].DATA_32 = pdwData[i-8];
            }
		}
		else if(j_local == 1)
		{
			for(i=4U; i<number_of_words(j_local, message_length); i++)
            {
				CSE_PRAM->RAMn[i].DATA_32 = pdwData[(i-4) + j_local*24];
            }
		}
		else
		{
			for(i=4U; i<number_of_words(j_local, message_length); i++)
            {
				CSE_PRAM->RAMn[i].DATA_32 = pdwData[(i-4) + j_local*28 - 4];
            }
		}

		CSE_PRAM->RAMn[3].DATA_32= message_length+128; // Write to Page0 Word3

		/* Start command by wring Header */
		if(j_local==0)
        {
            dwSeq = (uint32_t)CSEC_CALL_SEQ_FIRST;
        }
		else
        {
            dwSeq = (uint32_t)CSEC_CALL_SEQ_SUBSEQUENT;
        }

        dwCmd = CSEC_CMD_GENERATE_MAC << 24;
        dwCmd |= (CMD_FORMAT_COPY << 16);
        dwCmd |= (dwSeq << 8);
        dwCmd |= (uint8_t)key_id;

        CSE_PRAM->RAMn[0].DATA_32 = dwCmd;

        while((FTFC->FSTAT & FTFC_FSTAT_CCIF_MASK) != 0x80); //Check for the ongoing FLASH command

        csec_error_bits = CSE_PRAM->RAMn[1].DATA_32 >> 16; //Read Page0 Word1, Error Bits

		if(csec_error_bits != CSEC_NO_ERROR)
        {
            APPDebugPrintf("GenerateBootMac ERROR, 0x%04X\n", csec_error_bits);
            bRet = 2U;
			break;
        }
	    j_local++;
	}

    for(i=8U; i<12U; i++)                       // converte LSB double word to byte
    {
        uint32_t j = (i-8U)*4U;
		pbCmac[j+3U] = (uint8_t)(CSE_PRAM->RAMn[i].DATA_32 & 0x0FF);
        pbCmac[j+2U] = (uint8_t)((CSE_PRAM->RAMn[i].DATA_32 >> 8) & 0x0FF);
        pbCmac[j+1U] = (uint8_t)((CSE_PRAM->RAMn[i].DATA_32 >> 16) & 0x0FF);
        pbCmac[j+0U] = (uint8_t)((CSE_PRAM->RAMn[i].DATA_32 >> 24) & 0x0FF);
    }

ERR_EXIT:
	return bRet;
}

#if 0

/**
 * \brief Derives a key with a given constant
 */
static status_t sxSheDeriveKey( const uint8_t *pbKey, 
                                uint8_t *pbConstant, 
                                uint8_t *pbDerivedKey)
{
    status_t xStatus;
    uint8_t pbConcat[32];
    int i;

    for (i = 0; i < 16; i++)
    {
        pbConcat[i] = pbKey[i];
        pbConcat[i+16] = pbConstant[i];
    }

    xStatus = CSEC_DRV_MPCompress(pbConcat, 2U, pbDerivedKey, 1U);

    return xStatus;
}


/**
 * \brief Computes the M1-M3 values
 *
 */
static status_t sxSheComputeM1M2M3( const uint8_t *authKey, 
                                    csec_key_id_t authId, 
                                    csec_key_id_t keyId, 
                                    const uint8_t *key, 
                                    uint32_t counter,
                                    const uint8_t *uid, 
                                    uint8_t *m1, 
                                    uint8_t *m2, 
                                    uint8_t *m3, 
                                    bool bootProtection)
{
    status_t stat;
    int i;
    uint8_t iv[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    uint8_t k1[16];
    uint8_t k2[16];

    uint8_t m2Plain[32];

    uint8_t m1m2[48];

    /* Derive K1 and K2 from AuthID */
    sxSheDeriveKey(authKey, key_update_enc_c, k1);
    sxSheDeriveKey(authKey, key_update_mac_c, k2);

    /* Compute M1 = UID | ID | AuthID */
    for (i = 0; i < 15U; i++)
    {
        m1[i] = uid[i];
    }
    m1[15] = ((keyId & 0xFU) << 4U) | (authId & 0xFU);

    /* Compute M2 (C = counter, F = 0) */
    for(i = 0; i < 16U; i++)
    {
        m2Plain[i] = 0;
        m2Plain[16U + i] = key[i];
    }
    m2Plain[0] = (counter & 0xFF00000U) >> 20U;
    m2Plain[1] = (counter & 0xFF000U) >> 12U;
    m2Plain[2] = (counter & 0xFF0U) >> 4U;

    if(!bootProtection)
    {
    	m2Plain[3] = (counter & 0xFU) << 4U;
    }
    else
    {
    	m2Plain[3] = ((counter & 0xFU) << 4U) | 0x4U;
    }

    /* Encrypt M2 */
    stat = CSEC_DRV_LoadPlainKey(k1);
    if (stat != STATUS_SUCCESS)
    {
        goto M123_EXIT;
    }

    stat = CSEC_DRV_EncryptCBC(CSEC_RAM_KEY, m2Plain, 32U, iv, m2, 1U);
    if (stat != STATUS_SUCCESS)
    {
        goto M123_EXIT;
    }

    /* Compute M3 as CMAC(key=k2, m1|m2)*/
    for (i = 0; i < 16; i++)
    {
        m1m2[i] = m1[i];
    }
    for(i = 0; i < 32; i++)
    {
        m1m2[16 + i] = m2[i];
    }

    stat = CSEC_DRV_LoadPlainKey(k2);
    if (stat != STATUS_SUCCESS)
    {
        goto M123_EXIT;
    }

    stat = CSEC_DRV_GenerateMAC(CSEC_RAM_KEY, m1m2, 384U, m3, 1U);
    if (stat != STATUS_SUCCESS)
    {
        goto M123_EXIT;
    }

M123_EXIT:
    return stat;
}

/**
 * \brief Computes the M4 and M5 values 
 */
static status_t sxSheComputeM4M5(   csec_key_id_t authId, 
                                    csec_key_id_t keyId, 
                                    const uint8_t *key, 
                                    uint32_t counter,
                                    const uint8_t *uid, 
                                    uint8_t *m4, 
                                    uint8_t *m5)
{
    status_t stat;
    int i;

    uint8_t k3[16];
    uint8_t k4[16];

    uint8_t m4StarPlain[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint8_t m4StarCipher[16];

    /* Derive K4 and K5 from key ID */
    sxSheDeriveKey(key, key_update_enc_c, k3);
    sxSheDeriveKey(key, key_update_mac_c, k4);

    m4StarPlain[0] = (counter & 0xFF00000U) >> 20U;
    m4StarPlain[1] = (counter & 0xFF000U) >> 12U;
    m4StarPlain[2] = (counter & 0xFF0U) >> 4U;
    m4StarPlain[3] = ((counter & 0xFU) << 4U) | 0x8U;

    /* Encrypt M4* */
    stat = CSEC_DRV_LoadPlainKey(k3);
    if (stat != STATUS_SUCCESS)
    {
        goto M45_EXIT;
    }

    stat = CSEC_DRV_EncryptECB(CSEC_RAM_KEY, m4StarPlain, 16U, m4StarCipher, 1U);
    if (stat != STATUS_SUCCESS)
    {
        goto M45_EXIT;
    }

    /* Compute M4 = UID | ID | AuthID | M4* */
    for (i = 0; i < 15U; i++)
    {
        m4[i] = uid[i];
    }
    m4[15] = ((keyId & 0xFU) << 4U) | (authId & 0xFU);
    for (i = 0; i < 16U; i++)
    {
        m4[16U + i] = m4StarCipher[i];
    }

    stat = CSEC_DRV_LoadPlainKey(k4);
    if (stat != STATUS_SUCCESS)
    {
        goto M45_EXIT;
    }

    stat = CSEC_DRV_GenerateMAC(CSEC_RAM_KEY, m4, 256U, m5, 1U);
    if (stat != STATUS_SUCCESS)
    {
        goto M45_EXIT;
    }

M45_EXIT:
    return stat;
}
#endif

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * \brief initial the SHE hardwaer
 * \return 0 if PASS, else otherwise
 */
void sbSheInit(void)
{
    CSEC_DRV_Init(&DrvCsec_State);
}


/**
 * \brief   to setup the secure boot function in the SHE (CSEc), and it also
 *          generate new CMAC via the KEY_7
 * \param[in]   dwSize  seucre boot check size (in bits)
 * \param[in]   eMode   secure boot mode list in \csec_boot_flavor_t
 * \param[out]  pbCmac  point to output CMAC buffer, 16 bytes
 * \return 0 if PASS, else otherwise
 */
uint8_t sbSheBootModeSet(   uint32_t dwSize, 
                            csec_boot_flavor_t eMode, 
                            uint8_t *pbCmac)
{
    uint8_t u8_ret = 0;
    status_t xStatus;

    if(CSEC_BOOT_STRICT != eMode)               // don't config strict while dev
    {
        xStatus = CSEC_DRV_BootDefine(dwSize, eMode);
    }
    else
    {
        xStatus = STATUS_SEC_INVALID_COMMAND;
    }

    if(xStatus == STATUS_SUCCESS)
    {
        u8_ret = sbSheGenerateBootMac(  pbCmac, 
                                        (const uint32_t*)0,
                                        (uint8_t)CSEC_KEY_7, 
                                        dwSize);

        if(u8_ret != 0)
        {
            APPDebugPrintf("CSEC_DRV_GenerateMAC error 0x%X\n", u8_ret);
            u8_ret = 2U;
        }
        else
        {
            APPDebugPrintf("new BOOT_MAC:\n");
            sShePrintBuf(pbCmac, 16U);
        }
    }
    else
    {
        APPDebugPrintf("CSEC_DRV_BootDefine error 0x%X\n", xStatus);
        u8_ret = 1U;
    }

    return u8_ret;
}

/**
 * \brief rapper function to CMD_LOAD_KEY of the SHE
 * \param[in]   ekeyId  list in enum \csec_key_id_t, specify the KeyID to be 
 *              used to implement the requested cryptographic operation
 * \param[in]   m1      point to input buffer M1, 16 bytes
 * \param[in]   m2      point to input buffer M2, 32 bytes
 * \param[in]   m3      point to input buffer M3, 16 bytes
 * \param[out]  m4      point to output buffer M4, 32 bytes
 * \param[out]  m5      point to output buffer M5, 16 bytes
 * \return 0 if PASS, else otherwise
 */
uint8_t sbSheMemoryUpdate(  csec_key_id_t ekeyId,
                            const uint8_t * m1,
                            const uint8_t * m2,
                            const uint8_t * m3,
                            uint8_t * m4,
                            uint8_t * m5)
{
    uint8_t u8_ret;
    status_t xStatus;

    xStatus = CSEC_DRV_LoadKey(ekeyId, m1, m2, m3, m4, m5);

    if(xStatus == STATUS_SUCCESS)
    {
        u8_ret = 0;
    }
    else
    {
        APPDebugPrintf("CSEC_DRV_LoadKey error %X\n", xStatus);
        u8_ret = 1U;
    }

    return u8_ret;
}

#if 0
/**
 * \brief load key or BOOT_CMAC to the SHE
 * \param[in]   ekeyId      list in enum \csec_key_id_t
 * \param[in]   pbKeyNew    key buffer
 * \param[in]   bCounter    key update counter
 * \param[in]   blBootProtection    key boot protection flag
 * \param[out]  pbM5        output buffer for CMAC validation
 * \return 0 if PASS, else otherwise
 */
uint8_t sbSheLoadKey(   csec_key_id_t ekeyId, 
                        uint8_t *pbKeyNew, 
                        uint8_t bCounter, 
                        bool blBootProtection)
{
    uint8_t u8_ret = 0;
    status_t xStatus;
    uint8_t uid[15] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    uint8_t m1[16];
    uint8_t m2[32];
    uint8_t m3[16];
    uint8_t m4[32];
    uint8_t m5[16];

    xStatus = sxSheComputeM1M2M3(   g_authIdKey, 
                                    g_authId, 
                                    ekeyId, 
                                    pbKeyNew, 
                                    bCounter, 
                                    uid, 
                                    m1, 
                                    m2, 
                                    m3, 
                                    blBootProtection);

    if (xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("sxSheComputeM1M2M3 error %d\n", xStatus);
        u8_ret = 1U;
    }
    else
    {
        xStatus = CSEC_DRV_LoadKey(ekeyId, m1, m2, m3, m4, m5);

        if(xStatus == STATUS_SUCCESS)
        {
            u8_ret = 0;
        }
        else
        {
            APPDebugPrintf("CSEC_DRV_LoadKey error %d\n", xStatus);
            u8_ret = 2U;
        }
    }

    if(u8_ret == 0)
    {
        xStatus = sxSheComputeM4M5( g_authId, 
                                    ekeyId, 
                                    pbKeyNew, 
                                    bCounter,
                                    uid, 
                                    m4, 
                                    m5);

        if (xStatus != STATUS_SUCCESS)
        {
            APPDebugPrintf("sxSheComputeM4M5 error %d\n", xStatus);
            u8_ret = 3U;
        }
    }

    return u8_ret;
}
#endif

/**
 * \brief read the security boot status of SHE, ref to user manaul Table 37-1.
 * \param[out] pbStatus FCSESTAT1 register value
 * \retval 0 No Boot type
 * \retval 1 Boot CMAC is empty
 * \retval 2 Boot CMAC mismatch, secure boot fail
 * \retval 3 Boot CMAC match, secure boot OK
 * \retval 4 MAC_KEY is empty
 * \retval 5 unknow
 */
uint8_t sbSheSecureBootStautsGet(uint8_t* pbStatus)
{
    uint8_t bRet = 0;
    uint8_t bTmp;

    *pbStatus = (FTFC->FCSESTAT);

    bTmp = (FTFC->FCSESTAT) & 0x1EU;

    APPDebugPrintf("SHE Boot Status: ");

    switch(bTmp)
    {
        case 0x00U:                             // SB=0, BIN=0, BFN=0, BOK=0
            bRet = SHE_BOOT_NO_TYPE;
            APPDebugPrintf("disable\n");
            break;

        case 0x0EU:                             // SB=1, BIN=1, BFN=1, BOK=0
            bRet = SHE_BOOT_MAC_IS_EMPTY;
            APPDebugPrintf("no boot cmac\n");
            break;

        case 0x0AU:                             // SB=1, BIN=0, BFN=1, BOK=0
            bRet = SHE_BOOT_MAC_MISMATCH;
            APPDebugPrintf("cmac mismatch\n");
            break;

        case 0x12U:                             // SB=1, BIN=0, BFN=0, BOK=1
            bRet = SHE_BOOT_MAC_MATCH;
            APPDebugPrintf("cmac is match\n");
            break;

        case 0x08U:                             // SB=0, BIN=0, BFN=1, BOK=0
            bRet = SHE_BOOT_KEY_IS_EMPTY;
            APPDebugPrintf("no boot key\n");
            break;

        default:
            bRet = SHE_BOOT_STATUS_UNKNOW;
            APPDebugPrintf("unknown\n");
            break;
    }

    return bRet;
}

#if 0
/**
 * \brief Sets the MASTER_ECU_KEY
 * \param[in]   bAuthKeyId  the key id used to authentication, \csec_key_id_t
 * \param[in]   pbKeyBuf    point to the key buffer
 * \param[in]   dwCounter   update counter
 * \param[in]   pbUidBuf    point to input UID buffer, 15 bytes
 * \param[out]  pbM4        point to the output validate message M4, 32 bytes
 * \param[out]  pbM5        point to the output validate message M5, 16 bytes
 * \return 0 if PASS, else otherwise
 */
uint8_t sbMasterEcuKeyUpdate(   uint8_t bAuthKeyId,
                                const uint8_t* pbKeyBuf,
                                uint32_t dwCounter,
                                const uint8_t* pbUidBuf,
                                uint8_t *pbM4,
                                uint8_t *pbM5)
{
    uint8_t m1[16];
    uint8_t m2[32];
    uint8_t m3[16];
    uint8_t bRet = 0;

    status_t stat;

    stat = sxSheComputeM1M2M3(  g_emptyKey, 
                                (csec_key_id_t)bAuthKeyId, 
                                CSEC_MASTER_ECU, 
                                pbKeyBuf, 
                                dwCounter, 
                                pbUidBuf, 
                                m1, 
                                m2, 
                                m3,
                                false);

    if (stat != STATUS_SUCCESS)
    {
        APPDebugPrintf("sxSheComputeM1M2M3 fail %X\n", stat);
        bRet = 1U;
    }
    else
    {
        //APPDebugPrintf("M123OK\n");
        //bRet = CSEC_DRV_LoadKey(CSEC_MASTER_ECU, m1, m2, m3, m4, m5);

        sShePrintBuf(m1, 16);
        sShePrintBuf(m2, 32);
        sShePrintBuf(m3, 16);

        stat = sxSheComputeM4M5(bAuthKeyId, 
                                CSEC_MASTER_ECU, 
                                pbKeyBuf, 
                                dwCounter,
                                pbUidBuf, 
                                pbM4, 
                                pbM5);

        if (stat != STATUS_SUCCESS)
        {
            APPDebugPrintf("sxSheComputeM4M5 fail %X\n", stat);
            bRet = 2U;
        }
        else
        {
            sShePrintBuf(pbM4, 32);
            sShePrintBuf(pbM5, 16);
        }
    }

    return bRet;
}
#endif

/**
 * \brief it performs SHE's CMD_GET_ID API, this function can used to detect
 *        the MASTER_ECU_KEY is empty or not
 *
 * \param[in]   pbChallenge point to input challenge data buffer, 16 bytes
 * \param[out]  pbUid       point to output ID buffer, 15 bytes
 * \param[out]  pbSreg      point to output Status Register buffer, 1 byte
 * \param[out]  pbMac       point to output MAC data buffer, 16 bytes
 * \return 0 if PASS, else otherwise
 */
uint8_t sbSheGetId( const uint8_t* pbChallenge,
                    uint8_t* pbUid,
                    uint8_t* pbSreg,
                    uint8_t* pbMac)
{
    uint8_t bRet = 0;
    status_t xRet;
    uint8_t i;

    xRet = CSEC_DRV_GetID(pbChallenge, pbUid, pbSreg, pbMac);
    if(xRet != STATUS_SUCCESS)
    {
        APPDebugPrintf("sbSheGetId fail 0x%04X\n", xRet);
        bRet = 1U;
    }
    else
    {
        for(i=0; i<16; i++)
        {
            if(pbMac[i] != 0)                   // if MAC not 0, SHE has the KEY
            {
                blSheMasterEcuKeyIsEmpty = false;
                break;
            }
        }

        #if 1
        if(blSheMasterEcuKeyIsEmpty)
        {
            APPDebugPrintf("Master_Ecu_Key is empty\n");
        }
        else
        {
            APPDebugPrintf("Master_Ecu_Key has value\n");
        }
        #endif
        
        APPDebugPrintf("UID:\n");
        sShePrintBuf(pbUid, 15U);
        APPDebugPrintf("Sreg: 0x%02X\n", *pbSreg);

        APPDebugPrintf("MAC:\n");
        sShePrintBuf(pbMac, 16U);
    }

    return bRet;
}

/**
 * \brief is the MASTER_ECU_KEY empty
 * \return true or flase
 */
bool blIsSheMasterEcuKeyEmpty(void)
{
    return blSheMasterEcuKeyIsEmpty;
}

/**
 * \brief is the MASTER_ECU_KEY empty
 * \param[out]   pbBuf   point to output buffer for random number (16bytes)
 * \return 0 if PASS else otherwise
 */
uint8_t sbSheGenerateRandomNumber(uint8_t *pbBuf)
{
    status_t xStatus;
    uint8_t bRet = 0;

    xStatus = CSEC_DRV_InitRNG();
    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("CSEC_DRV_InitRNG error 0x%X\n", xStatus);
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_GenerateRND(pbBuf);

    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("GenerateRandomNumber fail 0x%04X\n", xStatus);
        bRet = 2U;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Decryption by default key
 * \param[in]   pbCipherText    point to input cipher text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbPlainText     point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS else otherwise
 */
uint8_t sbSheDecEcbByDefaultKey(const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_LoadPlainKey(g_defaultKey);

    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("CSEC_DRV_LoadPlainKey fail 0x%04X\n", xStatus);
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_DecryptECB(CSEC_RAM_KEY,
                                  pbCipherText,
                                  dwSize,
                                  pbPlainText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("CSEC_DRV_DecryptECB fail 0x%04X\n", xStatus);
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Decryption by the KEY_1
 * \param[in]   pbCipherText    point to input cipher text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbPlainText     point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS, 1 if no key, 2 otherwise
 */
uint8_t sbSheDecEcbByUserKey1(  const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_DecryptECB(CSEC_KEY_1,
                                  pbCipherText,
                                  dwSize,
                                  pbPlainText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        if(xStatus == STATUS_SEC_KEY_EMPTY)
        {
            APPDebugPrintf("User Key is empty\n", xStatus);
            bRet = 1U;
            goto ERROR;
        }

        APPDebugPrintf("CSEC_DRV_DecryptECB fail 0x%04X\n", xStatus);
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}



/**
 * \brief ECB Encryption by default key
 * \param[in]   pbPlainText     point to input plain text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbCipherText    point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS else otherwise
 */
uint8_t sbSheEncEcbByDefaultKey(const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_LoadPlainKey(g_defaultKey);

    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("CSEC_DRV_LoadPlainKey fail 0x%04X\n", xStatus);
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_EncryptECB(CSEC_RAM_KEY,
                                  pbPlainText,
                                  dwSize,
                                  pbCipherText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        APPDebugPrintf("CSEC_DRV_EncryptECB fail 0x%04X\n", xStatus);
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Encryption by the KEY_1
 * \param[in]   pbPlainText     point to input plain text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbCipherText    point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS, 1 if no key, 2 otherwise
 */
uint8_t sbSheEncEcbByUserKey1(  const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_EncryptECB(CSEC_KEY_1,
                                  pbPlainText,
                                  dwSize,
                                  pbCipherText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        if(xStatus == STATUS_SEC_KEY_EMPTY)
        {
            APPDebugPrintf("User Key is empty\n", xStatus);
            bRet = 1U;
            goto ERROR;
        }

        APPDebugPrintf("CSEC_DRV_EncryptECB fail 0x%04X\n", xStatus);
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}


