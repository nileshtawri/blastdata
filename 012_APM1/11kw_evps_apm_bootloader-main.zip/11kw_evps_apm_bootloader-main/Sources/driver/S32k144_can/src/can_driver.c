/*
* can_mdd.c
*
*  Created on: 2018��9��17��
*      Author: nxf47391
*/
#include "can_driver.h"
#include "User_config.h"
#include "TP.h"

#define DSP_APPL_VER_MSG_ID                     0x602U

#if 1
volatile uint8_t g_ucIsCountTime = 0u;
volatile uint32_t g_ulTxStartTime = 0u;
volatile uint32_t g_ulRxEndTime[2] = {0u};
uint8_t g_ucRxTimeRecord = 0u;
#endif	//end of 1


uint32_t dwCan2RxCnt = 0U;
uint32_t dwCan2TxCnt = 0U;
tRxCanMsg stCan2RxMsg = {0u};


static void CAN_Filiter_RXIndividual(void);
static void Config_Rx_Buffer(void);
static void Config_Tx_Buffer(void);
static uint8_t IsRxCANMsgId(uint32_t i_usRxMsgId);
static void CheckCANTranmittedStatus(void);
static void CheckCAN2TranmittedStatus(void);

static uint8_t bC28xApplVerMajor = 0;
static uint8_t bC28xApplVerMinor = 0;
static uint8_t bC28xApplVerDebug = 0;
static bool blGotC28xApplVerMsg = false;



void RxCANMsgMainFun(void);
void TransmittedCanMsgCallBack(void);

/* Config CAN filiter is individual */
static void CAN_Filiter_RXIndividual(void)
{
    uint32_t i;

    /* Set the ID mask type is individual */
    FLEXCAN_DRV_SetRxMaskType(0u, FLEXCAN_RX_MASK_INDIVIDUAL);

    for(i = 0u; i < g_ucRxCANMsgIDNum; i++)
    {
        FLEXCAN_DRV_SetRxIndividualMask(0u, g_astRxMsgConfig[i].RxID_Type, g_astRxMsgConfig[i].usRxMailBox, g_astRxMsgConfig[i].usRxMask);
    }

    FLEXCAN_DRV_SetRxMaskType(INST_CANCOM2, FLEXCAN_RX_MASK_INDIVIDUAL);
    FLEXCAN_DRV_SetRxIndividualMask(INST_CANCOM2, RX_PHY_ID_TYPE, RX_CAN2_MAILBOX_ID, 0x7FFU);
    
}

/* Config rx MB buffer */
static void Config_Rx_Buffer(void)
{
    uint32_t i;

    /* Configure RX buffer with index RX_MAILBOX for Function ID and Physical ID*/
    for(i = 0u; i < g_ucRxCANMsgIDNum; i++)
    {
#ifdef IsUse_CAN_Pal_Driver
    	/* According to Rx msg ID type to configure MB msg ID type */
		buff_RxTx_Cfg.idType = g_astRxMsgConfig[i].RxID_Type;
        CAN_ConfigRxBuff(&can_pal1_instance, g_astRxMsgConfig[i].usRxMailBox, &buff_RxTx_Cfg, g_astRxMsgConfig[i].usRxID);

#else
        buff_RxTx_Cfg.msg_id_type = g_astRxMsgConfig[i].RxID_Type;
        FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1, g_astRxMsgConfig[i].usRxMailBox, &buff_RxTx_Cfg, g_astRxMsgConfig[i].usRxID);
#endif	//end of IsUse_CAN_Pal_Driver
    }

    FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2, RX_CAN2_MAILBOX_ID, &buff_RxTx_Cfg, 0x110);//DSP_APPL_VER_MSG_ID);
}

/* Config tx MB buffer */
static void Config_Tx_Buffer(void)
{
    /* According to Tx msg ID type to config MB msg ID type */
    buff_RxTx_Cfg.msg_id_type = g_stTxMsgConfig.TxID_Type;

#ifdef IsUse_CAN_Pal_Driver
    /* Config Tx buffer with index Tx mailbox */
    CAN_ConfigTxBuff(&can_pal1_instance, g_stTxMsgConfig.ucTxMailBox, &buff_RxTx_Cfg);
#else
    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, g_stTxMsgConfig.ucTxMailBox, &buff_RxTx_Cfg, g_stTxMsgConfig.usTxID);
    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, g_stTxVerMsgConfig.ucTxMailBox, &buff_RxTx_Cfg, g_stTxVerMsgConfig.usTxID);
    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, g_stTxStateMsgConfig.ucTxMailBox, &buff_RxTx_Cfg, g_stTxStateMsgConfig.usTxID);
    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, TX_MAILBOX_3, &buff_RxTx_Cfg, MSG_ID_CAN2_STATE);
#endif	//end of IsUse_CAN_Pal_Driver

    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2, TX_CAN2_MAILBOX_ID, &buff_RxTx_Cfg, 0x100U);
}

/*Is Rx can message ID? If is rx can message id return TRUE, else return FALSE.*/
static uint8_t IsRxCANMsgId(uint32_t i_usRxMsgId)
{
    uint8_t Index = 0u;

    while(Index < g_ucRxCANMsgIDNum)
    {
        if(i_usRxMsgId  == g_astRxMsgConfig[Index].usRxID )
        {
            return TRUE;
        }

        Index++;
    }

    return FALSE;
}

/*check can transmitted data successfull?*/
static void CheckCANTranmittedStatus(void)
{
    status_t Can_Tx_Statu;

#ifdef IsUse_CAN_Pal_Driver
    Can_Tx_Statu = CAN_GetTransferStatus(&can_pal1_instance, g_stTxMsgConfig.ucTxMailBox);

#else
    Can_Tx_Statu = FLEXCAN_DRV_GetTransferStatus(INST_CANCOM1, g_stTxMsgConfig.ucTxMailBox);
#endif	//end of IsUse_CAN_Pal_Driver

    if(STATUS_SUCCESS == Can_Tx_Statu)
    {
        if(NULL != g_stTxMsgConfig.pfCallBack)
        {
            g_stTxMsgConfig.pfCallBack();
            g_stTxMsgConfig.pfCallBack = NULL;
        }
    }
}

static void CheckCAN2TranmittedStatus(void)
{
    status_t Can_Tx_Statu;

    Can_Tx_Statu = FLEXCAN_DRV_GetTransferStatus(INST_CANCOM2, TX_CAN2_MAILBOX_ID);

    if(STATUS_SUCCESS == Can_Tx_Statu)
    {
        dwCan2TxCnt++;
    }
}


/* Can operation completed callback function */
#ifdef IsUse_CAN_Pal_Driver
static void CAN_RxTx_Interrupt_Handle(uint32_t instance,
                                      flexcan_event_type_t eventType,
                                      uint32_t objIdx,
                                      void *driverState)
{
    uint32_t i;

    DEV_ASSERT(driverState != NULL);

    switch(eventType)
    {
    case CAN_EVENT_RX_COMPLETE:
        RxCANMsgMainFun();
        break;

    case CAN_EVENT_TX_COMPLETE:
        TxCANMsgMainFun();
        break;

    default:
        break;
    }

    /* Enable MB interrupt*/
    for(i = 0u; i < g_ucRxCANMsgIDNum; i++)
    {
        CAN_Receive(&can_pal1_instance,  g_astRxMsgConfig[i].usRxMailBox, &recvMsg);
    }
}

#else
static void CAN0_RxTx_Interrupt_Handle(uint32_t instance,
                                      flexcan_event_type_t eventType,
                                      uint32_t objIdx,
                                      flexcan_state_t *flexcanState)
{
    DEV_ASSERT(driverState != NULL);

    switch(eventType)
    {
    case FLEXCAN_EVENT_RX_COMPLETE:
        RxCANMsgMainFun();

        /* Enable MB interrupt*/
        if(RX_MAILBOX_FUN_ID == objIdx)
        {
            FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_FUN_ID, &recvMsg);
        }

        else if(RX_MAILBOX_PHY_ID == objIdx)
        {
            FLEXCAN_DRV_Receive(INST_CANCOM1, RX_MAILBOX_PHY_ID, &recvMsg);
        }

        else
        {
            ;
        }
        break;

    case FLEXCAN_EVENT_TX_COMPLETE:
        TxCANMsgMainFun();
        break;

    default:
        break;
    }
}



static void CAN2_RxTx_Interrupt_Handle(uint32_t instance,
                                      flexcan_event_type_t eventType,
                                      uint32_t objIdx,
                                      flexcan_state_t *flexcanState)
{
    DEV_ASSERT(driverState != NULL);

    switch(eventType)
    {
    case FLEXCAN_EVENT_RX_COMPLETE:
        RxCAN2MsgMainFun();

        /* Enable MB interrupt*/
        if(RX_CAN2_MAILBOX_ID == objIdx)
        {
            FLEXCAN_DRV_Receive(INST_CANCOM2, objIdx, &xCan2RecvMsg);
        }
        else
        {
            ;
        }
        break;

    case FLEXCAN_EVENT_TX_COMPLETE:
        TxCAN2MsgMainFun();
        break;

    default:
        break;
    }
}



#endif	//end of IsUse_CAN_Pal_Driver

/* Init CAN moudule */
void InitCAN(void)
{
#ifdef IsUse_CAN_Pal_Driver
    /*Init can basical elements */
    CAN_Init(&can_pal1_instance, &can_pal1_Config0);

    /* install can rx and tx interrupt callback function */
    CAN_InstallEventCallback(&can_pal1_instance, (can_callback_t)CAN_RxTx_Interrupt_Handle, NULL);
#else
    /*Init can basical elements */
    FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);

    FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);

    /* install can rx and tx interrupt callback function */
    FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1, (flexcan_callback_t)CAN0_RxTx_Interrupt_Handle, NULL);

    FLEXCAN_DRV_InstallEventCallback(INST_CANCOM2, (flexcan_callback_t)CAN2_RxTx_Interrupt_Handle, NULL);
#endif	//end of IsUse_CAN_Pal_Driver

    /* config MBn to Rx buffer */
    Config_Rx_Buffer();

    /* config MBn to Tx buffer */
    Config_Tx_Buffer();

    /* Can Rx individual filiter */
    CAN_Filiter_RXIndividual();

    /* Start receiving data in RX_MAILBOX and Enable MBn of Rx buffer interrupt */
    {
        uint32_t i = 0u;
        for(i = 0u; i < g_ucRxCANMsgIDNum; i++)
        {
#ifdef IsUse_CAN_Pal_Driver
            CAN_Receive(&can_pal1_instance, g_astRxMsgConfig[i].usRxMailBox, &recvMsg);

#else
            FLEXCAN_DRV_Receive(INST_CANCOM1, g_astRxMsgConfig[i].usRxMailBox, &recvMsg);
#endif	//end of IsUse_CAN_Pal_Driver
        }

        FLEXCAN_DRV_Receive(INST_CANCOM2, RX_CAN2_MAILBOX_ID, &xCan2RecvMsg);
    }

}

///*Init rx can fifo*/
//void InitRxCanFIFO(void)
//{
//    tErroCode eStatus;
//    ApplyFifo((300u), RX_CAN_FIFO, &eStatus);
//    if(ERRO_NONE != eStatus)
//    {
//        while(1);
//    }
//}

/*CAN Rx*/

#if USE_CAN_RX == CAN_RX_INTERRUPUT
void RxCANMsgMainFun(void)
{
    tRxCanMsg stRxCANMsg = {0u};
    uint8_t CANDataIndex = 0u;

#ifdef IsUse_CAN_Pal_Driver
    /* Read CAN massage data from recieve buffer recvMsg */
    stRxCANMsg.usRxDataId = recvMsg.id;
    stRxCANMsg.ucRxDataLen = recvMsg.length;
#else
    stRxCANMsg.usRxDataId = recvMsg.msgId;
    stRxCANMsg.ucRxDataLen = recvMsg.dataLen;
#endif	//end of IsUse_CAN_Pal_Driver

    if( (0u != stRxCANMsg.ucRxDataLen) &&
        (TRUE == IsRxCANMsgId(stRxCANMsg.usRxDataId)))
    {
  
        /*read can message*/
        for(CANDataIndex = 0u; CANDataIndex < stRxCANMsg.ucRxDataLen; CANDataIndex++)
        {
            stRxCANMsg.aucDataBuf[CANDataIndex] = recvMsg.data[CANDataIndex];
        }

		if(TRUE != TP_DriverWriteDataInTP(stRxCANMsg.usRxDataId, stRxCANMsg.ucRxDataLen, stRxCANMsg.aucDataBuf))
		{
			/*here is TP driver write data in TP failed, TP will lost CAN message*/
			while(1)
			{
			}
		}
#if 0  
        /*write data in softer data FIFO*/
        GetCanWriteLen(RX_BUS_FIFO, &xCanWriteLen, &eStatus);
        if((ERRO_NONE == eStatus) && (xCanWriteLen > acuCANMsgLen))
        {
            /*write data in software fifo*/
            WriteDataInFifo(RX_BUS_FIFO, (uint8_t *)&stRxCANMsg, acuCANMsgLen, &eStatus);

            if(ERRO_NONE != eStatus)
            {
                while(1);
            }
        }
        else
        {
            while(1);
        }
#endif		
    }
}

void RxCAN2MsgMainFun(void)
{
    uint8_t i = 0u;
    stCan2RxMsg.usRxDataId = xCan2RecvMsg.msgId;
    stCan2RxMsg.ucRxDataLen = xCan2RecvMsg.dataLen;

    if(0u != stCan2RxMsg.ucRxDataLen)
    {
        dwCan2RxCnt++;

        /*read can message*/
        for(i = 0u; i < stCan2RxMsg.ucRxDataLen; i++)
        {
            stCan2RxMsg.aucDataBuf[i] = xCan2RecvMsg.data[i];
        }
    }

    if (stCan2RxMsg.usRxDataId == MSG_ID_C28X_APP_VER)
    {
        blGotC28xApplVerMsg = true;
        bC28xApplVerMajor = stCan2RxMsg.aucDataBuf[0];
        bC28xApplVerMinor = stCan2RxMsg.aucDataBuf[1];
        bC28xApplVerDebug = stCan2RxMsg.aucDataBuf[2];
    }
}


#else

#endif	////end of USE_CAN_RX == CAN_RX_INTERRUPUT

/* CAN Tx */
#if USE_CAN_TX == CAN_TX_INTERRUPUT
void TxCANMsgMainFun(void)
{
    /*check */
    CheckCANTranmittedStatus();
}

void TxCAN2MsgMainFun(void)
{
    /*check */
    CheckCAN2TranmittedStatus();
}

#else

#endif	//end of USE_CAN_TX == CAN_TX_INTERRUPUT

/* CAN communication error  */
#if USE_CAN_ERRO == CAN_ERRO_INTERRUPUT

#else
void CANErroMainFun(void)
{

}
#endif	//end of USE_CAN_ERRO == CAN_ERRO_INTERRUPUT

/*can transmite message*/
uint8_t TransmiteCANMsg(const uint32_t i_usCANMsgID,
                        const uint8_t i_ucDataLen,
                        const uint8_t *i_pucDataBuf, 
                        const tpfNetTxCallBack i_pfNetTxCallBack,
                        const uint32_t i_txBlockingMaxtime)
{

    status_t CANTxStatus = STATUS_BUSY;
    uint8_t ret = 0u;
    
    /* change Tx massage length */
    buff_RxTx_Cfg.data_length = i_ucDataLen;

#ifdef IsUse_CAN_Pal_Driver
    uint8_t	i;
    can_message_t message;

    DEV_ASSERT(i_pucDataBuf != NULL);

    if(i_usCANMsgID != g_stTxMsgConfig.usTxID)
    {
        return FALSE;
    }

    message.cs = 0u;
    message.id = i_usCANMsgID;
    message.length = i_ucDataLen;

    for(i = 0u; i < i_ucDataLen; i++)
    {
        message.data[i] = i_pucDataBuf[i];
    }

    CAN_Send(&can_pal1_instance, g_stTxMsgConfig.ucTxMailBox, &message);

#else
    DEV_ASSERT(i_pucDataBuf != NULL);

    if(i_usCANMsgID != g_stTxMsgConfig.usTxID)
    {
        return FALSE;
    }

    CANTxStatus = FLEXCAN_DRV_Send(INST_CANCOM1, g_stTxMsgConfig.ucTxMailBox, &buff_RxTx_Cfg, i_usCANMsgID, i_pucDataBuf);

    g_stTxMsgConfig.pfCallBack = i_pfNetTxCallBack;
    
#endif	//end of IsUse_CAN_Pal_Driver

    if(STATUS_SUCCESS == CANTxStatus)
    {
        ret = TRUE;
    }
    else
    {
        ret = FALSE;
    }
        
    return ret;
}

/*transmitted can message*/
static uint8_t gs_ucIsTransmittedMsg = FALSE;

/*transmitted can message callback*/
void TransmittedCanMsgCallBack(void)
{
    gs_ucIsTransmittedMsg = TRUE;
}

/*set wait transmitted can message*/
void SetWaitTransmittedMsg(void)
{
    gs_ucIsTransmittedMsg = FALSE;
}

/*Is transmitted can messag? If transmitted return TRUE, else return FALSE.*/
uint8_t IsTransmittedMsg(void)
{
    return gs_ucIsTransmittedMsg;
}


uint8_t sC28xApplVerGet(uint8_t *pMajor, uint8_t *pMinor, uint8_t *pDebug)
{
    if (blGotC28xApplVerMsg == true)
    {
        *pMajor = bC28xApplVerMajor;
        *pMinor = bC28xApplVerMinor;
        *pDebug = bC28xApplVerDebug;
        return 0;
    }
    else
    {
        return 1U;
    }
}








