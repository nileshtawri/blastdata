/**
 * @file        Obc.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_OBC_H
#define         DEF_OBC_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------







//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------


typedef enum OBC_STATE_E
{
    OBC_SLEEP = 0,
    OBC_POWER_ON,
    OBC_BOOT_RUN,
    OBC_APPL_RUN,
    OBC_POWER_OFF,
    OBC_STATE_UNKONW,
}obc_state_t;


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------

extern void sObcBootRomInit(void);
extern void sObcBootRomPowerOn(void);
extern void sObcBootRomPowerOff(void);
//extern void sObcBootRomStop(void);
//extern void sObcBootRomStartXfer(void);
extern void sObcBootRomTask(void);
extern void sObcBootromStateGet(obc_state_t* pState);
extern void sObcBootromEntryPointSet(uint32_t dwAddr);
extern void sObcBootromTargetAddrSet(uint32_t dwAddr);
extern void sObcBootromCodeSizeSet(uint32_t dwByteSize);
//extern void sObcBootromSectorSizeSet(uint16_t wWordCount);
extern void sObcApplImageVerSet(uint8_t bMajor, uint8_t bMinor, uint8_t bDebug);
extern void sObcApplImageVerGet(uint8_t* pMajor, uint8_t* pMinor, uint8_t* pDebug);


extern uint8_t sObcBootromXferHeader(void);
extern uint8_t sObcBootromXfer2ndHeader(void);
extern uint8_t sObcBootromXferSector(const uint8_t* pBuf, uint16_t wBytes);
extern uint8_t sObcBootromXferStop(void);
extern void sObcBootloaderRun(bool *pReflashStatus);
extern void sObcApplicationRun(bool *pDependenceStatus);
extern bool sObcDownloadStatusGet(void);
extern bool sObcDependencyStatusGet(void);

#endif






