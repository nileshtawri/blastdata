/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */
/*!
 * @file bootloader_main.c
 * 
 * @brief: Add your description here for this file.
 *
 * @page misra_violations MISRA-C:2012 violations
 *
 * @section Rule_X-Y Rule: X.Y (Advisory/Required)
 * Violates MISRA 2012 Advisory Rule X.Y, Rule description here.
 *
 * @par Version Histroy
<pre><b>
Version:   Author:       Date&&Time:      Revision Log: </b>
 V1.0.0  Tomlin Tang  2019-03-25 11:50:56  First Creat
When you update, please do not forgot to del me and add your info at here.
</pre>
 */

#include "bootloader_main.h"


/*******************************************************************************
 * User Include
 ******************************************************************************/
#include "includes.h"
#include "uds_app.h"
#include "TP.h"
#include "fls_app.h"
#include "timer_hal.h"
#include "watchdog_hal.h"
#include "boot.h"
#include "CRC_HAL.h"
#include "can_cfg.h"
#include "Version.h"
#include "boot.h"
#include "she.h"
#include "can_driver.h"

#define     APM_STATE_BOOT                      8U

static void SendVerMsgFun(void);
static void SendAPmStateMsgFun(void);

static void SendObcCtrlMsg(void);


static bool blIsAppValid = FALSE;


/**
 * @brief   send APM_BOOT_VER CAN message
 */
static void SendVerMsgFun(void)
{
    uint8_t bMbox = g_stTxVerMsgConfig.ucTxMailBox;
    uint32_t dwCanId = g_stTxVerMsgConfig.usTxID;
    uint8_t abBuf[8] = {0};

    abBuf[0] = xBootVerInfo.bVerMajor;
    abBuf[1] = xBootVerInfo.bVerMinor;
    abBuf[2] = xBootVerInfo.bVerDebug;
    abBuf[3] = xBootVerInfo.bBuildHostId;
    abBuf[4] = (uint8_t)(xBootVerInfo.wBuildYear >> 8);
    abBuf[5] = (uint8_t)xBootVerInfo.wBuildYear;
    abBuf[6] = xBootVerInfo.bBuildMonth;
    abBuf[7] = xBootVerInfo.bBuildDay;

    FLEXCAN_DRV_Send(INST_CANCOM1, bMbox, &buff_RxTx_Cfg, dwCanId, abBuf);
}

static void SendObcCtrlMsg(void)
{
    uint8_t bMbox = TX_CAN2_MAILBOX_ID;
    uint32_t dwCanId = 0x100U;
    uint8_t abBuf[8] = {0};

    abBuf[0] = 0xCAU;
    abBuf[1] = 0xFEU;
    abBuf[2] = 0xBEU;
    abBuf[3] = 0xEFU;
    abBuf[4] = (uint8_t)(dwCan2TxCnt >> 8);
    abBuf[5] = (uint8_t)dwCan2TxCnt;
    abBuf[6] = (uint8_t)(dwCan2RxCnt >> 8);
    abBuf[7] = (uint8_t)dwCan2RxCnt;

    FLEXCAN_DRV_Send(INST_CANCOM2, bMbox, &buff_RxTx_Cfg, dwCanId, abBuf);



    abBuf[0] = 0xCAU;
    abBuf[1] = 0xFEU;
    abBuf[2] = 0xBEU;
    abBuf[3] = 0xEFU;
    abBuf[4] = (uint8_t)(dwCan2TxCnt >> 8);
    abBuf[5] = (uint8_t)dwCan2TxCnt;
    abBuf[6] = (uint8_t)(dwCan2RxCnt >> 8);
    abBuf[7] = (uint8_t)dwCan2RxCnt;

    FLEXCAN_DRV_Send(INST_CANCOM1, TX_MAILBOX_3, &buff_RxTx_Cfg, MSG_ID_CAN2_STATE, abBuf);
}

/**
 * @brief   send APM_STATE CAN message
 */
static void SendAPmStateMsgFun(void)
{
    uint8_t bMbox = g_stTxStateMsgConfig.ucTxMailBox;
    uint32_t dwCanId = g_stTxStateMsgConfig.usTxID;
    uint8_t abBuf[8] = {0};

    abBuf[0] = APM_STATE_BOOT;
    abBuf[1] = (blIsAppValid == FALSE) ? 0x01U : 0;

    FLEXCAN_DRV_Send(INST_CANCOM1, bMbox, &buff_RxTx_Cfg, dwCanId, abBuf);
}



/*FUNCTION**********************************************************************
 *
 * Function Name : BOOTLOADER_MAIN_Init
 * Description   : This function initial this module.
 *
 * Implements : BOOTLOADER_MAIN_Init_Activity
 *END**************************************************************************/
void BOOTLOADER_MAIN_Init(void (*pfBSP_Init)(void), void (*pfAbortTxMsg)(void))
{
	/*Is power on ?*/
	if(TRUE == Boot_IsPowerOnTriggerReset())
	{
		Boot_PowerONClearAllFlag();
	}

	/*Check jump to APP or not.*/
	//Boot_JumpToAppOrNot();
	
	/*User Init: clock CAN Lin etc..*/
	if(NULL_PTR != pfBSP_Init)
	{
		/*do BSP init*/
		(*pfBSP_Init)();
	}

    blIsAppValid = Boot_IsAPPValid();
	
	BOOTLOADER_DEBUG_Init();

    APPDebugPrintf("--- Build %s ---\n", xBootVerInfo.abBuildDateTime);

    if(TRUE != CRC_HAL_Init())
    {
    	APPDebugPrintf("CRC_HAL_Init failed!\n");
    }

	WATCHDOG_HAL_Init();

	TIMER_HAL_Init();

	TP_Init();

	if(TRUE != FLASH_HAL_APPAddrCheck())
	{
		APPDebugPrintf("\n FLASH_HAL_APPAddrCheck check error!\n");
	}

	UDS_Init();

	Boot_CheckReqBootloaderMode();

	TP_RegisterAbortTxMsg(pfAbortTxMsg);

	FLASH_APP_Init();
}

/*FUNCTION**********************************************************************
 *
 * Function Name : BOOTLOADER_MAIN_Demo
 * Description   : This function initial this module.
 *
 * Implements : BOOTLOADER_MAIN_Demo_Activity
 *END**************************************************************************/
void BOOTLOADER_MAIN_Demo(void)
{
    static uint8_t b100msCnt = 0;
    bool blIsUdsInDefaultSessin = FALSE;
    static uint32_t dwRxCnt = 0;
    uint8_t i;

#ifdef EN_DEBUG_IO
	static uint16 timerCnt1Ms = 0u;
#endif

    blIsUdsInDefaultSessin = IsCurDefaultSession();
	
	if(TRUE == TIMER_HAL_Is1msTickTimeout())
	{
		TP_SystemTickCtl();
		
		UDS_SystemTickCtl();

#ifdef EN_DEBUG_IO		
		/*tigger LED*/
		timerCnt1Ms++;
		if(250u == timerCnt1Ms)
		{
			timerCnt1Ms = 0u;

			ToggleDebugIO();
		}
#endif

        if(dwRxCnt != dwCan2RxCnt)
        {
            dwRxCnt = dwCan2RxCnt;

            DebugPrintf("CAN2 %05d: [0x%03X] ", dwCan2RxCnt, stCan2RxMsg.usRxDataId);
            for(i = 0u; i < stCan2RxMsg.ucRxDataLen; i++)
            {
                DebugPrintf("%02X ", stCan2RxMsg.aucDataBuf[i]);
            }
            DebugPrintf("\n");
        }

	}

	/*fed watchdog every 100ms*/
	if(TRUE == TIMER_HAL_Is100msTickTimeout())
	{
		WATCHDOG_HAL_Fed();

        if(blIsUdsInDefaultSessin == TRUE)
        {
            SendVerMsgFun();

            SendObcCtrlMsg();

            b100msCnt++;
            if(b100msCnt == 5U)
            {
                b100msCnt = 0;

                SendAPmStateMsgFun();
            }
        }
	}

	TP_MainFun();

	UDS_MainFun();

	Flash_OperateMainFunction();	
}

/*FUNCTION**********************************************************************
 *
 * Function Name : BOOTLOADER_MAIN_Deinit
 * Description   : This function initial this module.
 *
 * Implements : BOOTLOADER_MAIN_Deinit_Activity
 *END**************************************************************************/
void BOOTLOADER_MAIN_Deinit(void)
{

	
}
/******************************************************************************
 * EOF
 *****************************************************************************/
