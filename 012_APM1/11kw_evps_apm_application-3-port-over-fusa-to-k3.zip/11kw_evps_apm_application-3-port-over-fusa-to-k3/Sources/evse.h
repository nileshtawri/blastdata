/**
 * @file        Evse.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_EVSE_H
#define         DEF_EVSE_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum EVSE_STD_E
{
    EVSE_STD_INVALID = 0,
    EVSE_STD_J1772,
    EVSE_STD_GBT18487,
    EVSE_STD_IEC61851
}e_evse_std_t;

typedef enum EVSE_PROX_STATE
{
	CON_DISCONNECTED = 0,
	CON_LATCH_DEPRESSED,
	CON_LATCH_RELEASED
}prox_state_t;

enum
{
	VENT_REQ_NONE = 0,
	VENT_REQ_D,
	VENT_REQ_CHANGE_C2D,
	VENT_REQ_CHANGE_D2C
};

enum
{
	CP_DUTY_RANGE_INHIBIT = 0,
	CP_DUTY_RANGE_PER_5,
	CP_DUTY_RANGE_PER_10,
	CP_DUTY_RANGE_PER_10_85,
	CP_DUTY_RANGE_PER_85_9X,
	CP_DUTY_RANGE_PER_96,
	CP_DUTY_RANGE_PER_100
};


typedef enum EVSE_PILOT_STATE
{
    EVSE_PILOT_STATE_A = 0,
    EVSE_PILOT_STATE_B,
    EVSE_PILOT_STATE_C,
    EVSE_PILOT_STATE_D,
    EVSE_PILOT_STATE_E,
    EVSE_PILOT_STATE_F,
}pilot_state_t;

#if 0
typedef enum 
{
    EVSE_PROX_STATE_DISCONNECT = 0,
    EVSE_PROX_STATE_DEPRESSED,
    EVSE_PROX_STATE_RELEASED,
};
#endif

typedef struct PACKED IF_EVSE_INPUT_DATA_S
{
    pilot_state_t   eCpState;                   // control pilot state
    prox_state_t    ePpState;                   // proximity present state
    e_bool_t        eHavePulse;                 // control pilot has pulse or not
    e_bool_t        eObcOkCheck;                // is time to check OBC_OK_DIH
    f32             flCpDuty;                   // control pilot duty, unit: 1%
    f32             flCpFreq;                   // control pilot frequency, unit: 1Hz
}x_if_ei_t;

typedef struct PACKED IF_EVSE_OUTPUT_DATA_S
{
    e_bool_t        eCpReadyDoh;                // ready to close the S2 switch
    e_bool_t        eCpState_D_Doh;
    e_bool_t        eCpState_C_Doh;
    f32             flEvseImax;                 // EVSE's max current capability
}x_if_eo_t;

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sEvseIfInit(void);
extern void sEvseInit(void);
extern void sEvseTask(void);
extern void sEvseObcEnableSet(bool blEnable);
extern void sEvseVentReqSet(bool blVent);

#endif




