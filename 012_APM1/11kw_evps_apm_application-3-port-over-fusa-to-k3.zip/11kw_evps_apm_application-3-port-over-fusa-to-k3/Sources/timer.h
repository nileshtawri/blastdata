/**
 * @file        Timer.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef DEF_TIMER_H
#define DEF_TIMER_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include "type.h"


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

/* LPIT channel used */
#define LPIT_CHANNEL_0                          0UL
#define LPIT_Channel_0_IRQ                      LPIT0_Ch0_IRQn


#define LPIT_CHANNEL_1                          1UL
#define LPIT_Channel_1_IRQ                      LPIT0_Ch1_IRQn

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef void (*timer_func_t)(void);

typedef enum TIMER_ID_E
{
    TIMER_ID_IDLE,
    TIMER_ID_ADC,
    TIMER_ID_PWM,
    TIMER_ID_GPIO,
    TIMER_ID_CAN0_TASK,
    TIMER_ID_CAN2_TASK,
    TIMER_ID_UART,
    TIMER_ID_OBC,
    TIMER_ID_EVSE,
    TIMER_ID_HOUSE,
    TIMER_ID_TEST,
    TIMER_ID_EEP,
    TIMER_ID_ISOTP,
    TIMER_ID_UDS,
    TIMER_ID_TP_MAINFUN,
    TIMER_ID_ISO_TP_SEND_MSG,
    TIMER_ID_UDS_MAINFUN,
	TIMER_ID_SOFTSTART,
    TIMER_ID_CAN2_TP,
    TIMER_ID_NM,
    #if 1
    TIMER_ID_NM_TIMEOUT,
    TIMER_ID_REPEAT_MESSAGE,
    TIMER_ID_WAIT_BUS_SLEEP,
    TIMER_ID_APPL_FRAME_DELAY,
    #endif
    TIMER_ID_END
}timer_id_t;


typedef struct TIMER_S
{
    timer_id_t eTid;
    bool blEnable;
    bool blOneShot;
    u32 dwPeriod;    
    u32 dwRemain;
    timer_func_t pFunc;
}timer_t;

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------

extern void sTimerInit(void);
extern void sTimerRun(void);
extern void sTimerReset(timer_id_t eTid);
extern void sTimerStart(timer_id_t eTid);
extern void sTimerStop(timer_id_t eTid);
extern void sTimerPeriodSet(timer_id_t eTid, u32 dwTime);
extern void sTimerRemainSet(timer_id_t eTid, u32 dwTime);
extern bool sblTimerIsEnable(timer_id_t eTid);
extern u32 sdwTimerTickGet(void);
#endif


