/**
 * @file        csec.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "Cpu.h"
#include "type.h"


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static const uint8_t g_defaultKey[16] = {
    0x00U, 0x01U, 0x02U, 0x03U, 0x04U, 0x05U, 0x06U, 0x07U,
    0x08U, 0x09U, 0x0aU, 0x0bU, 0x0cU, 0x0dU, 0x0eU, 0x0fU};

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief       Initial CSEC Module
 */
void sCsecInit(void)
{
    CSEC_DRV_Init(&DrvCsec_State);
}

/**
 * \brief is the MASTER_ECU_KEY empty
 * \param[out]   pbBuf   point to output buffer for random number (16bytes)
 * \return 0 if PASS else otherwise
 */
uint8_t sCsecGenerateRandomNumber(uint8_t *pbBuf)
{
    status_t xStatus;
    uint8_t bRet = 0;

    xStatus = CSEC_DRV_InitRNG();
    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_GenerateRND(pbBuf);

    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 2U;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Decryption by default key
 * \param[in]   pbCipherText    point to input cipher text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbPlainText     point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS else otherwise
 */
uint8_t sCsecDecEcbByDefaultKey(const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_LoadPlainKey(g_defaultKey);

    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_DecryptECB(CSEC_RAM_KEY,
                                  pbCipherText,
                                  dwSize,
                                  pbPlainText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Encryption by default key
 * \param[in]   pbPlainText     point to input plain text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbCipherText    point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS else otherwise
 */
uint8_t sCsecEncEcbByDefaultKey(const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_LoadPlainKey(g_defaultKey);

    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 1U;
        goto ERROR;
    }

    xStatus = CSEC_DRV_EncryptECB(CSEC_RAM_KEY,
                                  pbPlainText,
                                  dwSize,
                                  pbCipherText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Decryption by the KEY_1
 * \param[in]   pbCipherText    point to input cipher text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbPlainText     point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS, 1 if no key, 2 otherwise
 */
uint8_t sCsecDecEcbByUserKey1(  const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_DecryptECB(CSEC_KEY_1,
                                  pbCipherText,
                                  dwSize,
                                  pbPlainText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        if(xStatus == STATUS_SEC_KEY_EMPTY)
        {
            bRet = 1U;
            goto ERROR;
        }

        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}

/**
 * \brief ECB Encryption by the KEY_1
 * \param[in]   pbPlainText     point to input plain text buffer
 * \param[in]   dwSize          input buffer size, bytes
 * \param[out]  pbCipherText    point to output buffer
 * \param[in]   dwTimeout       decryption timeout limit (ms)
 * \return 0 if PASS, 1 if no key, 2 otherwise
 */
uint8_t sCsecEncEcbByUserKey1(  const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout)
{
    uint8_t bRet = 0;
    status_t xStatus;

    xStatus = CSEC_DRV_EncryptECB(CSEC_KEY_1,
                                  pbPlainText,
                                  dwSize,
                                  pbCipherText,
                                  dwTimeout);

    if(xStatus != STATUS_SUCCESS)
    {
        if(xStatus == STATUS_SEC_KEY_EMPTY)
        {
            bRet = 1U;
            goto ERROR;
        }

        bRet = 2U;
        goto ERROR;
    }

ERROR:
    return bRet;
}
