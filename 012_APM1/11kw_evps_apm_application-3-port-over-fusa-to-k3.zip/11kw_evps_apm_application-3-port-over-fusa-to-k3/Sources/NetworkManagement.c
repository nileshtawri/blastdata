/**
 * @file        NetworkManagement.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "type.h"
#include "can.h"
#include "NetworkManagement.h"
#include "timer.h"
#include "housekeep.h"
#include "nvm.h"
#include "if.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

typedef enum NM_MODE_E
{
    NM_MODE_INVALID                         = 0,
    BUS_SLEEP_MODE                          = 0x01U,
    PREPARE_BUS_SLEEP_MODE                  = 0x02U,
	NETOWRK_MODE                            = 0x03U,
	REPEAT_MESSAGE_STATE                    = 0x04U,
	NORMAL_OPERATION_STATE                  = 0x05U,
	READY_SLEEP_STATE                       = 0x06U,
}NM_MODE_T;



//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static NM_MODE_T bNMOperation = BUS_SLEEP_MODE;
static NM_MODE_T bLastNMOperation = NM_MODE_INVALID;
static bool blRepeatMsgTimeout = false;
static bool blNmTimeout = false;

static const x_if_ho_t *pxIfHoDa = NULL;
static const net_conf_t *pxNetConf = NULL;

static u8 bNmTransmit = NM_CYCLE_TIME/10;
static u8 bNMControlBitVector = 0;
static bool blApplFrameEnable = false;
static bool blNmFrameEnable = false;
static bool blPrepareBusSleepTimeout = false;
static bool blNmImmediateTransmitEnable = false;
static bool blNMRelease = true;
static u8 bNMImmediateNMTimes = 0;
static bool blCANRxEventNM = false;
static bool blRepeatMessageReq = false;
//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------

/**
 * @brief        initial Network Management parameters
 */
void sNmInit (void)
{
    sNvmNetConfDefaultPtrGet(&pxNetConf);              /* get NM configuration data */

    sTimerPeriodSet(TIMER_ID_NM_TIMEOUT, pxNetConf->xNmConf.wNmTimeoutTimer);
    sTimerPeriodSet(TIMER_ID_REPEAT_MESSAGE, pxNetConf->xNmConf.wRepeatMsgTimer);
    sTimerPeriodSet(TIMER_ID_WAIT_BUS_SLEEP, pxNetConf->xNmConf.wWaitBusSleepTimer);
    sTimerPeriodSet(TIMER_ID_APPL_FRAME_DELAY, pxNetConf->xNmConf.w1stFrameDelayTimer);
}

u8 sbNmControlBitVectorGet(void)
{
    return bNMControlBitVector;
}

/**
 * @brief        Network Management Task
 */
void sNmTask (void)
{
	fs45_rx_data_t xRxData;
    x_conf_data_t *pxConf;
	status_t xStatus;
    bool blNmEnable = false;

    #if (HAVE_SBC_FUNCTION != 0)
    bool blCanWakeUp = true;
    #endif

    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_HO, false, (const void**)&pxIfHoDa);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */

    sNvmConfDataPtrGet(&pxConf);

    blNmEnable = !(pxConf->baDisa[CONF_DISA_NM] == (u8)'T');

    #if (HAVE_SBC_FUNCTION != 0)
    blCanWakeUp = !(pxConf->baDisa[CONF_DISA_CAN_WAKEUP] == (u8)'T');
    #endif

	if(blNmEnable == true)
	{
		switch(bNMOperation)
		{
			case BUS_SLEEP_MODE:
                blApplFrameEnable = false;
				blNmFrameEnable = false;
                blNMRelease = false;

                #if (HAVE_SBC_FUNCTION != 0)
				xStatus = (u16)FS45_ReadRegister(  FS45_M_WU_SOURCE_ADDR,
                                                    &xRxData);
                #else
                xStatus = STATUS_SUCCESS;
                xRxData.readData = FS45_R_M_IO_0_WU_MASK;
                #endif

				if(xStatus == STATUS_SUCCESS)
				{
					if((xRxData.readData & FS45_R_M_IO_0_WU_MASK) != 0)
					{
                        #if (HAVE_DEBUG_UART != 0)
				        DebugPrint("[NM] Active Wakeup\n");
				        #endif

						//Active Wake Up
						bNMControlBitVector |= REPEAT_MESSAGE_REQUEST_BIT;
						bNMControlBitVector |= ACTIVE_WAKEUP_BIT;

						bNmTransmit = NM_IMMEDIATE_CYCLE_TIME/10;
						bNMImmediateNMTimes = NM_IMMEDIATE_NM_TIMES;
						blNmImmediateTransmitEnable = true;
					}
					else
					{
                        #if (HAVE_DEBUG_UART != 0)
				        DebugPrint("[NM] Passive Wakeup\n");
				        #endif

						//Passive Wake Up
						bNMControlBitVector &= ~REPEAT_MESSAGE_REQUEST_BIT;
						bNMControlBitVector &= ~ACTIVE_WAKEUP_BIT;

						bNmTransmit = NM_CYCLE_TIME/10;
						bNMImmediateNMTimes = 0;
						blNmImmediateTransmitEnable = false;
					}

                    #if (HAVE_DEBUG_UART != 0)
    		        DebugPrint("[NM] BUS_SLEEP -> REPEAT_MSG\n");
    		        #endif

                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(1, bNMControlBitVector, bNmTransmit, bNMImmediateNMTimes);
                    #endif

    				bNMOperation = REPEAT_MESSAGE_STATE;
				}
				break;
			case PREPARE_BUS_SLEEP_MODE:
				if(bLastNMOperation != PREPARE_BUS_SLEEP_MODE)
				{
					blApplFrameEnable = false;
					blNmFrameEnable = false;
					blPrepareBusSleepTimeout = false;
					sTimerPeriodSet(TIMER_ID_WAIT_BUS_SLEEP, NM_WAIT_BUS_SLEEP_TIME);
					sTimerStart(TIMER_ID_WAIT_BUS_SLEEP);
					bLastNMOperation = PREPARE_BUS_SLEEP_MODE;
				}

				if(blCANRxEventNM == true)
				{
					sTimerRemainSet(TIMER_ID_WAIT_BUS_SLEEP, NM_WAIT_BUS_SLEEP_TIME);
				}

				if(blRepeatMessageReq == true)
				{
                    #if (HAVE_DEBUG_UART != 0)
    		        DebugPrint("[NM] PREPARE_BUS_SLEEP -> REPEAT_MSG\n");
    		        #endif

                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(2, bNMControlBitVector, bNmTransmit, 0);
                    #endif

					sTimerStop(TIMER_ID_WAIT_BUS_SLEEP);
					bNMOperation = REPEAT_MESSAGE_STATE;
				}

				if(blPrepareBusSleepTimeout)
				{
                    #if (HAVE_DEBUG_UART != 0)
    		        DebugPrint("[NM] PREPARE_BUS_SLEEP timeout, SBC Sleep\n");
    		        #endif

					if(pxIfHoDa->eApmWorkMode == APM_MODE_LATCH)
					{
                        #if (HVAE_DEGBU_NM != 0)
                        sCanTxNmDebug(4, bNMControlBitVector, bNmTransmit, 0);
                        #endif

                        #if (HAVE_SBC_FUNCTION != 0)
						(void)FS45_CAN_SetMode(fs45CanModeSleepNoWakeup, true);
						(void)FS45_SetLowPowerMode(false);
                        #else
                        #if (HAVE_DEBUG_UART != 0)
    		            DebugPrint("[NM] SBC Low Power without CAN wake up\n");
    		            #endif
                        #endif
					}
					else
					{
                        #if (HVAE_DEGBU_NM != 0)
                        sCanTxNmDebug(5, bNMControlBitVector, bNmTransmit, 0);
                        #endif

                        #if (HAVE_SBC_FUNCTION != 0)
                        if (blCanWakeUp == false)
                        {
                            (void)FS45_CAN_SetMode(fs45CanModeSleepNoWakeup, true);
                        }
						(void)FS45_SetLowPowerMode(false);
                        #else
                        #if (HAVE_DEBUG_UART != 0)
    		            DebugPrint("[NM] SBC Low Power\n");
    		            #endif
                        #endif
					}
				}
				break;
			case REPEAT_MESSAGE_STATE:
				if(bLastNMOperation != REPEAT_MESSAGE_STATE)
				{
					blNmFrameEnable = true;
					blNmTimeout = false;
					blRepeatMsgTimeout = false;
					sTimerPeriodSet(TIMER_ID_REPEAT_MESSAGE, NM_REPEAT_MESSAGE_TIME);
					sTimerStart(TIMER_ID_REPEAT_MESSAGE);
					sTimerPeriodSet(TIMER_ID_NM_TIMEOUT, NM_TIMEOUT_TIME);
					sTimerStart(TIMER_ID_NM_TIMEOUT);
					bLastNMOperation = REPEAT_MESSAGE_STATE;
				}

				//Leave  Repeat Message State
				if(blRepeatMsgTimeout == true)
				{
					blRepeatMessageReq = false;

					if(blNMRelease == true)    // Network Released
					{
                        #if (HVAE_DEGBU_NM != 0)
                        sCanTxNmDebug(6, bNMControlBitVector, bNmTransmit, 0);
                        #endif

						bNMOperation = READY_SLEEP_STATE;
					}
					else                        //Network Requested
					{
                        #if (HVAE_DEGBU_NM != 0)
                        sCanTxNmDebug(7, bNMControlBitVector, bNmTransmit, 0);
                        #endif

						bNMOperation = NORMAL_OPERATION_STATE;
					}
				}
				break;
			case NORMAL_OPERATION_STATE:
				if(bLastNMOperation != NORMAL_OPERATION_STATE)
				{
					blNmFrameEnable = true;
					bLastNMOperation = NORMAL_OPERATION_STATE;
				}

				if(blRepeatMessageReq == true)
				{
                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(8, bNMControlBitVector, bNmTransmit, 0);
                    #endif

					bNMOperation = REPEAT_MESSAGE_STATE;
				}

				if(blNMRelease == true)
				{
                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(9, bNMControlBitVector, bNmTransmit, 0);
                    #endif

					bNMOperation = READY_SLEEP_STATE;
				}
				break;
			case READY_SLEEP_STATE:
				if(bLastNMOperation != READY_SLEEP_STATE)
				{
					blNmFrameEnable = false;
					bLastNMOperation = READY_SLEEP_STATE;
				}

				if(blRepeatMessageReq == true)
				{
                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(10, bNMControlBitVector, bNmTransmit, 0);
                    #endif

					bNMOperation = REPEAT_MESSAGE_STATE;
				}

				if(blNmTimeout == true)
				{
                    #if (HVAE_DEGBU_NM != 0)
                    sCanTxNmDebug(11, bNMControlBitVector, bNmTransmit, 0);
                    #endif

					bNMOperation = PREPARE_BUS_SLEEP_MODE;
				}
				break;
			default:
				;
				break;
		}

		if (blCANRxEventNM == true)   // This event has to trigger before then 2000 laps to prevent system to go to sleep mode.
		{
			sTimerRemainSet(TIMER_ID_NM_TIMEOUT, NM_TIMEOUT_TIME);
			blCANRxEventNM = false;
		}
	}
	else
	{
		blApplFrameEnable = true;
		blNmFrameEnable = false;
		blPrepareBusSleepTimeout = true;
	}
}

/**
 * @brief       Process Network Management Timer Action
 */
void sNmTimerProcess (void)
{
	switch(bNMOperation)
	{
		case PREPARE_BUS_SLEEP_MODE:
			blPrepareBusSleepTimeout = true;
			break;
		case REPEAT_MESSAGE_STATE:
			blRepeatMsgTimeout = true;
			break;
		default:
			;
			break;
	}
}

/**
 * @brief       Process NM Frame Timeout Action
 */
void sNmFrameTimeoutProcess (void)
{
	if(bNMOperation == READY_SLEEP_STATE)
	{
		sTimerStop(TIMER_ID_NM_TIMEOUT);
		blNmTimeout = true;
	}
	else
	{
		blNmTimeout = false;
	}
}

void sNmApplFrameEnable (void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrint("[NM] ApplFrameEnable\n");
    #endif    

	blApplFrameEnable = true;
}


void sNmApplFrameEnableSet (bool blEnable)
{
	blApplFrameEnable = blEnable;
}

bool sblNmApplFrameEnableGet (void)
{
	return blApplFrameEnable;
}

void sNmFrameEnableSet (bool blEnable)
{
    blNmFrameEnable = blEnable;
}

bool sblNmFrameEnableGet (void)
{
	return blNmFrameEnable;
}

bool sblPrepareBusSleepGet (void)
{
    return blPrepareBusSleepTimeout;
}


bool sblNmImmediateTransmitEnableGet (void)
{
    return blNmImmediateTransmitEnable;
}


u8 sbNmTransmitGet (void)
{
    return bNmTransmit;
}

void sNmReleaseSet (bool blRelease)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrint("[NM] blNMRelease=%d\n", blRelease);
    #endif 

    blNMRelease = blRelease;
}


void sNmImmediateFrameCount(void)
{
    if (bNMImmediateNMTimes > 1)
    {
        bNMImmediateNMTimes--;
    }
    else
    {
        if(blNmImmediateTransmitEnable)
		{
			bNMControlBitVector &= ~REPEAT_MESSAGE_REQUEST_BIT;

			bNmTransmit = NM_CYCLE_TIME/10;
			blNmImmediateTransmitEnable = false;
		}
    }
}

void sNmRxEventSet(void)
{
    blCANRxEventNM = true;
}

void sNmRepeatMessageReqSet(void)
{
    blRepeatMessageReq = true;
}

