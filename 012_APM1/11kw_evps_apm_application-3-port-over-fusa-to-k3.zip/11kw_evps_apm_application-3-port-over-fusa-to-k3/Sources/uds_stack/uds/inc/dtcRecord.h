/**
 * @file        dtcRecord.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef DTC_H_
#define DTC_H_



//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------
typedef struct PACKED snapshot_record_s
{
    u16 wYear;
    u8 bMonth;
    u8 bDay;
    u8 bHour;
    u8 bMinute;
    u8 bSecond;
    u8 b100ms;

    u8 bApmIgnStatus;
    u8 bHvAuxEnStatus;
    u8 bApmModeCmd;
    u8 bApmWorkMode;
    f32 flLvdcVcmd;
    f32 flLvdcIcmd;
    f32 flLvIoutLimit;
    u64 qwApmErrorFlag;
    f32 flApmHvdcVolt;
    f32 flApmHvdcCurr;
    f32 flApmLvdcVolt;
    f32 flApmLvdcCurr;
    f32 flApmTempPcb;
    f32 flApmTempSr;
    f32 flApmTempCool;
    f32 flApmLvAuxVolt;
    f32 flApmBatVolt;

    u8 bObcModeCmd;
    u8 bObcWorkMode;
    f32 flHvdcVcmd;
    f32 flHvdcIcmd;
    u64 qwObcErrorFlag;
    f32 flObcPfcAuxVolt;
    f32 flObcPfcCurrA;
    f32 flObcPfcCurrB;
    f32 flObcPfcCurrC;
    f32 flObcPfcCurrD;
    f32 flObcGridVolt;
    f32 flObcGridCurr;
    f32 flObcGridFreq;
    f32 flObcHvdcVolt;
    f32 flObcHvdcCurr;
    f32 flObcBulkVolt;
    f32 flObcHvVoltRef;
    f32 flObcHvCurrRef;
    f32 flObcCtrlTheta;
    f32 flObcCtrlFreq;
    f32 flObcTempLlc;
    f32 flObcTempPfc;

    f32 flEvseProxVolt;
    f32 flEvsePilotVolt;
    f32 flEvsePilotDuty;
    f32 flEvseImax;
    u8 bS2Status;

    u32 dwCrcChecksum;
} snapshot_record_t;

typedef struct extended_record_s
{
	u32 occurrence_counter;
	u32 aging_counter;
	u32 failed_counter;
	u32 reserve_1;
	u32 reserve_2;
	u32 crc_checksum;
} extended_record_t;

//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sMakeSnapshotRecord (snapshot_record_t* pxData);

#endif /* DTCRECORD_H_ */
