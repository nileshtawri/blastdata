#include "uds_app_cfg.h"
#include "user_config.h"
#include "tp.h"
#include "uds_alg_hal.h"
#include "dtcmgr.h"

const DTC_CONFIG xDTCConfig[NUMBER_OF_DTC] =
{
    /*  DTC,    PreIncr, PreDecr, MonitorType, FilterIncr, FilterDecr, FilterMax,  Aging, WarningIndicator */
    { 0x100001,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100002,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100003,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100004,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100005,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100006,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0xD00001,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0xD00002,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0xD00003,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100101,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100102,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100103,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100104,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0x100105,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0xD00101,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
    { 0xD00102,     127,       128,    (u8)Continuous,    1,          1,          1,       100,        FALSE  },
};

static const RECORD_HEAD S_Record_01 =
{
	/*  next,			NumberOfDID,		ID_TABLE	*/
		NULL_PTR,			1u,				&xSnapShotDataID
};

static const RECORD_HEAD E_Record_01 =
{
	/*  next,			NumberOfDID,		ID_TABLE	*/
		&E_Record_01,		0u,				&xExtendedData
};

const RECORD_CONFIG xRecordConfig[NUMBER_OF_DTC] =
{
	/* 	s_number,	e_number	S_RECORD_HEAD,		E_RECORD_HEAD */
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
	{		1u,			1u,		&S_Record_01,		&E_Record_01	},
};
