#include "uds_app_cfg.h"
#include "user_config.h"
#include "tp.h"
#include "uds_alg_hal.h"
#include "debug.h"
#include "autolibc.h"
#include "DrvCrc.h"
#include "DrvFlash.h"
#include "nvm.h"
#include "EEPROM.h"
#include "dtcRecord.h"
#include "timer.h"
#include "dtcmgr.h"


#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


/***************************DTC Status define **************************/
/** @brief DTC status bit0 testFailed */
#define SB_TF           0x01U
/** @brief DTC status bit1 testFailedThisOperationCycle */
#define SB_TFTOC        0x02U
/** @brief DTC status bit2 pendingDTC */
#define SB_PDTC         0x04U
/** @brief DTC status bit3 confirmedDTC */
#define SB_CDTC         0x08U
/** @brief DTC status bit4 testNotCompletedSinceLastClear */
#define SB_TNCSLC       0x10U
/** @brief DTC status bit5 testFailedSinceLastClear */
#define SB_TFSLC        0x20U
/** @brief DTC status bit6 testNotCompletedThisOperationCycle */
#define SB_TNCTOC       0x40U
/** @brief DTC status bit7 warningIndicatorRequested */
#define SB_WIR          0x80U

#define DTCTotal					(NUMBER_OF_DTC)
#define	DTCRecordUnit				(4u)
#define SnapshotUnit				(sizeof(snapshot_table_t))
#define ExtendedUnit				(sizeof(extended_table_t))
#define DTCRecordLength 			(sizeof(DTC_RECORD)		 )
#define SnapshotRecordLength		(DTCTotal * SnapshotUnit )
#define ExtendedRecordLength		(DTCTotal * ExtendedUnit )

#define DTC_DATA_TOTAL_SIZE         (DTCRecordLength \
                                     + SnapshotRecordLength \
                                     + ExtendedRecordLength)


#define SNAPSHOT_RECORD_ID1			(0x01U)
#define EXTENDED_RECORD_ID1			(0x01U)
#define DTCCleanFlag				(0u)
#define DTCStatusFlagMask			(1u)
#define DTCSnapshotFlagMask			(2u)
#define DTCExtendedFlagMask			(4u)
#define	DTCClearFlagMask			(8u)

#define EEEPROM_SIZE                (xFlashSSDConfig.EEESize-256U)


enum
{
	eChkNewDTC,
	eWriteRecord,
	eChkCompleted,
	eEmergencyWrite,
	eEmergency,
	eHandlStateEnd
};

/**
 * @brief Struct type defining the run-time information for a DTC.
 *
 * @param bPreCounter		Specifies the counter used by the prefail filter.
 * @param bFilterCounter		Specifies the counter used by the filter.
 * @param bAgingCounter		Specifies the counter used by the aging algorithm.
 * @param bDTCStatus			Specifies the status of the DTC.
 *
 * @remark Struct element bPreCounter may be stored in RAM.
 *
 */
typedef struct
{
    s8 bPreCounter;
    u8 bFilterCounter;
    u8 bAgingCounter;
    u8 bDTCStatus;
}PACKED dtc_info_t;

typedef struct
{
    u16 wYear;
    u8 bMonth;
    u8 bDay;
    u8 bHour;
    u8 bMinute;
    u8 bSecond;
    u8 b100ms;

    u8 bApmIgnStatus;
    u8 bHvAuxEnStatus;
    u8 bApmModeCmd;
    u8 bApmWorkMode;
    f32 flLvdcVcmd;
    f32 flLvdcIcmd;
    f32 flLvIoutLimit;
    u64 qwApmErrorFlag;
    f32 flApmHvdcVolt;
    f32 flApmHvdcCurr;
    f32 flApmLvdcVolt;
    f32 flApmLvdcCurr;
    f32 flApmTempPcb;
    f32 flApmTempSr;
    f32 flApmTempCool;
    f32 flApmLvAuxVolt;
    f32 flApmBatVolt;

    u8 bObcModeCmd;
    u8 bObcWorkMode;
    f32 flHvdcVcmd;
    f32 flHvdcIcmd;
    u64 qwObcErrorFlag;
    f32 flObcPfcAuxVolt;
    f32 flObcPfcCurrA;
    f32 flObcPfcCurrB;
    f32 flObcPfcCurrC;
    f32 flObcPfcCurrD;
    f32 flObcGridVolt;
    f32 flObcGridCurr;
    f32 flObcGridFreq;
    f32 flObcHvdcVolt;
    f32 flObcHvdcCurr;
    f32 flObcBulkVolt;
    f32 flObcHvVoltRef;
    f32 flObcHvCurrRef;
    f32 flObcCtrlTheta;
    f32 flObcCtrlFreq;
    f32 flObcTempLlc;
    f32 flObcTempPfc;

    f32 flEvseProxVolt;
    f32 flEvsePilotVolt;
    f32 flEvsePilotDuty;
    f32 flEvseImax;
    u8 bS2Status;
}PACKED snap_did01_t;

typedef struct
{
	snap_did01_t	xID01;
	u8				bRecordNm;
	u8				bLength;
	u16 			wCRC;
}PACKED snap_record_t;

typedef union
{
	snap_record_t	xRecord;
}snapshot_table_t;

typedef struct
{
	u32 dwOccurrenceCounter;
	u32 dwAgingCounter;
	u32 dwFailedCounter;
	u32 dwReserve_1;
	u32 dwReserve_2;

}PACKED ext_data_t;

typedef struct
{
	ext_data_t 	xExtData;
	u8 			bRecordNm;
	u8			bLength;
	u16 		wCRC;

}PACKED ext_record_t;

typedef union
{
	ext_record_t		xRecord;
}extended_table_t;

/**
 * @brief Struct type defining the data to be stored in non-voltile memory.
 *
 * @param xaDTCInfo       Specifies an array of the DTC information for all supported DTCs.
 * @param BadKeyCounter Specifies a counter of the number of bad keys sent during SecurityAccess.
 *
 */
typedef struct
{
    dtc_info_t          xaDTCInfo[NUMBER_OF_DTC];
    dtc_info_t			xaPreDTCInfo[NUMBER_OF_DTC];
    snapshot_table_t	xSnapshot;
    extended_table_t	xExtended;
    u8					bUpdateFlag;
    u8					bExcuteFlag;
    u8					bHandlState;
    DTC_CODE			eDTCIndex;
}PACKED DTC_DATA;

typedef struct
{
    dtc_info_t    		xaDTCInfo[NUMBER_OF_DTC];
    u32      			wCRC;
}PACKED DTC_RECORD;

static void		        *pDTCRecord;
static void				*pSnapShotRecord;
static void				*pExtendedRecord;
static DTC_DATA         xDTCData;
static u8				bEmergencyWait;
static flash_ssd_config_t xFlashSSDConfig = {0};

// App callback api
#ifndef APP_DTC_CALLBACK

/**
 * @brief This function should evaluate the general conditions for enabling/disabling the DTC.
 *
 * @param DTC This parameter contains the code of the DTC (index in DTC table) to be evaluated.
 *
 * @return TRUE when the conditions for DTC handling are fulfilled else FALSE.
 */
boolean CheckAppMeetDTCTestConditions(DTC_CODE eDtc) { return TRUE; }
void APP_DTCIsClearDTC(DTC_CODE eDtc){ };
#endif

/**
 * @brief Flag indicating if an operation cycle is currently pending.
 */
static boolean blPendingOperationCycle = FALSE;
static boolean blApmOperationCycle = FALSE;
static boolean blObcOperationCycle = FALSE;

static boolean DTCTestEn = FALSE;               /* for debug only */
/**
 * @brief flag indicating the state of supporting DTC.  
 */
static const u8 bSupportedDTCStatus = (SB_TF | SB_CDTC | SB_TFSLC) ;
//static const u8 bRequestRecordStatus = (SB_TF);

const ID_TABLE xSnapShotDataID = { 0xC000,  &xDTCData.xSnapshot.xRecord.xID01, sizeof(xDTCData.xSnapshot.xRecord.xID01) };
const ID_TABLE xExtendedData = { 0x0000,  &xDTCData.xExtended.xRecord.xExtData, sizeof(xDTCData.xExtended.xRecord.xExtData) };
/**********************DTC Information Static function************************/
static void TestFailed(DTC_CODE eDtc);
static void TestPassed(DTC_CODE eDtc);
static boolean Aging(DTC_CODE eDtc);
static u8 GetDTCStatusByte(DTC_CODE eDtc);
static void ClearDTC(DTC_CODE eDtc);
//static u16 BinarySearchU32(const void* pTable, u8 bOffset, u16 wLow, u16 wHigh, u32 wKey);
static u16 swSearchDtcTable(u32 dwKey);
static boolean RecordIsEmpty(const void* pxStart, u8 bLength);
static u8 LoadDTCRecord(void);
static u8 LoadSnapshotRecord(DTC_CODE eDtc, u8 bIndex, u8 bNumber);
static u8 LoadExtendedRecord(DTC_CODE eDtc, u8 bIndex, u8 bNumber);
static u8 DTCStatusDataSave(DTC_CODE eDtc, u8 bNumber);
static u8 SnapshotDataSave(DTC_CODE eDtc);
static u8 ExtendedDataSave(DTC_CODE eDtc);
static u8 ClearSnapshot(DTC_CODE eDtc);
static u8 ClearExtended(DTC_CODE eDtc);
static void sReadExtendedRecord (DTC_CODE eDtc);
static void GetAppSnapshotData(void);
static u16 CalculatesRecordDistance(DTC_CODE eDtc, u8 bType);
static void CalculatesDataCrc16(const u8* pbBuf, u16 wLen, u16* pwCrc);
static void sCheckRecordUpdate(void);
/**********************DTC Information API function************************/

/**
 *  @brief This function reports that a test for a diagnostic trouble code has failed. 
 *  
 *  @param Dtc	Contains the alias name of the DTC for which the test failed.
 *  @return DTC status byte
 *  
 *  @details 
 */
u8 DTCTestFailed(DTC_CODE eDtc)
{
	dtc_info_t* dtcInfo;
	const DTC_CONFIG* dtcConfig;
	boolean disableDTCs;
	boolean generalCriteriasFulfilled;

	disableDTCs = CheckDiagServicesDisableDTCs();
	generalCriteriasFulfilled = CheckAppMeetDTCTestConditions(eDtc);

    blPendingOperationCycle = blApmOperationCycle || blObcOperationCycle;

	if( (eDtc < NUMBER_OF_DTC              ) &&
	    (generalCriteriasFulfilled        ) && 
        (((!disableDTCs                     ) &&
	      (blPendingOperationCycle            )) ||
		 (DTCTestEn						     )) )
	{
		dtcInfo = &xDTCData.xaDTCInfo[eDtc];
		dtcConfig = &xDTCConfig[eDtc];

		if(Disable != dtcConfig->bMonitorType)
		{
			if(dtcInfo->bPreCounter > (s8)PREFAIL_OFF)
			{
				if(((s8)PREFAIL_MAX - dtcInfo->bPreCounter) > dtcConfig->bPreIncr)
				{
					dtcInfo->bPreCounter += (s8)(PREFAIL_MAX & dtcConfig->bPreIncr);
				}
				else
				{
					dtcInfo->bPreCounter = (s8)PREFAIL_MAX;
				}
			}
			else
			{
				if(Continuous == dtcConfig->bMonitorType)
				{
					dtcInfo->bPreCounter = (s8)(PREFAIL_MAX & dtcConfig->bPreIncr);
				}
				else
				{
					dtcInfo->bPreCounter +=(s8)(PREFAIL_MAX & dtcConfig->bPreIncr);
				}
			}
		}
		else
		{
			dtcInfo->bPreCounter = PREFAIL_MAX;
		}

		if(dtcInfo->bPreCounter == PREFAIL_MAX)
		{
			TestFailed(eDtc);
		}
	}
    
    return GetDTCStatusByte(eDtc);
}

/**
 *  @brief This function reports that a test for a diagnostic trouble code has passed.
 *  
 *  @param Dtc	Contains the alias name of the DTC for which the test passed.
 *  @return DTC status byte
 *  
 *  @details 
 */
u8 DTCTestPassed(DTC_CODE eDtc)
{
	dtc_info_t* dtcInfo;
	const DTC_CONFIG* dtcConfig;
	boolean disableDTCs;
	boolean generalCriteriasFulfilled;

	disableDTCs = CheckDiagServicesDisableDTCs();
	generalCriteriasFulfilled = CheckAppMeetDTCTestConditions(eDtc);

    blPendingOperationCycle = blApmOperationCycle || blObcOperationCycle;

	if( (eDtc < NUMBER_OF_DTC              ) &&
	    (generalCriteriasFulfilled        ) && 
		(((!disableDTCs                     ) &&
		  (blPendingOperationCycle            )) ||
		 (DTCTestEn						     )) )

	{
		dtcInfo = &xDTCData.xaDTCInfo[eDtc];
		dtcConfig = &xDTCConfig[eDtc];
		
		if(Disable != dtcConfig->bMonitorType)
		{
			if(dtcInfo->bPreCounter > (s8)PREFAIL_OFF)
			{
				if(Continuous == dtcConfig->bMonitorType)
				{
					dtcInfo->bPreCounter = (s8)dtcConfig->bPreDecr;
				}
				else
				{
					dtcInfo->bPreCounter -= (s8)dtcConfig->bPreDecr;
				}
			}
			else
			{
				if( (((u8)(dtcInfo->bPreCounter - PREFAIL_MIN)) > dtcConfig->bPreDecr) &&
					(PREFAIL_MIN != (s8)dtcConfig->bPreDecr))
				{
					dtcInfo->bPreCounter -= (s8)dtcConfig->bPreDecr;
				}
				else
				{
					dtcInfo->bPreCounter = PREFAIL_MIN;
				}
			}
		}
		else
		{
			dtcInfo->bPreCounter = PREFAIL_MIN;
		}

		if(dtcInfo->bPreCounter == PREFAIL_MIN)
		{
			TestPassed(eDtc);
		}
	}

	return GetDTCStatusByte(eDtc);
}

/**
 * @brief This function starts a new APM operation cycle.
 *  
 * @return void
 *
 */
void StartApmDtcOperationCycle(void)
{
	u8 bDtc;
	dtc_info_t*   dtcInfo;

	for(bDtc = APM_FIRST_DTC_INDEX; bDtc <= APM_LAST_DTC_INDEX; bDtc++)
	{
		dtcInfo = &xDTCData.xaDTCInfo[bDtc];

		dtcInfo->bDTCStatus |= SB_TNCTOC;
		dtcInfo->bDTCStatus &= ~(SB_TF | SB_TFTOC);

		dtcInfo->bPreCounter = 0u;
	}
	blApmOperationCycle = TRUE;
}

/**
 * @brief This function starts a new OBC operation cycle.
 *  
 * @return void
 *
 */
void StartObcDtcOperationCycle(void)
{
	u8 bDtc;
	dtc_info_t*   dtcInfo;

	for(bDtc = OBC_FIRST_DTC_INDEX; bDtc <= OBC_LAST_DTC_INDEX; bDtc++)
	{
		dtcInfo = &xDTCData.xaDTCInfo[bDtc];

		dtcInfo->bDTCStatus |= SB_TNCTOC;
		dtcInfo->bDTCStatus &= ~(SB_TF | SB_TFTOC);

		dtcInfo->bPreCounter = 0u;
	}
	blObcOperationCycle = TRUE;
}


/**
 * @brief This function stops APM operation cycle.
 *  
 * @return void
 *
 */
void StopApmDtcOperationCycle(void)
{
	u8 bDtc;
	dtc_info_t*   dtcInfo;

	for(bDtc = APM_FIRST_DTC_INDEX; bDtc <= APM_LAST_DTC_INDEX; bDtc++)
	{
		dtcInfo = &xDTCData.xaDTCInfo[bDtc];

		if(!(dtcInfo->bDTCStatus & (SB_TFTOC)))
		{
			dtcInfo->bDTCStatus &= ~SB_PDTC;
		}
	}
	blApmOperationCycle = FALSE;
}

/**
 * @brief This function stops OBC operation cycle.
 *  
 * @return void
 *
 */
void StopObcDtcOperationCycle(void)
{
	u8 bDtc;
	dtc_info_t*   dtcInfo;

	for(bDtc = OBC_FIRST_DTC_INDEX; bDtc <= OBC_LAST_DTC_INDEX; bDtc++)
	{
		dtcInfo = &xDTCData.xaDTCInfo[bDtc];

		if(!(dtcInfo->bDTCStatus & (SB_TFTOC)))
		{
			dtcInfo->bDTCStatus &= ~SB_PDTC;
		}
	}
	blObcOperationCycle = FALSE;
}


/**
 * @brief This function clears information stored for a specific DTC or group of DTCs.
 *  
 * @param groupOfDTC    Contains the DTC group or DTC number for which information should be cleared.
 *
 * @return FALSE if the DTC or group doesn't exist otherwise TRUE.
 *
 */
boolean DTCClearDiagInfo(u32 dwGroupOfDTC)
{
	u16 index;
    boolean  result = TRUE;

	if(dwGroupOfDTC == 0xFFFFFFu)
	{
		for(index = 0u; index < (u16)NUMBER_OF_DTC; index++)
		{
			ClearDTC((DTC_CODE)index);
		}

		APP_DTCIsClearDTC((DTC_CODE)index);
	}
	else
	{
		result = FALSE;
	}
    
    return result;
}

/**
 * @brief This function retreives the DTCStatusAvailabilityMask.
 *
 *        The retreived value defines which bits of the bDTCStatus that are supported.
 *  
 * @return DTCStatusAvailabilityMask.
 *
 */
u8 GetStatusAvailabilityMask(void)
{   
    return (u8)bSupportedDTCStatus;
}

/**
 * @brief This function retreives a list of DTC and status information for the DTCs that match
 *        the status mask.
 *        
 * @param buffer        Contains the pointer to the buffer that receives the list of information.
 * @param numDTC        Contains maximum length of buffer (number of bytes)/number of DTC entries (4 bytes) copied to the buffer.
 * @param statusMask    Contains the status mask for which DTC information should be retreived.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 *
 */
boolean GetDTCByStatusMask(u8* pbBuffer, u16* pwNumDTC, u8 bStatusMask)
{
	DTC_CODE index;
	u32   dtc;
	u16   endBuffer;
    boolean  result = TRUE;

	endBuffer = (*pwNumDTC)>>2u;
	*pwNumDTC = 0u;

	for(index = (DTC_CODE)0u; index < NUMBER_OF_DTC; index++)
	{
		if(GetDTCStatusByte(index) & bStatusMask)
		{
			if(pbBuffer)
            {
                if((u16)index < endBuffer)
                {
                    dtc = xDTCConfig[index].dwDTC;
                    *pbBuffer++ = LOBYTE(HIWORD(dtc));
                    *pbBuffer++ = HIBYTE(LOWORD(dtc));
                    *pbBuffer++ = LOBYTE(LOWORD(dtc));
                    *pbBuffer++ = GetDTCStatusByte(index);
                }
                else
                {
                    result = FALSE;
                }
                
            }
			(*pwNumDTC)++;
		}
	}
    
    return result;
}

/**
 * @brief This function retreives a list of snapshot data records associated with a DTC.
 *        
 * @param dtc            Contains the DTC number.
 * @param recordNumber   Contains the record number (index).
 * @param statusDtc      Contains the pointer to DTC status byte information.
 * @param buffer         Contains the pointer to the buffer that receives the list of data records.
 * @param recLength      Contains maximum length of buffer (number of bytes)/number of bytes copied to the record.
 *
 * @return 0x00          Positive Response.
 * @return 0x12          Because the record data CRC16 Fail, so subfunction not support.
 * @return 0x31          Request out of range.
 *
 */
u8 GetDTCSnapshotRecordByDTCNumber(u32 dwDTCValue, u8 bRecordNumber, u8* pbStatusDtc, u8* pbBuffer, u16* pwRecLength)
{
	DTC_CODE dtc_index;
    boolean  result = OK;
	u8    temp;
	u8	 recordIndex;
	u8	 IdCount;
	u8	 *ptr;
	const RECORD_HEAD	*pHead;

	//dtc_index = BinarySearchU32((const void *)&xDTCConfig[0].dwDTC, sizeof(DTC_CONFIG), 0u,
    //                        NUMBER_OF_DTC, dwDTCValue);
    dtc_index = swSearchDtcTable(dwDTCValue);

    if( NUMBER_OF_DTC > dtc_index)
    {
    	temp = GetDTCStatusByte(dtc_index);
    	*pbStatusDtc = temp;
    	*pwRecLength = 0u;
    	pHead = xRecordConfig[dtc_index].pxSnapshotID;
    	ptr = pbBuffer;

    	if(temp & bSupportedDTCStatus)
    	{
			for(recordIndex=1u; recordIndex<=xRecordConfig[dtc_index].bSnapshotMaxNum; recordIndex++)
			{
				if( NULL_PTR != pHead )
				{
					temp = LoadSnapshotRecord(dtc_index,recordIndex,bRecordNumber);

					if( 1u >= temp )
					{
						*(ptr++) = recordIndex;
						*(ptr++) = pHead->bNumberOfDID;
						for(IdCount=0; IdCount<pHead->bNumberOfDID; IdCount++)
						{
							*(ptr++) = (u8)((pHead->pxIdTable[IdCount].wDataID)>>8u);
							*(ptr++) = (u8)(pHead->pxIdTable[IdCount].wDataID);
							(void)fsl_memcpy((void*)ptr, (const void *)(pHead->pxIdTable[IdCount].pStart), pHead->pxIdTable[IdCount].wLength);
							ptr += pHead->pxIdTable[IdCount].wLength;
						}
					}
					else
					{
						if(2u== temp)
						{
							result = SFNS;
						}
						else
						{
							result = ROOR;
						}

						*pwRecLength = 0u;
						break;
					}

					if(0xFFu != bRecordNumber)
					{
					    break;
					}
				}

				pHead = (RECORD_HEAD*) pHead->pNext;
			}

			*pwRecLength =(u16) (ptr - pbBuffer);

			if( (recordIndex > xRecordConfig[dtc_index].bSnapshotMaxNum) && (0xFFu != bRecordNumber) )
			{
				*pwRecLength = 0u;
				result = ROOR;
			}
    	}
    	else
    	{
    		*pwRecLength = 0u;
    	}
    }
    else
    {
        *pwRecLength = 0u;
        result = ROOR;
    }
    
    return result;

}

/**
 * @brief This function retreives a list of extended data records associated with a DTC.
 *        
 * @param dtc           Contains the DTC number.
 * @param recordNumber  Contains the record number (index).
 * @param buffer        Contains the pointer to the buffer that receives the list of data records.
 * @param recLength     Contains maximum length of buffer (number of bytes)/number of bytes copied to the record.
 *
 * @return 0x00          Positive Response.
 * @return 0x31          Request out of range.
 *
 */
u8 GetExtendedDataRecordByDTCNumber(u32 dwDTCValue, u8 bRecordNumber, u8* pbStatusDtc, u8* pbBuffer, u16* pwRecLength)
{
	DTC_CODE 	dtc_index;
    boolean  	result = OK;
    u8    	temp;
    u8	 	recordIndex;
    u8	 	*ptr;
    const RECORD_HEAD	*pHead;
    
    //dtc_index = BinarySearchU32((const void *)&xDTCConfig[0].dwDTC, sizeof(DTC_CONFIG), 0u,
    //                        NUMBER_OF_DTC, dwDTCValue);
    dtc_index = swSearchDtcTable(dwDTCValue);

    if( NUMBER_OF_DTC > dtc_index)
    {
    	temp = GetDTCStatusByte(dtc_index);
		*pbStatusDtc = temp;
		*pwRecLength = 0u;
		pHead = xRecordConfig[dtc_index].pxExtednedData;
		ptr = pbBuffer;

		if(temp & bSupportedDTCStatus)
		{
			for(recordIndex=1u; recordIndex<=xRecordConfig[dtc_index].bExtendedMaxNum; recordIndex++)
			{
				if( NULL_PTR != pHead )
				{
					temp = LoadExtendedRecord(dtc_index,recordIndex,bRecordNumber);

					if( 1u >= temp )
					{
						*(ptr++) = recordIndex;
						(void)fsl_memcpy((void*)ptr, (const void *)pHead->pxIdTable->pStart, pHead->pxIdTable->wLength);
						ptr += pHead->pxIdTable->wLength;
					}
					else
					{
						if(2u== temp)
						{
							result = SFNS;
						}
						else
						{
							result = ROOR;
						}

						*pwRecLength = 0u;
						break;
					}

					if(0xFFu != bRecordNumber)
					{
					    break;
					}
				}
			}

			*pwRecLength = (u16)(ptr - pbBuffer);

			if( (recordIndex > xRecordConfig[dtc_index].bExtendedMaxNum) && (0xFFu != bRecordNumber) )
			{
				*pwRecLength = 0u;
				result = ROOR;
			}
		}
    	else
    	{
    		*pwRecLength = 0u;
    	}
    }
    else
    {
        result = ROOR;
        *pwRecLength = 0u;
    }

	return result;
}

/**
 * @brief This function retreives a list of DTC and status information for the DTCs that is
 *        supported by the node.
 *        
 * @param buffer    Contains the pointer to the buffer that receives the list of information.
 * @param numDTC    Contains maximum length of buffer (number of bytes)/number of DTC entries (4 bytes) copied to the buffer.
 *
 * @return FALSE if the service is not implemented otherwise TRUE.
 */
boolean GetSupportedDTCs(u8* pbBuffer, u16* wNumDTC)
{
    
    return GetDTCByStatusMask(pbBuffer, wNumDTC, 0xFFu );
}

/**
 * @brief       This function run the Aging algorithm to clear APM DTCs.
 *
 * @param
 *
 * @return      true: if any bAgingCounter is changed.
 */
boolean sApmDtcAging(void)
{
	u8  bDtc;
	boolean bChanged;
	bChanged = FALSE;
	for(bDtc = APM_FIRST_DTC_INDEX; bDtc <= APM_LAST_DTC_INDEX; bDtc++)
	{

		if(Aging((DTC_CODE) bDtc))
		{
			bChanged = TRUE;
		}
	}
	return bChanged;

}

/**
 * @brief       This function run the Aging algorithm to clear OBC DTCs.
 *
 * @param
 *
 * @return      true: if any bAgingCounter is changed.
 */
boolean sObcDtcAging(void)
{
	u8  bDtc;
	boolean bChanged;
	bChanged = FALSE;
	for(bDtc = OBC_FIRST_DTC_INDEX; bDtc <= OBC_LAST_DTC_INDEX; bDtc++)
	{

		if(Aging((DTC_CODE) bDtc))
		{
			bChanged = TRUE;
		}
	}
	return bChanged;

}


void DTC_EmergenyNotice(void)
{

	if(eEmergencyWrite > xDTCData.bHandlState)
	{
		//if(TRUE == sEEP_Emergency(sizeof(DTC_RECORD)))
		if(TRUE == sEEP_Emergency(16u))
		{
			xDTCData.bHandlState = eEmergencyWrite;
		}
	}
}

void DTC_Handle(void)
{

	switch(xDTCData.bHandlState)
	{
		case eChkNewDTC:

			sCheckRecordUpdate();

			if(DTCCleanFlag != xDTCData.bUpdateFlag)
			{
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("DTC: new -> write\n");
                #endif

				xDTCData.bHandlState = eWriteRecord;
			}
		break;

		case eWriteRecord:

			if( DTCSnapshotFlagMask == (xDTCData.bUpdateFlag & DTCSnapshotFlagMask))
			{
				if(xDTCData.bUpdateFlag & DTCClearFlagMask)
				{
					if(1u == ClearSnapshot(xDTCData.eDTCIndex))
					{
                        #if (HAVE_DEBUG_UART != 0)
                        DebugPrint("DTC: clear snapshot\n");
                        #endif

						xDTCData.bExcuteFlag |= DTCSnapshotFlagMask;
						xDTCData.bHandlState = eChkCompleted;
					}
				}
				else
				{
					if(1u == SnapshotDataSave(xDTCData.eDTCIndex))
					{
                        #if (HAVE_DEBUG_UART != 0)
                        DebugPrint("DTC: save snapshot\n");
                        #endif

						xDTCData.bExcuteFlag |= DTCSnapshotFlagMask;
						xDTCData.bHandlState = eChkCompleted;
					}
				}
			}

			if(DTCExtendedFlagMask == (xDTCData.bUpdateFlag & DTCExtendedFlagMask))
			{
				if(xDTCData.bUpdateFlag & DTCClearFlagMask)
				{
					if(1u == ClearExtended(xDTCData.eDTCIndex))
					{
                        #if (HAVE_DEBUG_UART != 0)
                        DebugPrint("DTC: clear DTC%d extend\n", xDTCData.eDTCIndex);
                        #endif

						xDTCData.bExcuteFlag |= DTCExtendedFlagMask;
						xDTCData.bHandlState = eChkCompleted;
					}
				}
				else
				{
					if(1u == ExtendedDataSave(xDTCData.eDTCIndex))
					{
                        #if (HAVE_DEBUG_UART != 0)
                        DebugPrint("DTC: save DTC%d extend\n", xDTCData.eDTCIndex);
                        #endif

						xDTCData.bExcuteFlag |= DTCExtendedFlagMask;
						xDTCData.bHandlState = eChkCompleted;
					}
				}
			}

			if(DTCStatusFlagMask == (xDTCData.bUpdateFlag & DTCStatusFlagMask))
			{
				if( DTCStatusDataSave(xDTCData.eDTCIndex, 1u))
				{
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrint("DTC: save DTC%d status\n", xDTCData.eDTCIndex);
                    #endif

					xDTCData.bExcuteFlag |= DTCStatusFlagMask;
					xDTCData.bHandlState = eChkCompleted;
				}
			}

		break;

		case eChkCompleted:

			if(true == sEEP_IsIdle())
			{
				if(xDTCData.bExcuteFlag & DTCStatusFlagMask)
				{
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrint("DTC: status updated\n");
                    #endif

					xDTCData.bExcuteFlag &= (u8)~DTCStatusFlagMask;
					xDTCData.bUpdateFlag &= (u8)~DTCStatusFlagMask;
					xDTCData.xaPreDTCInfo[xDTCData.eDTCIndex] = xDTCData.xaDTCInfo[xDTCData.eDTCIndex];
				}

				if(xDTCData.bExcuteFlag & DTCExtendedFlagMask)
				{
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrint("DTC: extend updated\n");
                    #endif

					xDTCData.bExcuteFlag &= (u8)~DTCExtendedFlagMask;
					xDTCData.bUpdateFlag &= (u8)~DTCExtendedFlagMask;
				}

				if(xDTCData.bExcuteFlag & DTCSnapshotFlagMask)
				{
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrint("DTC: snapshot updated\n");
                    #endif

					xDTCData.bExcuteFlag &= (u8)~DTCSnapshotFlagMask;
					xDTCData.bUpdateFlag &= (u8)~DTCSnapshotFlagMask;
				}

				if(DTCCleanFlag == (xDTCData.bUpdateFlag & (DTCStatusFlagMask|DTCExtendedFlagMask|DTCSnapshotFlagMask)))
				{
					xDTCData.bUpdateFlag = DTCCleanFlag;
					xDTCData.bHandlState = eChkNewDTC;
				}
				else
				{
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrint("DTC: contine update\n");
                    #endif

					xDTCData.bHandlState = eWriteRecord;
				}
			}
		break;

		case eEmergencyWrite:

			if(TRUE == sEEP_IsIdle())
			{

#if(1)
				DTC_RECORD Temp;
				u16 crc16;

				(void)fsl_memcpy((void *)Temp.xaDTCInfo, (const void *)pDTCRecord, DTCRecordLength);
				CalculatesDataCrc16((const u8*)Temp.xaDTCInfo, (u16)(sizeof(Temp.xaDTCInfo)), &crc16);
				Temp.wCRC = (u32)crc16;
				(void)FLASH_DRV_EEEWrite(&xFlashSSDConfig,(u32)pDTCRecord, (u32)(sizeof(Temp)),(const u8*) &Temp);


				//(void)sEEP_Write((u32)DTCRecord, (u32)(sizeof(Temp)),(const u8*) &Temp);

#else
				u16 crc16;

				CalculatesDataCrc16((const u8*)xDTCData.xaDTCInfo, (u16)(sizeof(xDTCData.xaDTCInfo)), &crc16);

				for(xDTCData.eDTCIndex=DTC_P100001; xDTCData.eDTCIndex<4u;xDTCData.eDTCIndex++)
				{
					temp1 = *((u32*)DTCRecord + xDTCData.eDTCIndex);
					temp2 = *((u32*)&(xDTCData.xaDTCInfo[xDTCData.eDTCIndex]));
					if(temp2 != temp1)
					{
						FLASH_DRV_EEEWrite(&xFlashSSDConfig,(u32)(DTCRecord+4*xDTCData.eDTCIndex), 4u,(const u8*) &xDTCData.xaDTCInfo[xDTCData.eDTCIndex]);
					}
				}

				FLASH_DRV_EEEWrite(&xFlashSSDConfig,(u32)(DTCRecord+4*xDTCData.eDTCIndex), 4u,(const u8*) &crc16);
#endif
				bEmergencyWait = 0u;
				xDTCData.bHandlState = eEmergency;
			}

		break;

		case eEmergency:

			if(0xFFu > bEmergencyWait)
			{
				bEmergencyWait++;
			}
			else
			{
				xDTCData.bHandlState = eChkNewDTC;
				sEEPROMInit();
			}
		break;

		default:

		break;
	}

}

void DTC_Init(void)
{
    u8 i;
    
    xDTCData.bUpdateFlag = DTCCleanFlag;
    xDTCData.eDTCIndex = DTC_P100001;
    xDTCData.bHandlState = eChkNewDTC;
    
    sNvmGetSSDConfig(&xFlashSSDConfig);
    pDTCRecord = (void *)xFlashSSDConfig.EERAMBase;
    pSnapShotRecord = (void *)(pDTCRecord + DTCRecordLength);
    pExtendedRecord = (void *)(pSnapShotRecord + SnapshotRecordLength);

    DEV_ASSERT(EEEPROM_SIZE >= DTC_DATA_TOTAL_SIZE);
    
	if(0u==LoadDTCRecord())
    {
        for(i=0; i<NUMBER_OF_DTC; i++)
        {
        	xDTCData.xaDTCInfo[i].bPreCounter = 0u;
            xDTCData.xaPreDTCInfo[i] = xDTCData.xaDTCInfo[i];
        }
    }
    else
    {
    	for(i=0; i<NUMBER_OF_DTC; i++)
    	{
			xDTCData.xaDTCInfo[i].bPreCounter = 0u;
			xDTCData.xaDTCInfo[i].bDTCStatus = 0u;
			xDTCData.xaDTCInfo[i].bFilterCounter = 0u;
			xDTCData.xaDTCInfo[i].bAgingCounter = xDTCConfig[i].bAgingMax;
			xDTCData.xaPreDTCInfo[i].bDTCStatus = 0;
    	}
    }
}

/********************************************************/

static void GetAppSnapshotData(void)
{
    snapshot_record_t snapData;

    sMakeSnapshotRecord(&snapData);

    xDTCData.xSnapshot.xRecord.xID01.wYear              = snapData.wYear;
    xDTCData.xSnapshot.xRecord.xID01.bMonth             = snapData.bMonth;
    xDTCData.xSnapshot.xRecord.xID01.bDay               = snapData.bDay;
    xDTCData.xSnapshot.xRecord.xID01.bHour              = snapData.bHour;
    xDTCData.xSnapshot.xRecord.xID01.bMinute            = snapData.bMinute;
    xDTCData.xSnapshot.xRecord.xID01.bSecond            = snapData.bSecond;
    xDTCData.xSnapshot.xRecord.xID01.b100ms             = snapData.b100ms;

    xDTCData.xSnapshot.xRecord.xID01.bApmIgnStatus      = snapData.bApmIgnStatus;
    xDTCData.xSnapshot.xRecord.xID01.bHvAuxEnStatus     = snapData.bHvAuxEnStatus;
    xDTCData.xSnapshot.xRecord.xID01.bApmModeCmd        = snapData.bApmModeCmd;
    xDTCData.xSnapshot.xRecord.xID01.bApmWorkMode       = snapData.bApmWorkMode;
    xDTCData.xSnapshot.xRecord.xID01.flLvdcVcmd         = snapData.flLvdcVcmd;
    xDTCData.xSnapshot.xRecord.xID01.flLvdcIcmd         = snapData.flLvdcIcmd;
    xDTCData.xSnapshot.xRecord.xID01.flLvIoutLimit      = snapData.flLvIoutLimit;
    xDTCData.xSnapshot.xRecord.xID01.qwApmErrorFlag     = snapData.qwApmErrorFlag;
    xDTCData.xSnapshot.xRecord.xID01.flApmHvdcVolt      = snapData.flApmHvdcVolt;
    xDTCData.xSnapshot.xRecord.xID01.flApmHvdcCurr      = snapData.flApmHvdcCurr;
    xDTCData.xSnapshot.xRecord.xID01.flApmLvdcVolt      = snapData.flApmLvdcVolt;
    xDTCData.xSnapshot.xRecord.xID01.flApmLvdcCurr      = snapData.flApmLvdcCurr;
    xDTCData.xSnapshot.xRecord.xID01.flApmTempPcb       = snapData.flApmTempPcb;
    xDTCData.xSnapshot.xRecord.xID01.flApmTempSr        = snapData.flApmTempSr;
    xDTCData.xSnapshot.xRecord.xID01.flApmTempCool      = snapData.flApmTempCool;
    xDTCData.xSnapshot.xRecord.xID01.flApmLvAuxVolt     = snapData.flApmLvAuxVolt;
    xDTCData.xSnapshot.xRecord.xID01.flApmBatVolt       = snapData.flApmBatVolt;

    xDTCData.xSnapshot.xRecord.xID01.bObcModeCmd        = snapData.bObcModeCmd;
    xDTCData.xSnapshot.xRecord.xID01.bObcWorkMode       = snapData.bObcWorkMode;
    xDTCData.xSnapshot.xRecord.xID01.flHvdcVcmd         = snapData.flHvdcVcmd;
    xDTCData.xSnapshot.xRecord.xID01.flHvdcIcmd         = snapData.flHvdcIcmd;
    xDTCData.xSnapshot.xRecord.xID01.qwObcErrorFlag     = snapData.qwObcErrorFlag;
    xDTCData.xSnapshot.xRecord.xID01.flObcPfcAuxVolt    = snapData.flObcPfcAuxVolt;
    xDTCData.xSnapshot.xRecord.xID01.flObcPfcCurrA      = snapData.flObcPfcCurrA;
    xDTCData.xSnapshot.xRecord.xID01.flObcPfcCurrB      = snapData.flObcPfcCurrB;
    xDTCData.xSnapshot.xRecord.xID01.flObcPfcCurrC      = snapData.flObcPfcCurrC;
    xDTCData.xSnapshot.xRecord.xID01.flObcPfcCurrD      = snapData.flObcPfcCurrD;
    xDTCData.xSnapshot.xRecord.xID01.flObcGridVolt      = snapData.flObcGridVolt;
    xDTCData.xSnapshot.xRecord.xID01.flObcGridCurr      = snapData.flObcGridCurr;
    xDTCData.xSnapshot.xRecord.xID01.flObcGridFreq      = snapData.flObcGridFreq;
    xDTCData.xSnapshot.xRecord.xID01.flObcHvdcVolt      = snapData.flObcHvdcVolt;
    xDTCData.xSnapshot.xRecord.xID01.flObcHvdcCurr      = snapData.flObcHvdcCurr;
    xDTCData.xSnapshot.xRecord.xID01.flObcBulkVolt      = snapData.flObcBulkVolt;
    xDTCData.xSnapshot.xRecord.xID01.flObcHvVoltRef     = snapData.flObcHvVoltRef;
    xDTCData.xSnapshot.xRecord.xID01.flObcHvCurrRef     = snapData.flObcHvCurrRef;
    xDTCData.xSnapshot.xRecord.xID01.flObcCtrlTheta     = snapData.flObcCtrlTheta;
    xDTCData.xSnapshot.xRecord.xID01.flObcCtrlFreq      = snapData.flObcCtrlFreq;
    xDTCData.xSnapshot.xRecord.xID01.flObcTempLlc       = snapData.flObcTempLlc;
    xDTCData.xSnapshot.xRecord.xID01.flObcTempPfc       = snapData.flObcTempPfc;

    xDTCData.xSnapshot.xRecord.xID01.flEvseProxVolt     = snapData.flEvseProxVolt;
    xDTCData.xSnapshot.xRecord.xID01.flEvsePilotVolt    = snapData.flEvsePilotVolt;
    xDTCData.xSnapshot.xRecord.xID01.flEvsePilotDuty    = snapData.flEvsePilotDuty;
    xDTCData.xSnapshot.xRecord.xID01.flEvseImax         = snapData.flEvseImax;
    xDTCData.xSnapshot.xRecord.xID01.bS2Status          = snapData.bS2Status;

    xDTCData.xSnapshot.xRecord.bLength = sizeof(xDTCData.xSnapshot.xRecord) - 2u;
    xDTCData.xSnapshot.xRecord.bRecordNm = SNAPSHOT_RECORD_ID1;
}

/**
 * @brief       This function reports that a test for a diagnostic trouble code has failed.
 *
 * @param Dtc  Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static void TestFailed(DTC_CODE eDtc)
{
	dtc_info_t*           dtcInfo;
	const DTC_CONFIG*   dtcConfig;

    
	dtcInfo = &xDTCData.xaDTCInfo[eDtc];
	dtcConfig = &xDTCConfig[eDtc];

    if(dtcInfo->bDTCStatus & SB_PDTC)
    {
		if(FILTER_DISABLE > dtcConfig->bFilterMax)
		{
			if(!(dtcInfo->bDTCStatus & SB_TFTOC))
			{
				if(dtcInfo->bFilterCounter >= (dtcConfig->bFilterMax - dtcConfig->bFilterIncr))
				{
					dtcInfo->bFilterCounter = dtcConfig->bFilterMax;
					dtcInfo->bDTCStatus |= SB_CDTC;
				}
				else
				{
					dtcInfo->bFilterCounter += dtcConfig->bFilterIncr;
				}
			}
		}
		else
		{
			dtcInfo->bDTCStatus |= SB_CDTC;
		}

    }
    

    if(dtcInfo->bDTCStatus & SB_PDTC)
    {
    	dtcInfo->bAgingCounter = dtcConfig->bAgingMax;
    }

    if((dtcConfig->blWarningIndicator) && (dtcInfo->bDTCStatus & SB_CDTC))
	{
		dtcInfo->bDTCStatus |= SB_WIR;
	}

	dtcInfo->bDTCStatus |= (SB_TF | SB_TFTOC | SB_PDTC | SB_TFSLC);
	dtcInfo->bDTCStatus &= ~(SB_TNCSLC | SB_TNCTOC);

}

/**
 * @brief       This function reports that a test for a diagnostic trouble code has passed.
 *
 * @param Dtc  Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static void TestPassed(DTC_CODE eDtc)
{
	dtc_info_t*           dtcInfo;
	const DTC_CONFIG*   dtcConfig;

	dtcInfo = &xDTCData.xaDTCInfo[eDtc];
	dtcConfig = &xDTCConfig[eDtc];
    
	if(dtcInfo->bFilterCounter <= dtcConfig->bFilterDecr)
	{
		dtcInfo->bFilterCounter = 0u;
	}
	else
	{
		dtcInfo->bFilterCounter -= dtcConfig->bFilterDecr;
	}

	dtcInfo->bDTCStatus &= ~(SB_TF | SB_TNCSLC | SB_TNCTOC);
    
}


/**
 * @brief       This function controls the aging process of a DTC.
 *
 *              When a DTC aging counter reaches zero value its confirmed status is cleared.
 *
 * @param Dtc  Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static boolean Aging(DTC_CODE eDtc)
{
	dtc_info_t*           dtcInfo;
	const DTC_CONFIG*   dtcConfig;
	boolean             bChanged;
	u8	            preStatus;
	u8               preFilterCounter;
	u8               preAgingCounter;

	dtcInfo = &xDTCData.xaDTCInfo[eDtc];
	dtcConfig = &xDTCConfig[eDtc];
	bChanged = FALSE;

	preStatus       = dtcInfo->bDTCStatus;
	preFilterCounter= dtcInfo->bFilterCounter;
	preAgingCounter = dtcInfo->bAgingCounter;

	if((AGING_DISABLE > dtcConfig->bAgingMax) &&
	   ( (SB_CDTC) == (dtcInfo->bDTCStatus & (SB_CDTC | SB_TF | SB_TNCTOC ))))
	{
        if(0u < dtcInfo->bAgingCounter)
        {
            dtcInfo->bAgingCounter--;
        }

        if(0u == dtcInfo->bAgingCounter)
        {
            dtcInfo->bFilterCounter = 0u;
            dtcInfo->bDTCStatus &= ~(SB_CDTC | SB_WIR);
        }

        if( ((preStatus ^ dtcInfo->bDTCStatus) & bSupportedDTCStatus  ) ||
            ( preFilterCounter != dtcInfo->bFilterCounter            ) ||
            ( preAgingCounter  != dtcInfo->bAgingCounter             ) )
		{
        	bChanged = TRUE;
		}
		
	}
	return bChanged;
}

#if 0
/**
 * @brief       Search function which uses a binary search algorithm.
 *
 * @param table Contains the table being searched.
 * @param offset Contains the byte offset between two consecutive values.
 * @param low   Contains the start index to start from.
 * @param high  Contains the end index to search to.
 * @param key   Contains the key value to search for.
 *
 * @return      Index in table if found, otherwise 0xFFFF.
 */
static u16 BinarySearchU32(const void* pTable, u8 bOffset, u16 wLow, u16 wHigh, u32 wKey)
{
	u16 middle;
    u16 retKey;

	while(TRUE) 
	{
		if(wHigh == wLow)
		{
			if(wKey == *((const u32*)(((const u8*)pTable) + (wLow * bOffset))))
			{
				retKey = wLow;
                break;
			}
			else
			{
				retKey = 0xFFFFu;
                break;
			}
		}
		else
		{
			middle = (wLow + wHigh) / 2u;
			if(wKey == *((const u32*)(((const u8*)pTable) + (middle * bOffset))))
			{
				retKey = middle;
                break;
			}
			else if(wKey < * ((const u32*)(((const u8*)pTable) + (middle * bOffset))))
			{
				wHigh = middle;
			}
			else
			{
				wLow = middle + 1u;
			}
		}
	}
    
    return retKey;
}
#endif

/**
 * @brief       Search function which uses a binary search algorithm.
 *
 * @param[in] dwKey   Contains the key value to search for.
 *
 * @return      Index in table if found, otherwise 0xFFFF.
 */
static u16 swSearchDtcTable(u32 dwKey)
{
    u16 wIndex = 0xFFFFU;
    u16 i;

    for (i=0; i<NUMBER_OF_DTC; i++)
    {
        if (xDTCConfig[i].dwDTC == dwKey)
        {
            wIndex = i;
            break;
        }
    }
    
    return wIndex;
}

/**
 * @brief       This function returns the DTC status byte for the dtc associated with a DTC Code.
 *
 * @param Dtc   Contains the code of the dtc (index in DTC table).
 *
 * @return      DTC status byte
 */
static u8 GetDTCStatusByte(DTC_CODE eDtc)
{
	u8  bMask = bSupportedDTCStatus;
	return (xDTCData.xaDTCInfo[eDtc].bDTCStatus & bMask);
}

/************************** DTC APP ***********************************/

/**
 * @brief       calculates the distance of a snapshot/extended record.
 * @param[in]   dtc         Contains the code of the dtc (index in DTC table).
 * @param[in]   type        0:snapshot record, 1:extended record
 * @param[out]  distance    return distance of record
 * @note
 */
static u16 CalculatesRecordDistance(DTC_CODE eDtc, u8 bType)
{
	u8 bIndex;
	u16 bDistance = 0;

	for(bIndex=0; bIndex < eDtc; bIndex++)
	{
		if(0u==bType)
		{
			bDistance += xRecordConfig[bIndex].bSnapshotMaxNum;
		}
		else
		{
			bDistance += xRecordConfig[bIndex].bExtendedMaxNum;
		}
	}

	return bDistance;
}

/**
 * @brief       calculates the CRC16 of a snapshot/extended data block, it exclude the CRC16
 *              word (the 14th and 15th bytes) of the data buffer
 * @param[in]   pbBuf       point to the data black address
 * @param[in]   wLen        length (bytes) of the data block
 * @param[out]  pwCrc       return CRC16 value, 0 if error
 * @note        this function will skip 14th and 15th byte
 */
static void CalculatesDataCrc16(const u8* pbBuf, u16 wLen, u16* pwCrc)
{
    u32 dwCrcResult;
    crc_user_config_t xCrcConf;
    const u8* pbData = pbBuf;
    u16 wDataLen = wLen;

    (void)CRC_DRV_GetDefaultConfig(&xCrcConf);
    (void)CRC_DRV_Configure(INST_DRVCRC, &xCrcConf);

    CRC_DRV_WriteData(INST_DRVCRC, pbData, wDataLen);

    dwCrcResult = CRC_DRV_GetCrcResult(INST_DRVCRC);
    *pwCrc = (u16)dwCrcResult;
}

/**
 * @brief   check the record of NVM area are all 0xFF
 * @return  true if empty (all data are 0xFF), else false
 */
static boolean RecordIsEmpty(const void* pxStart, u8 bLength)
{
    boolean blRet = true;
    const u8 *pbBuf;
    u8 i;

    pbBuf = (const u8*)pxStart;

    for(i=0; i<bLength; i++)
    {
        if(pbBuf[i] != 0xFFU)    /* polyspace MISRA-C3:18.1 "read array via pointer" */
        {
            blRet = false;
            break;
        }
    }

    return blRet;
}


/**
 * @brief   load EEPROM's DTC data to \var xDTCData.xaDTCInfo
 * @retval      0 is PASS
 * @retval      1 record is empty, no data
 * @retval      2 CRC check fail
 */
static u8 LoadDTCRecord(void)
{
    
    u16 crc16;
    u8 i;
    u8 bret = 0;
    
    if(FALSE == RecordIsEmpty((const u8*)pDTCRecord, (u16)DTCRecordLength))
    {
        CalculatesDataCrc16((const u8*)pDTCRecord, (u16)(sizeof(xDTCData.xaDTCInfo)), &crc16);
        if( crc16 == (u16)(((DTC_RECORD *)pDTCRecord)->wCRC) )
        {
            for(i=0; i<NUMBER_OF_DTC; i++)
            {
                xDTCData.xaDTCInfo[i] = ((DTC_RECORD *)pDTCRecord)->xaDTCInfo[i];
            }
        }
        else
        {
            bret = 2u;
        }
    }
    else
    {
        bret = 1u;
    }
    
    return bret;
}

/**
 * @brief   load EEPROM's snapshot data to \var xDTCData.snapshot
 * @retval      0 is PASS
 * @retval      1 record is empty, no data
 * @retval      2 CRC check fail
 * @retval		3 request out of range
 */
static u8 LoadSnapshotRecord(DTC_CODE eDtc, u8 bIndex, u8 bNumber)
{
    u16 crc16;
    u16 distance;
    u16 RecordSize;
    u8 bRet = 0;
    snapshot_table_t *record_addr;
    
    if((NUMBER_OF_DTC > eDtc) && (xRecordConfig[eDtc].bSnapshotMaxNum >= bIndex) && (0u < bIndex))
    {
    	distance =  CalculatesRecordDistance(eDtc, 0u ) + bIndex - 1u;
		record_addr = (snapshot_table_t *)pSnapShotRecord + distance;
		RecordSize = ((snapshot_table_t *)record_addr)->xRecord.bLength;
    }
    else
    {
    	bRet = 3u;
    }

    if(0u==bRet)
    {
    	if( (record_addr->xRecord.bRecordNm == bNumber) || (0xFF == bNumber) )
    	{

			if( FALSE == RecordIsEmpty((const u8*)record_addr, RecordSize))
			{
				CalculatesDataCrc16((const u8*)record_addr, RecordSize,&crc16);
				if( crc16 == ((snapshot_table_t *)record_addr)->xRecord.wCRC )
				{
					(void)fsl_memcpy((void *)&xDTCData.xSnapshot, (const void *)record_addr, RecordSize);
				}
				else
				{
					bRet = 2u;
				}
			}
			else
			{
				fsl_memset((void*)&xDTCData.xSnapshot, 0u, RecordSize);
				bRet = 1u;
			}
    	}
    	else
		{
			bRet = 3u;
		}
    }
    

    return bRet;
}

/**
 * @brief   load EEPROM's extended data to \var xDTCData.extended
 * @retval      0 is PASS
 * @retval      1 record is empty, no data
 * @retval      2 CRC check fail
 * @retval		3 request out of range
 */
static u8 LoadExtendedRecord(DTC_CODE eDtc, u8 bIndex, u8 bNumber)
{
	u16 crc16;
	u16 distance;
	u16 RecordSize;
	u8 bRet = 0;
	extended_table_t *record_addr;

	(void)bIndex;
	if((NUMBER_OF_DTC > eDtc) && (xRecordConfig[eDtc].bExtendedMaxNum >= bNumber) && (0u < bNumber))
	{
		distance = CalculatesRecordDistance(eDtc, 1u ) + bNumber - 1u;
		record_addr = (extended_table_t *)pExtendedRecord + distance;
		RecordSize = ((extended_table_t *)record_addr)->xRecord.bLength;
	}
	else
	{
		bRet = 3u;
	}

	if( 0u == bRet )
	{
		if( (record_addr->xRecord.bRecordNm == bNumber) || (0xFF == bNumber) )
		{
			if(FALSE == RecordIsEmpty((const u8*)record_addr, RecordSize))
			{
				CalculatesDataCrc16((const u8*)record_addr, RecordSize,&crc16);
				if( crc16 == ((extended_table_t *)record_addr)->xRecord.wCRC )
				{
					(void)fsl_memcpy((void *)&xDTCData.xExtended, (const void *)record_addr, RecordSize);
				}
				else
				{
					bRet = 2u;
				}
			}
			else
			{
				fsl_memset((void*)&xDTCData.xExtended, 0u, RecordSize);
				bRet = 1u;
			}
		}
		else
		{
			bRet = 3u;
		}
	}


	return bRet;
}

/**
 * @brief   save current \var xDTCData.xaDTCInfo to EEPROM
 * @param   Dtc   Contains the code of the dtc (index in DTC table).
 * @param	Number of consecutive write buffer dtc
 * @return  0:Failed to write record to buffer
 * 			1:Writing record to the buffer succeeded
 */
static u8 DTCStatusDataSave(DTC_CODE eDtc, u8 bNumber)
{
    DTC_RECORD Temp;
    u16 crc16;
    u8  count;
    u8  bRet = 0u;

    if( (DTCRecordUnit*(bNumber+1)) <= sEEP_GetFreeBufferSize() )
	{
		(void)fsl_memcpy((void *)Temp.xaDTCInfo, (const void *)pDTCRecord, DTCRecordLength);
		for(count=0; count<bNumber; count++)
		{
			Temp.xaDTCInfo[eDtc+count] = xDTCData.xaDTCInfo[eDtc+count];
    	}

		CalculatesDataCrc16((const u8*)Temp.xaDTCInfo, (u16)(sizeof(Temp.xaDTCInfo)), &crc16);
		Temp.wCRC = (u32)crc16;
		bRet = sEEP_Write((u32)(pDTCRecord + eDtc*4), (u32)(DTCRecordUnit*bNumber),(const u8*) &Temp.xaDTCInfo[eDtc]);
		bRet = sEEP_Write((u32)(pDTCRecord + NUMBER_OF_DTC*4), (u32)DTCRecordUnit,(const u8*) &Temp.wCRC);
    }

    return bRet;
}


/**
 * @brief   save current \var xDTCData.snapshot to EEPROM
 * @param   Dtc   Contains the code of the dtc (index in DTC table).
 * @return  0:Failed to write record to buffer
 * 			1:Writing record to the buffer succeeded
 */
static u8 SnapshotDataSave(DTC_CODE eDtc)
{
    u16 crc16;
    u16 distance;
    u16 RecordSize;
    u16 WriteNumber;
    u8  number;
    u8  bRet = 0u;
    snapshot_table_t * record_addr;
    
    RecordSize = xDTCData.xSnapshot.xRecord.bLength;
    WriteNumber = sizeof(xDTCData.xSnapshot.xRecord);

    if( WriteNumber <= sEEP_GetFreeBufferSize() )
    {
		if(NUMBER_OF_DTC > eDtc)
		{
			distance = CalculatesRecordDistance(eDtc, 0u );
			record_addr = (snapshot_table_t *)pSnapShotRecord + distance;

			for(number=0u; number<xRecordConfig[eDtc].bSnapshotMaxNum; number++)
			{
				record_addr += number;
				if(TRUE == RecordIsEmpty((const void*)record_addr, RecordSize))
				{
					break;
				}
			}

			CalculatesDataCrc16((const u8*)&xDTCData.xSnapshot, (u16)RecordSize,&crc16);
			xDTCData.xSnapshot.xRecord.wCRC = crc16;
			bRet = sEEP_Write((u32)record_addr, (u32)WriteNumber,(const u8*) &xDTCData.xSnapshot);
		}
    }

    return bRet;
}

/**
 * @brief   save current \var xDTCData.extended to EEPROM
 * @param   Dtc   Contains the code of the dtc (index in DTC table).
 * @return  void
 */
static u8 ExtendedDataSave(DTC_CODE eDtc)
{
    u16 crc16;
    u16 distance;
    u16 RecordSize;
    u16 WriteNumber;
    u8  number;
    u8  bRet = 0u;
    extended_table_t * record_addr;

    RecordSize = xDTCData.xExtended.xRecord.bLength;
    WriteNumber = sizeof(xDTCData.xExtended.xRecord);

    if( WriteNumber <= sEEP_GetFreeBufferSize() )
    {
		if(NUMBER_OF_DTC > eDtc)
		{
			distance = CalculatesRecordDistance(eDtc, 1u );
			record_addr = (extended_table_t *)pExtendedRecord + distance;

			for(number=0u; number<xRecordConfig[eDtc].bExtendedMaxNum; number++)
			{
				record_addr += number;
				if(TRUE == RecordIsEmpty((const void*)record_addr, (u16)RecordSize))
				{
					break;
				}
			}

			CalculatesDataCrc16((const u8*)&xDTCData.xExtended, (u16)RecordSize,&crc16);
			xDTCData.xExtended.xRecord.wCRC = crc16;
			bRet = sEEP_Write((u32)record_addr, (u32)WriteNumber,(const u8*) &xDTCData.xExtended);
		}
    }

    return bRet;
}

/**
 * @brief       This function clears the information for a specific DTC.
 *
 * @param Dtc   Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static void ClearDTC(DTC_CODE eDtc)
{
	xDTCData.xaDTCInfo[eDtc].bDTCStatus = (SB_TNCSLC | SB_TNCTOC);
	xDTCData.xaDTCInfo[eDtc].bPreCounter = 0;
	xDTCData.xaDTCInfo[eDtc].bFilterCounter = 0;
	xDTCData.xaDTCInfo[eDtc].bAgingCounter = 0;
}

/**
 * @brief       This function clears the information for a specific snapshot.
 *
 * @param Dtc   Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static u8 ClearSnapshot(DTC_CODE eDtc)
{
	u16 distance;
	u16 RecordSize;
	u8  bRet = FALSE;
	snapshot_table_t *record_addr;

	if(NUMBER_OF_DTC > eDtc)
	{
		distance = CalculatesRecordDistance(eDtc, 0u );
		RecordSize = SnapshotUnit * xRecordConfig[eDtc].bSnapshotMaxNum;
		record_addr = (snapshot_table_t *)pSnapShotRecord + distance;

		(void)fsl_memset((void *)&xDTCData.xSnapshot, 0xFFu, RecordSize);

		if(RecordSize <= sEEP_GetFreeBufferSize())
		{
			bRet = sEEP_ClearData((u32)record_addr, RecordSize);
		}
	}

	return bRet;
}

/**
 * @brief       This function clears the information for a specific extended.
 *
 * @param Dtc   Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static u8 ClearExtended(DTC_CODE eDtc)
{
	u16 distance;
	u16 RecordSize;
	u8  bRet = FALSE;
	extended_table_t *record_addr;

	if(NUMBER_OF_DTC > eDtc)
	{
		distance = CalculatesRecordDistance(eDtc, 1u );;
		RecordSize = ExtendedUnit * xRecordConfig[eDtc].bExtendedMaxNum;
		record_addr = (extended_table_t *)pExtendedRecord + distance;

		(void)fsl_memset((void *)&xDTCData.xExtended, 0xFFu, RecordSize);
		if(RecordSize <= sEEP_GetFreeBufferSize())
		{
			bRet = sEEP_ClearData((u32)record_addr,(u32)RecordSize);
		}

	}

	return bRet;
}

/**
 * @brief       Read current dtc extended data to \var xDTCData.extended.
 *
 * @param Dtc   Contains the code of the dtc (index in DTC table).
 *
 * @return      void
 */
static void sReadExtendedRecord (DTC_CODE eDtc)
{
	xDTCData.xExtended.xRecord.xExtData.dwFailedCounter = xDTCData.xaDTCInfo[eDtc].bPreCounter;
	xDTCData.xExtended.xRecord.xExtData.dwOccurrenceCounter = xDTCData.xaDTCInfo[eDtc].bFilterCounter;
	xDTCData.xExtended.xRecord.xExtData.dwAgingCounter = xDTCData.xaDTCInfo[eDtc].bAgingCounter;
	xDTCData.xExtended.xRecord.xExtData.dwReserve_1 = 0xFF;
	xDTCData.xExtended.xRecord.xExtData.dwReserve_2 = 0xFF;
	xDTCData.xExtended.xRecord.bRecordNm = EXTENDED_RECORD_ID1;
	xDTCData.xExtended.xRecord.bLength = sizeof(xDTCData.xExtended.xRecord)-2u;

}

/**
 * @brief       Check for updates and write EEP modules
 *
 * @param Dtc   void
 *
 * @return      void
 */
static void sCheckRecordUpdate(void)
{
	dtc_info_t*         dtcInfo;
	dtc_info_t*         preDtcInfo;
	u8					Keep = 1u;



	while(Keep)
	{
		dtcInfo = &xDTCData.xaDTCInfo[xDTCData.eDTCIndex];
		preDtcInfo = &xDTCData.xaPreDTCInfo[xDTCData.eDTCIndex];
		if( (preDtcInfo->bDTCStatus ^ dtcInfo->bDTCStatus ) & SB_TF )
		{
            if( dtcInfo->bDTCStatus & SB_TF)
            {
                xDTCData.bUpdateFlag |= (DTCSnapshotFlagMask | DTCExtendedFlagMask);
                Keep = 0u;
                GetAppSnapshotData();
                sReadExtendedRecord(xDTCData.eDTCIndex);
            }
			
		}
        else if( (preDtcInfo->bDTCStatus ^ dtcInfo->bDTCStatus ) & SB_CDTC)
        {
            if( FALSE == (dtcInfo->bDTCStatus & SB_CDTC) )
            {
                xDTCData.bUpdateFlag |= (DTCClearFlagMask|DTCSnapshotFlagMask|DTCExtendedFlagMask);
            }
        }
        
		if( ((preDtcInfo->bDTCStatus ^ dtcInfo->bDTCStatus) & bSupportedDTCStatus  ) ||
			 ( preDtcInfo->bFilterCounter ^ dtcInfo->bFilterCounter           	) ||
			 ( preDtcInfo->bAgingCounter  ^ dtcInfo->bAgingCounter            	) )
		{
			Keep = 0u;
			xDTCData.bUpdateFlag |= DTCStatusFlagMask;
		}
        
		if(1u == Keep)
		{
			xDTCData.eDTCIndex++;
			if(NUMBER_OF_DTC == xDTCData.eDTCIndex)
			{
				xDTCData.eDTCIndex = DTC_P100001;
				Keep = 0u;
			}
		}
	}
}


