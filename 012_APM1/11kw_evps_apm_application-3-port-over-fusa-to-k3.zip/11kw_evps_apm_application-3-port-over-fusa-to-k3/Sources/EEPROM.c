#include "cpu.h"
#include "type.h"
#include "MCUC1.h"
#include "CS2.h"
#include "user_config.h"
#include "common_types.h"
#include "autolibc.h"
#include "devassert.h"
#include "nvm.h"
#include "EEPROM.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define EEP_BUFFER_NUMBER		(10u)
#define EEP_RINGBUF_SIZE		(512u)
#define EEP_Start_Addr			(flashSSDConfig.EERAMBase)
#define	EEP_Stop_Addr			(EEP_Start_Addr + flashSSDConfig.EEESize-256u)

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------
#define IsFlexRamReady()		((FTFx_FCNFG & FTFx_FCNFG_EEERDY_MASK) == FTFx_FCNFG_EEERDY_MASK)

#define CheckEEPIsNotEmpty()	(EEP_BUFFER_NUMBER > xEEPBuf.bFree)
//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------
typedef enum {
	EEPIdle = 0,
	EEPGetData,
	EEPWriteData,
	EEPClearData,
	EEPHandleTypeAll
}EEP_HANDLE_STATUS_TYPE;

typedef struct {
	u32 dwAddress;
	u16 wLength;
	u16 wCurLength;
	u16 wStartPoint;
	u16 wEndPoint;
} buf_head_t;

typedef struct {
	u16 wInIdx;
	u16 wOutIdx;
	u16 wInSize;
	u8 baBuffer[EEP_RINGBUF_SIZE];

} ringBuf_t;

typedef struct {
	buf_head_t xaHead[EEP_BUFFER_NUMBER];
	ringBuf_t xRingInf;
	u8 bFtIdx;
	u8 bRrIdx;
	u8 bFree;
} eep_buf_t;

typedef struct {
	u8  bWrSize;
	u16 wClrLength;
	u32 dwClrAddr;
} eep_data_t;
//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
static void sEEP_RingBuf_Init(void);
static void sEEP_RingBuf_Clear(void);
static u16 sEEP_GetBuffInputIdx(void);
static u16 sEEP_GetBuffOutputIdx(void);
static u8 sEEP_RingBuf_Put(const u8 *puData, u16 wNumber);
static u8 sEEP_RingBuf_Get(u8 *puData, u16 wNumber);
static u8 sEEP_FindEmptySpace(u8 * pbIndex);
static u8 sEEP_FetchingNextBuffHead(u8 * pbIndex);
static void sEEP_CloseCurrentBuffHead(u8 bIndex);
static u8 sEEP_CheckBufferOutIdxIsCorrect(u8 bBufIdx,u16 wRingIdx);
static u8 sEEP_CheckAlignAndSize(u32 dwDeset, u16 wLength);
static u8 EEP_FetchingAndWriteData(u8 bBufIdx);
static void EEP_WriteDataToFlexRAM(u8 bSize,u32 dwDest,const u8 * pbData);


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static EEP_HANDLE_STATUS_TYPE eEEPStatus = EEPIdle;
static eep_buf_t xEEPBuf;
static eep_data_t xEEPData;
static flash_ssd_config_t flashSSDConfig = {0};
static u8 bEEPHeadIdx;
static u16 wEmergenyWriteNumber;
//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/*
 ** ===================================================================
 **     @brief		 Initializes the data structure
 **     @Parameters  None
 **     @Returns     Nothing
 ** ===================================================================
 */
static void sEEP_RingBuf_Init(void)
{
	u8 i;

	xEEPBuf.xRingInf.wInIdx = 0u;
	xEEPBuf.xRingInf.wOutIdx = 0u;
	xEEPBuf.xRingInf.wInSize = 0u;
	for(i=0; i<EEP_BUFFER_NUMBER; i++)
	{
		xEEPBuf.xaHead[i].dwAddress = 0u;
		xEEPBuf.xaHead[i].wCurLength = 0u;
		xEEPBuf.xaHead[i].wLength = 0u;
		xEEPBuf.xaHead[i].wStartPoint = 0u;
		xEEPBuf.xaHead[i].wEndPoint = 0u;
	}
	xEEPBuf.bFtIdx = 0u;
	xEEPBuf.bRrIdx = 0u;
	xEEPBuf.bFree = EEP_BUFFER_NUMBER;

	xEEPData.wClrLength = 0u;

	eEEPStatus = EEPIdle;
}

/*
 ** ===================================================================
 **     @brief 		 Clear (empty) the ring baBuffer.
 **     @Parameters  None
 **     @Returns     Nothing
 ** ===================================================================
 */

static void sEEP_RingBuf_Clear(void)
{
	sEEP_RingBuf_Init();
}

/*
 ** ===================================================================
 **     @brief 		 Get Current buffer input index
 **     @Parameters  None
 **     @Returns     index Current buffer input index
 ** ===================================================================
 */
static u16 sEEP_GetBuffInputIdx(void)
{
	return xEEPBuf.xRingInf.wInIdx;
}

/*
 ** ===================================================================
 **     @brief 		 Get Current buffer output index
 **     @Parameters  None
 **     @Returns     index Current buffer output index
 ** ===================================================================
 */
static u16 sEEP_GetBuffOutputIdx(void)
{
	return xEEPBuf.xRingInf.wOutIdx;
}

/*
 ** ===================================================================
 **     @brief 		 Search empty space of EEP buffer
 **     @Parameters  pbIndex  pointer to the storage index number
 **     @Returns     0u : No buffer space
 **     			 1u : Find a buffer space
 ** ===================================================================
 */
static u8 sEEP_FindEmptySpace(u8 * pbIndex)
{
	u8 bRet = 0u;

	if(0u < xEEPBuf.bFree)
	{
		*pbIndex = xEEPBuf.bFtIdx;
		xEEPBuf.bFtIdx++;
		if(EEP_BUFFER_NUMBER == xEEPBuf.bFtIdx)
		{
			xEEPBuf.bFtIdx = 0u;
		}
		xEEPBuf.bFree--;
		bRet = 1u;
	}

	return bRet;
}

/*
 ** ===================================================================
 **     @brief 		 Fetching next EEP buffer head information
 **     @Parameters  pbIndex  Pointer to the storage index number
 **     @Returns     0u : No EEP buffer head
 **     			 1u : Find a EEP buffer head
 ** ===================================================================
 */
static u8 sEEP_FetchingNextBuffHead(u8 * pbIndex)
{
	u8 bRet = 0u;

	if(EEP_BUFFER_NUMBER > xEEPBuf.bFree)
	{
		*pbIndex = xEEPBuf.bRrIdx;
		bRet = 1u;
	}

	return bRet;
}

/*
 ** ===================================================================
 **     @brief 		 Close current EEP buffer head information
 **     @Parameters  bIndex  Current EEP buffer head index
 **     @Returns
 ** ===================================================================
 */
static void sEEP_CloseCurrentBuffHead(u8 bIndex)
{
	if(EEP_BUFFER_NUMBER > bIndex)
	{
		if( ( 0u < xEEPBuf.xaHead[bIndex].wLength) &&
			( xEEPBuf.xaHead[bIndex].wCurLength == xEEPBuf.xaHead[bIndex].wLength) )
		{
			xEEPBuf.xaHead[bIndex].wLength = 0u;
			xEEPBuf.xaHead[bIndex].wCurLength = 0u;
			xEEPBuf.bRrIdx++;
			if(EEP_BUFFER_NUMBER == xEEPBuf.bRrIdx)
			{
				xEEPBuf.bRrIdx = 0u;
			}
			xEEPBuf.bFree++;
		}
	}
}

/*
 ** ===================================================================
 **     @brief 		 Check whether the EEP header information is
 **     			 synchronized with the ring information
 **     @Parameters  bBufIdx  EEP head index
 **     @Parameters  wRingIdx Ring current OutIdx
 **     @Returns     0u: Both information are not synchronized
 **     			 1u: Both information are synchronized
 ** ===================================================================
 */
static u8 sEEP_CheckBufferOutIdxIsCorrect(u8 bBufIdx,u16 wRingIdx)
{
	u8 bRet = 0u;
	u16 bStart = xEEPBuf.xaHead[bBufIdx].wStartPoint;
	u16 bEnd = xEEPBuf.xaHead[bBufIdx].wEndPoint;
	u16 bLenInRing = 0;

	/* Check ring buffer index value is in range */
	if(bEnd > bStart)
	{
		if( (wRingIdx >= bStart) && (wRingIdx < bEnd) )
		{
			bRet = 1u;
		}
	}
	else
	{
		if( ((wRingIdx >= bStart) && (wRingIdx > bEnd)) ||
			((wRingIdx < bStart ) && (wRingIdx < bEnd))	)
		{
			bRet = 1u;
		}
	}

	/* Check data length is correct  */
	if(1u == bRet)
	{
		if(bEnd > bStart)
		{
			bLenInRing = bEnd - wRingIdx;
		}
		else
		{
			bLenInRing = EEP_RINGBUF_SIZE - wRingIdx + bEnd;
		}

		if( bLenInRing != (xEEPBuf.xaHead[bBufIdx].wLength - xEEPBuf.xaHead[bBufIdx].wCurLength) )
		{
			bRet = 0u;
		}
	}

	return bRet;
}

/*
 ** ===================================================================
 **     @brief 		Puts a new element into the baBuffer
 **
 **     @Parameters    	puData 	Pointer to new data to be put into the Buffer
 **     @Parameters		wNumber data length
 **     @Returns		Number of pushes to the queue
 ** ===================================================================
 */
static u8 sEEP_RingBuf_Put(const u8 *puData, u16 wNumber)
{
	u8 bInCount = 0u;
	u16 wCount = wNumber;
	const u8 *puSrc = puData;

	while(wCount>0)
	{
		if (xEEPBuf.xRingInf.wInSize == EEP_RINGBUF_SIZE)
		{
			break;
		}
		else
		{
			xEEPBuf.xRingInf.baBuffer[xEEPBuf.xRingInf.wInIdx] = *puSrc;
			xEEPBuf.xRingInf.wInIdx++;
			if (xEEPBuf.xRingInf.wInIdx == EEP_RINGBUF_SIZE)
			{
				xEEPBuf.xRingInf.wInIdx = 0;
			}
			xEEPBuf.xRingInf.wInSize++;
		}

		bInCount++;
		puSrc++;
		wCount--;
	}
	return bInCount;
}

/*
** ===================================================================
**
**     @brief   Removes an element from the Buffer
**
**     @Parameters  puData  Pointer to where to store the received element
**     @Parameters  wNumber data length
**     @Returns     Number of fetches in the queue
** ===================================================================
*/
static u8 sEEP_RingBuf_Get(u8 *puData, u16 wNumber)
{
	u8 bOutCount = 0u;
	u8 *puDest = puData;
	u16 bCount = wNumber;

	while(bCount > bOutCount)
	{
		if (0u == xEEPBuf.xRingInf.wInSize)
		{
			break;
		}
		else
		{
			*puDest = xEEPBuf.xRingInf.baBuffer[xEEPBuf.xRingInf.wOutIdx];
			xEEPBuf.xRingInf.wOutIdx++;
			if (xEEPBuf.xRingInf.wOutIdx==EEP_RINGBUF_SIZE)
			{
				xEEPBuf.xRingInf.wOutIdx = 0u;
			}
			xEEPBuf.xRingInf.wInSize--;
			bOutCount++;
			puDest++;
		}
	}

	return bOutCount;
}

/*
** ===================================================================
**
**     @brief   write data to flexRAM block
**
**     @Parameters  bSize   Write data type size
**     @Parameters  dwDest  write data address
**     @Parameters  pbData  Pointer to new data to be write into the flexRAM
**     @Returns
** ===================================================================
*/
static void EEP_WriteDataToFlexRAM(u8 bSize,u32 dwDest,const u8 * pbData)
{
	DEV_ASSERT(pbData != NULL);
	u32 dwTemp;

	if (0x01U == bSize)
	{
		*(u8 *)dwDest = *pbData;
	}

	if (0x02U == bSize)
	{
		dwTemp = (u32)(pbData[1]) << 8U;
		dwTemp |= (u32)(pbData[0]);
		*(volatile u16 *)dwDest = (u16)dwTemp;
	}

	if (0x04U == bSize)
	{
		dwTemp =  (u32)(pbData[3]) << 24U;
		dwTemp |= (u32)(pbData[2]) << 16U;
		dwTemp |= (u32)(pbData[1]) << 8U;
		dwTemp |= (u32)(pbData[0]);
		*(volatile u32 *)dwDest = dwTemp;
	}

}

/*
** ===================================================================
**
**     @brief   write data to flexRAM block
**
**     @Parameters  wLength Write data type size
**     @Parameters  dwDest  write data address
**     @Returns
** ===================================================================
*/
static u8 sEEP_CheckAlignAndSize(u32 dwDeset, u16 wLength)
{
	u8 bSize;

	/* Dest is 32bit-aligned and size is not less than 4 */
	if ((0U == (dwDeset & 3U)) && (wLength >= 4U))
	{
		bSize = 4U;
	}
	else if ((0U == (dwDeset & 1U)) && (wLength >= 2U))
	{
		bSize = 2U;
	}
	else
	{
		bSize = 1U;
	}

	return bSize;
}

/*
** ===================================================================
**
**     @brief   fetching data from ring buffer and write to flexRAM
**
**     @Parameters  bBufIdx EEPROM buffer head index
**     @Returns		0u:
**     				1u: All data writing completed
** ===================================================================
*/
static u8 EEP_FetchingAndWriteData(u8 bBufIdx)
{

	u16 wRemaining = xEEPBuf.xaHead[bBufIdx].wLength - xEEPBuf.xaHead[bBufIdx].wCurLength;
	u32 dwDeset = xEEPBuf.xaHead[bBufIdx].dwAddress;
	u8 bSize = 0u;
	u8 aTempData[4] = {0};
	u8 bRet = 0;

	if(IsFlexRamReady())
	{
		if( (wRemaining > 0u) && (wRemaining <= xEEPBuf.xRingInf.wInSize) )
		{
			dwDeset += xEEPBuf.xaHead[bBufIdx].wCurLength;
			bSize = sEEP_CheckAlignAndSize(dwDeset,wRemaining);
			(void)sEEP_RingBuf_Get(&aTempData[0],bSize);
			EEP_WriteDataToFlexRAM(bSize,dwDeset,(const u8 *)&aTempData);
			xEEPBuf.xaHead[bBufIdx].wCurLength += bSize;
		}

		if(xEEPBuf.xaHead[bBufIdx].wCurLength == xEEPBuf.xaHead[bBufIdx].wLength)
		{
			bRet = 1u;
		}
	}

	return bRet;
}

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
void sEEPROMInit(void) {

	status_t xRet;
	flash_eeprom_status_t EEStatus;

	sEEP_RingBuf_Init();
	wEmergenyWriteNumber = 0u;
	sNvmGetSSDConfig(&flashSSDConfig);

	xRet = FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_STATUS_QUERY, 0x00u,(flash_eeprom_status_t* const) &EEStatus);

	if(STATUS_SUCCESS == xRet)
	{

		if(1u == EEStatus.brownOutCode)
		{
			xRet = FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_COMPLETE_INTERRUPT_QUICK_WRITE, 0x00u,NULL);
		}

		if( (0u == EEStatus.brownOutCode) || ( (1u == EEStatus.brownOutCode) && (STATUS_SUCCESS == xRet) ) )
		{
			(void) FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_ENABLE, 0x00u,NULL);
		}
	}
}

void sEEP_Task(void)
{

	switch(eEEPStatus)
	{
		case EEPIdle:

			if(CheckEEPIsNotEmpty())
			{
				eEEPStatus = EEPGetData;
			}

		break;

		case EEPGetData:

			if(true == sEEP_FetchingNextBuffHead(&bEEPHeadIdx))
			{
				u16 bRingGetIdx = sEEP_GetBuffOutputIdx();

				if(true == sEEP_CheckBufferOutIdxIsCorrect(bEEPHeadIdx,bRingGetIdx ))
				{
					eEEPStatus = EEPWriteData;
				}
			}

		break;

		case EEPWriteData:

			if(true == EEP_FetchingAndWriteData(bEEPHeadIdx))
			{
				sEEP_CloseCurrentBuffHead(bEEPHeadIdx);
			}

			if( (0u == xEEPBuf.xaHead[bEEPHeadIdx].wLength) &&
			     IsFlexRamReady() )
			{
				if(CheckEEPIsNotEmpty())
				{
					eEEPStatus = EEPGetData;
				}
				else
				{
					eEEPStatus = EEPIdle;
				}
			}

		break;

		case EEPClearData:

			if( 0u < xEEPData.wClrLength )
			{
				if(IsFlexRamReady())
				{
					u32 dwEmpty = 0xFFFFFFFFu;

					xEEPData.bWrSize = sEEP_CheckAlignAndSize(xEEPData.dwClrAddr, xEEPData.wClrLength);
					EEP_WriteDataToFlexRAM(xEEPData.bWrSize,xEEPData.dwClrAddr, (const u8 *) &dwEmpty);

					if(xEEPData.bWrSize <= xEEPData.wClrLength)
					{
						xEEPData.wClrLength -= xEEPData.bWrSize;
						xEEPData.dwClrAddr += xEEPData.bWrSize;
					}
				}
			}
			else
			{
				eEEPStatus = EEPIdle;
			}

		break;

		default:
			eEEPStatus = EEPIdle;
		break;
	}
}

/*
** ===================================================================
**
**     @brief   Check EEPROM is idle status
**
**     @Returns     true EEPROM is idle
**     				false EEPROM is not idle
** ===================================================================
*/
u8 sEEP_IsIdle(void)
{
	u8 bRet = 0u;

	if(eEEPStatus == EEPIdle)
	{
		bRet = 1u;
	}

	return bRet;
}

/*
** ===================================================================
**
**     @brief   Get remaining size from buffer
**
**     @Returns     Number of remaining size
** ===================================================================
*/
u16 sEEP_GetFreeBufferSize(void)
{
	u16 bSize = 0u;

	if(xEEPBuf.bFree > 0u)
	{
		bSize = EEP_RINGBUF_SIZE - xEEPBuf.xRingInf.wInSize;
	}

	return bSize;
}

/*
** ===================================================================
**
**     @brief   Write data to EEPROM
**
**     @Parameters  dwDest  Start address for the intended write operation.
**     @Parameters  bSize   Size in byte to be written.
**     @Parameters  pbData  Pointer to source address from which data
**     @Returns     operation status
**        - 1u:         Operation was successful.
**        - 0u:         Operation failure was occurred.
** ===================================================================
*/
u8 sEEP_Write(u32 dwDest, u16 wSize, const u8 * pbData)
{
	DEV_ASSERT(pbData != NULL);
	DEV_ASSERT(bSize > 0U);

	u8  bRet = 0u;    /* Return code variable */
	u16 bFreeSize = sEEP_GetFreeBufferSize();
	u8 bEEPIdx = 0u;

	/* Check range */
	if ((dwDest >= EEP_Start_Addr) && ((dwDest + wSize) <= (EEP_Stop_Addr)))
	{
		bRet = 1u;
	}

	if( (1u == bRet) && (bFreeSize >= wSize) )
	{
		if(1u == sEEP_FindEmptySpace(&bEEPIdx))
		{
			xEEPBuf.xaHead[bEEPIdx].dwAddress = dwDest;
			xEEPBuf.xaHead[bEEPIdx].wLength  = wSize;
			xEEPBuf.xaHead[bEEPIdx].wCurLength = 0u;
			xEEPBuf.xaHead[bEEPIdx].wStartPoint = sEEP_GetBuffInputIdx();
			(void)sEEP_RingBuf_Put(pbData,wSize);
			xEEPBuf.xaHead[bEEPIdx].wEndPoint = sEEP_GetBuffInputIdx();
			if(EEPIdle == eEEPStatus)
			{
				eEEPStatus = EEPGetData;
			}
		}
		else
		{
			bRet = 0u;
		}
	}
	else
	{
		bRet = 0u;
	}

	return bRet;
}

u8 sEEP_Emergency(u16 byteNumber)
{

	u8 bRet = FALSE;

	if(EEPIdle == eEEPStatus)
	{
		sEEP_RingBuf_Clear();
		bRet = TRUE;
		(void) FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_QUICK_WRITE, byteNumber, NULL);
	}

	return bRet;
}
/*
** ===================================================================
**
**     @brief   Clear EEPROM data
**
**     @Parameters  dwDest  Start address for the intended write operation.
**     @Parameters  bSize   Size in byte to be cleared.
**     @Returns     operation status
**        - 1u:         Operation was successful.
**        - 0u:         Operation failure was occurred.
** ===================================================================
*/
u8 sEEP_ClearData(u32 dwDest, u16 wSize)
{
	DEV_ASSERT(bSize > 0U);

	u8 bRet = 0u;    /* Return code variable */

	/* Check range */
	if ((dwDest >= EEP_Start_Addr) && ((dwDest + wSize) <= (EEP_Stop_Addr)))
	{
		bRet = 1u;
	}

	if( (1u == bRet ) && sEEP_IsIdle() )
	{
		xEEPData.dwClrAddr = dwDest;
		xEEPData.wClrLength = wSize;
		eEEPStatus = EEPClearData;
	}
	else
	{
		bRet = 0u;
	}

	return bRet;
}

/*
** ===================================================================
**
**     @brief   Clear all EEPROM
**
**     @Returns     operation status
**        - 1u:         Operation was successful.
**        - 0u:         Operation failure was occurred.
** ===================================================================
*/
u8 sEEP_ClearAll(void)
{
	u8 bRet = 0u;    /* Return code variable */

	bRet = sEEP_ClearData(EEP_Start_Addr, (EEP_Stop_Addr-EEP_Start_Addr));

	return bRet;
}

