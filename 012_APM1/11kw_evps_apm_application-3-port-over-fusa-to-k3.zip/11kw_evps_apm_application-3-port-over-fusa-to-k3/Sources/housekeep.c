/**
 * @file        housekeep.c
 * @copyright   Lite-On Technology Corp.
 */


//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "timer.h"
#include "gpio.h"
#include "type.h"
#include "can.h"
#include "housekeep.h"
#include "pwm.h"
#include "sbc.h"
#include "adc.h"
#include "nvm.h"
#include "math.h"
#include "if.h"
#include "config.h"
#include "obc.h"
#include "evse.h"
#include "networkManagement.h"
#include "dtcRecord.h"
#include "autolibc.h"
#include "dtcmgr.h"
#include "SafetyMeasure.h"
#include "PowerDerating.h"


#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define APM_EFFICIENCY                          0.95F

#define DELAY_MS_1ST_TEST                       10U
#define DELAY_MS_POWERON                        200U // NOTE! it need more than IGN assert check time
#define DELAY_MS_AUX_UV                         50U
#define DELAY_MS_SLEEP                          100U
#define DELAY_MS_NM_RELEASE                     5000U
#define DELAY_MS_PRECHARGE                      100U
#define DELAY_MS_DISCHARGE                      100U
#define DELAY_MS_FAULT                          500U
#define DELAY_MS_LATCH                          1000U
#define DELAY_MS_DIAG_TEST                      20U

#define PRECHARGE_HVDC_VOLT                     300.0F
#define DISCHARGE_HVDC_VOLT                     50.0F

#define ASSERT_HV_IN_LOW                        195.0F
#define DEASSERT_HV_IN_LOW                      200.0F
#define ASSERT_HV_IN_HIGH                       405.0F
#define DEASSERT_HV_IN_HIGH                     400.0F

#define ASSERT_BAT_LOW                          8.0F
#define DEASSERT_BAT_LOW                        8.5F
#define ASSERT_BAT_HIGH                         15.0F
#define DEASSERT_BAT_HIGH                       14.5F

#define ERROR_MASK_POWERON                      ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_BST_OC \
                                                | MASK_BST_OV_SW \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR \
                                                | MASK_DIAG_OV_ERR \
                                                | MASK_DIAG_SC_ERR )

#define ERROR_MASK_IDLE                         ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_LV_OV_HW \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_OC_HW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_PCB_OT \
                                                | MASK_SR_OT \
                                                | MASK_COOL_OT \
                                                | MASK_BST_OV_SW \
                                                | MASK_BST_OV_HW \
                                                | MASK_BST_OC \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR )


#define ERROR_MASK_STANDBY                      ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_LV_OV_HW \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_OC_HW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_PCB_OT \
                                                | MASK_SR_OT \
                                                | MASK_COOL_OT \
                                                | MASK_BST_OV_SW \
                                                | MASK_BST_OV_HW \
                                                | MASK_BST_OC \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR )

#define ERROR_MASK_DIAG                         ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_PCB_OT \
                                                | MASK_SR_OT \
                                                | MASK_COOL_OT \
                                                | MASK_BST_OV_SW \
                                                | MASK_BST_OV_HW \
                                                | MASK_BST_OC \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR \
                                                | MASK_DIAG_OV_ERR \
                                                | MASK_DIAG_SC_ERR )


    
#define ERROR_MASK_SOFTSTART                    ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_LV_OV_HW \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_OC_HW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_HV_UV \
                                                | MASK_PCB_OT \
                                                | MASK_SR_OT \
                                                | MASK_COOL_OT \
                                                | MASK_BST_OV_SW \
                                                | MASK_BST_OV_HW \
                                                | MASK_BST_OC \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR )


#define ERROR_MASK_DCDC                         ( MASK_SBC_ERR \
                                                | MASK_CONF_ERR \
                                                | MASK_CALI_ERR \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV \
                                                | MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_LV_OV_HW \
                                                | MASK_LV_OV_SW \
                                                | MASK_LV_UV \
                                                | MASK_LV_OC_HW \
                                                | MASK_LV_OC_SW \
                                                | MASK_HV_OV \
                                                | MASK_HV_OC \
                                                | MASK_HV_UV \
                                                | MASK_PCB_OT \
                                                | MASK_SR_OT \
                                                | MASK_COOL_OT \
                                                | MASK_BST_OC \
                                                | MASK_BST_OV_HW \
                                                | MASK_BST_OV_SW \
                                                | MASK_BST_UV \
                                                | MASK_LV_OP \
                                                | MASK_HV_AUX_OV \
                                                | MASK_CPU_ERR )

#define WARNING_MASK                            ( MASK_CONF_EMPTY \
                                                | MASK_CALI_EMPTY \
                                                | MASK_DSP_NG \
                                                | MASK_DSP_LOSS \
                                                | MASK_VCU_LOSS \
                                                | MASK_OBC_NG \
                                                | MASK_CP_OF \
                                                | MASK_CP_UF )

#define LV_AUX_RETRY_MASK                       ( MASK_LV_AUX_OV \
                                                | MASK_LV_AUX_UV \
                                                | MASK_BAT_OV \
                                                | MASK_BAT_UV )

#define HW_LATCH_ERROR_MASK                     ( MASK_LV_OV_HW \
                                                | MASK_LV_OC_HW \
                                                | MASK_BST_OV_HW )


//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

typedef bool (*pfCheckFunc)(void);

typedef struct HYSTERESIS_EVENT_S           /* hysteresis event */
{
    u8 bBitMaskIndex;                       // a ID list in \BIT_FLAG_E
    const u8 *pbDisable;                    // point to a char, to disable this event if only if 'T'
    bool blState;                           // event is assert or not
    pfCheckFunc pfAssertCheck;              // point to a function to check assertion
    u16 wAssertCount;                       // internal counter for assertion
    const u16 *pwAssertTime;                // point to sustain time, time unit: 1ms
    pfCheckFunc pfDeassertCheck;            // point to a function to check deassertion
    u16 wDeassertCount;                     // internal counter for deassertion
    const u16 *pwDeassertTime;              // point to sustain time, time unit: 1ms
    u8 bRetryCounter;                       // internal retry counter
    const u8 *pbRetryEnable;                // point to a char, to enable retry if only if 'T'
    const u16 *pwRetryLimit;                // point to retry limit number of times
    const u16 *pwRetryDelay;                // point to retry delay time (ms)
}x_he_t;


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


/*------ assetion or deassertion check functions for x_he_t structure  -------*/
/*---------------------------------- start  ----------------------------------*/
static bool sblAssertBoostOvSw(void);
static bool sblDeassertBoostOvSw(void);
static bool sblAssertBoostOvHw(void);
static bool sblDeassertBoostOvHw(void);
static bool sblAssertBoostUv(void);
static bool sblDeassertBoostUv(void);
static bool sblAssertBoostOc(void);
static bool sblDeassertBoostOc(void);

static bool sblAssertLvAuxUv(void);
static bool sblDeassertLvAuxUv(void);
static bool sblAssertLvAuxOv(void);
static bool sblDeassertLvAuxOv(void);

static bool sblAssertHvAuxUv(void);
static bool sblDeassertHvAuxUv(void);
static bool sblAssertHvAuxOv(void);
static bool sblDeassertHvAuxOv(void);

static bool sblAssertLvOvSw(void);
static bool sblDeassertLvOvSw(void);
static bool sblAssertLvUv(void);
static bool sblDeassertLvUv(void);
static bool sblAssertLvOcSw(void);
static bool sblDeassertLvOcSw(void);
static bool sblAssertLvOvHw(void);
static bool sblDeassertLvOvHw(void);
static bool sblAssertLvOcHw(void);
static bool sblDeassertLvOcHw(void);
static bool sblAssertLvOp(void);
static bool sblDeassertLvOp(void);

static bool sblAssertPcbOt(void);
static bool sblDeassertPcbOt(void);
static bool sblAssertSrOt(void);
static bool sblDeassertSrOt(void);
static bool sblAssertCoolantOt(void);
static bool sblDeassertCoolantOt(void);

static bool sblAssertCpOf(void);
static bool sblDeassertCpOf(void);
static bool sblAssertCpUf(void);
static bool sblDeassertCpUf(void);

static bool sblAssertIgnHigh(void);
static bool sblDeassertIgnHigh(void);

static bool sblAssertHvdcHigh(void);
static bool sblDeassertHvdcHigh(void);
static bool sblAssertHvdcLow(void);
static bool sblDeassertHvdcLow(void);
static bool sblAssertHvdcOv(void);
static bool sblDeassertHvdcOv(void);
static bool sblAssertHvdcUv(void);
static bool sblDeassertHvdcUv(void);
static bool sblAssertHvdcOc(void);
static bool sblDeassertHvdcOc(void);


static bool sblAssertBatteryLow(void);
static bool sblDeassertBatteryLow(void);
static bool sblAssertBatteryUv(void);
static bool sblDeassertBatteryUv(void);
static bool sblAssertBatteryHigh(void);
static bool sblDeassertBatteryHigh(void);
static bool sblAssertBatteryOv(void);
static bool sblDeassertBatteryOv(void);

static bool sblAssertObcFail(void);
static bool sblDeassertObcFail(void);
static bool sblAssertDspFail(void);
static bool sblDeassertDspFail(void);

static bool sblAssertCan0Loss(void);
static bool sblDeassertCan0Loss(void);
static bool sblAssertCan2Loss(void);
static bool sblDeassertCan2Loss(void);

static bool sblAssertDiagOvpFail(void);
static bool sblDeassertDiagOvpFail(void);
static bool sblAssertDiagScpFail(void);
static bool sblDeassertDiagScpFail(void);

static void sVcmdToDuty(void);
static void sIcmdToDuty(void);

static void sObcOnOffCheck(void);

static void sApmDtcPassProcess(void);
static void sApmDtcFailProcess(void);


/*----------------------------------   end  ----------------------------------*/
/*------ assetion or deassertion check functions for x_he_t structure  -------*/


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static bool blSoftStartFinish = false;
static u64 qwEventFlags = 0ULL;
static u64 qwSystemEventFlags = 0ULL;

static x_conf_data_t xConfData;

static const x_if_ci0_t *pxIfCi0Data = NULL;    // point to IF_CI0 data
static const x_if_ci2_t *pxIfCi2Data = NULL;    // point to IF_CI2 data
static const x_if_di_t *pxIfDiData = NULL;      // point to IF_DI data
static const x_if_ai_t *pxIfAiData = NULL;      // point to IF_AI data
static const x_if_oo_t *pxIfObcData = NULL;     // point to IF_OO data
static const x_if_ei_t *pxIfEiData = NULL;      // point to IF_EI data
static const x_if_eo_t *pxIfEvseOutput = NULL;  // point to IF_EO data

static x_if_ho_t xIfHoData =                    // IF_HO, housekeep output data
{
    .eApmWorkMode       = APM_MODE_POWERON,
    .qwApmErrorFlag     = 0ULL,

    .flLvdcVcmd         = 0.0F,
    .flLvdcIcmd         = 0.0F,
    .wVcmdDutyCnt       = 0,
    .wIcmdDutyCnt       = 0,

    .eIgnState          = BOOL_FALSE,

    .eLvdcEnDol         = BOOL_FALSE,
    .eBoostEnDol        = BOOL_FALSE,
    .eApmAuxEnDoh       = BOOL_FALSE,
    .eLatchUnlockDoh    = BOOL_FALSE,
    .eDiagApmDoh        = BOOL_FALSE,

    .eApmAuxUvCheck     = BOOL_FALSE,
    .eLvdcUvCheck       = BOOL_FALSE,
    .eBoostUvCheck      = BOOL_FALSE,
};

static snapshot_record_t xSnapshotRecord;


static const u8 bDisableIgnCheck = 0;           // 'T' to disable
static const u16 wIgnAssertTime = 100U;         // 0.1 s, NOTE! it need less than poweron delay time
static const u16 wIgnDeassertTime = 100U;       // 0.1 s

static const u8 bDisableBatLowCheck = 0;        // 'T' to disable
static const u16 wBatLowAssertTime = 100U;      // 0.1 s
static const u16 wBatLowDeassertTime = 100U;    // 0.1 s

static const u8 bDisableBatHighCheck = 0;       // 'T' to disable
static const u16 wBatHighAssertTime = 100U;     // 0.1 s
static const u16 wBatHighDeassertTime = 100U;   // 0.1 s

static const u8 bDisableHvdcLowCheck = 0;       // 'T' to disable
static const u16 wHvdcLowAssertTime = 100U;     // 0.1 s
static const u16 wHvdcLowDeassertTime = 100U;   // 0.1 s

static const u8 bDisableHvdcHighCheck = 0;      // 'T' to disable
static const u16 wHvdcHighAssertTime = 100U;    // 0.1 s
static const u16 wHvdcHighDeassertTime = 100U;  // 0.1 s

static const u16 wDspNgAssertTime = 10U;        // 0.01 s
static const u16 wDspNgDeassertTime = 100U;     // 0.1 s

static const u16 wObcNgAssertTime = 10U;        // 0.01 s
static const u16 wObcNgDeassertTime = 100U;     // 0.1 s

static const u16 wCan0LossAssertTime = 1000U;   // 1.0 s
static const u16 wCan0LossDeassertTime = 500U;  // 0.5 s
static const u16 wCan2LossAssertTime = 1000U;   // 1.0 s
static const u16 wCan2LossDeassertTime = 500U;  // 0.5 s

static const u8 bNoRetry = 0;
static const u16 wNotUse = 0;
static const u8 bFalse = 0;
static const u8 bTrue = (u8)'T';

static x_he_t xaEvent[EVENT_NUM] =              // Hysteresis Event data
{
    {                                           // EVENT_BST_OV_SW
        .bBitMaskIndex      = (u8)BIT_BST_OV_SW,
        .pbDisable          = &bTrue,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBoostOvSw,
        .wAssertCount       = 0,
        .pwAssertTime       = &wNotUse,
        .pfDeassertCheck    = &sblDeassertBoostOvSw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wNotUse,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_BST_OV_HW
        .bBitMaskIndex      = (u8)BIT_BST_OV_HW,
        .pbDisable          = &bTrue,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBoostOvHw,
        .wAssertCount       = 0,
        .pwAssertTime       = &wNotUse,
        .pfDeassertCheck    = &sblDeassertBoostOvHw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wNotUse,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_BST_OC
        .bBitMaskIndex      = (u8)BIT_BST_OC,
        .pbDisable          = &bTrue,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBoostOc,
        .wAssertCount       = 0,
        .pwAssertTime       = &wNotUse,
        .pfDeassertCheck    = &sblDeassertBoostOc,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wNotUse,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_BST_UV
        .bBitMaskIndex      = (u8)BIT_BST_UV,
        .pbDisable          = &bTrue,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBoostUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &wNotUse,
        .pfDeassertCheck    = &sblDeassertBoostUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wNotUse,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_LV_OV_SW
        .bBitMaskIndex      = (u8)BIT_LV_OV_HW,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvOvSw,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvOvSw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].wRetryInterval,
    },
    {                                           // EVENT_LV_UV
        .bBitMaskIndex      = (u8)BIT_LV_UV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].wRetryInterval,
    },
    {                                           // EVENT_HVDC_OV
        .bBitMaskIndex      = (u8)BIT_HV_OV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvdcOv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertHvdcOv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].wRetryInterval,
    },
    {                                           // EVENT_HVDC_UV
        .bBitMaskIndex      = (u8)BIT_HV_UV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvdcUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertHvdcUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].wRetryInterval,
    },
    {                                           // EVENT_HVDC_OC
        .bBitMaskIndex      = (u8)BIT_HV_OC,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvdcOc,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertHvdcOc,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].wRetryInterval,
    },
    {                                           // EVENT_HV_AUX_UV
        .bBitMaskIndex      = (u8)BIT_HV_AUX_UV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvAuxUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertHvAuxUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].wRetryInterval,
    },
    {                                           // EVENT_HV_AUX_OV
        .bBitMaskIndex      = (u8)BIT_HV_AUX_OV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvAuxOv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertHvAuxOv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].wRetryInterval,
    },
    {                                           // EVENT_LV_AUX_UV
        .bBitMaskIndex      = (u8)BIT_LV_AUX_UV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvAuxUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvAuxUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].wRetryInterval,
    },
    {                                           // EVENT_LV_AUX_OV
        .bBitMaskIndex      = (u8)BIT_LV_AUX_OV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvAuxOv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvAuxOv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].wRetryInterval,
    },
    {                                           // EVENT_LV_OC_SW
        .bBitMaskIndex      = (u8)BIT_LV_OC_SW,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvOcSw,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvOcSw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].wRetryInterval,
    },
    {                                           // EVENT_LV_OV_HW
        .bBitMaskIndex      = (u8)BIT_LV_OV_HW,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvOvHw,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvOvHw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_HW].wRetryInterval,
    },
    {                                           // EVENT_LV_OC_HW
        .bBitMaskIndex      = (u8)BIT_LV_OC_HW,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvOcHw,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvOcHw,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_HW].wRetryInterval,
    },
    {                                           // EVENT_LV_OP
        .bBitMaskIndex      = (u8)BIT_LV_OP,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertLvOp,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertLvOp,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].wRetryInterval,
    },
    {                                           // EVENT_PCB_OT
        .bBitMaskIndex      = (u8)BIT_PCB_OT,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertPcbOt,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertPcbOt,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].wRetryInterval,
    },
    {                                           // EVENT_SR_OT
        .bBitMaskIndex      = (u8)BIT_SR_OT,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertSrOt,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertSrOt,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].wRetryInterval,
    },
    {                                           // EVENT_COOLANT_OT
        .bBitMaskIndex      = (u8)BIT_COOL_OT,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertCoolantOt,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertCoolantOt,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].wRetryInterval,
    },
    {                                           // EVENT_BAT_OV
        .bBitMaskIndex      = (u8)BIT_BAT_OV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBatteryOv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertBatteryOv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].wRetryInterval,
    },
    {                                           // EVENT_BAT_UV
        .bBitMaskIndex      = (u8)BIT_BAT_UV,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBatteryUv,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertBatteryUv,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].wRetryInterval,
    },
    {                                           // EVENT_CP_OF
        .bBitMaskIndex      = (u8)BIT_CP_OF,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertCpOf,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertCpOf,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].wRetryInterval,
    },
    {                                           // EVENT_CP_UF
        .bBitMaskIndex      = (u8)BIT_CP_UF,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertCpUf,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertCpUf,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].wRetryInterval,
    },
    {                                           // EVENT_OBC_NG
        .bBitMaskIndex      = (u8)BIT_OBC_NG,
        .pbDisable          = &bFalse,
        .blState            = false,
        .pfAssertCheck      = &sblAssertObcFail,
        .wAssertCount       = 0,
        .pwAssertTime       = &wObcNgAssertTime,
        .pfDeassertCheck    = &sblDeassertObcFail,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wObcNgDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_DSP_NG
        .bBitMaskIndex      = (u8)BIT_DSP_NG,
        .pbDisable          = &bFalse,
        .blState            = false,
        .pfAssertCheck      = &sblAssertDspFail,
        .wAssertCount       = 0,
        .pwAssertTime       = &wDspNgAssertTime,
        .pfDeassertCheck    = &sblDeassertDspFail,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wDspNgDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_VCU_LOSS
        .bBitMaskIndex      = (u8)BIT_VCU_LOSS,
        .pbDisable          = &bFalse,
        .blState            = false,
        .pfAssertCheck      = &sblAssertCan0Loss,
        .wAssertCount       = 0,
        .pwAssertTime       = &wCan0LossAssertTime,
        .pfDeassertCheck    = &sblDeassertCan0Loss,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wCan0LossDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_DSP_LOSS
        .bBitMaskIndex      = (u8)BIT_DSP_LOSS,
        .pbDisable          = &bFalse,
        .blState            = false,
        .pfAssertCheck      = &sblAssertCan2Loss,
        .wAssertCount       = 0,
        .pwAssertTime       = &wCan2LossAssertTime,
        .pfDeassertCheck    = &sblDeassertCan2Loss,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wCan2LossDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_DIAG_OVP
        .bBitMaskIndex      = (u8)BIT_DIAG_OV_ERR,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertDiagOvpFail,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertDiagOvpFail,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_OVP].wRetryInterval,
    },
    {                                           // EVENT_DIAG_SCP
        .bBitMaskIndex      = (u8)BIT_DIAG_SC_ERR,
        .pbDisable          = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].bDisableSetting,
        .blState            = false,
        .pfAssertCheck      = &sblAssertDiagScpFail,
        .wAssertCount       = 0,
        .pwAssertTime       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].wResponseTime,
        .pfDeassertCheck    = &sblDeassertDiagScpFail,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].wRecoveryTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].bEnableRetry,
        .pwRetryLimit       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].wRetryLimit,
        .pwRetryDelay       = &xConfData.xaItem[CONF_ITEM_MCU_DIAG_SCP].wRetryInterval,
    },

    {                                           // EVENT_IGN_ON
        .bBitMaskIndex      = (u8)BIT_INVALID,
        .pbDisable          = &bDisableIgnCheck,
        .blState            = false,
        .pfAssertCheck      = &sblAssertIgnHigh,
        .wAssertCount       = 0,
        .pwAssertTime       = &wIgnAssertTime,
        .pfDeassertCheck    = &sblDeassertIgnHigh,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wIgnDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },

    {                                           // EVENT_BAT_LOW
        .bBitMaskIndex      = (u8)BIT_INVALID,
        .pbDisable          = &bDisableBatLowCheck,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBatteryLow,
        .wAssertCount       = 0,
        .pwAssertTime       = &wBatLowAssertTime,
        .pfDeassertCheck    = &sblDeassertBatteryLow,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wBatLowDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_BAT_HIGH
        .bBitMaskIndex      = (u8)BIT_INVALID,
        .pbDisable          = &bDisableBatHighCheck,
        .blState            = false,
        .pfAssertCheck      = &sblAssertBatteryHigh,
        .wAssertCount       = 0,
        .pwAssertTime       = &wBatHighAssertTime,
        .pfDeassertCheck    = &sblDeassertBatteryHigh,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wBatHighDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_HVDC_LOW
        .bBitMaskIndex      = (u8)BIT_INVALID,
        .pbDisable          = &bDisableHvdcLowCheck,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvdcLow,
        .wAssertCount       = 0,
        .pwAssertTime       = &wHvdcLowAssertTime,
        .pfDeassertCheck    = &sblDeassertHvdcLow,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wHvdcLowDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
    {                                           // EVENT_HVDC_HIGH
        .bBitMaskIndex      = (u8)BIT_INVALID,
        .pbDisable          = &bDisableHvdcHighCheck,
        .blState            = false,
        .pfAssertCheck      = &sblAssertHvdcHigh,
        .wAssertCount       = 0,
        .pwAssertTime       = &wHvdcHighAssertTime,
        .pfDeassertCheck    = &sblDeassertHvdcHigh,
        .wDeassertCount     = 0,
        .pwDeassertTime     = &wHvdcHighDeassertTime,
        .bRetryCounter      = 0,
        .pbRetryEnable      = &bNoRetry,
        .pwRetryLimit       = &wNotUse,
        .pwRetryDelay       = &wNotUse,
    },
};



//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

static bool sblAssertIgnHigh(void)
{
    return (pxIfDiData->eSbcIgnDih == BOOL_TRUE);
}

static bool sblDeassertIgnHigh(void)
{
    return (pxIfDiData->eSbcIgnDih == BOOL_FALSE);
}


static bool sblAssertBatteryLow(void)
{
    return (pxIfAiData->flLvBatVolt < ASSERT_BAT_LOW);
}

static bool sblDeassertBatteryLow(void)
{
    return (pxIfAiData->flLvBatVolt > DEASSERT_BAT_LOW);
}

static bool sblAssertBatteryUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].flTriggerPoint;
    return (pxIfAiData->flLvBatVolt < flVal);
}

static bool sblDeassertBatteryUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BAT_UVP].flRecoveryPoint;
    return (pxIfAiData->flLvBatVolt > flVal);
}

static bool sblAssertBatteryHigh(void)
{
    return (pxIfAiData->flLvBatVolt > ASSERT_BAT_HIGH);
}

static bool sblDeassertBatteryHigh(void)
{
    return (pxIfAiData->flLvBatVolt < DEASSERT_BAT_HIGH);
}

static bool sblAssertBatteryOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].flTriggerPoint;
    return (pxIfAiData->flLvBatVolt > flVal);
}

static bool sblDeassertBatteryOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BAT_OVP].flRecoveryPoint;
    return (pxIfAiData->flLvBatVolt < flVal);
}

static bool sblAssertHvdcHigh(void)
{
    return (pxIfAiData->flHvdcVolt > ASSERT_HV_IN_HIGH);
}

static bool sblDeassertHvdcHigh(void)
{
    return (pxIfAiData->flHvdcVolt < DEASSERT_HV_IN_HIGH);
}

static bool sblAssertHvdcLow(void)
{
    return (pxIfAiData->flHvdcVolt < ASSERT_HV_IN_LOW);
}

static bool sblDeassertHvdcLow(void)
{
    return (pxIfAiData->flHvdcVolt > DEASSERT_HV_IN_LOW);
}

static bool sblAssertHvdcOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].flTriggerPoint;
    return (pxIfAiData->flHvdcVolt > flVal);
}

static bool sblDeassertHvdcOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_OVP].flRecoveryPoint;
    return (pxIfAiData->flHvdcVolt < flVal);
}

static bool sblAssertHvdcUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].flTriggerPoint;
    return (pxIfAiData->flHvdcVolt < flVal);
}

static bool sblDeassertHvdcUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_UVP].flRecoveryPoint;
    return (pxIfAiData->flHvdcVolt > flVal);
}

static bool sblAssertHvdcOc(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].flTriggerPoint;
    return (pxIfAiData->flHvdcCurr > flVal);
}

static bool sblDeassertHvdcOc(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_OCP].flRecoveryPoint;
    return (pxIfAiData->flHvdcCurr < flVal);
}


static bool sblAssertBoostOvSw(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_OVP_SW].flTriggerPoint;
    return (pxIfAiData->flBoostVolt > flVal);
    #endif
    return false;
}

static bool sblDeassertBoostOvSw(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_OVP_SW].flRecoveryPoint;
    return (pxIfAiData->flBoostVolt < flVal);
    #endif
    return false;
}

static bool sblAssertBoostOvHw(void)
{
    return (pxIfDiData->eBoostOvpDih == BOOL_TRUE);
}

static bool sblDeassertBoostOvHw(void)
{
    return (pxIfDiData->eBoostOvpDih == BOOL_FALSE);
}

static bool sblAssertBoostOc(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_OCP].flTriggerPoint;
    return (pxIfAiData->flBoostCurr > flVal);
    #endif
    return false;
}

static bool sblDeassertBoostOc(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_OCP].flRecoveryPoint;
    return (pxIfAiData->flBoostCurr < flVal);
    #endif
    return false;
}

static bool sblAssertBoostUv(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_UVP].flTriggerPoint;
    return (pxIfAiData->flBoostVolt < flVal);
    #endif
    return false;
}

static bool sblDeassertBoostUv(void)
{
    #if 0
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_BST_UVP].flRecoveryPoint;
    return (pxIfAiData->flBoostVolt > flVal);
    #endif
    return false;
}


static bool sblAssertLvAuxUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].flTriggerPoint;
    return (pxIfAiData->flAuxLvVolt < flVal);
}

static bool sblDeassertLvAuxUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_UVP].flRecoveryPoint;
    return (pxIfAiData->flAuxLvVolt > flVal);
}

static bool sblAssertLvAuxOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].flTriggerPoint;
    return (pxIfAiData->flAuxLvVolt > flVal);
}

static bool sblDeassertLvAuxOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_AUX_OVP].flRecoveryPoint;
    return (pxIfAiData->flAuxLvVolt < flVal);
}

static bool sblAssertHvAuxUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].flTriggerPoint;
    return (pxIfAiData->flAuxHvVolt < flVal);
}

static bool sblDeassertHvAuxUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_UVP].flRecoveryPoint;
    return (pxIfAiData->flAuxHvVolt > flVal);
}

static bool sblAssertHvAuxOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].flTriggerPoint;
    return (pxIfAiData->flAuxHvVolt > flVal);
}

static bool sblDeassertHvAuxOv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_HV_AUX_OVP].flRecoveryPoint;
    return (pxIfAiData->flAuxHvVolt < flVal);
}


static bool sblAssertLvOvSw(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].flTriggerPoint;
    return (pxIfAiData->flLvdcVolt > flVal);
}

static bool sblDeassertLvOvSw(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OVP_SW].flRecoveryPoint;
    return (pxIfAiData->flLvdcVolt < flVal);
}

static bool sblAssertLvUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].flTriggerPoint;
    return (pxIfAiData->flLvdcVolt < flVal);
}

static bool sblDeassertLvUv(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_UVP].flTriggerPoint;
    return (pxIfAiData->flLvdcVolt > flVal);
}

static bool sblAssertLvOcSw(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].flTriggerPoint;
    return (pxIfAiData->flLvdcCurr > flVal);
}

static bool sblDeassertLvOcSw(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OCP_SW].flRecoveryPoint;
    return (pxIfAiData->flLvdcCurr < flVal);
}

static bool sblAssertLvOvHw(void)
{
    return (pxIfDiData->eHwOvpTriggered == BOOL_TRUE);
}

static bool sblDeassertLvOvHw(void)
{
    return (pxIfDiData->eHwOvpTriggered == BOOL_FALSE);
}

static bool sblAssertLvOcHw(void)
{
    return (pxIfDiData->eHwScpTriggered == BOOL_TRUE);
}

static bool sblDeassertLvOcHw(void)
{
    return (pxIfDiData->eHwScpTriggered == BOOL_FALSE);
}

static bool sblAssertLvOp(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].flTriggerPoint;
    f32 flPow = pxIfAiData->flLvdcVolt * pxIfAiData->flLvdcCurr;
    return (flPow > flVal);
}

static bool sblDeassertLvOp(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_LV_OPP].flRecoveryPoint;
    f32 flPow = pxIfAiData->flLvdcVolt * pxIfAiData->flLvdcCurr;
    return (flPow < flVal);
}

static bool sblAssertPcbOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].flTriggerPoint;
    return (pxIfAiData->flPcbTemp > flVal);
}

static bool sblDeassertPcbOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_PCB_OTP].flRecoveryPoint;
    return (pxIfAiData->flPcbTemp < flVal);
}

static bool sblAssertSrOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].flTriggerPoint;
    return (pxIfAiData->flSrTemp > flVal);
}

static bool sblDeassertSrOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_SR_OTP].flRecoveryPoint;
    return (pxIfAiData->flSrTemp < flVal);
}

static bool sblAssertCoolantOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].flTriggerPoint;
    return (pxIfAiData->flCoolTemp > flVal);
}

static bool sblDeassertCoolantOt(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_COOLANT_OTP].flRecoveryPoint;
    return (pxIfAiData->flCoolTemp < flVal);
}


static bool sblAssertCpOf(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].flTriggerPoint;
    return (pxIfEiData->flCpFreq > flVal);
}

static bool sblDeassertCpOf(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_EVSE_OFP].flRecoveryPoint;
    return (pxIfEiData->flCpFreq < flVal);
}

static bool sblAssertCpUf(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].flTriggerPoint;
    return (pxIfEiData->flCpFreq < flVal);
}

static bool sblDeassertCpUf(void)
{
    f32 flVal = xConfData.xaItem[CONF_ITEM_MCU_EVSE_UFP].flRecoveryPoint;
    return (pxIfEiData->flCpFreq > flVal);
}

static bool sblAssertObcFail(void)
{
    return ((pxIfEvseOutput->eCpReadyDoh == BOOL_TRUE)
            && (pxIfDiData->eObcOkDih == BOOL_FALSE));
}

static bool sblDeassertObcFail(void)
{
    return ((pxIfEvseOutput->eCpReadyDoh == BOOL_FALSE)
            || ((pxIfEvseOutput->eCpReadyDoh == BOOL_TRUE)
            && (pxIfDiData->eObcOkDih == BOOL_TRUE)));
}

static bool sblAssertDspFail(void)
{
    return (pxIfDiData->eDspOkDih == BOOL_FALSE);
}

static bool sblDeassertDspFail(void)
{
    return (pxIfDiData->eDspOkDih == BOOL_TRUE);
}

static bool sblAssertCan0Loss(void)
{
    return (pxIfCi0Data->eRxApmCmdTimeout == BOOL_TRUE);
}

static bool sblDeassertCan0Loss(void)
{
    return (pxIfCi0Data->eRxApmCmdTimeout == BOOL_FALSE);
}

static bool sblAssertCan2Loss(void)
{
    return (pxIfCi2Data->eRxTimeout == BOOL_TRUE);
}

static bool sblDeassertCan2Loss(void)
{
    return (pxIfCi2Data->eRxTimeout == BOOL_FALSE);
}

static bool sblAssertDiagOvpFail(void)
{
    bool blRet;

    if ((xIfHoData.eDiagApmDoh == BOOL_TRUE) 
        && (pxIfDiData->eLvdcOvpDih == BOOL_FALSE))
    {
        blRet = true;
    }
    else
    {
        blRet = false;
    }

    return blRet;
}

static bool sblDeassertDiagOvpFail(void)
{
    bool blRet;

    if ((xIfHoData.eDiagApmDoh == BOOL_TRUE) 
        && (pxIfDiData->eLvdcOvpDih == BOOL_TRUE))
    {
        blRet = true;
    }
    else
    {
        blRet = false;
    }

    return blRet;
}

static bool sblAssertDiagScpFail(void)
{
    bool blRet;

    if ((xIfHoData.eDiagApmDoh == BOOL_TRUE) 
        && (pxIfDiData->eLvdcScpDih == BOOL_FALSE))
    {
        blRet = true;
    }
    else
    {
        blRet = false;
    }

    return blRet;
}

static bool sblDeassertDiagScpFail(void)
{
    bool blRet;

    if ((xIfHoData.eDiagApmDoh == BOOL_TRUE) 
        && (pxIfDiData->eLvdcScpDih == BOOL_TRUE))
    {
        blRet = true;
    }
    else
    {
        blRet = false;
    }

    return blRet;
}

/**
 * @brief       Read current events and system events
 */
static u64 sqwEventFlagGet (void)
{
    qwEventFlags |= qwSystemEventFlags;
	return qwEventFlags;
}

static void sEventScan(void)
{
    u16 i;
    bool blDeassert;
    bool blAssert;
    u16 wTime;
    u8 bRet = 0;

    for (i = 0; i < (u16)EVENT_NUM; i++)
    {
        if (xaEvent[i].pbDisable == NULL)
        {
            bRet = 1U;
            goto LABEL_ERROR;
        }

        if (xaEvent[i].pfDeassertCheck == NULL)
        {
            bRet = 2U;
            goto LABEL_ERROR;
        }

        if (xaEvent[i].pfAssertCheck == NULL)
        {
            bRet = 3U;
            goto LABEL_ERROR;
        }

        if (*xaEvent[i].pbDisable != (u8)'T')
        {
            if (xaEvent[i].blState == true)
            {
                blDeassert = xaEvent[i].pfDeassertCheck();
                if (blDeassert == true)
                {
                    xaEvent[i].wDeassertCount++;

                    wTime = *xaEvent[i].pwDeassertTime / HOUSEKEEP_TIMEBASE;

                    if (xaEvent[i].wDeassertCount >= wTime)
                    {
                        xaEvent[i].blState = false;
                        xaEvent[i].wDeassertCount = 0;
                    }
                }
                else
                {
                    xaEvent[i].wDeassertCount = 0;
                }
            }
            else
            {
                blAssert = xaEvent[i].pfAssertCheck();
                if (blAssert == true)
                {
                    xaEvent[i].wAssertCount++;

                    wTime = *xaEvent[i].pwAssertTime / HOUSEKEEP_TIMEBASE;

                    if (xaEvent[i].wAssertCount >= wTime)
                    {
                        xaEvent[i].blState = true;
                        xaEvent[i].wAssertCount = 0;
                    }
                }
                else
                {
                    xaEvent[i].wAssertCount = 0;
                }
            }
        }
        else
        {
            xaEvent[i].wDeassertCount = 0;
            xaEvent[i].wAssertCount = 0;
            xaEvent[i].blState = false;
        }
    }

LABEL_ERROR:
    if (bRet != 0)
    {
        #if (HAVE_DEBUG_UART != 0)
	    DebugPrint("xaEvent[%d] NULL ERROR %d\n", i, bRet);
	    #endif

        while(true){;}                          // fatal error, stop here
    }
}

static void sInterfaceCheck(void)
{
    u8 i;
    e_if_err_t xRet = IF_ERR_NONE;

    for (i = (u8)IF_AI; i < (u8)IF_NUM; i++)
    {
        const void *pvTemp;

        /* polyspace-begin MISRA-C3:10.5 "different pointer type" */
        xRet = sbIfGet((e_if_id_t)i, true, &pvTemp);
        /* polyspace-end MISRA-C3:10.5 "different pointer type" */

        if (xRet != IF_ERR_NONE)
        {
            if (xRet == IF_ERR_TIMEOUT)         // if timeout due to timer stop
            {
                bool blEnable;

                if (i == (u8)IF_OO)
                {
                    blEnable = sblTimerIsEnable(TIMER_ID_OBC);
                }
                else if (i == (u8)IF_CI2)
                {
                    blEnable = false;
                }
                else
                {
                    blEnable = false;
                }
                                                // ignore this timeout error
                xRet = blEnable ? IF_ERR_TIMEOUT : IF_ERR_NONE;
            }
        }

        if (xRet != IF_ERR_NONE)
        {
            #if (HAVE_DEBUG_UART != 0)
    	    DebugPrint("sbIfGet[%d] ERROR %d\n", i, xRet);
    	    #endif
        }
    }
}

static void sErrorFlagUpdate(void)
{
    u64 qwFlags = 0;
    
    qwFlags |= xaEvent[EVENT_VCU_LOSS].blState ?        MASK_VCU_LOSS : 0;
    qwFlags |= xaEvent[EVENT_BAT_OV].blState ?          MASK_BAT_OV : 0;

    if (pxIfDiData->eHwSbcIntTriggered == BOOL_TRUE)
    {
        qwFlags |= MASK_BAT_UV;
    }

    qwFlags |= xaEvent[EVENT_BAT_UV].blState ?          MASK_BAT_UV : 0;
    qwFlags |= xaEvent[EVENT_LV_AUX_OV].blState ?       MASK_LV_AUX_OV : 0;
    qwFlags |= xaEvent[EVENT_LV_OV_HW].blState ?        MASK_LV_OV_HW : 0;
    qwFlags |= xaEvent[EVENT_LV_OV_SW].blState ?        MASK_LV_OV_SW : 0;
    qwFlags |= xaEvent[EVENT_LV_OC_HW].blState ?        MASK_LV_OC_HW : 0;
    qwFlags |= xaEvent[EVENT_LV_OC_SW].blState ?        MASK_LV_OC_SW : 0;
    qwFlags |= xaEvent[EVENT_HVDC_OV].blState ?         MASK_HV_OV : 0;
    qwFlags |= xaEvent[EVENT_HVDC_OC].blState ?         MASK_HV_OC : 0;
    qwFlags |= xaEvent[EVENT_HVDC_UV].blState ?         MASK_HV_UV : 0;
    qwFlags |= xaEvent[EVENT_PCB_OT].blState ?          MASK_PCB_OT : 0;
    qwFlags |= xaEvent[EVENT_SR_OT].blState ?           MASK_SR_OT : 0;
    qwFlags |= xaEvent[EVENT_COOLANT_OT].blState ?      MASK_COOL_OT : 0;
    qwFlags |= xaEvent[EVENT_LV_OP].blState ?           MASK_LV_OP : 0;
    qwFlags |= xaEvent[EVENT_HV_AUX_OV].blState ?       MASK_HV_AUX_OV : 0;

    #if (HVAE_BOOST_FUNC != 0)
    qwFlags |= xaEvent[EVENT_BST_OC].blState ?          MASK_BST_OC : 0;
    qwFlags |= xaEvent[EVENT_BST_OV_SW].blState ?       MASK_BST_OV_SW : 0;
    qwFlags |= xaEvent[EVENT_BST_OV_HW].blState ?       MASK_BST_OV_HW : 0;

    if ((xIfHoData.eBoostEnDol == BOOL_TRUE) 
        && (xIfHoData.eBoostUvCheck == BOOL_TRUE))
    {
        qwFlags |= xaEvent[EVENT_BST_UV].blState ?      MASK_BST_UV : 0;
    }
    #endif

    if ((xIfHoData.eApmWorkMode == APM_MODE_DIAG)
        || (xIfHoData.eApmWorkMode == APM_MODE_POWERON))
    {
        qwFlags |= xaEvent[EVENT_DIAG_OVP].blState ?    MASK_DIAG_OV_ERR : 0;
        qwFlags |= xaEvent[EVENT_DIAG_SCP].blState ?    MASK_DIAG_SC_ERR : 0;
    }

    if ((xIfHoData.eLvdcEnDol == BOOL_TRUE) 
        && (xIfHoData.eLvdcUvCheck == BOOL_TRUE))
    {
        qwFlags |= xaEvent[EVENT_LV_UV].blState ?       MASK_LV_UV : 0;
    }

    if ((xIfHoData.eApmAuxEnDoh == BOOL_TRUE)
        && (xIfHoData.eApmAuxUvCheck == BOOL_TRUE))
    {
        qwFlags |= xaEvent[EVENT_LV_AUX_UV].blState ?   MASK_LV_AUX_UV : 0;
    }

    if ((pxIfObcData->eObcAuxUvCheck == BOOL_TRUE)
        && (pxIfObcData->eObcAuxEnDoh == BOOL_TRUE))
    {
        qwFlags |= xaEvent[EVENT_HV_AUX_UV].blState ?   MASK_HV_AUX_UV : 0;
    }

    if (pxIfObcData->eDspOkCheck == BOOL_TRUE)
    {
        qwFlags |= xaEvent[EVENT_DSP_NG].blState ?      MASK_DSP_NG : 0;
    }

    if (pxIfEiData->eObcOkCheck == BOOL_TRUE)
    {
        qwFlags |= xaEvent[EVENT_OBC_NG].blState ?      MASK_OBC_NG : 0;
    }

    if (pxIfObcData->eObcState == OBC_APPL_RUN)
    {
        qwFlags |= xaEvent[EVENT_DSP_LOSS].blState ?    MASK_DSP_LOSS : 0;
        qwFlags |= xaEvent[EVENT_CP_OF].blState ?       MASK_CP_OF : 0;
        qwFlags |= xaEvent[EVENT_CP_UF].blState ?       MASK_CP_UF : 0;
    }

    qwEventFlags = qwFlags;
}

/**
 * @brief       Input Signal Analysis,
 *              1) to scan all hysterisis events in \xaEvent.
 *              2) to scan all end-to-end interface data in \IF_ID_E
 *              3) to update event status to \qwCurrentEventFlags
 */
static void sInputSignalAnalysis (void)
{
	sEventScan();                               // (1) scan events in \xaEvent.

    sInterfaceCheck();                          // (2) scan e2e interface data
    
    sErrorFlagUpdate();                         // (3) update qwCurrentEventFlags
}

/**
 * @brief       System Protection
 */
static void sSystemProtection(void)
{
    xIfHoData.eLvdcEnDol        = BOOL_FALSE;
    xIfHoData.eBoostEnDol       = BOOL_FALSE;
    xIfHoData.eDiagApmDoh       = BOOL_FALSE;

    xIfHoData.flLvdcVcmd        = 0.0F;
    xIfHoData.flLvdcIcmd        = 0.0F;
    xIfHoData.wVcmdDutyCnt      = 0;
    xIfHoData.wIcmdDutyCnt      = 0;

    if ((xIfHoData.qwApmErrorFlag & LV_AUX_RETRY_MASK) != 0)
    {
        xIfHoData.eApmAuxEnDoh  = BOOL_FALSE;
    }

    if ((xIfHoData.qwApmErrorFlag & MASK_BAT_OV) != 0)
    {
        sObcStop();
    }

    sApmDtcFailProcess();
}

/**
 * @brief       Power Derate by Vin under 322.5V
 */
static f32 sflPowerDeratingVin (void)
{
    PowerDerating_U.AMP_Vin = pxIfAiData->flHvdcVolt;    

    AMP_Vin_Derating_Trigger();                 // 2.2KW Vin derating

    return PowerDerating_Y.APM_Derating_Vin;

    #if 0                                       // 3KW Vin derating method
	f32 flCurrentTemp = 0.0F;
	f32 flPowerTemp = 0.0F;
	f32 flVoltageCMDTemp;
    f32 flHvVoltage;
    f32 flDeratingVin = 0.0F;

	flVoltageCMDTemp = pxIfCi0Data->flApmVcmd;
    flHvVoltage = pxIfAiData->flHvdcVolt;

	if(flHvVoltage < 322.5F)
	{
		flPowerTemp = flHvVoltage * 9.3F;
		flCurrentTemp = flPowerTemp / flVoltageCMDTemp;
		flDeratingVin = flCurrentTemp;
	}
	else
	{
		flCurrentTemp = 3000.0F / flVoltageCMDTemp;
		flDeratingVin = flCurrentTemp;
	}

    if (flDeratingVin < 0.0F)
    {
        flDeratingVin = 0.0F;
    }

    if (flDeratingVin > APM_ICMD_MAX)
    {
        flDeratingVin = APM_ICMD_DEFAULT;
    }

    return flDeratingVin;
    #endif
}

/**
 * @brief       Power Derate by Vout, Vout >= 13.8V Limit to 3000W
 */
static f32 sflPowerDeratingVout (void)
{
    PowerDerating_U.APM_Volt = pxIfAiData->flLvdcVolt;

    APM_Volt_Derating_Trigger();                // 2.2KW Vcmd derating

    return PowerDerating_Y.APM_Derating_Vo;

    #if 0                                       // 3KW Vcmd derating
	f32 flVoltageCMDTemp = 0.0F;
	f32 flCurrentTemp = 0.0F;
    f32 flDeratingVout = 0.0F;

	flVoltageCMDTemp = pxIfCi0Data->flApmVcmd;

	if(pxIfCi0Data->flApmVcmd >= 13.8F)
	{
		if(pxIfCi0Data->flApmVcmd > 15.5F)
		{
			flDeratingVout = 0.0F;
		}
		else
		{
			flCurrentTemp = 3000.0F / flVoltageCMDTemp;
			flDeratingVout = (u16)flCurrentTemp;
		}
	}
	else
	{
		flDeratingVout = 218.0F;
	}

    return flDeratingVout;
    #else

    return APM_ICMD_MAX;

    #endif
}

/**
 * @brief       Power Derate by Temp
 */
static f32 sflPowerDeratingTemp (void)
{
    PowerDerating_U.APM_Temperature = pxIfAiData->flCoolTemp;

    APM_Temperature_Derating_Trigger();         // 2.2KW thermal derating

    return PowerDerating_Y.APM_Derating_Temperature;

    #if 0                                       // 3KW thermal derating
	f32 flVoltageCMDTemp;
	f32 flCurrentTemp = 0.0F;
	f32 flPowerTemp = 0.0F;
    f32 flCoolantTemp;
    f32 flDeratingTemp = 0.0F;

	flVoltageCMDTemp = pxIfCi0Data->flApmVcmd;
    flCoolantTemp = pxIfAiData->flCoolTemp;

	if (flCoolantTemp > 65.0F)
	{
		flPowerTemp = 16000.0F - (200.0F * flCoolantTemp);
		flCurrentTemp = flPowerTemp / flVoltageCMDTemp;
		flDeratingTemp = flCurrentTemp;
	}
	else
	{
		flCurrentTemp = 3000.0F / flVoltageCMDTemp;
		flDeratingTemp = flCurrentTemp;
	}

    if (flDeratingTemp < 0.0F)
    {
        flDeratingTemp = 0.0F;
    }

    if (flDeratingTemp > APM_ICMD_MAX)
    {
        flDeratingTemp = APM_ICMD_DEFAULT;
    }

    return flDeratingTemp;
    #endif
}

/**
 * @brief       Power Derate Current Set
 */
static void sPowerDeratingSet (void)
{
    static f32 flMinCurrLast = APM_ICMD_MAX;
    f32 flMinCurr = APM_ICMD_MAX;
    f32 flDeratingVin;
    f32 flDeratingVout;
    f32 flDeratingTemp;

	flDeratingVin = sflPowerDeratingVin();      // power derate for Vin
    flDeratingVin /= pxIfCi0Data->flApmVcmd;
	flDeratingVout = sflPowerDeratingVout();    // power derate for Vcmd
    flDeratingVout /= pxIfCi0Data->flApmVcmd;
	flDeratingTemp = sflPowerDeratingTemp();    // power dereate for thermal
    flDeratingTemp /= pxIfCi0Data->flApmVcmd;

	if (pxIfCi0Data->flApmIcmd < flMinCurr)
	{
		flMinCurr = pxIfCi0Data->flApmIcmd;
	}

	if (flDeratingVin < flMinCurr)
	{
		flMinCurr = flDeratingVin;
	}
    /* polyspace-begin MISRA-C3:14.3 "always true for sflPowerDeratingVout" */
    /* polyspace-begin MISRA-C3:2.1 "unused code for sflPowerDeratingVout" */
	if (flDeratingVout < flMinCurr)
    /* polyspace-end MISRA-C3:14.3 "always true for sflPowerDeratingVout" */
    /* polyspace-end MISRA-C3:2.1 "unused code for sflPowerDeratingVout" */
	{
		flMinCurr = flDeratingVout;
	}

	if (flDeratingTemp < flMinCurr)
	{
		flMinCurr = flDeratingTemp;
	}

    flMinCurr = (0.7F * flMinCurrLast) + (0.3F * flMinCurr);

    flMinCurrLast = flMinCurr;

	if(xConfData.baDisa[CONF_DISA_DERATING] == (u8)'T')
	{
		xIfHoData.flLvdcIcmd = pxIfCi0Data->flApmIcmd;
	}
	else
	{
		xIfHoData.flLvdcIcmd = flMinCurr;
	}

    sIcmdToDuty();
}

#if (HVAE_BOOST_FUNC != 0)
/**
 * @brief       enable or disable BOOST depends on HV
 */
static void sBoostEnableCheck(void)
{
    static u32 dwStartBoostTime = 0;
    u32 dwTick;

    if ((xaEvent[EVENT_HVDC_HIGH].blState == true) 
        || (xaEvent[EVENT_HVDC_LOW].blState == true))
    {
        xIfHoData.eBoostEnDol = BOOL_FALSE;
        xIfHoData.eBoostUvCheck = BOOL_FALSE;
    }
    else
    {
        if (xIfHoData.eBoostEnDol == BOOL_FALSE)
        {
            dwStartBoostTime = sdwTimerTickGet();
        }

        xIfHoData.eBoostEnDol = BOOL_TRUE;

        dwTick = sdwTimerTickGet();
        if (dwTick - dwStartBoostTime > TIME(0.5))
        {
            xIfHoData.eBoostUvCheck = BOOL_TRUE;
        }
    }
}
#endif

/**
 * \brief       to compute PWM duty by Vcmd with calibration gain/offset value
 */
static void sVcmdToDuty(void)
{
    f32 flCmdAdj, flSwGain, flSwOffset;

    sVcmdGainOffsetGet(&flSwGain, &flSwOffset);

    flCmdAdj = xIfHoData.flLvdcVcmd * flSwGain;
    flCmdAdj += flSwOffset;

    flCmdAdj *= PWM_VCMD_HW_GAIN;
    flCmdAdj += PWM_VCMD_HW_OFFSET;

    flCmdAdj *= 0.01F;                          // unit is %
    /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
    flCmdAdj *= (f32)PWM_PERIOD;
    /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
    flCmdAdj += 0.5F;

    xIfHoData.wVcmdDutyCnt = (u16)flCmdAdj;
}

/**
 * \brief       to compute PWM duty by Icmd with calibration gain/offset value
 */
static void sIcmdToDuty(void)
{
    f32 flCmdAdj, flSwGain, flSwOffset;

    sIcmdGainOffsetGet(&flSwGain, &flSwOffset);

    flCmdAdj = xIfHoData.flLvdcIcmd * flSwGain;
    flCmdAdj += flSwOffset;

    flCmdAdj *= PWM_ILIM_HW_GAIN;
    flCmdAdj += PWM_ILIM_HW_OFFSET;

    flCmdAdj *= 0.01F;                          // unit is %
    /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
    flCmdAdj *= (f32)PWM_PERIOD;
    /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */
    flCmdAdj += 0.5F;

    xIfHoData.wIcmdDutyCnt = (u16)flCmdAdj;
}

/**
 * \brief       return a delay time to indicate there are some event need to
 *              retry again for test assertion or not.
 *
 * \return      0: there is no event needs to retry,
 *              1~0xFFFFU: retry interval time, max. time of them,
 *              0x10000U ~ 0xFFFFFFFFUL: retry number of times is over limit.
 */
static u32 sdwRetryEventDelayTime(void)
{
    u32 wDelay = 0;
    u8 i;
    u8 bRetryEvent = 0;
    u64 wqErrFlag = xIfHoData.qwApmErrorFlag;
    u64 wqEventMask;

    for (i = 0; i < (u8)EVENT_NUM; i++)
    {
        wqEventMask = 1ULL << xaEvent[i].bBitMaskIndex;

        if ((*xaEvent[i].pbDisable != (u8)'T')      // if event is enabled
            && (*xaEvent[i].pbRetryEnable == (u8)'T')   // and need retry 
            && ((wqErrFlag & wqEventMask) != 0)     // and this is an error event
            && (xaEvent[i].blState == true))        // and now still assert
        {
            xaEvent[i].bRetryCounter++;

            if (*xaEvent[i].pwRetryLimit == 0)      // if no limit, always retry
            {
                if (*xaEvent[i].pwRetryDelay > wDelay)
                {
                    wDelay = *xaEvent[i].pwRetryDelay;
                    bRetryEvent = i;

                    #if (HAVE_DEBUG_UART != 0)
            	    DebugPrint("RETRY forever event %d, cnt %d, delay %d\n",
                                bRetryEvent, xaEvent[i].bRetryCounter, wDelay);
                    #endif
                }
            }
            else
            {                                       // if retry counter reach limit times
                if (xaEvent[i].bRetryCounter > *xaEvent[i].pwRetryLimit)
                {
                    wDelay = 0x10000UL;             // return 0x10000 to latch
                    bRetryEvent = i;

                    #if (HAVE_DEBUG_UART != 0)
            	    DebugPrint("Latch event %d, cnt %d, delay %d\n",
                                bRetryEvent, xaEvent[i].bRetryCounter, wDelay);
                    #endif

                    break;
                }
                else
                {                                   // if a event needs retry
                    if (*xaEvent[i].pwRetryDelay > wDelay)
                    {
                        wDelay = *xaEvent[i].pwRetryDelay;
                        bRetryEvent = i;

                        #if (HAVE_DEBUG_UART != 0)
                	    DebugPrint("RETRY event %d, cnt %d, delay %d\n",
                            bRetryEvent, xaEvent[i].bRetryCounter, wDelay);
                        #endif
                    }
                }
            }
        }
    }

    if (wDelay != 0)
    {
        for (i = 0; i < (u8)EVENT_NUM; i++)
        {
            if (i != bRetryEvent)
            {
                xaEvent[i].bRetryCounter = 0;
            }
        }
    }
	

    return wDelay;
}

/**
 * \brief   check condition to turn on or turn off OBC sub-module
 */
static void sObcOnOffCheck(void)
{
    static prox_state_t ePpStateLast = CON_DISCONNECTED;
    static pilot_state_t eCpStateLast = EVSE_PILOT_STATE_A;
    //static obc_mode_cmd_t eObcCmdLast = OBC_MODE_CMD_UNKNOW;
    static u32 dwDspIdleCnt = 0;
    static u32 dwCan2StopCnt = 0;

    prox_state_t ePpState = pxIfEiData->ePpState;
    pilot_state_t eCpState = pxIfEiData->eCpState;
    obc_work_mode_t eObcWorkMode = pxIfCi2Data->eObcWorkMode;
    e_bool_t eblCan2Loss = pxIfCi2Data->eRxTimeout;
    obc_mode_cmd_t eObcCmd = pxIfCi0Data->eObcModeCmd; 

    bool blObcEnabled = sblTimerIsEnable(TIMER_ID_OBC);

    if (blObcEnabled)                           // if obc enabled
    {
        if (eblCan2Loss == BOOL_TRUE)
        {
            eObcWorkMode = OBC_WORK_MODE_UNKNOW;

            if (pxIfObcData->eObcState == OBC_APPL_RUN)
            {
                dwCan2StopCnt++;
            }

            if (dwCan2StopCnt >= TIME(10.0F))  // stop OBC if its CAN loss 10 sec
            {
                #if (HAVE_DEBUG_UART != 0)
        	    DebugPrint("OBC no CAN 10 sec\n");
                #endif

                #if 0                           // TODO: enable this code after 'BOOT' mode ready
                sObcStop();                     // don't power off DSP for JTAG program
                #endif
            }
        }
        else
        {
            dwCan2StopCnt = 0;
        }

        if ((eObcWorkMode == OBC_WORK_MODE_OFF)
              && (pxIfObcData->eObcState == OBC_APPL_RUN))  //210 (e4c5de42ff1a) don't turn off OBC aux. power if it is in LATCH state
        {
            dwDspIdleCnt++;

            if (dwDspIdleCnt >= TIME(10.0F))    // stop OBC if it is idle 10 sec
            {
                #if (HAVE_DEBUG_UART != 0)
        	    DebugPrint("OBC idle 3 sec\n");
                #endif

                sObcStop();
            }
        }
        else
        {
            dwDspIdleCnt = 0;
        }
    }
    else                                        // if obc is disabled
    {
        if ((xIfHoData.qwApmErrorFlag & MASK_BAT_OV) == 0)
        {                                       // turn on OBC AUX without BAT_OV
            if ((ePpStateLast == CON_LATCH_DEPRESSED)
                && (ePpState == CON_LATCH_RELEASED))
            {
                #if (HAVE_DEBUG_UART != 0)
        	    DebugPrint("Prox. OK\n");
                #endif
        
                dwDspIdleCnt = 0;
                dwCan2StopCnt = 0;

                sObcStart();                    // start OBC if proximity release
            }

            if ((eCpStateLast == EVSE_PILOT_STATE_A)
                && (eCpState == EVSE_PILOT_STATE_B))
            {
                #if (HAVE_DEBUG_UART != 0)
        	    DebugPrint("Pilot. A->B\n");
                #endif

                dwDspIdleCnt = 0;
                dwCan2StopCnt = 0;

                sObcStart();                    // start OBC if pilot state A->B
            }

            if ((eObcCmd == OBC_MODE_CMD_RUN)
                || (eObcCmd == OBC_MODE_CMD_STANDBY))
            {
                #if (HAVE_DEBUG_UART != 0)
        	    DebugPrint("OBC OFF->RUN\n");
                #endif

                dwDspIdleCnt = 0;
                dwCan2StopCnt = 0;

                sObcStart();                    // start OBC if CAN cmd is 'RUN'
            }                                   // or 'STANDBY'
        }
    }

    ePpStateLast = ePpState;
    eCpStateLast = eCpState;
    //eObcCmdLast = eObcCmd;
}

/**
 * @brief       main state machine
 */
static void sStateMachine(void)
{
    static x_apm_work_mode_t eLastMode = APM_MODE_INVALIDE;
    static u32 dwStartTick = 0;
    static u32 dwRetryDelay = 0;
    
    u32 dwCurrTick;
    u64 qwEvents = sqwEventFlagGet();

    xIfHoData.eIgnState = xaEvent[EVENT_IGN_ON].blState ? BOOL_TRUE : BOOL_FALSE;

    switch(xIfHoData.eApmWorkMode)
	{
		case APM_MODE_POWERON:
			if(eLastMode != APM_MODE_POWERON)
			{
				#if (HAVE_DEBUG_UART != 0)
				DebugPrint("APM_POWERON\r\n");
				#endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eLvdcEnDol        = BOOL_FALSE;
                xIfHoData.eBoostEnDol       = BOOL_FALSE;
                xIfHoData.eApmAuxEnDoh      = BOOL_FALSE;
                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;
                xIfHoData.eDiagApmDoh       = BOOL_TRUE;    // enable self-diagnostic

                xIfHoData.wVcmdDutyCnt      = 0;
                xIfHoData.wIcmdDutyCnt      = 0;
                xIfHoData.flLvdcVcmd        = 0.0F;
                xIfHoData.flLvdcIcmd        = 0.0F;

                sTimerStart(TIMER_ID_CAN0_TASK);

                eLastMode = APM_MODE_POWERON;
			}
            else
            {
                dwCurrTick = sdwTimerTickGet();

                if ((dwCurrTick - dwStartTick) >= DELAY_MS_POWERON)
                {                               // this delay should longer than
                                                // (DELAY_MS_1ST_TEST + 10U)
                    xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                }
                else if ((dwCurrTick - dwStartTick) >= (DELAY_MS_DIAG_TEST + 10U))
                {                               // unlock done
                    xIfHoData.eLatchUnlockDoh = BOOL_FALSE;
                }
                else if ((dwCurrTick - dwStartTick) >= DELAY_MS_DIAG_TEST)
                {                               // self-diagnostic test is done
                    xIfHoData.eDiagApmDoh = BOOL_FALSE;
                    xIfHoData.eLatchUnlockDoh = BOOL_TRUE;
                }
                else
                {
                    ;
                }

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_POWERON) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;

                    if (((qwEvents & MASK_DIAG_OV_ERR) != 0)
                        || ((qwEvents & MASK_DIAG_SC_ERR) != 0))
                    {                           // if self-diagnostic fail
                        xIfHoData.eApmWorkMode = APM_MODE_LATCH;
                    }
                }
            }
			break;

        case APM_MODE_IDLE:
			if(eLastMode != APM_MODE_IDLE)
			{
				#if (HAVE_DEBUG_UART != 0)
				DebugPrint("APM_IDLE\r\n");
				#endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                StartApmDtcOperationCycle();

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eDiagApmDoh       = BOOL_FALSE;
				xIfHoData.eApmAuxEnDoh      = BOOL_TRUE;
                xIfHoData.eApmAuxUvCheck    = BOOL_FALSE;
                xIfHoData.eLvdcUvCheck      = BOOL_FALSE;

				eLastMode = APM_MODE_IDLE;
			}
            else
            {
                bool blNmTimeout = sblPrepareBusSleepGet();
                bool blObcEnabled = sblTimerIsEnable(TIMER_ID_OBC);

                dwCurrTick = sdwTimerTickGet();                

                if ((dwCurrTick - dwStartTick) >= DELAY_MS_AUX_UV)
                {
                    xIfHoData.eApmAuxUvCheck = BOOL_TRUE;

                    if ((pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_STANDBY)
                        || (pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_DCDC))
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                    }
                    
                    if ((pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_PRECHARGE)
                        && (xConfData.baDisa[CONF_DISA_PRECHARGE] != (u8)'T'))
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_PRECHARGE;
                    }
                }

                if ((dwCurrTick - dwStartTick) >= DELAY_MS_NM_RELEASE)
                {
                    sNmReleaseSet(true);
                }

                if (((dwCurrTick - dwStartTick) >= DELAY_MS_SLEEP)
                    && (xIfHoData.eIgnState == BOOL_FALSE)
                    && (blObcEnabled == false)
                    && (blNmTimeout == true))
                {
                    xIfHoData.eApmWorkMode = APM_MODE_SLEEP;
                }

                #if 0
                if ((xConfData.baDisa[CONF_DISA_OBC_TASK] != (u8)'T'))
                {
                    sObcOnOffCheck();
                }
                #else
                sObcOnOffCheck();
                #endif

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_IDLE) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
            }
			break;

        case APM_MODE_SLEEP:
			if(eLastMode != APM_MODE_SLEEP)
			{
				#if (HAVE_DEBUG_UART != 0)
				DebugPrint("APM_SLEEP\r\n");
				#endif

                StopApmDtcOperationCycle();

                dwStartTick = sdwTimerTickGet();

				xIfHoData.eApmAuxEnDoh = BOOL_FALSE;

				eLastMode = APM_MODE_SLEEP;
			}
            else
            {
                bool blNmTimeout = sblPrepareBusSleepGet();

                dwCurrTick = sdwTimerTickGet();

                if (((dwCurrTick - dwStartTick) >= DELAY_MS_SLEEP)
                    && (blNmTimeout == true))
                {
                    #if (HAVE_SBC_FUNCTION != 0)
                    if (xConfData.baDisa[CONF_DISA_CAN_WAKEUP] == (u8)'T')
                    {
                        (void)FS45_CAN_SetMode(fs45CanModeSleepNoWakeup, true);
                    }
                    (void)FS45_SetLowPowerMode(false);
                    #endif

                    for(;;){;}
                }
                else
                {
                    if ((pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_STANDBY)
                        || (pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_DCDC))
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                    }
                }
            }
			break;

		case APM_MODE_STANDBY:
			if(eLastMode != APM_MODE_STANDBY)
			{
				#if (HAVE_DEBUG_UART != 0)
				DebugPrint("APM_STANDBY\r\n");
				#endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eDiagApmDoh       = BOOL_FALSE;
                xIfHoData.eApmAuxEnDoh      = BOOL_TRUE;
				xIfHoData.eLvdcEnDol        = BOOL_FALSE;
                xIfHoData.eBoostEnDol       = BOOL_FALSE;
                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;

                xIfHoData.eLvdcUvCheck      = BOOL_FALSE;

                xIfHoData.wVcmdDutyCnt      = 0;
                xIfHoData.wIcmdDutyCnt      = 0;
                xIfHoData.flLvdcVcmd        = 0.0F;
                xIfHoData.flLvdcIcmd        = 0.0F;

				eLastMode = APM_MODE_STANDBY;
			}
            else
            {
                bool blCan0Loss = xaEvent[EVENT_VCU_LOSS].blState;
                apm_mode_cmd_t xModeCmd = pxIfCi0Data->eApmModeCmd;

                // dwCurrTick = sdwTimerTickGet(); // not use

                blCan0Loss = false;             // disable CAN loss then default DCDC

                if (blCan0Loss == true)
                {
                    if (xIfHoData.eIgnState == BOOL_TRUE)
				    {
                        #if 0                           // not config
                        if (xConfData.baDisa[CONF_DISA_MODE_DIAG] == (u8)'T')
                        {
				            xIfHoData.eApmWorkMode = APM_MODE_SOFTSTART;
                        }
                        else
                        {
                            xIfHoData.eApmWorkMode = APM_MODE_DIAG;
                        }
                        #else
                        xIfHoData.eApmWorkMode = APM_MODE_DIAG;
                        #endif
				    }
                    else
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                    }
                }
                else
                {
                    if ((xIfHoData.eIgnState == BOOL_TRUE) 
                        && (xModeCmd == APM_MODE_CMD_DCDC))
                    {
                        #if 0                           // not config
                        if (xConfData.baDisa[CONF_DISA_MODE_DIAG] == (u8)'T')
                        {
				            xIfHoData.eApmWorkMode = APM_MODE_SOFTSTART;
                        }
                        else
                        {
                            xIfHoData.eApmWorkMode = APM_MODE_DIAG;
                        }
                        #else
                        xIfHoData.eApmWorkMode = APM_MODE_DIAG;
                        #endif
                    }

                    if ((xIfHoData.eIgnState == BOOL_FALSE) 
                        && (xModeCmd == APM_MODE_CMD_IDLE))
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                    }

                    #if (HAVE_TEST_MODE != 0)
                    if (xModeCmd == APM_MODE_CMD_TEST)
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_TEST;
                    }
                    #endif

                    if ((pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_DISCHARGE)
                        && (xConfData.baDisa[CONF_DISA_DISCHARGE] != (u8)'T'))
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_DISCHARGE;
                    }
                }

                #if 0
                if ((xConfData.baDisa[CONF_DISA_OBC_TASK] != (u8)'T'))
                {
                    sObcOnOffCheck();
                }
                #else
                sObcOnOffCheck();
                #endif

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_STANDBY) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
            }
			break;

        case APM_MODE_DIAG:                     // self diagnostic for HW OVP, SCP
            if(eLastMode != APM_MODE_DIAG)
            {
	            #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_SELF_DIAG\r\n");
	            #endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                sApmDtcAging();

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eDiagApmDoh       = BOOL_TRUE;    // enable self-diagnostic
                xIfHoData.eLvdcEnDol        = BOOL_FALSE;
                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;

                xIfHoData.eLvdcUvCheck      = BOOL_FALSE;

                xIfHoData.wVcmdDutyCnt      = 0;
                xIfHoData.wIcmdDutyCnt      = 0;
                xIfHoData.flLvdcVcmd        = 0.0F;
                xIfHoData.flLvdcIcmd        = 0.0F;

                eLastMode = APM_MODE_DIAG;
            }
            else
            {
                dwCurrTick = sdwTimerTickGet();

                if ((dwCurrTick - dwStartTick) >= DELAY_MS_DIAG_TEST)
                {                               // self-test pass, unlock and goto soft-start
                    xIfHoData.eDiagApmDoh = BOOL_FALSE;
                    xIfHoData.eLatchUnlockDoh = BOOL_TRUE;
                    xIfHoData.eApmWorkMode = APM_MODE_SOFTSTART;
                }

                #if 0
                if ((xConfData.baDisa[CONF_DISA_OBC_TASK] != (u8)'T'))
                {
                    sObcOnOffCheck();
                }
                #else
                sObcOnOffCheck();
                #endif

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_DIAG) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
            }
            break;


		case APM_MODE_SOFTSTART:
            if(eLastMode != APM_MODE_SOFTSTART)
            {
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_SOFTSTART\r\n");
                #endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;
                xIfHoData.eLvdcEnDol        = BOOL_TRUE;

                blSoftStartFinish = false;

                PowerDerating_initialize();
                
                sPowerDeratingSet();
                
                sTimerStart(TIMER_ID_SOFTSTART);

                eLastMode = APM_MODE_SOFTSTART;
            }
            else
            {
                // dwCurrTick = sdwTimerTickGet(); // not use

                if (blSoftStartFinish == true)
                {
                    sTimerStop(TIMER_ID_SOFTSTART);

                    xIfHoData.eApmWorkMode = APM_MODE_ACTIVE;
                }

                #if 0
                if ((xConfData.baDisa[CONF_DISA_OBC_TASK] != (u8)'T'))
                {
                    sObcOnOffCheck();
                }
                #else
                sObcOnOffCheck();
                #endif

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_SOFTSTART) != 0)
                {
                    sTimerStop(TIMER_ID_SOFTSTART);

                    sSystemProtection();

                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
			}
			break;

		case APM_MODE_ACTIVE:
            
            sPowerDeratingSet();

            if(eLastMode != APM_MODE_ACTIVE)
            {
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_DCDC\r\n");
                #endif

                #if (HAVE_DEBUG_GPIO != 0)
                PINS_DRV_TogglePins(TEST_PIN1_PORT, (1UL << TEST_PIN1_INDEX));
                #endif

                dwStartTick = sdwTimerTickGet();

                xIfHoData.eLvdcUvCheck = BOOL_TRUE;

                eLastMode = APM_MODE_ACTIVE;
            }
			else
			{
                bool blCan0Loss = xaEvent[EVENT_VCU_LOSS].blState;
                apm_mode_cmd_t xModeCmd = pxIfCi0Data->eApmModeCmd;

                // dwCurrTick = sdwTimerTickGet(); // not use

                if (blCan0Loss == true)
                {
                    if (xIfHoData.eIgnState == BOOL_FALSE)
                    {
                        xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                    }
                    else
                    {
                        xIfHoData.flLvdcVcmd = APM_VCMD_DEFAULT;
                        xIfHoData.flLvdcIcmd = APM_ICMD_DEFAULT;

                        sVcmdToDuty();
                        sIcmdToDuty();
                    }
                }
                else
                {
                    if ((xIfHoData.eIgnState == BOOL_FALSE)
                        || (xModeCmd == APM_MODE_CMD_STANDBY)
                        || (xModeCmd == APM_MODE_CMD_IDLE))
                    {                           // IG Off or APM_MODE_CMD Off
                        xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                    }
                    else
                    {
                        xIfHoData.flLvdcVcmd = pxIfCi0Data->flApmVcmd;

                        sVcmdToDuty();
                    }
                }

                #if (HVAE_BOOST_FUNC != 0)
                sBoostEnableCheck();            // check HV to on/off BOOST
                #endif

                #if 0
                if ((xConfData.baDisa[CONF_DISA_OBC_TASK] != (u8)'T'))
                {
                    sObcOnOffCheck();
                }
                #else
                sObcOnOffCheck();
                #endif

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_DCDC) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
			}
			break;
		
		case APM_MODE_FAULT:

            sApmDtcFailProcess();

            if(eLastMode != APM_MODE_FAULT)
            {
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_FAULT\r\n");
                #endif

                dwStartTick = sdwTimerTickGet();
                
                dwRetryDelay = sdwRetryEventDelayTime();

                //pxIfDiData->eHwSbcIntTriggered = BOOL_FALSE; // TODO: refact it

                eLastMode = APM_MODE_FAULT;
            }
            else
            {
                dwCurrTick = sdwTimerTickGet();
                                                // update CAN error flags
                xIfHoData.qwApmErrorFlag |= qwEvents;

                if (dwRetryDelay == 0)          // no event needs to retry
                {
                    if ((dwCurrTick - dwStartTick) >= DELAY_MS_FAULT)
                    {
                        qwEvents &= ~WARNING_MASK;  // ignore warning events

                        if (qwEvents == 0)      // if no error event, 
                        {                       // go back to standby or idle
                            if ((xIfHoData.qwApmErrorFlag | LV_AUX_RETRY_MASK) != 0)
                            {
                                xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                            }
                            else
                            {
                                xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                            }

                            sApmDtcPassProcess();
                        }
                    }
                }
                else if (dwRetryDelay > 0xFFFFU)// if retry times over limit,
                {                               // go to latch state
                    xIfHoData.eApmWorkMode = APM_MODE_LATCH;
                }
                else                            // if some event need to retry,
                {                               
                    if ((dwCurrTick - dwStartTick) >= dwRetryDelay)
                    {
                        if ((qwEvents & LV_AUX_RETRY_MASK) != 0)
                        {                       // retry aux. power
                            xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                        }
                        else
                        {                       // go to standby then try again
                            xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                        }
                    }
                }

                sObcOnOffCheck();

                if (xIfHoData.eApmWorkMode == APM_MODE_STANDBY)
                {                               // if recover to standby
                    xIfHoData.eLatchUnlockDoh = BOOL_TRUE;   // unlock latch
                }
            }

            #if (HAVE_TEST_MODE != 0)           // for test only
            if(pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_TEST)
            {
                xIfHoData.eApmWorkMode = APM_MODE_TEST;
            }
            #endif
			break;

		case APM_MODE_LATCH:
            if(eLastMode != APM_MODE_LATCH)
            {
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_LATCH\r\n");
                #endif

                StopApmDtcOperationCycle();
        
                dwStartTick = sdwTimerTickGet();

                xIfHoData.eDiagApmDoh       = BOOL_FALSE;
                xIfHoData.eLvdcEnDol        = BOOL_FALSE;
                xIfHoData.eBoostEnDol       = BOOL_FALSE;
                xIfHoData.eApmAuxEnDoh      = BOOL_FALSE;
                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;

                xIfHoData.wVcmdDutyCnt      = 0;
                xIfHoData.wIcmdDutyCnt      = 0;
                xIfHoData.flLvdcVcmd        = 0.0F;
                xIfHoData.flLvdcIcmd        = 0.0F;

                eLastMode = APM_MODE_LATCH;
            }
            else
            {
                #if 0       // for prototype stage, don't sleep while latch
                bool blNmTimeout = sblPrepareBusSleepGet();
                #endif

                dwCurrTick = sdwTimerTickGet();

                if ((dwCurrTick - dwStartTick) >= DELAY_MS_NM_RELEASE)
                {
                    sNmReleaseSet(true);
                }

                #if 0       // for prototype stage, don't sleep while latch
                if (((dwCurrTick - dwStartTick) >= DELAY_MS_LATCH) 
                    && (blNmTimeout == true))
                {
                    #if (HAVE_SBC_FUNCTION != 0)
                    (void)FS45_CAN_SetMode(fs45CanModeSleepNoWakeup, true);
                    (void)FS45_SetLowPowerMode(false);
                    #endif

                    for(;;){;}
                }
                #endif
            }
			break;

        // TODO: check configuration for precharge function
        case APM_MODE_PRECHARGE:
            if(eLastMode != APM_MODE_PRECHARGE)
			{
                #if (HAVE_DEBUG_UART != 0)
				DebugPrint("APM_PRECHARGE\r\n");
				#endif

                dwStartTick = sdwTimerTickGet();

                eLastMode = APM_MODE_PRECHARGE;
            }
            else
            {
                dwCurrTick = sdwTimerTickGet();

                if (((dwCurrTick - dwStartTick) >= DELAY_MS_PRECHARGE)
                    && (pxIfAiData->flHvdcVolt > PRECHARGE_HVDC_VOLT))
                {
                    xIfHoData.eApmWorkMode = APM_MODE_STANDBY;
                }

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_STANDBY) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
            }
            break;

        // TODO: check configuration for discharge function
        case APM_MODE_DISCHARGE:
            if(eLastMode != APM_MODE_DISCHARGE)
			{
                #if (HAVE_DEBUG_UART != 0)
                DebugPrint("APM_DISCHARGE\r\n");
                #endif

                dwStartTick = sdwTimerTickGet();

                eLastMode = APM_MODE_DISCHARGE;
            }
            else
            {
                dwCurrTick = sdwTimerTickGet();

                if (((dwCurrTick - dwStartTick) >= DELAY_MS_DISCHARGE)
                    && (pxIfAiData->flHvdcVolt < DISCHARGE_HVDC_VOLT))
                {
                    xIfHoData.eApmWorkMode = APM_MODE_IDLE;
                }

                xIfHoData.qwApmErrorFlag = qwEvents;

                if ((qwEvents & ERROR_MASK_STANDBY) != 0)
                {
                    sSystemProtection();
                    xIfHoData.eApmWorkMode = APM_MODE_FAULT;
                }
            }
            break;



        #if (HAVE_TEST_MODE != 0)
        case APM_MODE_TEST:                     // for test only
            if(eLastMode != APM_MODE_TEST)
			{
                #if (HAVE_DEBUG_UART != 0)
			    DebugPrint("*** APM in TEST mode ***\n");
			    #endif

                xIfHoData.flLvdcVcmd = pxIfCi0Data->flApmVcmd;
                xIfHoData.flLvdcIcmd = pxIfCi0Data->flApmIcmd;

                sVcmdToDuty();
                sIcmdToDuty();

                xIfHoData.eDiagApmDoh       = BOOL_FALSE;
                xIfHoData.eLvdcEnDol        = BOOL_TRUE;
                xIfHoData.eBoostEnDol       = BOOL_TRUE;
                xIfHoData.eApmAuxEnDoh      = BOOL_TRUE;
                xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;

                sObcStart();                    // start OBC task

                eLastMode = APM_MODE_TEST;
            }
            else
            {
                xIfHoData.flLvdcVcmd = pxIfCi0Data->flApmVcmd;
                xIfHoData.flLvdcIcmd = pxIfCi0Data->flApmIcmd;

                sVcmdToDuty();
                sIcmdToDuty();
            
                xIfHoData.qwApmErrorFlag = qwEvents;

                if (pxIfCi0Data->eApmModeCmd == APM_MODE_CMD_STANDBY)
                {
                    xIfHoData.eApmWorkMode = APM_MODE_STANDBY;

                    sObcStop();                 // stop OBC task
                }
            }            
            break;
        #endif
		
		default:
			#if (HAVE_DEBUG_UART != 0)
            DebugPrint("Unkonwn State ERROR!\n");
            #endif

            xIfHoData.eDiagApmDoh       = BOOL_FALSE;
            xIfHoData.eLvdcEnDol        = BOOL_FALSE;
            xIfHoData.eBoostEnDol       = BOOL_FALSE;
            xIfHoData.eApmAuxEnDoh      = BOOL_FALSE;
            xIfHoData.eLatchUnlockDoh   = BOOL_FALSE;

            xIfHoData.wVcmdDutyCnt      = 0;
            xIfHoData.wIcmdDutyCnt      = 0;
            xIfHoData.flLvdcVcmd        = 0.0F;
            xIfHoData.flLvdcIcmd        = 0.0F;
			break;
	}
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief   flush the data buffer before leave an ISR,
 *          it is a workaround for ARM CM4 Errata 838869.
 *          Store immediate overlapping exception return operation might vector
 *          to incorrect interrupt.
 *          The erratum can be avoided by ensuring a DSB occurs between the 
 *          store and the BX instruction.
 */
void sFlushBuffer(void)
{
    /* polyspace-begin MISRA-C3:1.1 "standard C syntax" */
    /* polyspace-begin MISRA-C3:D4.3 "Assembly" */
    __asm volatile ("dsb 0xf" : : : "memory");
    /* polyspace-end MISRA-C3:1.1 "standard C syntax" */
    /* polyspace-end MISRA-C3:D4.3 "Assembly" */
}

/**
 * @brief       initial IF_HO data pointer, it should be call before call IfGet
 */
void sHousekeepIfInit(void)
{
    (void)sbIfSet(IF_HO, &xIfHoData);           // init IF_HO data pointer
}


/**
 * @brief       to initial housekeep's interface data pointer,
 *              this function shall be call before other function to get IF_HO
 */
void sHouseKeepInit(void)
{
    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_CI0, false, (const void**)&pxIfCi0Data);

    (void)sbIfGet(IF_CI2, false, (const void**)&pxIfCi2Data);

    (void)sbIfGet(IF_AI, false, (const void**)&pxIfAiData);

    (void)sbIfGet(IF_DI, false, (const void**)&pxIfDiData);

    (void)sbIfGet(IF_EI, false, (const void**)&pxIfEiData);

    (void)sbIfGet(IF_OO, false, (const void**)&pxIfObcData);

    (void)sbIfGet(IF_EO, false, (const void**)&pxIfEvseOutput);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */

    sNvmConfDataRead(&xConfData);

    sTimerPeriodSet(TIMER_ID_HOUSE, HOUSEKEEP_TIMEBASE);

    sTimerStart(TIMER_ID_HOUSE);
}


/**
 * @brief       House Keep System Task Use to Manager System State
 */
void sHuoseKeepTask(void)
{
	sInputSignalAnalysis();                     // input singal detection

    sStateMachine();                            // main state machine

    (void)sbIfSet(IF_HO, &xIfHoData);           // update output signals
}

/**
 * @brief       Output Soft Start, increase or Decrease 0.1V per 1ms
 */
void sSoftStart (void)
{
    u32 dwValA;
    u32 dwValB;
    f32 flTmp;

    flTmp = (pxIfCi0Data->flApmVcmd * 10.0F) + 0.5F;
    dwValA = (u32)flTmp;

    flTmp = (xIfHoData.flLvdcVcmd * 10.0F) + 0.5F;
    dwValB = (u32)flTmp;
	
	if(dwValA != dwValB)
	{
		if(pxIfCi0Data->flApmVcmd > xIfHoData.flLvdcVcmd)
		{
			xIfHoData.flLvdcVcmd += 0.1F;
			if(pxIfCi0Data->flApmVcmd < xIfHoData.flLvdcVcmd)
			{
				xIfHoData.flLvdcVcmd = pxIfCi0Data->flApmVcmd;
			}
		}

		if(pxIfCi0Data->flApmVcmd < xIfHoData.flLvdcVcmd)
		{
			xIfHoData.flLvdcVcmd -= 0.1F;
			if(pxIfCi0Data->flApmVcmd > xIfHoData.flLvdcVcmd)
			{
				xIfHoData.flLvdcVcmd = pxIfCi0Data->flApmVcmd;
			}
		}

        sVcmdToDuty();

        (void)sbIfSet(IF_HO, &xIfHoData);       // update output signals
	}
	else
	{
		blSoftStartFinish = true;
	}
}



/**
 * \brief       to set a flag to \qwSystemEventFlags
 * \param[in]   qwErrorbit  bit mask to set error flags
 */
void sEventFlagSet (u64 qwErrorbit)
{
	qwSystemEventFlags |= qwErrorbit;
}

/**
 * \brief       to clear a flag in \qwSystemEventFlags
 * \param[in]   qwErrorbit  bit mask to clear error flags
 */
void sEventFlagClear (u64 qwErrorbit)
{
	qwSystemEventFlags &= ~qwErrorbit;
}



/**
 * @brief       Make a snapshot record
 */
void sMakeSnapshotRecord (snapshot_record_t* pxData)
{
    void* pDest;
    const void* pSrc;
    u32 dwLen;
    u8 bStatus;

    if (pxIfCi0Data->eRxSysTimeTimeout == BOOL_FALSE)
    {
        xSnapshotRecord.wYear = pxIfCi0Data->wYear;
        xSnapshotRecord.bMonth = pxIfCi0Data->bMonth;
        xSnapshotRecord.bDay = pxIfCi0Data->bDay;
        xSnapshotRecord.bHour = pxIfCi0Data->bHour;
        xSnapshotRecord.bMinute = pxIfCi0Data->bMinute;
        xSnapshotRecord.bSecond = pxIfCi0Data->bSec;
        xSnapshotRecord.b100ms = pxIfCi0Data->b100ms;
    }
    else
    {
        xSnapshotRecord.wYear = 0;
        xSnapshotRecord.bMonth = 0;
        xSnapshotRecord.bDay = 0;
        xSnapshotRecord.bHour = 0;
        xSnapshotRecord.bMinute = 0;
        xSnapshotRecord.bSecond = 0;
        xSnapshotRecord.b100ms = 0;
    }

    bStatus = (pxIfDiData->eSbcIgnDih == BOOL_TRUE) ? 1U : 0;
    xSnapshotRecord.bApmIgnStatus = bStatus;

    bStatus = (pxIfObcData->eObcAuxEnDoh == BOOL_TRUE) ? 1U : 0;
    xSnapshotRecord.bHvAuxEnStatus = bStatus;

    xSnapshotRecord.bApmModeCmd = (u8)pxIfCi0Data->eApmModeCmd;
    xSnapshotRecord.bApmWorkMode = (u8)xIfHoData.eApmWorkMode;
    xSnapshotRecord.flLvdcVcmd = pxIfCi0Data->flApmVcmd;
    xSnapshotRecord.flLvdcIcmd = pxIfCi0Data->flApmIcmd;
    xSnapshotRecord.flLvIoutLimit = xIfHoData.flLvdcIcmd;
    xSnapshotRecord.qwApmErrorFlag = xIfHoData.qwApmErrorFlag;
    xSnapshotRecord.flApmHvdcVolt = pxIfAiData->flHvdcVolt;
    xSnapshotRecord.flApmHvdcCurr = pxIfAiData->flHvdcCurr;
    xSnapshotRecord.flApmLvdcVolt = pxIfAiData->flLvdcVolt;
    xSnapshotRecord.flApmLvdcCurr = pxIfAiData->flLvdcCurr;
    xSnapshotRecord.flApmTempPcb = pxIfAiData->flPcbTemp;
    xSnapshotRecord.flApmTempSr = pxIfAiData->flSrTemp;
    xSnapshotRecord.flApmTempCool = pxIfAiData->flCoolTemp;
    xSnapshotRecord.flApmLvAuxVolt = pxIfAiData->flAuxLvVolt;
    xSnapshotRecord.flApmBatVolt = pxIfAiData->flLvBatVolt;

    xSnapshotRecord.bObcModeCmd = (u8)pxIfCi0Data->eObcModeCmd;
    xSnapshotRecord.flHvdcVcmd = pxIfCi0Data->flObcVcmd;
    xSnapshotRecord.flHvdcIcmd = pxIfCi0Data->flObcIcmd;

    if (pxIfCi2Data->eRxTimeout == BOOL_TRUE)
    {
        xSnapshotRecord.bObcWorkMode = 0;
        xSnapshotRecord.qwObcErrorFlag = 0;
        xSnapshotRecord.flObcPfcAuxVolt = 0.0F;
        xSnapshotRecord.flObcPfcCurrA = 0.0F;
        xSnapshotRecord.flObcPfcCurrB = 0.0F;
        xSnapshotRecord.flObcPfcCurrC = 0.0F;
        xSnapshotRecord.flObcPfcCurrD = 0.0F;
        xSnapshotRecord.flObcGridVolt = 0.0F;
        xSnapshotRecord.flObcGridCurr = 0.0F;
        xSnapshotRecord.flObcGridFreq = 0.0F;
        xSnapshotRecord.flObcHvdcVolt = 0.0F;
        xSnapshotRecord.flObcHvdcCurr = 0.0F;
        xSnapshotRecord.flObcBulkVolt = 0.0F;
        xSnapshotRecord.flObcHvVoltRef = 0.0F;
        xSnapshotRecord.flObcHvCurrRef = 0.0F;
        xSnapshotRecord.flObcCtrlTheta = 0.0F;
        xSnapshotRecord.flObcCtrlFreq = 0.0F;
        xSnapshotRecord.flObcTempLlc = 0.0F;
        xSnapshotRecord.flObcTempPfc = 0.0F;
    }
    else
    {
        xSnapshotRecord.bObcWorkMode = (u8)pxIfCi2Data->eObcWorkMode;
        xSnapshotRecord.qwObcErrorFlag = pxIfCi2Data->qwObcErrorFlag;
        xSnapshotRecord.flObcPfcAuxVolt = pxIfCi2Data->flObcPfcAuxVolt;
        xSnapshotRecord.flObcPfcCurrA = pxIfCi2Data->flObcPfcCurrA;
        xSnapshotRecord.flObcPfcCurrB = pxIfCi2Data->flObcPfcCurrB;
        xSnapshotRecord.flObcPfcCurrC = pxIfCi2Data->flObcPfcCurrC;
        xSnapshotRecord.flObcPfcCurrD = pxIfCi2Data->flObcPfcCurrD;
        xSnapshotRecord.flObcGridVolt = pxIfCi2Data->flObcGridVolt;
        xSnapshotRecord.flObcGridCurr = pxIfCi2Data->flObcGridCurr;
        xSnapshotRecord.flObcGridFreq = pxIfCi2Data->flObcGridFreq;
        xSnapshotRecord.flObcHvdcVolt = pxIfCi2Data->flObcHvdcVolt;
        xSnapshotRecord.flObcHvdcCurr = pxIfCi2Data->flObcHvdcCurr;
        xSnapshotRecord.flObcBulkVolt = pxIfCi2Data->flObcBulkVolt;
        xSnapshotRecord.flObcHvVoltRef = pxIfCi2Data->flObcHvVoltRef;
        xSnapshotRecord.flObcHvCurrRef = pxIfCi2Data->flObcHvCurrRef;
        xSnapshotRecord.flObcCtrlTheta = pxIfCi2Data->flObcCtrlTheta;
        xSnapshotRecord.flObcCtrlFreq = pxIfCi2Data->flObcCtrlFreq;
        xSnapshotRecord.flObcTempLlc = pxIfCi2Data->flObcTempLlc;
        xSnapshotRecord.flObcTempPfc = pxIfCi2Data->flObcTempPfc;
    }

    xSnapshotRecord.flEvseProxVolt = pxIfAiData->flProxiVolt;
    xSnapshotRecord.flEvsePilotVolt = pxIfAiData->flPilotVolt;;
    xSnapshotRecord.flEvsePilotDuty = pxIfEiData->flCpDuty;
    xSnapshotRecord.flEvseImax = pxIfEvseOutput->flEvseImax;

    bStatus = (pxIfEvseOutput->eCpReadyDoh == BOOL_TRUE) ? 1U : 0;
    xSnapshotRecord.bS2Status = bStatus;

    dwLen = sizeof(snapshot_record_t);
    pDest = (void*)pxData;
    pSrc = (const void*)&xSnapshotRecord;

    (void)fsl_memcpy(pDest, pSrc, dwLen);
}


/**
 * @brief       DTC Pass Process for APM statmachine
 */
static void sApmDtcPassProcess (void)
{
	(void)DTCTestPassed(DTC_P100101);
	(void)DTCTestPassed(DTC_P100102);
	(void)DTCTestPassed(DTC_P100103);
	(void)DTCTestPassed(DTC_P100104);
	(void)DTCTestPassed(DTC_P100105);
	(void)DTCTestPassed(DTC_U100101);
	(void)DTCTestPassed(DTC_U100102);
}

/**
 * @brief       DTC Faild Process for APM statmachine
 */
static void sApmDtcFailProcess(void)
{
    if ((qwEventFlags & MASK_DTC_APM_LVDC) != 0)
    {
        (void)DTCTestFailed(DTC_P100101);
    }

    if ((qwEventFlags & MASK_DTC_APM_HVDC) != 0)
    {
        (void)DTCTestFailed(DTC_P100102);
    }

    if ((qwEventFlags & MASK_DTC_APM_OTP) != 0)
    {
        (void)DTCTestFailed(DTC_P100103);
    }

    if ((qwEventFlags & MASK_DTC_APM_AUX) != 0)
    {
        (void)DTCTestFailed(DTC_P100104);
    }

    if ((qwEventFlags & MASK_DTC_APM_BAT) != 0)
    {
        (void)DTCTestFailed(DTC_P100105);
    }

    if ((qwEventFlags & MASK_DTC_APM_INIT) != 0)
    {
        (void)DTCTestFailed(DTC_U100101);
    }
}




