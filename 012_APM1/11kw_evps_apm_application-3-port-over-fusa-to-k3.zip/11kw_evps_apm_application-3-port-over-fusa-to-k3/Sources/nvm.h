/**
 * @file        nvm.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         LAYOUT_H
#define         LAYOUT_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

#define CALI_DATA_VERSION                       1U  /* 1st version, 20220609 */

#define CONF_DATA_VERSION                       1U  /* 1st version, 20220609 */

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))

//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum NVM_DATA_TYPE_E                    /* NVM data block type define */
{
    NVM_DATA_TYPE_NONE = 0,
    NVM_DATA_TYPE_CALI,                         // for calibration data
    NVM_DATA_TYPE_CONF,                         // for configuration data
    NVM_DATA_TYPE_NET,                          // for network stack data
}nvm_data_type_t;

typedef enum CALI_ITEM_E
{
    CALI_ITEM_LVDC_VOLT_ADC = 0,                // REMOTE_VOLT_ADC
    CALI_ITEM_LVDC_CURR_ADC,                    // LVDC_CURR_ADC
    CALI_ITEM_LVDC_VOLT_PWM,                    // LVDC_CVCC_VOLT_PWM
    CALI_ITEM_LVDC_CURR_PWM,                    // LVDC_CVCC_CURR_PWM
    CALI_ITEM_BAT_VOLT_ADC,                     // SBC_MUX_ADC
    CALI_ITEM_HVDC_VOLT_APM_ADC,                // HVDC_VOLT_ADC
    CALI_ITEM_HVDC_CURR_APM_ADC,                // APM_CURR_ADC
    CALI_ITEM_HVDC_VOLT_OBC_ADC,                // OBC_VOLT_ADC
    CALI_ITEM_HVDC_CURR_OBC_ADC,                // OBC_CURR_ADC
    CALI_ITEM_GRID_VOLT_ADC,                    // AC_N/L_VOLT_ADC (RMS)
    CALI_ITEM_GRID_CURR_ADC,                    // PFC_CSA_ADC x 4
    CALI_ITEM_BULK_VOLT_ADC,                    // BULK_VOLT_ADC
    CALI_ITEM_RESERVED_0,                       // not used
    CALI_ITEM_RESERVED_1,                       // not used
    CALI_ITEM_RESERVED_2,                       // not used
    CALI_ITEM_RESERVED_3,                       // not used
    CALI_ITEM_RESERVED_4,                       // not used
    CALI_ITEM_NUMBER,
}e_cali_item_t;


typedef struct PACKED DATA_HEADER_S             /* header of a NVM data block */
{
    u8 baTag[2];                                // constant, 0x55, 0xAA
    u16 wBlockLen;                              // block length (bytes)
    u8 bType;                                   // \enum nvm_data_type_t
    u16 wYear;
    u8 bMonth;
    u8 bDay;
    u8 bHour;
    u8 bMin;
    u8 bSec;
    u8 bVersion;                                // data format version
    u8 bWriteCounter;
    u16 wCrc16Ccitt;    
}data_header_t;

typedef struct PACKED PROT_PARAM_S              /* protection data parameter */
{
    u8  bDisableSetting;                        // disable if only if 'T'
    f32 flTriggerPoint;
    u16 wResponseTime;                          // time unit: 1ms
    f32 flRecoveryPoint;
    u16 wRecoveryTime;                          // time unit: 1ms
    u8  bEnableRetry;                           // enable retry if only if 'T'
    u16 wRetryLimit;                            
    u16 wRetryInterval;                         // time unit: 1ms
}prot_param_t;

typedef struct PACKED CALI_PARAM_S              /* calibration data parameter */
{
    f32 flMeasureLow;                           // measure value by equipment
    f32 flMeasureHigh;                          // measure value by equipment
    f32 flNativeLow;                            // native value from MCU
    f32 flNativeHHigh;                          // native value from MCU
    f32 flGain;                                 // gain value for calibration
    f32 flOffset;                               // offset value for calibration
}cali_param_t;

typedef struct PACKED CALI_DATA_GAIN_OFFSET_S   /* calibration data block */
{
    data_header_t xHead;
    cali_param_t xaItem[CALI_ITEM_NUMBER];
}x_cali_data_t;

typedef enum CONF_PROT_E                        // protect configuration items
{                                               // === PFC side MCU's items ===
    CONF_ITEM_DSP_CAN_LOSS_MCU = 0,
    CONF_ITEM_DSP_HV_OVP_SW,
    CONF_ITEM_DSP_HV_OVP_HW,
    CONF_ITEM_DSP_HV_UVP,
    CONF_ITEM_DSP_HV_OCP_SW,
    CONF_ITEM_DSP_HV_OCP_HW,
    CONF_ITEM_DSP_GRID_OVP,
    CONF_ITEM_DSP_RMS_GRID_OVP,
    CONF_ITEM_DSP_RMS_GRID_UVP,
    CONF_ITEM_DSP_GRID_UFP,
    CONF_ITEM_DSP_GRID_OFP,
    CONF_ITEM_DSP_PFC_MOS_OCP,
    CONF_ITEM_DSP_LLC_OCP_HW,
    CONF_ITEM_DSP_PFC_OVP_HW,
    CONF_ITEM_DSP_BULK_OVP_SW,
    CONF_ITEM_DSP_BULK_UVP,
    CONF_ITEM_DSP_PFC_AUX_UVP,
    CONF_ITEM_DSP_PFC_AUX_OVP,
    CONF_ITEM_DSP_OTP_1,
    CONF_ITEM_DSP_LLC_OTP,
    CONF_ITEM_DSP_PFC_OTP,
    CONF_ITEM_DSP_DIAG_HV_OVP,
    CONF_ITEM_DSP_DIAG_LLC_OCP,
    CONF_ITEM_DSP_DIAG_HV_SCP,
    CONF_ITEM_DSP_DIAG_PFC_OVP,
    CONF_ITEM_DSP_CMPSS_HV_OCP,
    CONF_ITEM_DSP_CMPSS_HV_OVP,
    CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP,
    CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP,
    CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP,
    CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP,
    CONF_ITEM_DSP_CMPSS_PFC_OVP,
    CONF_ITEM_MCU_HV_AUX_UVP,                   // === LV side MCU's items ===
    CONF_ITEM_MCU_HV_AUX_OVP,
    CONF_ITEM_MCU_LV_OVP_SW,
    CONF_ITEM_MCU_LV_OVP_HW,
    CONF_ITEM_MCU_LV_UVP,
    CONF_ITEM_MCU_LV_AUX_UVP,
    CONF_ITEM_MCU_LV_AUX_OVP,
    CONF_ITEM_MCU_LV_OCP_HW,
    CONF_ITEM_MCU_LV_OCP_SW,
    CONF_ITEM_MCU_LV_OPP,
    CONF_ITEM_MCU_HV_OVP,
    CONF_ITEM_MCU_HV_UVP,
    CONF_ITEM_MCU_HV_OCP,
    CONF_ITEM_MCU_PCB_OTP,
    CONF_ITEM_MCU_SR_OTP,
    CONF_ITEM_MCU_COOLANT_OTP,
    CONF_ITEM_MCU_BAT_OVP,
    CONF_ITEM_MCU_BAT_UVP,
    CONF_ITEM_MCU_EVSE_OFP,
    CONF_ITEM_MCU_EVSE_UFP,
    CONF_ITEM_MCU_DIAG_OVP,
    CONF_ITEM_MCU_DIAG_SCP,
    CONF_ITEM_RESERVED_0,
    CONF_ITEM_RESERVED_1,
    CONF_ITEM_RESERVED_2,
    CONF_ITEM_RESERVED_3,
    CONF_ITEM_RESERVED_4,
    CONF_ITEM_NUMBER,
}e_conf_prot_t;

typedef enum CONF_DISABLE_E
{
    CONF_DISA_J1772 = 0,                        // disable J1772 detection if only if 'T'
    CONF_DISA_DERATING,                         // disable derating function if only if 'T'
    CONF_DISA_PRECHARGE,                        // bypass pre-charge state if only if 'T'
    CONF_DISA_DISCHARGE,                        // bypass dis-charge state if only if 'T'
    CONF_DISA_NM,                               // disable Network Management if only if 'T'
    CONF_DISA_CAN_WAKEUP,                       // disable CAN wakeup if only if 'T'
    CONF_DISA_RESERVED_1,
    CONF_DISA_RESERVED_2,
    CONF_DISA_RESERVED_3,
    CONF_DISA_RESERVED_4,
    CONF_DISA_RESERVED_5,
    CONF_DISA_NUMBER,
}e_conf_disa_t;

typedef enum DSP_PARAM_E
{
    DSP_PARAM_PFC_V_KP = 0,
    DSP_PARAM_PFC_V_KI,
    DSP_PARAM_PFC_I_KP,
    DSP_PARAM_PFC_I_KI,
    DSP_PARAM_PFC_MAX,
    DSP_PARAM_PFC_MIN,
    DSP_PARAM_PFC_GAIN,
    DSP_PARAM_PFC_IO,
    DSP_PARAM_LLC_V_KP,
    DSP_PARAM_LLC_V_KI,
    DSP_PARAM_LLC_I_KP,
    DSP_PARAM_LLC_I_KI,
    DSP_PARAM_RESERVED_0,
    DSP_PARAM_RESERVED_1,
    DSP_PARAM_RESERVED_2,
    DSP_PARAM_RESERVED_3,
    DSP_PARAM_NUMBER
}e_dsp_param_t;

typedef struct PACKED CONFIGURATION_DATA_S      /* configuration data block */
{
    data_header_t   xHead;
    u8              baDisa[CONF_DISA_NUMBER];
    prot_param_t    xaItem[CONF_ITEM_NUMBER];
    u8              bPadding;                   /* add this byte for c28 decode */
    f32             faParam[DSP_PARAM_NUMBER];
}x_conf_data_t;

typedef struct PACKED NM_PARAM_S
{
    u8 bEcuId;
    u16 wRepeatMsgTimer;
    u16 wNmTimeoutTimer;
    u16 wWaitBusSleepTimer;
    u16 w1stFrameDelayTimer;
    u16 wNmCycleTimer;
    u16 wNmImmediateCycleTimer;
    u16 wImmediateNmTimes;
    u16 wNmReserve0;
    u16 wNmReserve1;
    u16 wNmReserve2;
    u16 wNmReserve3;
    u16 wNmReserve4;
}nm_param_t;

typedef struct PACKED UDS_PARAM_S
{
    u32 dwPhysicalAddr;
    u32 dwFunctionalAddr;
    u32 dwTesterAddr;
    u16 wP2ServerTime;
    u16 wP2ExtendServerTime;
    u16 wS3ServerTime;
    u16 wUdsReserve0;
    u16 wUdsReserve1;
    u16 wUdsReserve2;
    u16 wUdsReserve3;
    u16 wUdsReserve4;
}uds_param_t;

typedef struct PACKED TP_PARAM_S
{
    u8 bStMin;                                  /* STmin */
    u8 bBlockSize;                              /* Block Size */
    u16 wWftMax;                                /* WFT Max */
    u8 bLinkDataLenth;                          /* Data link layer length */
    u8 bTxPadding;                              /* padding data */
    u16 wAs;                                    /* N_As */
    u16 wAr;                                    /* N_Ar */
    u16 wBs;                                    /* N_Bs */
    u16 wBr;                                    /* N_Br */
    u16 wCs;                                    /* N_Cs */
    u16 wCr;                                    /* N_Cr */
    u16 wTpReserve0;
    u16 wTpReserve1;
    u16 wTpReserve2;
    u16 wTpReserve3;
    u16 wTpReserve4;
}tp_param_t;

typedef struct PACKED NET_CONF_S
{
    data_header_t   xHead;
    nm_param_t      xNmConf;
    tp_param_t      xTpConf;
    uds_param_t     xUdsConf;
}net_conf_t;


//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
void sNvmInit(void);

#if 0                                           // unusd code
u8 sbNvmConfDataSave(void);
u8 sbNvmCaliDataSave(void);
void sNvmConfDataWrite(const x_conf_data_t* pxData, bool blKeepWrCnt);
void sNvmCaliDataWrite(const x_cali_data_t* pxData, bool blKeepWrCnt);
void sNvmConfDataAddrGet(const x_conf_data_t *pxAddr);
u8 sbNvmDataVerify(const void* pData);
#endif

void sNvmConfDataRead(x_conf_data_t* pxData);

void sNvmCaliDataRead(x_cali_data_t* pxData);

void sNvmCaliDataReset(void);
void sNvmGetSSDConfig(flash_ssd_config_t * const pSSDConfig);

void sNvmCaliDataPtrGet(x_cali_data_t** pxData);

void sNvmConfDataPtrGet(x_conf_data_t** ppxData);

void sNvmNetConfDefaultPtrGet(const net_conf_t** ppxData);

#endif

