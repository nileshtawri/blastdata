/**
 * @file        Sbc.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "Cpu.h"
#include "status.h"
#include "Sbc.h"
#include "housekeep.h"
#include "config.h"
#include "nvm.h"
#include "autolibc.h"

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static u8 blFs0bRelease = false;

#if (HAVE_SBC_FUNCTION != 0)
static fs45_drv_config_t xSbcConf;
#endif

//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief       Initialize SBC
 */
void sSBCInitial(void)
{
    #if (HAVE_SBC_FUNCTION != 0)

    fs45_rx_data_t xRxData;
    u16 wStatus = 0U;
    status_t xStatus;
    x_conf_data_t *pxConf;
    bool blJ1772Enable;

    void* pDest;
    const void* pSrc;
    u32 dwLen;

    dwLen = sizeof(fs45_drv_config_t);
    pDest = (void*)&xSbcConf;
    pSrc = (const void*)&sbc_fs45_InitConfig;

    (void)fsl_memcpy(pDest, pSrc, dwLen);

    sNvmConfDataPtrGet(&pxConf);
    blJ1772Enable = !(pxConf->baDisa[CONF_DISA_J1772] == (u8)'T');

    if (blJ1772Enable)
    {
        xSbcConf.wu1Reg.wuIo2 = FS45_RW_M_WU_IO2_ANY_EDGE;
    }

    //Initial SPI
    xStatus = LPSPI_DRV_MasterInit( LPSPICOM1, 
                                    &lpspiCom1State, 
                                    &lpspiCom1_MasterConfig0);
    if (xStatus != STATUS_SUCCESS)
    {
        sEventFlagSet(MASK_SBC_ERR);
    }

    wStatus = (u16)FS45_Init(&xSbcConf, LPSPICOM1, 50u);

    if((wStatus == (u16)STATUS_SUCCESS) || (wStatus == (u16)SBC_WD_ERROR))
    {
        wStatus = 0;
    	wStatus |= (u16)FS45_WD_ChangeWindow(FS45_W_FS_WD_WINDOW_12MS);
        wStatus |= (u16)FS45_CAN_SetMode(fs45CanModeNormal, true);
    	wStatus |= (u16)FS45_SwitchAMUXchannel(FS45_RW_M_AMUX_VSNS_W);
    	wStatus |= (u16)FS45_ReadRegister(FS45_M_IO_OUT_AMUX_ADDR, &xRxData);
        if( (wStatus != (u16)STATUS_SUCCESS)
            || ((xRxData.readData & 0x07u) != FS45_RW_M_AMUX_VSNS_W))
        {
        	wStatus = (u16)SBC_COMM_ERROR;
        }
    }

    if (wStatus != (u16)STATUS_SUCCESS)
    {
    	sEventFlagSet(MASK_SBC_ERR);
    }

    #endif
}

/**
 * \brief       Initialize SBC
 * \param[in]   bPinMask    
 * \param[out]  pblPin, point to input bool variable. true = high, false = low
 * \return      \enum status_t
 */
status_t sSbcReadIoPin(u8 bPinMask, bool *pblPin)
{
    #if (HAVE_SBC_FUNCTION != 0)

    fs45_rx_data_t xRxData;
    status_t xStatus;

    xStatus = FS45_ReadRegister(FS45_M_IO_INPUT_ADDR, &xRxData);

    if(xStatus == STATUS_SUCCESS)
    {
        *pblPin = ((xRxData.readData & bPinMask) != 0);
    }

    return xStatus;

    #else

    (void)bPinMask;
    *pblPin = true;
    return STATUS_SUCCESS;

    #endif
}

/**
 * @brief       check error counter and then reelase FS0B pin
 */
status_t sbSbcFs0bCheck(void)
{
    #if (HAVE_SBC_FUNCTION != 0)

    status_t eRet;
    u8 bErrCount;

    fs45_rx_data_t xRxData;

    eRet = FS45_GetFaultErrorCounterValue(&bErrCount);

    if((eRet == STATUS_SUCCESS) && (bErrCount == 0))
    {
        eRet = FS45_ReadRegister(FS45_FS_RELEASE_FSXB_ADDR, &xRxData);
        if(eRet == STATUS_SUCCESS)
        {
            if((xRxData.readData & FS45_R_FS_FS0B_SNS_MASK) == 0)
            {
                eRet = FS45_ReleaseFSx(fs45ReleaseFs0b);
    			if(eRet == STATUS_SUCCESS)
    			{
    				blFs0bRelease = true;
    				sEventFlagClear(MASK_SBC_FS);
    			}
    			else
    			{
    				blFs0bRelease = false;
    				sEventFlagSet(MASK_SBC_FS);
    			}
            }
            else
            {
            	blFs0bRelease = true;
            	sEventFlagClear(MASK_SBC_FS);
            }
			goto EndTag;
        }
    }

	blFs0bRelease = false;
	sEventFlagSet(MASK_SBC_FS);

EndTag:
    return eRet;

    #else

    return STATUS_SUCCESS;

    #endif

}


/**
 * \brief       does SBC release FS0B?
 * \retern      \blFs0bRelease
 */
bool sblIsFs0bRelease(void)
{
    return blFs0bRelease;
}


