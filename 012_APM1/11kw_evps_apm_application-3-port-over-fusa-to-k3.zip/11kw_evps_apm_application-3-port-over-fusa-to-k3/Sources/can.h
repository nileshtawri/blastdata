/**
 * @file        can.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_CAN_H
#define         DEF_CAN_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "can_tp_cfg.h"


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum APM_MODE_CMD_E
{
    APM_MODE_CMD_INVALID        = 0,
    APM_MODE_CMD_IDLE           = 1U,
    APM_MODE_CMD_STANDBY        = 2U,
    APM_MODE_CMD_DCDC           = 3U,
    APM_MODE_CMD_PRECHARGE      = 4U,
    APM_MODE_CMD_DISCHARGE      = 5U,
    APM_MODE_CMD_TEST           = 0xFFU,
}apm_mode_cmd_t;
#if(HVAE_11KW_CAN_SPECS == 1)
typedef enum OBC_SAFETY_CMD_E
{
  OBC_SAFETY_CMD_SLEEP     = 0xB0,
  OBC_SAFETY_CMD_STANDBY   = 0xB1,
  OBC_SAFETY_CMD_FrwdOn    = 0xB2,
  OBC_SAFETY_CMD_ReverseOn  = 0xB3,
  OBC_SAFETY_CMD_INVALID   = 0xFF,
}obc_safety_cmd_t;
typedef enum OBC_NEWMODE_CMD_E
{
    OBC_MODE_CMD_SLEEP = 0xA0,
    OBC_MODE_CMD_STANDBY_OFF = 0xA1,
    OBC_MODE_CMD_FrwdOn = 0xA2,
    OBC_MODE_CMD_RevOn  = 0xA3,
    OBC_MODE_CMD_IVALID = 0xA4,
}obc_newmode_cmd_t;
#endif

typedef enum OBC_MODE_CMD_E
{
    OBC_MODE_CMD_STANDBY = 0,
    OBC_MODE_CMD_RUN,
    OBC_MODE_CMD_OFF,
    OBC_MODE_CMD_START,
    OBC_MODE_CMD_UNKNOW,
}obc_mode_cmd_t;


typedef enum OBC_WORK_MODE_E
{
    OBC_WORK_MODE_START = 0,
    OBC_WORK_MODE_IDLE,
    OBC_WORK_MODE_STANDBY,
    OBC_WORK_MODE_RUN,
    OBC_WORK_MODE_OFF,
    OBC_WORK_MODE_FAIL,                         // temporary failure
    OBC_WORK_MODE_LATCH,                        // critical failure
    OBC_WORK_MODE_UNKNOW,
}obc_work_mode_t;


typedef struct PACKED CAN0_IF_DATA_S
{
    apm_mode_cmd_t eApmModeCmd;
    f32 flApmVcmd;
    f32 flApmIcmd;
    obc_mode_cmd_t eObcModeCmd;
    f32 flObcVcmd;
    f32 flObcIcmd;
    e_bool_t eRxApmCmdTimeout;
    e_bool_t eRxObcCmdTimeout;
    e_bool_t eRxSysTimeTimeout;
    u16 wYear;
    u8 bMonth;
    u8 bDay;
    u8 bHour;
    u8 bMinute;
    u8 bSec;
    u8 b100ms;
#if (HVAE_11KW_CAN_SPECS == 1)
	 u8 bAliveCounter;
	 obc_safety_cmd_t eRedundantModeCmd;
#endif
}x_if_ci0_t;

typedef struct PACKED CAN2_IF_DATA_S
{
    obc_work_mode_t eObcWorkMode;
    u64 qwObcErrorFlag;
    f32 flObcPfcAuxVolt;
    f32 flObcPfcCurrA;
    f32 flObcPfcCurrB;
    f32 flObcPfcCurrC;
    f32 flObcPfcCurrD;
    f32 flObcGridVolt;
    f32 flObcGridCurr;
    f32 flObcGridFreq;
    f32 flObcHvdcVolt;
    f32 flObcHvdcCurr;
    f32 flObcBulkVolt;
    f32 flObcHvVoltRef;
    f32 flObcHvCurrRef;
    f32 flObcCtrlTheta;
    f32 flObcCtrlFreq;
    f32 flObcTempLlc;
    f32 flObcTempPfc;
    e_bool_t eRxTimeout;
}x_if_ci2_t;
#if (HVAE_11KW_CAN_SPECS == 1)

typedef union {
	u16 u16All;
    struct{ //Bytes
		u16 u8Lsb:8;
		u16 u8Msb:8;
    };
}can_data_t;

typedef union {
    u16 u16All;
    struct{ //Bytes
    	u16 u8Lsb:8;
    	u16 u8Msb:8;
    };
    struct{ //Bits
            //OBC Operating States
    	u16 bObcMode:4;

            //GPIO, Control, CMD Status
    	u16 bPfcEn:1;                  // 1- PFC En High, 0 - PFC En Low
    	u16 bRectEnabled:1;            // 1- Rectifier Mode Enabled, 0- Rectifier Mode Disabled
    	u16 bInvertEnabled:1;          // 1- Inverter Mode Enabled, 0- Inverter Mode Disabled
    	u16 bCanCmdStatus:1;           // 1- OBC ON Command Received, 0 - OBC OFF Command Received

    	u16 bPosSequence:1;            // 1 - +ve Sequence, 0 - -ve Sequence
    	u16 bRelayON:1;                // 1 - Relay is OK, 0 - Relay is OFF
    	u16 bAcStatusOk:1;             // 1 - AC OK, 0 - AC Fail
    	u16 bPfcStatusOk:1;            // 1 - PFC OK, 0 - PFC Fail

    	u16 bClllcStatusOk:1;          // 1 - Clllc OK, 0 - CLLLC not OK
    	u16 bNpcFault:1;               // 1 - Npc in Fault State, 0 - Npc Not in Fault State
    	u16 bOTFault:1;                // 1 - Over Temperature Fault Occured, 0 - No over Temperature Fault
    	u16 bCanCmdTimeout:1;          // 1 - CAN CMD Timeout, 0 - CAN CMD Receive Ok
    };
}obc_pri_status_t;  // first two byte of MSG ID 0x110

typedef union {
	u16 u16All;
    struct{ //Bytes
		u16 u8Lsb:8;
		u16 u8Msb:8;
    };
    struct{ //Bits
            //Forward Mode Faults
    	u16 bFreOver:1;
    	u16 bFreqUnder:1;
    	u16 bPhaseLoss:1;
    	u16 bPhaseUnbal:1;
            //Common Faults
    	u16 bIpOVP:1;
    	u16 bIpUvp:1;
    	u16 bFltRes1:1;
    	u16 bTzFault:1;
            //Reverse Mode Faults
    	u16 bPfcOvp:1;
    	u16 bPfcUvp:1;
    	u16 bPfcOcp:1;
    	u16 bPfcUnbal:1;
            //Temperature Faults
    	u16 bNpcOt:1;
    	u16 bClllcOt:1;
    	u16 bAuxOV:1;
    	u16 bAuxUV:1;
    };
}obc_pri_faults_t;

typedef struct {
        //Message ID 0x110
    obc_pri_status_t sObcPriStatus;
    can_data_t sVacA;
    can_data_t sIacA;
    can_data_t sVpfcMid;

        //Message ID 0x130
    obc_pri_faults_t sObcPriFaults;
    can_data_t sResData1;
    can_data_t sResData2;
    can_data_t sVAux;

        //Message ID 0x131
    can_data_t sVacB;
    can_data_t sVacC;
    can_data_t sIacB;
    can_data_t sIacC;

        //Message ID 0x132
    can_data_t sIphaseA;
    can_data_t sIphaseB;
    can_data_t sIphaseC;
    can_data_t sVpfcOut;

        //Message ID 0x133
    can_data_t sTNpcA;
    can_data_t sTNpcB;
    can_data_t sTNpcC;
    can_data_t sTClllcP1;
    can_data_t sTClllcP2;

        //Message ID 0x134
    u16 u16FwRev[8];

        //Message ID 0x135

        //Message ID 0x136
    can_data_t sDebug1;
    can_data_t sDebug2;
    can_data_t sDebug3;

        //Message ID 0x137
    can_data_t sDebug4;
    can_data_t sDebug5;
    can_data_t sDebug6;

}outbox_pri_data_t;    // 0x110,0x130,0x131  ... primary cmd and status

typedef union {
	u16 u16All;
    struct{ //Bytes
		u16 u8Lsb:8;
		u16 u8Msb:8;
    };
    struct{ //Bits
            //OBC Operating States
    	u16 bObcMode:4;

            //GPIO, Control, CMD Status
    	u16 bCpReady:1;                // 1- CP Ready High, 0 - CP Ready Low
    	u16 bFrwdEnabled:1;            // 1- Forward Mode Enabled, 0- Forward Mode Disabled
    	u16 bRevEnabled:1;             // 1- Reverse Mode Enabled, 0- Reverse Mode Disabled
    	u16 bCanCmdStatus:1;           // 1- OBC ON Command Received, 0 - OBC OFF Command Received

    	u16 bAcStatusOk:1;             // 1 - AC OK, 0 - AC Fail
    	u16 bPfcStatusOk:1;            // 1 - PFC OK, 0 - PFC Fail
    	u16 bClllcEnabled:1;           // 1 - Clllc Enabled by PFC, 0 - Clllc Disabled by PFC
    	u16 bClllcStatusOk:1;          // 1 - Clllc OK, 0 - CLLLC not OK

    	u16 bObcStatusOk:1;            // 1 - OBC OK, 0 - OBC not OK
    	u16 bClllcFault:1;             // 1 - Clllc in Fault State, 0 - Clllc Not in Fault State
    	u16 bOTFault:1;                // 1 - Over Temperature Fault Occured, 0 - No over Temperature Fault
    	u16 bCanCmdTimeout:1;          // 1 - CAN CMD Timeout, 0 - CAN CMD Receive Ok
    };
}obc_sec_status_t;

typedef union {
	u16 u16All;
    struct{ //Bytes
		u16 u8Lsb:8;
		u16 u8Msb:8;
    };
    struct{ //Bits
            //Forward Mode Faults
    	u16 bVoutOvp:1;
    	u16 bVoutOcp:1;
    	u16 bVoutOcp1:1;
        u16 bVoutOcp2:1;
            //Common Faults
        u16 bFltRes1:1;
        u16 bAuxOv:1;
        u16 bAuxUv:1;
        u16 bTzFault:1;
            //Reverse Mode Faults
        u16 bVbulkOvp:1;
        u16 bVbulkOcp:1;
        u16 bVbulkOcp1:1;
        u16 bVbulkOcp2:1;
            //Temperature Faults
        u16 bClllcOtS1:1;
        u16 bClllcOtS2:1;
        u16 bFltRes2:1;
        u16 bClllcOtw:1;
    };
}obc_sec_faults_t;

typedef union {
    u16 u16All;
    struct{ //Bytes
        u16 u8Lsb:8;
        u16 u8Msb:8;
    };
    struct{ //Bits
            //OBC Control Mode
        u16 bObcMode:2;
        u16 bObcCtrlCCCV:1;
        u16 bSrEnabled:1;
        u16 bIshareEnabled:1;

        u16 bStateRes1:1;
        u16 bStateRes2:1;
        u16 bStateRes3:1;

        u16 bBurstDuty1:4;
        u16 bBurstDuty2:4;
    };
}clllc_ctrl_status_t;

typedef struct {
        //Message ID 0x120
    obc_sec_status_t sObcSecStatus;
    can_data_t sVout;
    can_data_t sIout;
    can_data_t sVbulk;

        //Message ID 0x140
    obc_sec_faults_t sObcSecFaults;
    can_data_t sResData1;
    can_data_t sResData2;
    can_data_t sIpri;

        //Message ID 0x141
    can_data_t sIout1;
    can_data_t sIout2;
    can_data_t sIpri1;
    can_data_t sIpri2;

        //Message ID 0x142
    can_data_t sTlllc1;
    can_data_t sTlllc2;
    can_data_t sTlllcRes1;
    can_data_t sTlllcRes2;
    can_data_t sIshareErr;
    can_data_t sIshareAdj;

        //Message ID 0x143
    clllc_ctrl_status_t sClllcCtrlStat;
    can_data_t sPhaseShigft1;
    can_data_t sPhaseShigft2;
    can_data_t sLllcPeriod1;
    can_data_t sLllcPeriod2;

        //Message ID 0x144
    u16 u16FwRev[8];

        //Message ID 0x145

        //Message ID 0x146
    can_data_t sDebug1;
    can_data_t sDebug2;
    can_data_t sDebug3;

        //Message ID 0x147
    can_data_t sDebug4;
    can_data_t sDebug5;
    can_data_t sDebug6;

}outbox_sec_data_t;

typedef struct {

u8 Cmd;
u8 MessageId;
u8 Data0_Lsb;
u8 Data0_Msb;
u8 Data1_Lsb;
u8 Data1_Msb;
u8 Data2_Lsb;
u8 Data2_Msb;
}obc_pri_dbg_cmd;

typedef struct {
	u8 Cmd;
	u8 MessageId;
	u8 Data0_Lsb;
	u8 Data0_Msb;
	u8 Data1_Lsb;
	u8 Data1_Msb;
	u8 Data2_Lsb;
	u8 Data2_Msb;
}obc_sec_dbg_cmd;


#endif

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sCanIfInit(void);

extern void sCan0Init(void);
extern void sCan0Task(void);

#if 0                                           // unused code
extern bool sblIsCan0Loss(void);
extern apm_mode_cmd_t sxCanApmModeCmdGet(void);
extern f32 sflCanApmVcmdGet(void);
extern f32 sflCanApmIcmdGet(void);

#endif

extern void sIsoTpSendMsg(void);


extern void sCan2IsoTp(void);
extern void sCan2Task(void);

extern void sCan2Init_100k(void);
extern void sCan2Init(void);
extern bool sblIsC2kBootromFinish(void);

extern void sCanTxNmDebug(u8 bDbg0, u8 bDbg1, u8 bDbg2, u8 bDbg3);


#endif

