import os
import sys
import re
from subprocess import Popen, PIPE
from string import Template
from datetime import datetime
import platform

def whereis(program):
    for path in os.environ.get('PATH', '').split(os.pathsep):
        p = os.path.join(path, program)
        if os.path.exists(p) and os.path.isfile(p):
            return p
    return None

def update_template(infile, outfile, d):
    print('Generating "%s" from "%s"' % (outfile, infile))
    f = open(infile)
    src = f.read()
    f.close()

    dest = Template(src).substitute(d)

    f= open(outfile, 'w')
    f.write(dest)
    f.close()

    print("Done")

def get_tags():
    cmd = ['hg.exe', 'tags',]
    output = Popen(cmd, shell=False, stdout=PIPE).stdout.read().decode()
    tags = []
    r = re.compile(r'^(\S+)\s+(-?\d+):([\da-fA-F]+)')
    for tagline in output.split('\n'):
        m = r.match(tagline)
        if m:
            tags.append(m.groups())
    return tags

def get_latest_tag():
    cmd = ['hg.exe', 'log', '-r', '.', '--template', 'OK: {latesttag}']
    output = Popen(cmd, shell=False, stdout=PIPE).stdout.read().decode()
    if output.startswith('OK:'):
        _, tag = output.split(' ')
        return tag
    return ''

def get_latest_tag_distance():
    cmd = ['hg.exe', 'log', '-r', '.', '--template', 'OK: {latesttagdistance}']
    output = Popen(cmd, shell=False, stdout=PIPE).stdout.read().decode()
    if output.startswith('OK:'):
        _, dist = output.split(' ')
        return int(dist)
    return -1

def get_short_node():
    cmd = ['hg.exe', 'log', '-r', '.', '--template', 'OK: {node|short}']
    output = Popen(cmd, shell=False, stdout=PIPE).stdout.read().decode()
    if output.startswith('OK:'):
        _, node = output.split(' ')
        return node
    return '?'

def is_modified():
    cmd = ['hg.exe', 'status']
    output = Popen(cmd, shell=False, stdout=PIPE).stdout.read().decode()
    if output:
        return True
    return False

def get_version():
    d = {'abVersion': '', 'abHgVersion': '', 'abHgNode': '?', 'bBuildHostId': 0, \
         'wBuildYear': 0, 'bBuildMonth': 0, 'bBuildDay': 0, \
         'bVerMajor': 0, 'bVerMinor': 0, 'bVerDebug': 0}

    if whereis('hg.exe'):
        tags = get_tags()
        if len(tags) > 1:
            tag = get_latest_tag()
            tag_ver = tag.split('.')
            d['bVerMajor'] = int(tag_ver[0])
            d['bVerMinor'] = int(tag_ver[1])
            d['bVerDebug'] = int(tag_ver[2])
        else:
            tag = ""
        dist = get_latest_tag_distance()
        node = get_short_node()

        if tag:
            hgversion = "v" + tag
        else:
            hgversion = "<null>"

        if dist > 0:
            hgversion = hgversion + "+" + str(dist)

        if is_modified():
            node = node + "+"
            hgversion = hgversion + "+"

        d['abVersion'] = tag
        d['abHgVersion'] = hgversion
        d['abHgNode'] = node
    else:
        print('Cannot find hg.exe')

    return d

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: %s in_file out_file" % os.path.basename(__file__))
    else:
        d = get_version()
        
        if 'ETWM5444' in platform.node():           # snaku local bulid
            d['bBuildHostId'] = 255
        elif 'ETWM5733' in platform.node():         # damon local build
            d['bBuildHostId'] = 254
        elif 'ETWM5903' in platform.node():         # build server 1
            d['bBuildHostId'] = 1
        else:                                       # unknow host
            d['bBuildHostId'] = 0
        d['wBuildYear'] = datetime.now().year
        d['bBuildMonth'] = datetime.now().month
        d['bBuildDay'] = datetime.now().day
        
        for key in d:
            print("%s: %s" % (key, d[key]))
        
        update_template(sys.argv[1], sys.argv[2], d)
