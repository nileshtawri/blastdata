#ifndef __shell_CONFIG_H
#define __shell_CONFIG_H

#ifndef shell_CONFIG_BLOCKING_SEND_ENABLED
  #define shell_CONFIG_BLOCKING_SEND_ENABLED  (0)
    /*!< 1: Sending is blocking (with an optional timeout); 0: Do not block on sending */
#endif

#ifndef shell_CONFIG_BLOCKING_SEND_TIMEOUT_MS
  #define shell_CONFIG_BLOCKING_SEND_TIMEOUT_MS  (0)
    /*!< Total blocking time (timeout) in milliseconds, uses 0 for blocking without a timeout */
#endif

#ifndef shell_CONFIG_BLOCKING_SEND_TIMEOUT_WAIT_MS
  #define shell_CONFIG_BLOCKING_SEND_TIMEOUT_WAIT_MS  (0)
    /*!< waiting time during blocking, use 0 (zero) for polling */
#endif

#ifndef shell_CONFIG_BLOCKING_SEND_RTOS_WAIT
  #define shell_CONFIG_BLOCKING_SEND_RTOS_WAIT  (0)
    /*!< 1: Use WaitmsOS() instead of Waitms(); 0: Use Waitms() instead of WaitOSms() */
#endif

#ifndef shell_CONFIG_USE_MUTEX
  #define shell_CONFIG_USE_MUTEX  (0)
    /*!< 1: use RTOS mutex; 0: do not use RTOS mutex */
#endif

#ifndef shell_CONFIG_DEFAULT_SHELL_BUFFER_SIZE
  #define shell_CONFIG_DEFAULT_SHELL_BUFFER_SIZE  (48)
    /*!< default buffer size for shell command parsing */
#endif

#ifndef shell_CONFIG_DEFAULT_SERIAL
  #define shell_CONFIG_DEFAULT_SERIAL  (0)
    /*!< 1: the shell implements its own StdIO which is returned by GetStdio(); 0: The shell does not implement its own standard I/O */
#endif

#if shell_CONFIG_DEFAULT_SERIAL
  #define shell_CONFIG_DEFAULT_SERIAL_RECEIVE_FCT_NAME   RecvChar
    /*!< Function name to read a character and returning ERR_OK if it was successful */

  #define shell_CONFIG_DEFAULT_SERIAL_SEND_FCT_NAME   SendChar
    /*!< Function name to send a character and returning ERR_OK if it was successful */

  #define shell_CONFIG_DEFAULT_SERIAL_RXAVAIL_FCT_NAME   GetCharsInRxBuf
    /*!< Function name to check if there is anything available to receive and returns TRUE, otherwise FALSE */
#endif

#ifndef shell_CONFIG_PROMPT_STRING
  #define shell_CONFIG_PROMPT_STRING    "OBC> "
#endif

#ifndef shell_CONFIG_PROJECT_NAME_STRING
  #define shell_CONFIG_PROJECT_NAME_STRING    "OBC_6K6_A"
#endif


#endif /* __shell_CONFIG_H */
