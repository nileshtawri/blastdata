#ifndef __RingBuf_CONFIG_H
#define __RingBuf_CONFIG_H

#ifndef RingBuf_CONFIG_REENTRANT
  #define RingBuf_CONFIG_REENTRANT      1 /* 1: reentrant implementation; 0: non-reentrant implementation */
#endif

#ifndef RingBuf_CONFIG_BUF_SIZE
  #define RingBuf_CONFIG_BUF_SIZE       64   /* number of elements in the buffer */
#endif

#ifndef RingBuf_CONFIG_ELEM_SIZE
  #define RingBuf_CONFIG_ELEM_SIZE      1   /* size of a single element in bytes */
#endif

#endif /* __RingBuf_CONFIG_H */
