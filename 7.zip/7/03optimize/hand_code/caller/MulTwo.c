#include "MulTwo.h"

int MulTwo(int In)
{
  return In * 2;
}
 
