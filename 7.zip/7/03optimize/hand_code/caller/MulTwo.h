
extern int MulTwo(int In);
