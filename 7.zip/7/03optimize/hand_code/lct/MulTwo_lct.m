% GetVal_function
def               = legacy_code('initialize');
def.SFunctionName = 'MulTwo_Sfcn';
def.OutputFcnSpec = 'int16 y1 = MulTwo(int16 u1)';
def.HeaderFiles   = {'MulTwo.h'};
def.SourceFiles   = {'MulTwo.c'};
def.IncPaths      = {pwd}; 
def.SrcPaths      = {pwd}; 
%def.Options.singleCPPMexFile = true;

legacy_code('sfcn_cmex_generate', def);cd
legacy_code('compile', def);
legacy_code('sfcn_tlc_generate', def);
legacy_code('rtwmakecfg_generate', def);
legacy_code('slblock_generate', def);

