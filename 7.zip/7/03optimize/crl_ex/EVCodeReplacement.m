function hLib = EVCodeReplacement


hLib = RTW.TflTable;
%---------- entry: RTW_OP_ADD ----------- 
hEnt = createCRLEntry(hLib, ...
    'double y1 = double u1 + double u2', ...
    'double y1 = Sumfunc( double u1, double u2 )');
hEnt.setTflCOperationEntryParameters( ...
          'Priority', 100);

hEnt.EntryInfo.Algorithm = 'RTW_CAST_BEFORE_OP';

hLib.addEntry( hEnt ); 

