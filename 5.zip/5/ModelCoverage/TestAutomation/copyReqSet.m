function copyReqSet(src,dest)
% Copies req set and links file

    d=fileparts(which([src '.slreqx_']));
    copyfile(which([src '.slreqx_']),fullfile(d,[dest '.slreqx']));
    copyfile(which([src '.slmx_']),fullfile(d,[dest '.slmx']));
    
end

