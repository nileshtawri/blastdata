%% ========================================================================
%       Open "TAL" Test File in Test Manager - Short Test Plan
%  ========================================================================
%%  Open TAL Requirements 
copyReqSet('MW_CruiseControl_TAL','MW_CruiseControl_TAL');
reqSet = slreq.open('MW_CruiseControl_TAL');
reqSet.close(false);
reqSet = slreq.open('MW_CruiseControl_TAL');
%%  Open test file to show TAL features
copyReqsTestCase('CruiseControl_TAL_Tests','CruiseControl_TAL_Tests');
sltest.testmanager.load('CruiseControl_TAL_Tests.mldatx');
sltest.testmanager.view;
