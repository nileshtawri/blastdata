%% ========================================================================
%       Open "BuiltIn" Test File in Test Manager - Short Test Plan
%  ========================================================================
%%  Open test file to show BuiltIn features
sltest.testmanager.load('CruiseControlTests_BuiltIn.mldatx');
sltest.testmanager.view;