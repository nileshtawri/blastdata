%% ========================================================================
%       Requirements Based Functional Testing - SL Test Short Final
%  ========================================================================
%% close Short and open ShortFinal system harness 
try
sltest.harness.close('CruiseControl_SLT_0','CruiseControl_Harness_SigEditor');
end
sltest.harness.open('CruiseControl_SLT_0','CruiseControl_Harness_SigEditorFinal');
