%% ========================================================================
%       Requirements Based Functional Testing
%  ========================================================================
%% close Short or ShortFinal and open ShortTestSeq system harness 
try
sltest.harness.close('CruiseControl_SLT_0','CruiseControl_Harness_SigEditor');
end
try
sltest.harness.close('CruiseControl_SLT_0','CruiseControl_Harness_SigEditorFinal');
end
try
sltest.harness.open('CruiseControl_SLT_0','CruiseControl_Harness_ShortTestSeq_v2');
catch
bdclose all
clear all
open_system('CruiseControl_SLT_0');    
sltest.harness.open('CruiseControl_SLT_0','CruiseControl_Harness_ShortTestSeq_v2');
end
