%% ========================================================================
%       SL Check 
%  ========================================================================
%% close
bdclose all
clear all

%%  Open Cruise Control version for checking
copyReqsMdl('CruiseControl_Req','CruiseControl_MA');
copyReqsDataDict('CruiseControl_Req_dd','CruiseControl_Req_dd');
open_system('CruiseControl_MA.slx');
