%% ========================================================================
%       SL Check 
%  ========================================================================

%%  Open Cruise Control version for checking
copyReqsMdl('CruiseControl_Req_wEditTimeFix','CruiseControl_MA');
open_system('CruiseControl_MA.slx');


