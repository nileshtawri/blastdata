copyfile(which('sl_customization_disable'), [pwd filesep 'sl_customization.m']);
