%% ========================================================================
%       SL Check 
%  ========================================================================
%% close
bdclose all
clear all

%%  Open Cruise Control version for checking
copyReqsMdl('CruiseControl_Req_wMABfix','CruiseControl_MAB');
open_system('CruiseControl_MAB.slx');

