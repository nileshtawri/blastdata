//#############################################################################
//
// FILE:   empty_driverlib_main.c
//
// TITLE:  Empty Project
//
// Empty Project Example
//
// This example is an empty project setup for Driverlib development.
//
//#############################################################################
//
//
// $Copyright:
// Copyright (C) 2021 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the
//   distribution.
//
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "CAN_define.h"
#include "string.h"
#include "ADC_ValueConvert.h"
#include "ADC_ValueConvert_private.h"
#include "Control_SM_test.h"
#include "Control_SM_test_private.h"
#include "LLC_Control_Loop.h"
#include "LLC_Control_Loop_private.h"
#include "General_PFC_Control_Loop.h"
#include "General_PFC_Control_Loop_private.h"
#include "HouseKeeping.h"
#include "HouseKeeping_private.h"


#include "sta_timer.h"
#include "sta_tests.h"
#include "sta_comm.h"

#include "crc16.h"
#include "nvm.h"
#include "rtwtypes.h"
#include "Calibration.h"
#include "Configuration.h"

#define STA_MAIN_TIMEOUT    400U
#define CALI_DATA_ADDR      0x0000B800U
#define CONF_DATA_ADDR      0x0000BC00U

typedef void (*TASK_FPTR)(void);
typedef enum TASK_ID_E
{
    TASK_PROTECTION,
    TASK_CANMSG_SEND,
    TASK_CANMSG_DECODE,
    TASK_STATE_MACHINE,
    TASK_POWERDERATING,
    TASK_INPUTXBARCLEAR,
    TASK_HWDIAGNOSIS,
    TASK_PROTECTION_SWITCH,
    TASK_MAX
}TASK_ID_T;

typedef struct TASK_E
{
    TASK_ID_T task_id;
    bool enable;
    bool one_shot;
    uint32_t period;
    uint32_t remain;
    TASK_FPTR pf_func;
}TASK_T;

void sTaskRun(void);
void sDiagnosis_HWProtection(void);
void sProtection_Switch(void);
void sInputXBAR_Clear(void);
void CaliDataUpdate(void);
void ConfDataUpdate(void);
void Conf_KpKi_Param_Update(void);
void DetectDataVersion(void);

static TASK_T parameter[] =
{
     {TASK_PROTECTION, true, false, 1u, 1u, ProtectionTrigger},
     {TASK_CANMSG_SEND, true, false, 1u, 1u, Ifx_CanHandler_processOutbox},
     {TASK_CANMSG_DECODE, true, false, 5u, 5u, Ifx_CanHandler_processInbox},
     {TASK_STATE_MACHINE, true, false, 10u, 10u, SMTrigger},
     {TASK_POWERDERATING, true, false, 1u, 1u, PowerDeratingTrigger},
     {TASK_INPUTXBARCLEAR, true, false, 5u, 5u, sInputXBAR_Clear},
     {TASK_HWDIAGNOSIS, true, false, 10u, 10u, sDiagnosis_HWProtection},
     {TASK_PROTECTION_SWITCH, true, false, 10u, 10u, sProtection_Switch},
};

bool Diagnosis_HWProtection_OK;
bool Diagnosis_HV_SC_ERROR;
bool Diagnosis_HV_OC_ERROR;
bool Diagnosis_HV_OV_ERROR;
bool Diagnosis_PFC_OV_ERROR;
uint16_t wSelftestIndex = 0;
uint16_t wErrorCode = 0;
volatile uint32_t CanErrorFlag = 0;
volatile uint32_t rxMsgCount = 0;
uint32_t dwTimerCount = 0;
uint16_t Can0Node0Rxmsgs[Can_DATA_LENGTH];
uint16_t Can0Node1Rxmsgs[Can_DATA_LENGTH];
uint16_t Can0Node2Rxmsgs[Can_DATA_LENGTH];
uint16_t Can0Node3Rxmsgs[Can_DATA_LENGTH];
uint16_t Can0Node4Rxmsgs[Can_DATA_LENGTH];

App TI_App;

uint16_t wduty_temp;
uint16_t wphase_temp;
uint16_t wdeadtime_temp;
uint16_t EPWM_A_PFC_CMPA;
uint16_t EPWM_A_PFC_CMPB;
uint16_t EPWM_B_PFC_CMPA;
uint16_t EPWM_B_PFC_CMPB;

int16_T *Data;
int16_T DataFormat[4];
uint8_T CaliDataVersion;
uint8_T ConfDataVersion;

//
// Main
//
void main(void)
{   //int i;
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull ups.
    //
    Device_initGPIO();

    //
    // Disable global interrupts.
    //
    DINT;


    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Configure Timer 0 as the main time-out timer
    //
    STA_Timer_config(STA_MAIN_TIMEOUT);

    //SysCtl_setSyncInputConfig(SYSCTL_SYNC_IN_EPWM4, SYSCTL_SYNC_IN_SRC_EPWM1SYNCOUT);
    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    EINT;
    ERTM;

    /**/while (wSelftestIndex <= 14)
     {
        if(STA_Timer_isTimedOut())
        {
        //STA_Tests_injectErrorEnable();
        STA_Tests_injectErrorDisable();
        STA_Tests_testDevice(STA_Tests_testArray[wSelftestIndex++]);
        STA_Timer_restart();
        }
     }

    //
    // Disable global interrupts.
    //
    DINT;

    Interrupt_disable(INT_TIMER0);

    ADC_ValueConvert_initialize();

    Control_SM_test_initialize();
    LLC_Control_Loop_initialize();
    General_PFC_Control_Loop_initialize();
    HouseKeeping_initialize();

    DetectDataVersion();
    Cali_Verify =sNvmDataVerify(NVM_DATA_TYPE_CALI);
    Calibration_Function();
    CaliDataUpdate();
    Conf_Verify =sNvmDataVerify(NVM_DATA_TYPE_CONF);
    Configuration_Function();
    ConfDataUpdate();
    //Conf_KpKi_Param_Update();

    Board_init();

    wErrorCode = STL_Util_getErrorFlag();
    if (wErrorCode != 0)
     {
         HouseKeeping_U.wDiagnosisStatus = 2;
     }
    else
    {
        HouseKeeping_U.wDiagnosisStatus = 1;
    }



    EINT;
    ERTM;

    while(1)
    {

        sTaskRun();

    }

    /*data = (int16_t *)0x0000BC00;
    offset = *data;
    for (i=0; i<16; i++)
    {
        data = (int16_t *)(0x0000BC00 + i);
        offset[i] =  *data;
    }*/

}

//
// adcA1ISR - ADC A Interrupt 1 ISR
//
#pragma CODE_SECTION(adcA1ISR,".TI.ramfunc");
__interrupt void adcA1ISR(void)
{
    //
    // Add the latest result to the buffer
    //
    ADC_ValueConvert_U.wLLCCurrAdc = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);  //A3 Result
    ADC_ValueConvert_U.wOBCTemp1Adc = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER1);             //A6 Result
    ADC_ValueConvert_U.PFCIswBAdc = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER2); //A4 Result
    ADC_ValueConvert_U.PFCIswAAdc = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER3); //A9 Result

    ADC_ValueConvert_U.wPFCVoltAdc = (ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER0) + //B0 Result
                                              ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER2) +
                                              ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER3) +
                                              ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER4) +
                                              ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER5) +
                                              ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER6)) / 6;
    ADC_ValueConvert_U.wLLCVoltAdc = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER1); //B6 Result

    ADC_ValueConvert_U.wGridVoltLAdc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER0); //C0 Result
    ADC_ValueConvert_U.PFCIswCAdc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER1); //C1 Result
    ADC_ValueConvert_U.wOBCTemp2Adc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER2); //C3 Result
    ADC_ValueConvert_U.wGridVoltNAdc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER3); //C4 Result
    ADC_ValueConvert_U.PFCIswDAdc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER4); //C5 Result
    ADC_ValueConvert_U.wPFCAuxAdc = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER5); //C6 Result

    ADC_ValueConvert_step();


    // Dummy signal for test
    //ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCVolt = 400;
    //ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.GridVoltRms = 130;
    //ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4.LLCVolt = 300;

    Control_SM_test_U.PhyValueOut_PFC_nm4g = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1;

    Control_SM_test_step();

    // PFC controller
    /**/General_PFC_Control_Loop_U.PFC_Vcmd_Out = Control_SM_test_Y.PFC_Vcmd_Out;
    General_PFC_Control_Loop_U.PFC_Vo = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCVolt;
    General_PFC_Control_Loop_U.PFC_Vrms = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.GridVoltRms;
    General_PFC_Control_Loop_U.PFC_Isw_A = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCIswA;
    General_PFC_Control_Loop_U.PFC_Isw_B = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCIswB;
    General_PFC_Control_Loop_U.PFC_Isw_C = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCIswC;
    General_PFC_Control_Loop_U.PFC_Isw_D = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCIswD;
    General_PFC_Control_Loop_U.PFC_Reset = Control_SM_test_Y.PFC_Reset;
    General_PFC_Control_Loop_U.PFC_Isw_cmd_Init = Control_SM_test_Y.PFC_Isw_cmd_Init;
    General_PFC_Control_Loop_U.PFC_Duty_Init = Control_SM_test_Y.PFC_Duty_Init;
    General_PFC_Control_Loop_U.GridTheta = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.GridVoltTheta;
    General_PFC_Control_Loop_U.PFC_Duty_Out = Control_SM_test_Y.PFC_Duty_Out;

    General_PFC_Control_Loop_step();

    if(Control_SM_test_Y.PFC_PWM_On == false)
    {
        EPWM_setActionQualifierContSWForceAction(EPWM_A_PFC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
        EPWM_setActionQualifierContSWForceAction(EPWM_A_PFC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_OUTPUT_LOW);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_PFC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_PFC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_OUTPUT_LOW);
    }
    else
    {
        EPWM_setActionQualifierContSWForceAction(EPWM_A_PFC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_A_PFC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_PFC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_PFC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_DISABLED);
    }

    EPWM_setCounterCompareValue(EPWM_RELAY, EPWM_COUNTER_COMPARE_B, Control_SM_test_Y.Relay_PWM_CMPB);
    EPWM_A_PFC_CMPA = General_PFC_Control_Loop_Y.PFC_Duty_A * EPWM_A_PFC_INITIAL_PERIOD;
    EPWM_A_PFC_CMPB = EPWM_A_PFC_INITIAL_PERIOD - (General_PFC_Control_Loop_Y.PFC_Duty_B * EPWM_A_PFC_INITIAL_PERIOD);
    EPWM_B_PFC_CMPA = General_PFC_Control_Loop_Y.PFC_Duty_C*EPWM_A_PFC_INITIAL_PERIOD;
    EPWM_B_PFC_CMPB = EPWM_B_PFC_INITIAL_PERIOD - (General_PFC_Control_Loop_Y.PFC_Duty_D * EPWM_A_PFC_INITIAL_PERIOD);

    EPWM_setCounterCompareValue(EPWM_A_PFC, EPWM_COUNTER_COMPARE_A, EPWM_A_PFC_CMPA);
    EPWM_setCounterCompareValue(EPWM_A_PFC, EPWM_COUNTER_COMPARE_B, EPWM_A_PFC_CMPB);
    EPWM_setCounterCompareValue(EPWM_B_PFC, EPWM_COUNTER_COMPARE_A, EPWM_B_PFC_CMPA);
    EPWM_setCounterCompareValue(EPWM_B_PFC, EPWM_COUNTER_COMPARE_B, EPWM_B_PFC_CMPB);

    // LLC controller
    /**/LLC_Control_Loop_U.LLC_Reset = Control_SM_test_Y.LLC_Reset;
    LLC_Control_Loop_U.PhyValueOut_LLC_mtcd = ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4;
    LLC_Control_Loop_U.PhyValueOut_PFC_mjhy = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1;
    //LLC_Control_Loop_U.PhyValueOut_PFC_mjhy.PFCVolt = 400;
    LLC_Control_Loop_U.flLLCVoltRef = Control_SM_test_Y.flLLCVoltRef;
    LLC_Control_Loop_U.flLLCCurrRef = Control_SM_test_Y.flLLCCurrRef;

    LLC_Control_Loop_step();

    if(Control_SM_test_Y.LLC_PWM_On == false || LLC_Control_Loop_Y.wCtrlOutTheta <= Control_SM_test_Y.wLLCMinDuty)
    {
        EPWM_setActionQualifierContSWForceAction(EPWM_A_LLC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
        EPWM_setActionQualifierContSWForceAction(EPWM_A_LLC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_OUTPUT_HIGH);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_LLC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_OUTPUT_LOW);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_LLC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_OUTPUT_HIGH);
    }
    else
    {
        EPWM_setActionQualifierContSWForceAction(EPWM_A_LLC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_A_LLC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_LLC, EPWM_AQ_OUTPUT_A, EPWM_AQ_SW_DISABLED);
        EPWM_setActionQualifierContSWForceAction(EPWM_B_LLC, EPWM_AQ_OUTPUT_B, EPWM_AQ_SW_DISABLED);
    }

    EPWM_setTimeBasePeriod(EPWM_A_LLC, LLC_Control_Loop_Y.wCtrlOutFreq);
    wduty_temp = LLC_Control_Loop_Y.wCtrlOutFreq*0.5;
    EPWM_setCounterCompareValue(EPWM_A_LLC, EPWM_COUNTER_COMPARE_A, wduty_temp);

    wdeadtime_temp = 0.0 * LLC_Control_Loop_Y.wCtrlOutFreq + 20.0;
    if (wdeadtime_temp < 15)
    {
        wdeadtime_temp = 15;
    }

    EPWM_setRisingEdgeDelayCount(EPWM_A_LLC, wdeadtime_temp);
    EPWM_setFallingEdgeDelayCount(EPWM_A_LLC, wdeadtime_temp);
    EPWM_setRisingEdgeDelayCount(EPWM_B_LLC, wdeadtime_temp);
    EPWM_setFallingEdgeDelayCount(EPWM_B_LLC, wdeadtime_temp);

    wphase_temp = (556.0 - (float)(LLC_Control_Loop_Y.wCtrlOutTheta));
    EPWM_setPhaseShift(EPWM_B_LLC, wphase_temp);
    EPWM_setGlobalLoadOneShotLatch(EPWM_A_LLC);

    //
    // Clear the interrupt flag
    //
    ADC_clearInterruptStatus(ADCA_module_BASE, ADC_INT_NUMBER1);

    //
    // Check if overflow has occurred
    //
    if(true == ADC_getInterruptOverflowStatus(ADCA_module_BASE, ADC_INT_NUMBER1))
    {
        ADC_clearInterruptOverflowStatus(ADCA_module_BASE, ADC_INT_NUMBER1);
        ADC_clearInterruptStatus(ADCA_module_BASE, ADC_INT_NUMBER1);
    }

    //
    // Acknowledge the interrupt
    //
    Interrupt_clearACKGroup(INT_ADCA_module_1_INTERRUPT_ACK_GROUP);

}

// CPU timer1 ISR
//#pragma CODE_SECTION(sTimer1Isr,".TI.ramfunc");
__interrupt void sTimer1Isr(void)
{
    static bool blProtection_CMPSS;

    /*blProtection_CMPSS = XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPH) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPL) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPH) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPL) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS3_CTRIPH) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPH) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPL) ||
                         XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS7_CTRIPH);*/

    if(Conf_item[26].disable != 84)//DSP_CMPSS_HV_OVP
    {
        blProtection_CMPSS |= XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPL);
    }
    else
    {

    }
    if(Conf_item[25].disable != 84)//DSP_CMPSS_HV_OCP;
    {
        blProtection_CMPSS |= XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPH);
    }
    else
    {

    }
    if(Conf_item[27].disable != 84)//DSP_CMPSS_PFC_MOS_OCP
    {
        blProtection_CMPSS |= (XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPH) ||
                              XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPL) ||
                              XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPH) ||
                              XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPL));
    }
    else
    {

    }
    if(Conf_item[28].disable != 84)//DSP_CMPSS_PFC_AUX_OVP
    {
        blProtection_CMPSS |= XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS3_CTRIPH);
    }
    else
    {

    }

    if(Conf_item[31].disable != 84)//DSP_CMPSS_PFC_OVP
    {
        blProtection_CMPSS |= XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS7_CTRIPH);
    }
    else
    {

    }

    dwTimerCount += 1;

    HouseKeeping_U.PhyValueOut_LLC_odl4 = ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4;
    HouseKeeping_U.PhyValueOut_PFC_lers = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1;
    HouseKeeping_U.PhyValueOut_Other_pji3 = ADC_ValueConvert_Y.PhyValueOut_Other_hqpw;
    HouseKeeping_U.wVCURequest = TI_App.can.inbox.MODE_CMD;
    HouseKeeping_U.flOBCVoltCmd = TI_App.can.inbox.HVDC_VOLT_CMD;
    HouseKeeping_U.flOBCCurrCmd = TI_App.can.inbox.HVDC_CURR_CMD;
    HouseKeeping_U.EVSE_Imax = 35;
    HouseKeeping_U.flDCCurr = 0.0;  //TI_App.can.inbox.APM_CURR_IN;
    HouseKeeping_U.blPowerDeratingEn = true;
    HouseKeeping_U.flCoolantTemp = 50;   //TI_App.can.inbox.COOLANT_TEMP;
    HouseKeeping_U.blSleepCommand = false;
    HouseKeeping_U.wPrechargeStatus = true;
    HouseKeeping_U.wDischargeStatus = true;
    HouseKeeping_U.blFault_CMPSS = blProtection_CMPSS;
    HouseKeeping_U.blHV_OVP_HW = XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT6);
    HouseKeeping_U.blHV_SCP_HW = XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT3);
    HouseKeeping_U.blLLC_OCP_HW = XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT2);
    HouseKeeping_U.blPFC_OVP_HW = XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT1);
    HouseKeeping_U.blCali_Conf_Err = DSP_CALI_ERR | DSP_CONF_ERR;
    HouseKeeping_U.blCAN_LOSS = false;

    /*rxMsgCount++;
    if(rxMsgCount==5)
    {
        Ifx_CanHandler_processInbox();
        rxMsgCount=0;
    }
    Ifx_CanHandler_processOutbox();

    //ProtectionTrigger();
    SMTrigger();
    PowerDeratingTrigger();*/

    Control_SM_test_U.blReqCtrlOn = HouseKeeping_Y.blReqCtrlOn;
    Control_SM_test_U.flLLCVoltCmd = HouseKeeping_Y.flLLCVoltCmd;
    Control_SM_test_U.flLLCCurrCmd = HouseKeeping_Y.flLLCCurrCmd;

}

__interrupt void canISR(void)
{
    uint32_t status;


    status = CAN_getInterruptCause(CANA_BASE);

    if(status == CAN_INT_INT0ID_STATUS)
    {
        // Read the controller status.  This will return a field of status
        // error bits that can indicate various errors.  Error processing
        // is not done in this example for simplicity.  Refer to the
        // API documentation for details about the error status bits.
        // The act of reading this status will clear the interrupt.
        status = CAN_getStatus(CANA_BASE);
        // Check to see if an error occurred.
        if(((status  & ~(CAN_STATUS_TXOK | CAN_STATUS_RXOK)) != 7) &&
           ((status  & ~(CAN_STATUS_TXOK | CAN_STATUS_RXOK)) != 0))
        {// Set a flag to indicate some errors may have occurred.
            CanErrorFlag = 1;
        }
    }

    else if(status == TX_MSG_OBJ_ID4)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID4);
        CanErrorFlag = 0;
    }

    else if(status == TX_MSG_OBJ_ID5)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID5);
        CanErrorFlag = 0;
    }

    else if(status == TX_MSG_OBJ_ID6)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID6);
        CanErrorFlag = 0;
    }
    else if(status == TX_MSG_OBJ_ID7)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID7);
        CanErrorFlag = 0;
    }
    else if(status == TX_MSG_OBJ_ID8)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID8);
        CanErrorFlag = 0;
    }
    else if(status == TX_MSG_OBJ_ID9)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID9);
        CanErrorFlag = 0;
    }
    else if(status == TX_MSG_OBJ_ID10)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID10);
        CanErrorFlag = 0;
    }
    else if(status == TX_MSG_OBJ_ID11)
    {

        // Getting to this point means that the TX interrupt occurred on
        // message object 1, and the message TX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, TX_MSG_OBJ_ID11);
        CanErrorFlag = 0;
    }
    else if(status == RX_MSG_OBJ_ID)
    {

        CAN_readMessage(CANA_BASE, RX_MSG_OBJ_ID, Can0Node0Rxmsgs);


        // Getting to this point means that the RX interrupt occurred on
        // message object 2, and the message RX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, RX_MSG_OBJ_ID);

        CanErrorFlag = 0;
    }
    else if(status == RX_MSG_OBJ_ID2 )
    {
        //Ifx_CanHandler_processInbox();
        CAN_readMessage(CANA_BASE, RX_MSG_OBJ_ID2, Can0Node1Rxmsgs);


        // Getting to this point means that the RX interrupt occurred on
        // message object 2, and the message RX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, RX_MSG_OBJ_ID2);

        CanErrorFlag = 0;
    }
    else if(status == RX_MSG_OBJ_ID3)
    {
        //Ifx_CanHandler_processInbox();
        CAN_readMessage(CANA_BASE, RX_MSG_OBJ_ID3, Can0Node2Rxmsgs);


        // Getting to this point means that the RX interrupt occurred on
        // message object 2, and the message RX is complete.  Clear the
        // message object interrupt.
        CAN_clearInterruptStatus(CANA_BASE, RX_MSG_OBJ_ID3);

        CanErrorFlag = 0;
    }
    else  {} // If something unexpected caused the interrupt, this would handle it.

    // Clear the global interrupt flag for the CAN interrupt line
    CAN_clearGlobalInterruptStatus(CANA_BASE, CAN_GLOBAL_INT_CANINT0);

    // Acknowledge this interrupt located in group 9
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP9);
}

void sTaskRun(void)
{
    uint16_t wtask_id;
    uint32_t dwtimercount;

    if (dwTimerCount != 0)
    {
        CPUTimer_stopTimer(CPUTIMER1_BASE);
        dwtimercount = dwTimerCount;
        CPUTimer_startTimer(CPUTIMER1_BASE);

        for (wtask_id = 0; wtask_id < TASK_MAX; wtask_id++)
        {
            if(parameter[wtask_id].enable == true)
            {
                if (dwtimercount >= parameter[wtask_id].remain)
                {
                    parameter[wtask_id].pf_func();
                    parameter[wtask_id].remain = 0;
                    if (parameter[wtask_id].one_shot == true)
                    {
                        parameter[wtask_id].enable = false;
                    }
                    else
                    {
                        parameter[wtask_id].remain = parameter[wtask_id].period;
                    }
                }
                else
                {
                    parameter[wtask_id].remain -= dwtimercount;
                }
            }

        }
        CPUTimer_stopTimer(CPUTIMER1_BASE);
        dwTimerCount = 0;
        CPUTimer_startTimer(CPUTIMER1_BASE);
    }
}

void CanVariableInit(void)
{
    memset(Can0Node0Rxmsgs,0,sizeof(Can0Node0Rxmsgs));
    memset(Can0Node1Rxmsgs,0,sizeof(Can0Node1Rxmsgs));
    memset(Can0Node2Rxmsgs,0,sizeof(Can0Node2Rxmsgs));
    memset(Can0Node3Rxmsgs,0,sizeof(Can0Node3Rxmsgs));
    memset(Can0Node4Rxmsgs,0,sizeof(Can0Node4Rxmsgs));
    //memset(Can0Node0Txmsgs,0,sizeof(Can0Node0Txmsgs));

}

void Ifx_CanHandler_processInbox(void)
{
    uint16_t temp;
    uint16_t u8_HiWord, u8_LowWord;
//    ID:0x101
            temp = Can0Node0Rxmsgs[0];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node0Rxmsgs[1];
            TI_App.can.inbox.EVSE_IMAX = (u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node0Rxmsgs[2];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node0Rxmsgs[3];
            TI_App.can.inbox.APM_CURR_IN = (u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node0Rxmsgs[4];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node0Rxmsgs[5];
            TI_App.can.inbox.COOLANT_TEMP = (u8_HiWord + u8_LowWord)/100.00;

//    ID:0x111
            temp = Can0Node1Rxmsgs[0];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node1Rxmsgs[1];
            TI_App.can.inbox.PFC_V_Kp = (u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node1Rxmsgs[2];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node1Rxmsgs[3];
            TI_App.can.inbox.PFC_V_Ki = (u8_HiWord + u8_LowWord)/10.0;

            temp = Can0Node1Rxmsgs[4];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node1Rxmsgs[5];
            TI_App.can.inbox.PFC_I_Kp =(u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node1Rxmsgs[6];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node1Rxmsgs[7];
            TI_App.can.inbox.PFC_I_Ki =(u8_HiWord + u8_LowWord)/100.00;

//    ID:0x112
            temp = Can0Node3Rxmsgs[0];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node3Rxmsgs[1];
            TI_App.can.inbox.Upper_Limit = u8_HiWord + u8_LowWord;

            temp = Can0Node3Rxmsgs[2];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node3Rxmsgs[3];
            TI_App.can.inbox.Lower_Limit = u8_HiWord + u8_LowWord;

            temp = Can0Node3Rxmsgs[4];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node3Rxmsgs[5];
            TI_App.can.inbox.Control_Gain =(u8_HiWord + u8_LowWord)/1000.000;

            temp = Can0Node3Rxmsgs[6];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node3Rxmsgs[7];
            TI_App.can.inbox.PFC_Io =(u8_HiWord + u8_LowWord)/100.00;
            if(TI_App.can.inbox.PFC_Io < 0.01)
               TI_App.can.inbox.PFC_Io = 0.01;
            else if(TI_App.can.inbox.PFC_Io > 16.5)
               TI_App.can.inbox.PFC_Io = 16.5;

//    ID:0x113
            temp = Can0Node4Rxmsgs[0];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node4Rxmsgs[1];
            TI_App.can.inbox.LLC_V_Kp = (u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node4Rxmsgs[2];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node4Rxmsgs[3];
            TI_App.can.inbox.LLC_V_Ki = (u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node4Rxmsgs[4];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node4Rxmsgs[5];
            TI_App.can.inbox.LLC_I_Kp =(u8_HiWord + u8_LowWord)/100.00;

            temp = Can0Node4Rxmsgs[6];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node4Rxmsgs[7];
            TI_App.can.inbox.LLC_I_Ki =(u8_HiWord + u8_LowWord)/100.00;

//    ID:0x100
            temp = Can0Node2Rxmsgs[0];
            TI_App.can.inbox.MODE_CMD = Can0Node2Rxmsgs[0];

            temp = Can0Node2Rxmsgs[1];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node2Rxmsgs[2];
            TI_App.can.inbox.HVDC_VOLT_CMD = (u8_HiWord + u8_LowWord)/100.00;

            //temp = Can0Node2Rxmsgs[3];
            //TI_App.can.inbox.HVDC_CURR_CMD = Can0Node2Rxmsgs[3]/10.0;

            temp = Can0Node2Rxmsgs[3];
            u8_HiWord = temp << 8;
            u8_LowWord = Can0Node2Rxmsgs[4];
            TI_App.can.inbox.HVDC_CURR_CMD = (u8_HiWord + u8_LowWord)/100.00;

}

void Ifx_CanHandler_processOutbox(void)
{
    static uint32_t CanTx_Index = 0;
    uint16_t Can0Node0Txmsgs[Can_DATA_LENGTH];
    uint16_t Buff;
    int16_t Buff2;

    switch(CanTx_Index)
    {
        case 0:     // ID: 0x110 : 8 DLC, OBC_STATE
            Can0Node0Txmsgs[0] = 0;

            TI_App.can.outbox.OBC_CAN_STATE = 0;
            Buff = TI_App.can.outbox.OBC_CAN_STATE;
            Can0Node0Txmsgs[1] = (uint8_t)(Buff << 7);//TI_App.can.outbox.OBC_CAN_STATE

            TI_App.can.outbox.CC_Command_FB = Control_SM_test_Y.flLLCCurrRef;
            Buff = (uint16_t)(100 * TI_App.can.outbox.CC_Command_FB);//TI_App.can.outbox.CC_Command_FB
            Can0Node0Txmsgs[2] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[3] = (uint8_t)Buff;

            TI_App.can.outbox.CV_Command_FB = Control_SM_test_Y.flLLCVoltRef;
            Buff = (uint16_t)(100 * TI_App.can.outbox.CV_Command_FB);//TI_App.can.outbox.CV_Command_FB
            Can0Node0Txmsgs[4] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[5] = (uint8_t)Buff;

            Can0Node0Txmsgs[6] = 0;
            Can0Node0Txmsgs[7] = 0;
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID4, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 1:     // ID : 0x114 : 8 DLC, PFC_DATA_INFO_6k6
            TI_App.can.outbox.BULK_VOLT = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.PFCVolt;
            Buff = (uint16_t)(10*TI_App.can.outbox.BULK_VOLT);//TI_App.can.outbox.BULK_VOLT
            Can0Node0Txmsgs[0] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[1] = (uint8_t)Buff;

            TI_App.can.outbox.PFC_A_CURR = HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswA_RMS;
            Buff = (uint16_t)(10 * TI_App.can.outbox.PFC_A_CURR);
            Can0Node0Txmsgs[2] = (uint8_t)(Buff); //TI_App.can.outbox.PFC_A_CURR

            TI_App.can.outbox.PFC_B_CURR = HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswB_RMS;
            Buff = (uint16_t)(10 * TI_App.can.outbox.PFC_B_CURR);
            Can0Node0Txmsgs[3] = (uint8_t)(Buff); //TI_App.can.outbox.PFC_B_CURR

            TI_App.can.outbox.PFC_C_CURR = HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswC_RMS;
            Buff = (uint16_t)(10 * TI_App.can.outbox.PFC_C_CURR);
            Can0Node0Txmsgs[4] = (uint8_t)(Buff); //TI_App.can.outbox.PFC_C_CURR

            TI_App.can.outbox.PFC_D_CURR = HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswD_RMS;
            Buff = (uint16_t)(10 * TI_App.can.outbox.PFC_D_CURR);
            Can0Node0Txmsgs[5] = (uint8_t)(Buff); //TI_App.can.outbox.PFC_D_CURR

            Can0Node0Txmsgs[6] = 0;
            Can0Node0Txmsgs[7] = 0;

            /*Buff = (uint16_t)(1 * offset[0]);
            Can0Node0Txmsgs[0] = (uint8_t)Buff;
            Can0Node0Txmsgs[1] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[1]);
            Can0Node0Txmsgs[2] = (uint8_t)Buff;
            Can0Node0Txmsgs[3] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[2]);
            Can0Node0Txmsgs[4] = (uint8_t)Buff;
            Can0Node0Txmsgs[5] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[3]);
            Can0Node0Txmsgs[6] = (uint8_t)Buff;
            Can0Node0Txmsgs[7] = (uint8_t)(Buff >> 8);*/
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID5, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 2:    // ID : 0x116 : 8 DLC, GRID_DATA_INFO_6K6
            TI_App.can.outbox.GRID_CURR = (HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswA_RMS + HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswB_RMS
                                          + HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswC_RMS + HouseKeeping_U.PhyValueOut_Other_pji3.PFCIswD_RMS)*Cali_item.GRID_CURR_ADC_Gain + Cali_item.GRID_CURR_ADC_Offset;
            Buff = (uint16_t)(100 * TI_App.can.outbox.GRID_CURR);//TI_App.can.outbox.GRID_CURR
            Can0Node0Txmsgs[0] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[1] = (uint8_t)Buff;

            TI_App.can.outbox.GRID_FREQ = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.GridVoltFreq;
            Buff = (uint16_t)(100 * TI_App.can.outbox.GRID_FREQ);//TI_App.can.outbox.GRID_FREQ
            Can0Node0Txmsgs[2] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[3] = (uint8_t)Buff;

            TI_App.can.outbox.GRID_VOLT = ADC_ValueConvert_Y.PhyValueOut_PFC_peb1.GridVoltRms;
            Buff = (int16_t)(10 * TI_App.can.outbox.GRID_VOLT);//TI_App.can.outbox.GRID_VOLT
            Can0Node0Txmsgs[4] = (int8_t)(Buff >> 8);
            Can0Node0Txmsgs[5] = (int8_t)Buff;

            TI_App.can.outbox.PFC_AUX_VOLT = HouseKeeping_U.PhyValueOut_Other_pji3.PFCAux;
            Buff = (int16_t)(10 * TI_App.can.outbox.PFC_AUX_VOLT);////TI_App.can.outbox.PFC_AUX_VOLT
            Can0Node0Txmsgs[6] = (uint8_t)(Buff); //TI_App.can.outbox.PFC_AUX_VOLT

            Can0Node0Txmsgs[7] = 0;

            /*Buff = (uint16_t)(1 * offset[4]);
            Can0Node0Txmsgs[0] = (uint8_t)Buff;
            Can0Node0Txmsgs[1] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[5]);
            Can0Node0Txmsgs[2] = (uint8_t)Buff;
            Can0Node0Txmsgs[3] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[6]);
            Can0Node0Txmsgs[4] = (uint8_t)Buff;
            Can0Node0Txmsgs[5] = (uint8_t)(Buff >> 8);
            Buff = (uint16_t)(1 * offset[7]);
            Can0Node0Txmsgs[6] = (uint8_t)Buff;
            Can0Node0Txmsgs[7] = (uint8_t)(Buff >> 8);*/
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID6, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 3:     // ID : 0x11A : 8 DLC, HVDC_CTRL_INFO_6K6
            TI_App.can.outbox.HVDC_CTRL_FREQ = LLC_Control_Loop_Y.wCtrlOutFreq;
            Buff = (uint16_t)(100 * (1/(TI_App.can.outbox.HVDC_CTRL_FREQ*0.00000001))*0.001);//TI_App.can.outbox.HVDC_CTRL_FREQ
            Can0Node0Txmsgs[0] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[1] = (uint8_t)Buff;

            TI_App.can.outbox.HVDC_CTRL_THETA = LLC_Control_Loop_Y.wCtrlOutFreq;
            Buff = (uint16_t)(100 * ((float)wphase_temp / TI_App.can.outbox.HVDC_CTRL_THETA) * 360.0);//TI_App.can.outbox.HVDC_CTRL_THETA
            Can0Node0Txmsgs[2] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[3] = (uint8_t)Buff;

            TI_App.can.outbox.HVDC_CURR_REF = Control_SM_test_U.flLLCCurrCmd;
            Buff = (uint16_t)(100 * TI_App.can.outbox.HVDC_CURR_REF);
            Can0Node0Txmsgs[4] = (uint8_t)(Buff >> 8); //TI_App.can.outbox.HVDC_CURR_REF
            Can0Node0Txmsgs[5] = (uint8_t)Buff;

            TI_App.can.outbox.HVDC_VOLT_REF = Control_SM_test_U.flLLCVoltCmd;
            Buff = (uint16_t)(100 * TI_App.can.outbox.HVDC_VOLT_REF);//TI_App.can.outbox.HVDC_VOLT_REF
            Can0Node0Txmsgs[6] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[7] = (uint8_t)Buff;
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID7, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 4:     // ID : 0x11C : 8 DLC, HVDC_DATA_INFO_6K6
            //TI_App.can.outbox.HVDC_CURR = ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4.LLCCurr;
            TI_App.can.outbox.HVDC_CURR = (0.9 * TI_App.can.outbox.HVDC_CURR) + (0.1 * ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4.LLCCurr);
            Buff = 100 * TI_App.can.outbox.HVDC_CURR; //TI_App.can.outbox.HVDC_CURR
            Can0Node0Txmsgs[0] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[1] = (uint8_t)(Buff);

            //TI_App.can.outbox.HVDC_VOLT = ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4.LLCVolt;
            TI_App.can.outbox.HVDC_VOLT = (0.9 * TI_App.can.outbox.HVDC_VOLT) + (0.1 * ADC_ValueConvert_Y.PhyValueOut_LLC_dvi4.LLCVolt);
            Buff = (uint16_t)(100 * TI_App.can.outbox.HVDC_VOLT);//TI_App.can.outbox.HVDC_VOLT
            Can0Node0Txmsgs[2] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[3] = (uint8_t)Buff;

            Can0Node0Txmsgs[4] = 0;
            Can0Node0Txmsgs[5] = 0;
            Can0Node0Txmsgs[6] = 0;
            Can0Node0Txmsgs[7] = 0;
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID8, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 5:     // ID : 0x11E : 8 DLC, OBC_FAULT_INFO_6K6
            TI_App.can.outbox.fault1.HVDC_SCP_HW = HouseKeeping_Y.OBCProtectionMsg_nja1.HV_SCP_HW.Temp_Error_Up;
            TI_App.can.outbox.fault1.HVDC_OCP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.LLCCurr.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_AUX_UVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCAux.Temp_Error_Low;
            TI_App.can.outbox.fault1.PFC_AUX_OVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCAux.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_UVP_SW = HouseKeeping_Y.OBCProtectionMsg_nja1.PFCVolt.Temp_Error_Low;
            TI_App.can.outbox.fault1.PFC_OVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCVolt.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_OVP_HW = HouseKeeping_Y.OBCProtectionMsg_nja1.PFC_OVP_HW.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_D_OCP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCIswD.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_C_OCP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCIswC.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_B_OCP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCIswB.Temp_Error_Up;
            TI_App.can.outbox.fault1.PFC_A_OCP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.PFCIswA.Temp_Error_Up;
            TI_App.can.outbox.fault1.GRID_RMS_UVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.GridVoltRms.Temp_Error_Low;
            TI_App.can.outbox.fault1.GRID_RMS_OVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.GridVoltRms.Temp_Error_Up;
            TI_App.can.outbox.fault1.GRID_OVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.GridVolt.Temp_Error_Up;
            TI_App.can.outbox.fault1.GRID_UFP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.GridVoltFreq.Temp_Error_Low;
            TI_App.can.outbox.fault1.GRID_OFP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.GridVoltFreq.Temp_Error_Up;

            memcpy(&Buff, &TI_App.can.outbox.fault1, sizeof(TI_App.can.outbox.fault1));
            Can0Node0Txmsgs[0] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[1] = (uint8_t)Buff;


            TI_App.can.outbox.fault2.DIAG_HV_SC_FAIL =Diagnosis_HV_SC_ERROR;
            TI_App.can.outbox.fault2.DIAG_HV_OC_FAIL =Diagnosis_HV_OC_ERROR;
            TI_App.can.outbox.fault2.DIAG_HV_OV_FAIL =Diagnosis_HV_OV_ERROR;
            TI_App.can.outbox.fault2.HVDC_OCP_HW = HouseKeeping_Y.OBCProtectionMsg_nja1.LLC_OCP_HW.Temp_Error_Up;
            TI_App.can.outbox.fault2.LOST_OF_CAN=0;
            TI_App.can.outbox.fault2.DSP_CONF_EMPTY=DSP_CONF_EMPTY;
            TI_App.can.outbox.fault2.DSP_CONF_ERR=DSP_CONF_ERR;
            TI_App.can.outbox.fault2.DSP_CALI_EMPTY=DSP_CALI_EMPTY;
            TI_App.can.outbox.fault2.DSP_CALI_ERR=DSP_CALI_ERR;
            TI_App.can.outbox.fault2.DSP_SELF_TEST_ERR=0;
            TI_App.can.outbox.fault2.OBC_OTP_3_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.OBCTemp3.Temp_Error_Up;
            TI_App.can.outbox.fault2.NTC_LLC_MOS_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.OBCTemp1.Temp_Error_Up;
            TI_App.can.outbox.fault2.NTC_PFC_MOS_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.OBCTemp2.Temp_Error_Up;
            TI_App.can.outbox.fault2.HVDC_UVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.LLCVolt.Temp_Error_Low;
            TI_App.can.outbox.fault2.HVDC_OVP_SW= HouseKeeping_Y.OBCProtectionMsg_nja1.LLCVolt.Temp_Error_Up;
            TI_App.can.outbox.fault2.HVDC_OVP_HW = HouseKeeping_Y.OBCProtectionMsg_nja1.HV_OVP_HW.Temp_Error_Up;

            memcpy(&Buff, &TI_App.can.outbox.fault2, sizeof(TI_App.can.outbox.fault2));
            Can0Node0Txmsgs[2] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[3] = (uint8_t)Buff;

            TI_App.can.outbox.fault3.PFC_OVP_CMPSS7 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS7_CTRIPH);
            TI_App.can.outbox.fault3.PFC_D_OCP_CMPSS6 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPL);
            TI_App.can.outbox.fault3.PFC_A_OCP_CMPSS6 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS6_CTRIPH);
            TI_App.can.outbox.fault3.NTC_LLC_MOS_CMPSS5 =false;//XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS5_CTRIPH);
            TI_App.can.outbox.fault3.NTC_PFC_MOS_CMPSS4 =false;//XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS4_CTRIPH);
            TI_App.can.outbox.fault3.PFC_AUX_OVP_CMPSS3 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS3_CTRIPH);
            TI_App.can.outbox.fault3.PFC_C_OCP_CMPSS2 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPL);
            TI_App.can.outbox.fault3.PFC_B_OCP_CMPSS2 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS2_CTRIPH);
            TI_App.can.outbox.fault3.HVDC_OVP_CMPSS1 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPL);
            TI_App.can.outbox.fault3.HVDC_OCP_CMPSS1 =XBAR_getInputFlagStatus(XBAR_INPUT_FLG_CMPSS1_CTRIPH);
            TI_App.can.outbox.fault3.DIAG_PFC_OV_FAIL =Diagnosis_PFC_OV_ERROR;


            memcpy(&Buff, &TI_App.can.outbox.fault3, sizeof(TI_App.can.outbox.fault3));
            Can0Node0Txmsgs[4] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[5] = (uint8_t)Buff;

            TI_App.can.outbox.fault4.STATUS = HouseKeeping_Y.wOBCState;
            TI_App.can.outbox.fault4.REV4 = 0;


            memcpy(&Buff, &TI_App.can.outbox.fault4, sizeof(TI_App.can.outbox.fault4));
            Can0Node0Txmsgs[6] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[7] = (uint8_t)Buff;
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID9, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 6:     // ID : 0x120 : 8 DLC, OBC_TEMP_6K6
			TI_App.can.outbox.OBC_TEMP_1 = HouseKeeping_U.PhyValueOut_Other_pji3.OBCTemp1;
            Buff2 = (int16_t)(10 * TI_App.can.outbox.OBC_TEMP_1);//TI_App.can.outbox.OBC_TEMP_1
            Can0Node0Txmsgs[0] = (int8_t)(Buff2 >> 8);
            Can0Node0Txmsgs[1] = (int8_t)Buff2;

			TI_App.can.outbox.OBC_TEMP_2 = HouseKeeping_U.PhyValueOut_Other_pji3.OBCTemp2;
            Buff2 = (int16_t)(10 * TI_App.can.outbox.OBC_TEMP_2);//TI_App.can.outbox.OBC_TEMP_2
            Can0Node0Txmsgs[2] = (int8_t)(Buff2 >> 8);
            Can0Node0Txmsgs[3] = (int8_t)Buff2;

			TI_App.can.outbox.OBC_TEMP_3 = HouseKeeping_U.PhyValueOut_Other_pji3.OBCTemp3;
            Buff2 = (int16_t)(10 * TI_App.can.outbox.OBC_TEMP_3);//TI_App.can.outbox.OBC_TEMP_3
            Can0Node0Txmsgs[4] = (int8_t)(Buff2 >> 8);
            Can0Node0Txmsgs[5] = (int8_t)Buff2;

            Can0Node0Txmsgs[6] = 0;
            Can0Node0Txmsgs[7] = 0;
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID10, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;

        case 7:        // ID : 0x602 : 8 DLC, DSP_VERSION
			TI_App.can.outbox.DSP_APP_VER_MAJOR = 0;
			Buff = TI_App.can.outbox.DSP_APP_VER_MAJOR;
            Can0Node0Txmsgs[0] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_VER_MAJOR

			TI_App.can.outbox.DSP_APP_VER_MINOR = 1;
			Buff = TI_App.can.outbox.DSP_APP_VER_MINOR;
            Can0Node0Txmsgs[1] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_VER_MINOR

			TI_App.can.outbox.DSP_APP_VER_DEBUG = 0;
			Buff = TI_App.can.outbox.DSP_APP_VER_DEBUG;
            Can0Node0Txmsgs[2] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_VER_DEBUG

			TI_App.can.outbox.DSP_APP_BUILD_HOST = 1;
			Buff = TI_App.can.outbox.DSP_APP_BUILD_HOST;
            Can0Node0Txmsgs[3] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_BUILD_HOST

			TI_App.can.outbox.DSP_APP_BUILD_YEAR = 2022;
            Buff = (uint16_t)(TI_App.can.outbox.DSP_APP_BUILD_YEAR);//TI_App.can.outbox.DSP_APP_BUILD_YEAR
            Can0Node0Txmsgs[4] = (uint8_t)(Buff >> 8);
            Can0Node0Txmsgs[5] = (uint8_t)Buff;

			TI_App.can.outbox.DSP_APP_BUILD_MONTH = 6;
			Buff = TI_App.can.outbox.DSP_APP_BUILD_MONTH;
            Can0Node0Txmsgs[6] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_BUILD_MONTH

			TI_App.can.outbox.DSP_APP_BUILD_DAY = 29;
			Buff = TI_App.can.outbox.DSP_APP_BUILD_DAY;
            Can0Node0Txmsgs[7] = (uint8_t)(Buff); //TI_App.can.outbox.DSP_APP_BUILD_DAY
            CAN_sendMessage(CANA_BASE, TX_MSG_OBJ_ID11, Can_DATA_LENGTH, Can0Node0Txmsgs);
            break;
        default:
            break;
    }
    CanTx_Index++;

    if(CanTx_Index >= 10)
        CanTx_Index = 0;

}

void sDiagnosis_HWProtection(void)
{
    bool blDiagnostic_HW;

    if (HouseKeeping_Y.blReqDiagnosis == 1)
    {
        GPIO_writePin(15,1);
        DEVICE_DELAY_US(10000);

        if (Conf_item[21].disable == 84)
        {
            Diagnosis_HV_SC_ERROR = false;
        }
        else
        {
            Diagnosis_HV_OV_ERROR = !(XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT6));
        }
        if (Conf_item[22].disable == 84)
        {
            Diagnosis_HV_SC_ERROR = false;
        }
        else
        {
            Diagnosis_HV_OC_ERROR = !(XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT2));
        }
        if (Conf_item[23].disable == 84)
        {
            Diagnosis_HV_SC_ERROR = false;
        }
        else
        {
            Diagnosis_HV_SC_ERROR = !(XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT3));
        }
        if (Conf_item[24].disable == 84)
        {
            Diagnosis_HV_SC_ERROR = false;
        }
        else
        {
            Diagnosis_PFC_OV_ERROR = !(XBAR_getInputFlagStatus(XBAR_INPUT_FLG_INPUT1));
        }


        blDiagnostic_HW = Diagnosis_HV_SC_ERROR || Diagnosis_HV_OC_ERROR || Diagnosis_HV_OV_ERROR || Diagnosis_PFC_OV_ERROR;
        //blDiagnostic_HW = Diagnosis_HV_SC_ERROR || Diagnosis_HV_OV_ERROR || Diagnosis_PFC_OV_ERROR;

        if (blDiagnostic_HW ==false)
        {
            Diagnosis_HWProtection_OK = true;
            GPIO_writePin(15,0);
            GPIO_clearPortPins(GPIO_PORT_A, 15);
            GPIO_togglePin(5);
            DEVICE_DELAY_US(10000);
            GPIO_togglePin(5);
            XBAR_clearOutputLatch(XBAR_OUTPUT3);
            XBAR_clearOutputLatch(XBAR_OUTPUT4);
            EPWM_clearTripZoneFlag(EPWM_A_LLC, EPWM_TZ_FLAG_DCAEVT1 | EPWM_TZ_FLAG_OST);
            EPWM_clearTripZoneFlag(EPWM_B_LLC, EPWM_TZ_FLAG_DCAEVT1 | EPWM_TZ_FLAG_OST);
            EPWM_clearTripZoneFlag(EPWM_A_PFC, EPWM_TZ_FLAG_DCAEVT2 | EPWM_TZ_FLAG_CBC);
            EPWM_clearTripZoneFlag(EPWM_B_PFC, EPWM_TZ_FLAG_DCAEVT2 | EPWM_TZ_FLAG_CBC);
            XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT1);
            XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT2);
            XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT3);
            XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT6);
        }
        else
        {
            Diagnosis_HWProtection_OK = false;
        }

        if (Diagnosis_HWProtection_OK == false)
         {
             HouseKeeping_U.wDiagnosisStatus = 2;
         }
        else
        {
            HouseKeeping_U.wDiagnosisStatus = 1;
        }
    }
}

void sInputXBAR_Clear(void)
{
    if (GPIO_readPin(9) == 0)
    {
        XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT1);
    }
    if (GPIO_readPin(25) == 0)
    {
        XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT2);
    }
    if (GPIO_readPin(39) == 0)
    {
        XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT3);
    }
    if (GPIO_readPin(59) == 0)
    {
        XBAR_clearInputFlag(XBAR_INPUT_FLG_INPUT6);
    }

}

void sProtection_Switch(void)
{
    static uint16_t counter;

    if (HouseKeeping_Y.blProtectionSWEnable == true)
    {
        counter++;
        if (counter >=50)
        {
            counter = 50;

            if (Conf_item[3].disable == 84)
            {
                AnalogParameter_Protection[1].TripEnable_Low = 84;
            }
            else
            {
                AnalogParameter_Protection[1].TripEnable_Low = 1;
            }
            if (Conf_item[15].disable == 1)
            {
                AnalogParameter_Protection[0].TripEnable_Low = 84;
            }
            else
            {
                AnalogParameter_Protection[0].TripEnable_Low = 1;
            }
        }
        if (Conf_item[8].disable == 84)
        {
            AnalogParameter_Protection[4].TripEnable_Low = 84;
        }
        else
        {
            AnalogParameter_Protection[4].TripEnable_Low = 1;
        }
    }
    else
    {
        AnalogParameter_Protection[0].TripEnable_Low = 84;
        AnalogParameter_Protection[1].TripEnable_Low = 84;
        AnalogParameter_Protection[4].TripEnable_Low = 84;
        counter = 0;
    }

}

/**
 * \brief   check the CRC of the calibrtion data
 *
 * \param [in]  eType   enum of \nvm_data_type_t
 *
 * \retval  0   PASS
 * \retval  1   empty if tag is 0xFFFF
 * \retval  2   tag error
 * \retval  3   data type or length error
 * \retval  4   CRC check fail
 */
uint8_T sNvmDataVerify(nvm_data_type_t eType)
{
    uint8_T bRet = 0;
    uint16_T *pwWord;
    uint8_T dwAddr;
    int16_t *psData;
    uint16_T wTag;
    uint8_T bType;
    uint16_T wBlockSize, wHeadSize, wDataSize;
    bool blOdd;

    if (eType == NVM_DATA_TYPE_CALI)            // check type paramter
    {
        dwAddr = CALI_DATA_ADDR;
    }
    else if (eType == NVM_DATA_TYPE_CONF)
    {
        dwAddr = CONF_DATA_ADDR;
    }
    else
    {
        bRet = 3U;
    }

    if (bRet == 0)
    {
        pwWord = (uint16_T*)dwAddr;
        wTag = *pwWord;

        if (wTag == 0xFFFFU)                    // check tag of the header
        {
            bRet = 1U;
        }
        else if (wTag != 0x55AAU)
        {
            bRet = 2U;
        }
        else
        {
            bRet = 0;
        }
    }

    if (bRet == 0)
    {
        psData = (int16_T*)(dwAddr + 2U);
        bType = __byte(psData, 1);

        if (bType != (uint8_T)eType)                 // check data type
        {
            bRet = 3U;
        }
    }

    if (bRet == 0)
    {
        wHeadSize = 16U;
        pwWord = (uint16_T*)(dwAddr + 1U);
        wBlockSize = *pwWord;                   // get the block size (bytes)
        sSwapWord(&wBlockSize);

        if ((wBlockSize == 0)                   // check data length
            && (wBlockSize >= 2048U))
        {
            bRet = 3U;
        }
        else
        {
            wDataSize = wBlockSize - wHeadSize; // convert size to words

            if ((wDataSize % 2U) == 0)
            {
                wDataSize /= 2U;
                blOdd = false;
            }
            else
            {
                wDataSize = (wDataSize / 2U) + 1U;
                blOdd = true;
            }
        }
    }

    if (bRet == 0)
    {
        int16_t sData;
        uint16_T i;
        uint8_T bByte;
        uint16_T wData;
        uint16_T wCrc;

        psData = (int16_T*)dwAddr;

        crc16_init();

        for (i = 0; i < 7U; i++)                // compute the CRC of head part
        {
            sData = *psData;
            bByte = __byte(&sData,1U);          // MSB first
            crc16_update(bByte);
            bByte = __byte(&sData,0);           // LSB
            crc16_update(bByte);

            psData++;
        }

        psData = (int16_T*)(dwAddr + 8U);

        for (i = 0; i < wDataSize; i++)         // compute the CRC of remain data
        {
            sData = *psData;
            bByte = __byte(&sData,1U);          // MSB first
            crc16_update(bByte);

            if ((i == (wDataSize-1))
                && (blOdd == true))
            {
                break;                          // skip last byte if size is odd
            }

            bByte = __byte(&sData,0);           // LSB
            crc16_update(bByte);

            psData++;
        }

        crc16_result_get(&wData);               // get the CRC result
        sSwapWord(&wData);

        wCrc = *((uint16_T*)(dwAddr + 7U));

        if (wData != wCrc)                      // verify the CRC
        {
            bRet = 4U;
        }
    }

    return bRet;
}


void CaliDataUpdate(void)
{
    AnalogParameter_Conversion[1].CaliGain = Cali_item.HVDC_VOLT_OBC_ADC_Gain;
    AnalogParameter_Conversion[1].CaliOffset = Cali_item.HVDC_VOLT_OBC_ADC_Offset;
    AnalogParameter_Conversion[2].CaliGain = Cali_item.HVDC_CURR_OBC_ADC_Gain;
    AnalogParameter_Conversion[2].CaliOffset = Cali_item.HVDC_CURR_OBC_ADC_Offset;
    AnalogParameter_Conversion[4].CaliGain = Cali_item.GRID_VOLT_ADC_Gain;
    AnalogParameter_Conversion[4].CaliOffset = Cali_item.GRID_VOLT_ADC_Offset;
    AnalogParameter_Conversion[0].CaliGain = Cali_item.BULK_VOLT_ADC_Gain;
    AnalogParameter_Conversion[0].CaliOffset = Cali_item.BULK_VOLT_ADC_Offset;

}

void ConfDataUpdate(void)
{
    /***************************PFCVoltParameter(OVP)******************************/
    AnalogParameter_Protection[0].TripEnable_Up = Conf_item[14].disable;
    AnalogParameter_Protection[0].TripPoint_Up = Conf_item[14].triggerPoint;
    AnalogParameter_Protection[0].TripTime_Up = Conf_item[14].responseTime*0.001;
    AnalogParameter_Protection[0].RecoverPoint_Up = Conf_item[14].recoveryPoint;
    AnalogParameter_Protection[0].RecoverTime_Up = Conf_item[14].recoveryTime*0.001;
    AnalogParameter_Protection[0].RetryEnable_Up = Conf_item[14].retry;
    AnalogParameter_Protection[0].RetryLimit_Up = Conf_item[14].retryLimit;
    AnalogParameter_Protection[0].RetryTime_Up = Conf_item[14].retryInterval*0.001;
    /***************************PFCVoltParameter(UVP)******************************/
    AnalogParameter_Protection[0].TripEnable_Low = Conf_item[15].disable;
    AnalogParameter_Protection[0].TripPoint_Low = Conf_item[15].triggerPoint;
    AnalogParameter_Protection[0].TripTime_Low = Conf_item[15].responseTime*0.001;
    AnalogParameter_Protection[0].RecoverPoint_Low = Conf_item[15].recoveryPoint;
    AnalogParameter_Protection[0].RecoverTime_Low = Conf_item[15].recoveryTime*0.001;
    AnalogParameter_Protection[0].RetryEnable_Low = Conf_item[15].retry;
    AnalogParameter_Protection[0].RetryLimit_Low = Conf_item[15].retryLimit;
    AnalogParameter_Protection[0].RetryTime_Low = Conf_item[15].retryInterval*0.001;
    /***************************LLCVoltParameter(OVP)******************************/
    AnalogParameter_Protection[1].TripEnable_Up = Conf_item[1].disable;
    AnalogParameter_Protection[1].TripPoint_Up = Conf_item[1].triggerPoint;
    AnalogParameter_Protection[1].TripTime_Up = Conf_item[1].responseTime*0.001;
    AnalogParameter_Protection[1].RecoverPoint_Up = Conf_item[1].recoveryPoint;
    AnalogParameter_Protection[1].RecoverTime_Up = Conf_item[1].recoveryTime*0.001;
    AnalogParameter_Protection[1].RetryEnable_Up = Conf_item[1].retry;
    AnalogParameter_Protection[1].RetryLimit_Up = Conf_item[1].retryLimit;
    AnalogParameter_Protection[1].RetryTime_Up = Conf_item[1].retryInterval*0.001;
    /***************************LLCVoltParameter(UVP)******************************/
    AnalogParameter_Protection[1].TripEnable_Low = Conf_item[3].disable;
    AnalogParameter_Protection[1].TripPoint_Low = Conf_item[3].triggerPoint;
    AnalogParameter_Protection[1].TripTime_Low = Conf_item[3].responseTime*0.001;
    AnalogParameter_Protection[1].RecoverPoint_Low = Conf_item[3].recoveryPoint;
    AnalogParameter_Protection[1].RecoverTime_Low = Conf_item[3].recoveryTime*0.001;
    AnalogParameter_Protection[1].RetryEnable_Low = Conf_item[3].retry;
    AnalogParameter_Protection[1].RetryLimit_Low = Conf_item[3].retryLimit;
    AnalogParameter_Protection[1].RetryTime_Low = Conf_item[3].retryInterval*0.001;
    /***************************LLCCurrParameter(OCP)******************************/
    AnalogParameter_Protection[2].TripEnable_Up = Conf_item[4].disable;
    AnalogParameter_Protection[2].TripPoint_Up = Conf_item[4].triggerPoint;
    AnalogParameter_Protection[2].TripTime_Up = Conf_item[4].responseTime*0.001;
    AnalogParameter_Protection[2].RecoverPoint_Up = Conf_item[4].recoveryPoint;
    AnalogParameter_Protection[2].RecoverTime_Up = Conf_item[4].recoveryTime*0.001;
    AnalogParameter_Protection[2].RetryEnable_Up = Conf_item[4].retry;
    AnalogParameter_Protection[2].RetryLimit_Up = Conf_item[4].retryLimit;
    AnalogParameter_Protection[2].RetryTime_Up = Conf_item[4].retryInterval*0.001;
    /***************************GridVoltParameter(OVP)*****************************/
    AnalogParameter_Protection[3].TripEnable_Up = Conf_item[6].disable;
    AnalogParameter_Protection[3].TripPoint_Up = Conf_item[6].triggerPoint;
    AnalogParameter_Protection[3].TripTime_Up = Conf_item[6].responseTime*0.001;
    AnalogParameter_Protection[3].RecoverPoint_Up = Conf_item[6].recoveryPoint;
    AnalogParameter_Protection[3].RecoverTime_Up = Conf_item[6].recoveryTime*0.001;
    AnalogParameter_Protection[3].RetryEnable_Up = Conf_item[6].retry;
    AnalogParameter_Protection[3].RetryLimit_Up = Conf_item[6].retryLimit;
    AnalogParameter_Protection[3].RetryTime_Up = Conf_item[6].retryInterval*0.001;
    /***************************GridVoltRmsParameter(OVP)**************************/
    AnalogParameter_Protection[4].TripEnable_Up = Conf_item[7].disable;
    AnalogParameter_Protection[4].TripPoint_Up = Conf_item[7].triggerPoint;
    AnalogParameter_Protection[4].TripTime_Up = Conf_item[7].responseTime*0.001;
    AnalogParameter_Protection[4].RecoverPoint_Up = Conf_item[7].recoveryPoint;
    AnalogParameter_Protection[4].RecoverTime_Up = Conf_item[7].recoveryTime*0.001;
    AnalogParameter_Protection[4].RetryEnable_Up = Conf_item[7].retry;
    AnalogParameter_Protection[4].RetryLimit_Up = Conf_item[7].retryLimit;
    AnalogParameter_Protection[4].RetryTime_Up = Conf_item[7].retryInterval*0.001;
    /***************************GridVoltRmsParameter(UVP)**************************/
    AnalogParameter_Protection[4].TripEnable_Low = Conf_item[8].disable;
    AnalogParameter_Protection[4].TripPoint_Low = Conf_item[8].triggerPoint;
    AnalogParameter_Protection[4].TripTime_Low = Conf_item[8].responseTime*0.001;
    AnalogParameter_Protection[4].RecoverPoint_Low = Conf_item[8].recoveryPoint;
    AnalogParameter_Protection[4].RecoverTime_Low = Conf_item[8].recoveryTime*0.001;
    AnalogParameter_Protection[4].RetryEnable_Low = Conf_item[8].retry;
    AnalogParameter_Protection[4].RetryLimit_Low = Conf_item[8].retryLimit;
    AnalogParameter_Protection[4].RetryTime_Low = Conf_item[8].retryInterval*0.001;
    /****************************GridFreqParameter(UFP)***************************/
    AnalogParameter_Protection[5].TripEnable_Low = Conf_item[9].disable;
    AnalogParameter_Protection[5].TripPoint_Low = Conf_item[9].triggerPoint;
    AnalogParameter_Protection[5].TripTime_Low = Conf_item[9].responseTime*0.001;
    AnalogParameter_Protection[5].RecoverPoint_Low = Conf_item[9].recoveryPoint;
    AnalogParameter_Protection[5].RecoverTime_Low = Conf_item[9].recoveryTime*0.001;
    AnalogParameter_Protection[5].RetryEnable_Low = Conf_item[9].retry;
    AnalogParameter_Protection[5].RetryLimit_Low = Conf_item[9].retryLimit;
    AnalogParameter_Protection[5].RetryTime_Low = Conf_item[9].retryInterval*0.001;
    /****************************GridFreqParameter(OFP)***************************/
    AnalogParameter_Protection[5].TripEnable_Up = Conf_item[10].disable;
    AnalogParameter_Protection[5].TripPoint_Up = Conf_item[10].triggerPoint;
    AnalogParameter_Protection[5].TripTime_Up = Conf_item[10].responseTime*0.001;
    AnalogParameter_Protection[5].RecoverPoint_Up = Conf_item[10].recoveryPoint;
    AnalogParameter_Protection[5].RecoverTime_Up = Conf_item[10].recoveryTime*0.001;
    AnalogParameter_Protection[5].RetryEnable_Up = Conf_item[10].retry;
    AnalogParameter_Protection[5].RetryLimit_Up = Conf_item[10].retryLimit;
    AnalogParameter_Protection[5].RetryTime_Up = Conf_item[10].retryInterval*0.001;
    /*****************************PFCAuxParameter(UVP)***************************/
    AnalogParameter_Protection[6].TripEnable_Low = Conf_item[16].disable;
    AnalogParameter_Protection[6].TripPoint_Low = Conf_item[16].triggerPoint;
    AnalogParameter_Protection[6].TripTime_Low = Conf_item[16].responseTime*0.001;
    AnalogParameter_Protection[6].RecoverPoint_Low = Conf_item[16].recoveryPoint;
    AnalogParameter_Protection[6].RecoverTime_Low = Conf_item[16].recoveryTime*0.001;
    AnalogParameter_Protection[6].RetryEnable_Low = Conf_item[16].retry;
    AnalogParameter_Protection[6].RetryLimit_Low = Conf_item[16].retryLimit;
    AnalogParameter_Protection[6].RetryTime_Low = Conf_item[16].retryInterval*0.001;
    /*****************************PFCAuxParameter(OVP)***************************/
    AnalogParameter_Protection[6].TripEnable_Up = Conf_item[17].disable;
    AnalogParameter_Protection[6].TripPoint_Up = Conf_item[17].triggerPoint;
    AnalogParameter_Protection[6].TripTime_Up = Conf_item[17].responseTime*0.001;
    AnalogParameter_Protection[6].RecoverPoint_Up = Conf_item[17].recoveryPoint;
    AnalogParameter_Protection[6].RecoverTime_Up = Conf_item[17].recoveryTime*0.001;
    AnalogParameter_Protection[6].RetryEnable_Up = Conf_item[17].retry;
    AnalogParameter_Protection[6].RetryLimit_Up = Conf_item[17].retryLimit;
    AnalogParameter_Protection[6].RetryTime_Up = Conf_item[17].retryInterval*0.001;
    /****************************OBCTemp1Parameter(LLC)***************************/
    AnalogParameter_Protection[7].TripEnable_Up = Conf_item[19].disable;
    AnalogParameter_Protection[7].TripPoint_Up = Conf_item[19].triggerPoint;
    AnalogParameter_Protection[7].TripTime_Up = Conf_item[19].responseTime*0.001;
    AnalogParameter_Protection[7].RecoverPoint_Up = Conf_item[19].recoveryPoint;
    AnalogParameter_Protection[7].RecoverTime_Up = Conf_item[19].recoveryTime*0.001;
    AnalogParameter_Protection[7].RetryEnable_Up = Conf_item[19].retry;
    AnalogParameter_Protection[7].RetryLimit_Up = Conf_item[19].retryLimit;
    AnalogParameter_Protection[7].RetryTime_Up = Conf_item[19].retryInterval*0.001;
    /****************************OBCTemp2Parameter(PFC)***************************/
    AnalogParameter_Protection[8].TripEnable_Up = Conf_item[20].disable;
    AnalogParameter_Protection[8].TripPoint_Up = Conf_item[20].triggerPoint;
    AnalogParameter_Protection[8].TripTime_Up = Conf_item[20].responseTime*0.001;
    AnalogParameter_Protection[8].RecoverPoint_Up = Conf_item[20].recoveryPoint;
    AnalogParameter_Protection[8].RecoverTime_Up = Conf_item[20].recoveryTime*0.001;
    AnalogParameter_Protection[8].RetryEnable_Up = Conf_item[20].retry;
    AnalogParameter_Protection[8].RetryLimit_Up = Conf_item[20].retryLimit;
    AnalogParameter_Protection[8].RetryTime_Up = Conf_item[20].retryInterval*0.001;
    /****************************PFCIswAParameter(OCP)***************************/
    AnalogParameter_Protection[10].TripEnable_Up = Conf_item[11].disable;
    AnalogParameter_Protection[10].TripPoint_Up = Conf_item[11].triggerPoint;
    AnalogParameter_Protection[10].TripTime_Up = Conf_item[11].responseTime*0.001;
    AnalogParameter_Protection[10].RecoverPoint_Up = Conf_item[11].recoveryPoint;
    AnalogParameter_Protection[10].RecoverTime_Up = Conf_item[11].recoveryTime*0.001;
    AnalogParameter_Protection[10].RetryEnable_Up = Conf_item[11].retry;
    AnalogParameter_Protection[10].RetryLimit_Up = Conf_item[11].retryLimit;
    AnalogParameter_Protection[10].RetryTime_Up = Conf_item[11].retryInterval*0.001;
    /****************************PFCIswBParameter(OCP)***************************/
    AnalogParameter_Protection[11].TripEnable_Up = Conf_item[11].disable;
    AnalogParameter_Protection[11].TripPoint_Up = Conf_item[11].triggerPoint;
    AnalogParameter_Protection[11].TripTime_Up = Conf_item[11].responseTime*0.001;
    AnalogParameter_Protection[11].RecoverPoint_Up = Conf_item[11].recoveryPoint;
    AnalogParameter_Protection[11].RecoverTime_Up = Conf_item[11].recoveryTime*0.001;
    AnalogParameter_Protection[11].RetryEnable_Up = Conf_item[11].retry;
    AnalogParameter_Protection[11].RetryLimit_Up = Conf_item[11].retryLimit;
    AnalogParameter_Protection[11].RetryTime_Up = Conf_item[11].retryInterval*0.001;
    /****************************PFCIswCParameter(OCP)***************************/
    AnalogParameter_Protection[12].TripEnable_Up = Conf_item[11].disable;
    AnalogParameter_Protection[12].TripPoint_Up = Conf_item[11].triggerPoint;
    AnalogParameter_Protection[12].TripTime_Up = Conf_item[11].responseTime*0.001;
    AnalogParameter_Protection[12].RecoverPoint_Up = Conf_item[11].recoveryPoint;
    AnalogParameter_Protection[12].RecoverTime_Up = Conf_item[11].recoveryTime*0.001;
    AnalogParameter_Protection[12].RetryEnable_Up = Conf_item[11].retry;
    AnalogParameter_Protection[12].RetryLimit_Up = Conf_item[11].retryLimit;
    AnalogParameter_Protection[12].RetryTime_Up = Conf_item[11].retryInterval*0.001;
    /****************************PFCIswDParameter(OCP)***************************/
    AnalogParameter_Protection[13].TripEnable_Up = Conf_item[11].disable;
    AnalogParameter_Protection[13].TripPoint_Up = Conf_item[11].triggerPoint;
    AnalogParameter_Protection[13].TripTime_Up = Conf_item[11].responseTime*0.001;
    AnalogParameter_Protection[13].RecoverPoint_Up = Conf_item[11].recoveryPoint;
    AnalogParameter_Protection[13].RecoverTime_Up = Conf_item[11].recoveryTime*0.001;
    AnalogParameter_Protection[13].RetryEnable_Up = Conf_item[11].retry;
    AnalogParameter_Protection[13].RetryLimit_Up = Conf_item[11].retryLimit;
    AnalogParameter_Protection[13].RetryTime_Up = Conf_item[11].retryInterval*0.001;
    /********************************HV_OVP_HW(OVP)******************************/
    AnalogParameter_Protection[14].TripEnable_Up = Conf_item[2].disable;
    AnalogParameter_Protection[14].TripPoint_Up = Conf_item[2].triggerPoint;
    AnalogParameter_Protection[14].TripTime_Up = Conf_item[2].responseTime*0.001;
    AnalogParameter_Protection[14].RecoverPoint_Up = Conf_item[2].recoveryPoint;
    AnalogParameter_Protection[14].RecoverTime_Up = Conf_item[2].recoveryTime*0.001;
    AnalogParameter_Protection[14].RetryEnable_Up = Conf_item[2].retry;
    AnalogParameter_Protection[14].RetryLimit_Up = Conf_item[2].retryLimit;
    AnalogParameter_Protection[14].RetryTime_Up = Conf_item[2].retryInterval*0.001;
    /********************************HV_SCP_HW(SCP)******************************/
    AnalogParameter_Protection[15].TripEnable_Up = Conf_item[5].disable;
    AnalogParameter_Protection[15].TripPoint_Up = Conf_item[5].triggerPoint;
    AnalogParameter_Protection[15].TripTime_Up = Conf_item[5].responseTime*0.001;
    AnalogParameter_Protection[15].RecoverPoint_Up = Conf_item[5].recoveryPoint;
    AnalogParameter_Protection[15].RecoverTime_Up = Conf_item[5].recoveryTime*0.001;
    AnalogParameter_Protection[15].RetryEnable_Up = Conf_item[5].retry;
    AnalogParameter_Protection[15].RetryLimit_Up = Conf_item[5].retryLimit;
    AnalogParameter_Protection[15].RetryTime_Up = Conf_item[5].retryInterval*0.001;
    /********************************LLC_OCP_HW(OCP)******************************/
    AnalogParameter_Protection[16].TripEnable_Up = Conf_item[12].disable;
    AnalogParameter_Protection[16].TripPoint_Up = Conf_item[12].triggerPoint;
    AnalogParameter_Protection[16].TripTime_Up = Conf_item[12].responseTime*0.001;
    AnalogParameter_Protection[16].RecoverPoint_Up = Conf_item[12].recoveryPoint;
    AnalogParameter_Protection[16].RecoverTime_Up = Conf_item[12].recoveryTime*0.001;
    AnalogParameter_Protection[16].RetryEnable_Up = Conf_item[12].retry;
    AnalogParameter_Protection[16].RetryLimit_Up = Conf_item[12].retryLimit;
    AnalogParameter_Protection[16].RetryTime_Up = Conf_item[12].retryInterval*0.001;
    /********************************PFC_OVP_HW(OVP)******************************/
    AnalogParameter_Protection[17].TripEnable_Up = Conf_item[13].disable;
    AnalogParameter_Protection[17].TripPoint_Up = Conf_item[13].triggerPoint;
    AnalogParameter_Protection[17].TripTime_Up = Conf_item[13].responseTime*0.001;
    AnalogParameter_Protection[17].RecoverPoint_Up = Conf_item[13].recoveryPoint;
    AnalogParameter_Protection[17].RecoverTime_Up = Conf_item[13].recoveryTime*0.001;
    AnalogParameter_Protection[17].RetryEnable_Up = Conf_item[13].retry;
    AnalogParameter_Protection[17].RetryLimit_Up = Conf_item[13].retryLimit;
    AnalogParameter_Protection[17].RetryTime_Up = Conf_item[13].retryInterval*0.001;
    /********************************DSP_CMPSS_HV_OCP*****************************/
    OBC_CURR_CMPSS = (uint16_T)((Conf_item[25].triggerPoint*0.066+0.33)*1241.212);
    /********************************DSP_CMPSS_HV_OVP*****************************/
    OBC_VOLT_CMPSS = (uint16_T)(((Conf_item[26].triggerPoint*0.00199421817+1.44))*1241.212);//0.002157318
    /******************************DSP_CMPSS_PFC_MOS_OCP**************************/
    PFC_CS_CMPSS = (uint16_T)(Conf_item[27].triggerPoint*0.178*1241.212);
    /******************************DSP_CMPSS_PFC_AUX_OVP**************************/
    PFC_AUX_CMPSS = (uint16_T)(Conf_item[28].triggerPoint*0.17184265*1241.212);
    /******************************DSP_CMPSS_PFC_MOS_OTP**************************/
    //NTC_PFC_MOS_CMPSS = Conf_item[29].triggerPoint;
    /******************************DSP_CMPSS_LLC_MOS_OTP**************************/
    //NTC_LLC_MOS_CMPSS = Conf_item[30].triggerPoint;
    /*******************************DSP_CMPSS_PFC_OVP**************************/
    BULK_VOLT_CMPSS = (uint16_T)(Conf_item[31].triggerPoint*0.006618638*1241.212);

    /*
    Conf_item[0].disable;
    Conf_item[0].triggerPoint;
    Conf_item[0].responseTime;
    Conf_item[0].recoveryPoint;
    Conf_item[0].recoveryTime;
    Conf_item[0].retry;
    Conf_item[0].retryLimit;
    Conf_item[0].retryInterval;

    Conf_item[18].disable;
    Conf_item[18].triggerPoint;
    Conf_item[18].responseTime;
    Conf_item[18].recoveryPoint;
    Conf_item[18].recoveryTime;
    Conf_item[18].retry;
    Conf_item[18].retryLimit;
    Conf_item[18].retryInterval;



    Conf_item[21].disable;
    Conf_item[21].triggerPoint;
    Conf_item[21].responseTime;
    Conf_item[21].recoveryPoint;
    Conf_item[21].recoveryTime;
    Conf_item[21].retry;
    Conf_item[21].retryLimit;
    Conf_item[21].retryInterval;

    Conf_item[22].disable;
    Conf_item[22].triggerPoint;
    Conf_item[22].responseTime;
    Conf_item[22].recoveryPoint;
    Conf_item[22].recoveryTime;
    Conf_item[22].retry;
    Conf_item[22].retryLimit;
    Conf_item[22].retryInterval;

    Conf_item[23].disable;
    Conf_item[23].triggerPoint;
    Conf_item[23].responseTime;
    Conf_item[23].recoveryPoint;
    Conf_item[23].recoveryTime;
    Conf_item[23].retry;
    Conf_item[23].retryLimit;
    Conf_item[23].retryInterval;

    Conf_item[24].disable;
    Conf_item[24].triggerPoint;
    Conf_item[24].responseTime;
    Conf_item[24].recoveryPoint;
    Conf_item[24].recoveryTime;
    Conf_item[24].retry;
    Conf_item[24].retryLimit;
    Conf_item[24].retryInterval;

    Conf_item[25].disable;
    Conf_item[25].triggerPoint;
    Conf_item[25].responseTime;
    Conf_item[25].recoveryPoint;
    Conf_item[25].recoveryTime;
    Conf_item[25].retry;
    Conf_item[25].retryLimit;
    Conf_item[25].retryInterval;

    Conf_item[26].disable;
    Conf_item[26].triggerPoint;
    Conf_item[26].responseTime;
    Conf_item[26].recoveryPoint;
    Conf_item[26].recoveryTime;
    Conf_item[26].retry;
    Conf_item[26].retryLimit;
    Conf_item[26].retryInterval;

    Conf_item[27].disable;
    Conf_item[27].triggerPoint;
    Conf_item[27].responseTime;
    Conf_item[27].recoveryPoint;
    Conf_item[27].recoveryTime;
    Conf_item[27].retry;
    Conf_item[27].retryLimit;
    Conf_item[27].retryInterval;

    Conf_item[28].disable;
    Conf_item[28].triggerPoint;
    Conf_item[28].responseTime;
    Conf_item[28].recoveryPoint;
    Conf_item[28].recoveryTime;
    Conf_item[28].retry;
    Conf_item[28].retryLimit;
    Conf_item[28].retryInterval;

    Conf_item[29].disable;
    Conf_item[29].triggerPoint;
    Conf_item[29].responseTime;
    Conf_item[29].recoveryPoint;
    Conf_item[29].recoveryTime;
    Conf_item[29].retry;
    Conf_item[29].retryLimit;
    Conf_item[29].retryInterval;

    Conf_item[30].disable;
    Conf_item[30].triggerPoint;
    Conf_item[30].responseTime;
    Conf_item[30].recoveryPoint;
    Conf_item[30].recoveryTime;
    Conf_item[30].retry;
    Conf_item[30].retryLimit;
    Conf_item[30].retryInterval;

    Conf_item[31].disable;
    Conf_item[31].triggerPoint;
    Conf_item[31].responseTime;
    Conf_item[31].recoveryPoint;
    Conf_item[31].recoveryTime;
    Conf_item[31].retry;
    Conf_item[31].retryLimit;
    Conf_item[31].retryInterval;
    */
}

void Conf_KpKi_Param_Update(void)
{
    PFC_VKp = Conf_Param.PFC_V_Kp;
    PFC_VKi = Conf_Param.PFC_V_Ki;
    PFC_IKp = Conf_Param.PFC_I_Kp;
    PFC_IKi = Conf_Param.PFC_I_Ki;
    Full_load_Up = Conf_Param.VPI_Upper_Limit;
    Full_load_Lo = Conf_Param.VPI_Lower_Limit;
    flCVKp = Conf_Param.LLC_V_Kp;
    flCVKi = Conf_Param.LLC_V_Ki;
    flCCKp = Conf_Param.LLC_I_Kp;
    flCCKi = Conf_Param.LLC_I_Ki;

}

void DetectDataVersion(void)
{
    Data= (int16_T *)(0x0000B806);  // Cali data format version
    DataFormat[0] = (*Data)>>8;
    CaliDataVersion = __byte(DataFormat, 0);
    if(CaliDataVersion != CALI_DATA_VERSION)
    {
        DSP_CALI_ERR = 1;
    }
    else
    {
        DSP_CALI_ERR = 0;
    }

    Data= (int16_T *)(0x0000BC06);  // Conf data format version
    DataFormat[1] = (*Data)>>8;
    ConfDataVersion = __byte(DataFormat, 2);
    if(ConfDataVersion != CONF_DATA_VERSION)
    {
        DSP_CONF_ERR = 1;
    }
    else
    {
        DSP_CONF_ERR = 0;
    }
}
//
// End of File
//
