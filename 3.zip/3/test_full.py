
import csv
import random
import time
import serial
import re

#import visa # https://pyvisa.readthedocs.io/
import pyvisa as visa
import array as CurrCh1
import array as Vin

def Read_PSU( command):
    ser.flushInput()
    ser.write(command.encode('ascii'))
    #ser.write(cmd1.encode('ascii'))
    ser.timeout = 1.
    time.sleep(1)
    decoded_bytes = ser.readline()
    time.sleep(2)
    data1 = decoded_bytes.decode("utf-8")
    PSU_Value = data1.replace('\n',' ')
    PSU_Value = PSU_Value.replace('\r',' ')
    return PSU_Value

def Read_VOUT( command):
    ser.write(command.encode('ascii'))
    ser.timeout = 1.
    time.sleep(1)
    decoded_bytes = ser.readline()
    #time.sleep(1)
    PSU_Value  = decoded_bytes.decode("utf-8")
    #PSU_Value =  (re.findall("\d+\.\d+", str(decoded_bytes)))
    # print(PSU_Value)
    return PSU_Value
x_value = 1
Vout_ELOAD = 0
Vout_PSU = 0
Vout_DAQ = 0

Iout_ELOAD = 0
Iout_PSU = 0
Iout_DAQ = 0

Vin_ACS = 0
Vin_PSU = 0
Vin_DAQ = 0

Iin_ACS = 0
Iin_PSU = 0
Iin_DAQ = 0

Vin_PM = 0
Iin_PM = 0

Pout_Eload = 0
Pout_PSU = 0

Vout_accuracy = 0
Iout_accuracy = 0
Vin_accuracy = 0
Iin_accuracy = 0
Pout_accuracy = 0

def Shutdown():
    ACSource.write('VOLT:AC 120')
    Eload.write('CURR:STAT:L2 1.0')
    Eload.write('LOAD OFF')
    ACSource.write('OUTP OFF')
    
def Setting_AC(Vin,Iout,Freq):
    mes1='CURR:STAT:L2' + ' ' + str(round(Iout,2))
    Eload.write(mes1)
    mes2 ='VOLT:AC'+' '+str(round(Vin,2))
    ACSource.write(mes2)
    mes3 ='FREQ'+' '+str(round(Freq,2))
    ACSource.write(mes3)
    return


def Read_Equip():
    vMeasured_Iout = float( Eload.query('MEAS:CURR?') )
    vMeasured_Vout = float( Eload.query('MEAS:VOLT?') )
    vMeasured_Iin = float( ACSource.query('MEAS:VOLT?'))
    vMeasured_Vin = float( ACSource.query('MEAS:CURR?'))
   # vPMeter_Iout = float( Eload.query('MEAS:CURR?') )
   # vPMeter_Vout = float( Eload.query('MEAS:VOLT?') )
   # vPMeter_Iin = float( ACSource.query('MEAS:VOLT?'))
   # vPMeter_Vin = float( ACSource.query('MEAS:CURR?'))
    return 

fieldnames = ["freq","Vout_ELOAD","Vout_PSU", \
                        "Iout_ELOAD", "Iout_PSU", \
                        "Vin_ACS", "Vin_PSU",\
                        "Iin_ACS","Iin_PSU",\
                        "Vin_PM","Iin_PM",\
                        "Pout_Eload","Pout_PSU",\
                        "Vout_accuracy","Iout_accuracy","Vin_accuracy","Iin_accuracy","Pout_accuracy" ]


with open('psu_data.csv', 'w') as csv_file:
    csv_writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    csv_writer.writeheader()

# Identify the eqipment connected
rm = visa.ResourceManager()
print("Resources detected\n{}\n".format(rm.list_resources()))
# EV Lab
Eload = rm.open_resource('USB0::0x0A69::0x0879::63206AL01175::INSTR')
ACSource = rm.open_resource('USB0::0x0A69::0x0883::96150900001019::INSTR')
#  CIPS lab
#Eload = rm.open_resource('USB0::0x0A69::0x0879::63206AL01175::INSTR')
#ACSource = rm.open_resource('USB0::0x0A69::0x0883::96150700000135::INSTR')

PMeter = rm.open_resource('USB0::0x0B21::0x0025::4333574B313930343445::INSTR')
#Scope = rm.open_resource('USB0::0x0699::0x0527::C031334::INSTR')
# Serial communication setup
#Vin
cmd1="lrpsu -c 136 "
#Iin
cmd2="lrpsu -c 137 "
#Vout
cmd3="RVout -c 139 -a 0 "
#cmd3="rpsu -c 139 -d 2 "
#cmd3="lrpsu -c 139"
#Iout
cmd4="lrpsu -c 140 "
cmd5="lrpsu -c 150 "

ser = serial.Serial('COM3')
ser.flushInput()
ser.baudrate = 115200
ser.bytesize = serial.EIGHTBITS #number of bits per bytes
ser.parity = serial.PARITY_NONE #set parity check: no parity
ser.stopbits = serial.STOPBITS_ONE #number of stop bits
ser.timeout = 1            #non-block read
#ser.xonxoff = False     #disable software flow control
#ser.rtscts = False     #disable hardware (RTS/CTS) flow control
#ser.dsrdtr = False       #disable hardware (DSR/DTR) flow control
#ser.writeTimeout = 2     #timeout for write

mes1 = 'CURR:STAT:L2' + '  ' + '1.00' 
Eload.write(mes1)
mes2 ='VOLT:AC'+' '+ '120'
ACSource.write(mes2)
Eload.write('LOAD ON')
#Configure the AC Source 

ACSource.write('INST:NSEL 3')
ACSource.write('VOLT:AC 120')
ACSource.write('OUTP ON')
#ACSource.write('OUTP OFF')
print('Start PSU accuracy test.')
Vin_voltage = [90,115,180,230,264]
freq = 0
y_value = 0

while y_value < 5:
    x_value = 1 
    while x_value < 21:

      with open('psu_data.csv', 'a') as csv_file:
        csv_writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

        info = {
            "freq":freq,
            "Vout_ELOAD": Vout_ELOAD,
            "Vout_PSU": Vout_PSU,
            "Iout_ELOAD": Iout_ELOAD,
            "Iout_PSU": Iout_PSU,
            "Vin_PSU": Vin_PSU,
            "Vin_ACS": Vin_ACS,
            "Iin_PSU": Iin_PSU,
            "Iin_ACS":Iin_ACS,
            "Vin_PM": Vin_PM,
            "Iin_PM":Iin_PM,
            "Pout_Eload":Pout_Eload,
            "Pout_PSU":Pout_PSU,
            "Vout_accuracy": Vout_accuracy,
            "Iout_accuracy": Iout_accuracy,
            "Vin_accuracy": Vin_accuracy,
            "Iin_accuracy": Iin_accuracy,
            "Pout_accuracy": Pout_accuracy
           
        }

        csv_writer.writerow(info)
        print( freq,Vout_ELOAD,Vout_PSU,Iout_ELOAD,Iout_PSU,Vin_ACS,Vin_PSU,Iin_ACS,Iin_PSU,Vin_PM,Iin_PM,Pout_Eload,Pout_PSU )
        print(Vout_accuracy,Iout_accuracy,Vin_accuracy,Iin_accuracy,Pout_accuracy)
        
         
        # for y in range (0,20,1):
            # Vin = 230
            # Iout = y*0.5
              
        
        i = 0
        if (Vin_voltage[y_value] == 180 or Vin_voltage[y_value] == 230 or Vin_voltage[y_value] == 264):
            freq = 50
        else:
            freq = 60
        Setting_AC(Vin_voltage[y_value],1.25*x_value,freq)
        time.sleep(5)
        Vout_ELOAD = float(Eload.query('MEAS:VOLT?'))
        Vout_PSU = float(Read_PSU(cmd3))
        PMeter.write('NUMeric:FORMat ASCII')
        PMeter.write('NUMeric:NORMal:NUMber 1')
        
        #Vout_PSU =Read_PSU(cmd3)
        #Iout_PSU = Read_PSU(cmd4)
        #Vin_PSU = Read_PSU(cmd1)
        #Iin_PSU = Read_PSU(cmd2)
        Vout_DAQ = 0 
        Iout_ELOAD = float(Eload.query('MEAS:CURR?'))        
        Iout_PSU = float(Read_PSU(cmd4))
        Iout_accuracy = round(100*(Iout_ELOAD-Iout_PSU)/Iout_ELOAD,2)
        if Iout_accuracy < 5:
          print('Iout test passed')
        else:
          print('Iout test Failed')
        Vout_accuracy = round(100*(Vout_ELOAD-Vout_PSU)/Vout_ELOAD,2)
        if Vout_accuracy < 5:
          print('Vout test passed')
        else:
          print('Vout test Failed')
        Vin_ACS = round(float(ACSource.query('MEAS:VOLT:AC?')),2)
        Vin_PSU = float(Read_PSU(cmd1))
        PMeter.write('NUMeric:NORMal:ITEM1 U,1')
        Vin_PM = float(PMeter.query('NUMeric:NORMal:VALUE?'))
        Vin_accuracy = round(100*(Vin_PM-Vin_PSU)/Vin_PM,2)
        if Vin_accuracy < 5:
          print('Vin test passed')
        else:
          print('Vin test Failed')
        Vin_DAQ = 0
        Iin_ACS = float(ACSource.query('MEAS:CURR:AC?'))
        Iin_PSU = float(Read_PSU(cmd2))
        PMeter.write('NUMeric:NORMal:ITEM1 I,1')
        Iin_PM = float(PMeter.query('NUMeric:NORMal:VALUE?'))
        Iin_accuracy = round(100*(Iin_PM-Iin_PSU)/Iin_PM,2)
        if Iin_accuracy < 5:
          print('Iin test passed')
        else:
          print('Iin test Failed')
       
        Iin_DAQ = 0
        Pout_Eload = float(Eload.query('MEAS:POWER?'))
        Pout_PSU = float(Read_PSU(cmd5))
        Pout_accuracy = round(100*(Pout_Eload-Pout_PSU)/Pout_Eload,2)
        if Pout_accuracy < 5:
          print('Pout test passed')
        else:
          print('Pout test Failed')
        x_value += 1 
    y_value += 1
    
Shutdown()       
    #time.sleep(1)