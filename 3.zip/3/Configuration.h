/*
 * Configuration.h
 *
 *  Created on: 2022�~5��25��
 *      Author: MartinChou
 */

#ifndef CONFIGURATION_H_
#define CONFIGURATION_H_


#include "rtwtypes.h"
#include "string.h"

extern uint16_T DSP_CONF_EMPTY;
extern uint16_T DSP_CONF_ERR;
extern uint8_T Conf_Verify;


typedef struct              /* protection data parameter */
{
    uint8_T  disable;
    real32_T triggerPoint;
    uint16_T responseTime;
    real32_T recoveryPoint;
    uint16_T recoveryTime;
    uint8_T  retry;
    uint16_T retryLimit;
    uint16_T retryInterval;
}Conf_item_def;

extern Conf_item_def Conf_item[32];

/*
 Conf_item[0]   DSP_CAN_LOSS_MCU
 Conf_item[1]   DSP_HV_OVP_SW;
 Conf_item[2]   DSP_HV_OVP_HW;
 Conf_item[3]   DSP_HV_UVP_SW;
 Conf_item[4]   DSP_HV_OCP_SW;
 Conf_item[5]   DSP_HV_SCP_HW;
 Conf_item[6]   DSP_GRID_OVP_SW;
 Conf_item[7]   DSP_RMS_GRID_OVP_SW;
 Conf_item[8]   DSP_RMS_GRID_UVP_SW;
 Conf_item[9]   DSP_GRID_UFP_SW;
 Conf_item[10]  DSP_GRID_OFP_SW;
 Conf_item[11]  DSP_PFC_MOS_OCP_SW;
 Conf_item[12]  DSP_LLC_OCP_HW;
 Conf_item[13]  DSP_PFC_OVP_HW;
 Conf_item[14]  DSP_BULK_OVP_SW;
 Conf_item[15]  DSP_BULK_UVP_SW;
 Conf_item[16]  DSP_PFC_AUX_UVP_SW;
 Conf_item[17]  DSP_PFC_AUX_OVP_SW;
 Conf_item[18]  DSP_OTP_1;
 Conf_item[19]  DSP_LLC_OTP;
 Conf_item[20]  DSP_PFC_OTP;
 Conf_item[21]  DSP_DIAG_HV_OVP_FAIL;
 Conf_item[22]  DSP_DIAG_LLC_OCP_FAIL;
 Conf_item[23]  DSP_DIAG_HV_SCP_FAIL;
 Conf_item[24]  DSP_DIAG_PFC_OVP_FAIL;
 Conf_item[25]  DSP_CMPSS_HV_OCP;
 Conf_item[26]  DSP_CMPSS_HV_OVP;
 Conf_item[27]  DSP_CMPSS_PFC_MOS_OCP;
 Conf_item[28]  DSP_CMPSS_PFC_AUX_OVP;
 Conf_item[29]  DSP_CMPSS_PFC_MOS_OTP;
 Conf_item[30]  DSP_CMPSS_LLC_MOS_OTP;
 Conf_item[31]  DSP_CMPSS_PFC_OVP;
*/

 typedef struct
 {
     real32_T PFC_V_Kp;
     real32_T PFC_V_Ki;
     real32_T PFC_I_Kp;
     real32_T PFC_I_Ki;
     real32_T VPI_Upper_Limit;
     real32_T VPI_Lower_Limit;
     real32_T PFC_Gain;
     real32_T PFC_Io;
     real32_T LLC_V_Kp;
     real32_T LLC_V_Ki;
     real32_T LLC_I_Kp;
     real32_T LLC_I_Ki;
 }Conf_KpKi_Param;

extern Conf_KpKi_Param Conf_Param;



int16_T Hextoint16(int16_T *Array, size_t arr_size);
void Configuration_Function(void);
void Configuration_item_default(void);
void Configuration_KpKi_Param_default(void);

#endif /* CONFIGURATION_H_ */
