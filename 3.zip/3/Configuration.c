/*
 * Configuration.c
 *
 *  Created on: 2022�~5��25��
 *      Author: MartinChou
 */

#include "Calibration.h"
#include "Configuration.h"

int16_T *data_Conf;
int16_T Configuration_HexData[580];
int16_T tmp[512];
int16_T disable[1];
int16_T triggerPoint[2];
int16_T responseTime[1];
int16_T recoveryPoint[2];
int16_T recoveryTime[1];
int16_T retry[1];
int16_T retryLimit[512];
int16_T retryInterval[1];
real32_T Configuration_Data[512];
uint8_T Conf_Verify;
uint16_T DSP_CONF_EMPTY;
uint16_T DSP_CONF_ERR;
uint8_T Conf_Verify;

int16_T *data_KpKi_Param;
int16_T KpKi_Param[2];
real32_T KpKi_Param_FloatData[12];

Conf_item_def Conf_item[32] = {0};
//Conf_item_DSP Conf_item;
Conf_KpKi_Param Conf_Param;


void Configuration_Function(void)
{
    static int i, j;
    if(Conf_Verify==2 || Conf_Verify==3 || Conf_Verify==4)
    {
        Configuration_item_default();
        Configuration_KpKi_Param_default();
        DSP_CONF_ERR =1;
    }
    else if(Conf_Verify==1)
    {
        Configuration_item_default();
        Configuration_KpKi_Param_default();
        DSP_CONF_EMPTY =1;
    }
    else
    {
        for(i=13, j=0; i<296; i+=9, j+=8)
        {
                data_Conf = (int16_T *)(0x0000BC00+i);
                Configuration_HexData[i] = (uint8_T) (*data_Conf & 0x00FF);  //disable
                disable[0] = Configuration_HexData[i];
                Configuration_Data[j] = disable[0];

                data_Conf = (int16_T *)(0x0000BC00+i+1);
                Configuration_HexData[i+1] = *data_Conf;  //triggerPoint High word
                data_Conf = (int16_T *)(0x0000BC00+i+2);
                Configuration_HexData[i+2] = *data_Conf;  //triggerPoint Low word
                triggerPoint[0] = Configuration_HexData[i+1];
                triggerPoint[1] = Configuration_HexData[i+2];
                Configuration_Data[j+1] = HextoFloat(triggerPoint, 2);

                data_Conf = (int16_T *)(0x0000BC00+i+3);
                Configuration_HexData[i+3] = *data_Conf;  //responseTime
                responseTime[0] = Configuration_HexData[i+3];
                Configuration_Data[j+2] = Hextoint16(responseTime, 1);

                data_Conf = (int16_T *)(0x0000BC00+i+4);
                Configuration_HexData[i+4] = *data_Conf;  //recoveryPoint High word
                data_Conf = (int16_T *)(0x0000BC00+i+5);
                Configuration_HexData[i+5] = *data_Conf;  //recoveryPoint Low word
                recoveryPoint[0] = Configuration_HexData[i+4];
                recoveryPoint[1] = Configuration_HexData[i+5];
                Configuration_Data[j+3] = HextoFloat(recoveryPoint, 2);

                data_Conf = (int16_T *)(0x0000BC00+i+6);
                Configuration_HexData[i+6] = *data_Conf;  //recoveryTime
                recoveryTime[0] = Configuration_HexData[i+6];
                Configuration_Data[j+4] =  Hextoint16(recoveryTime, 1);

                data_Conf = (int16_T *)(0x0000BC00+i+7);
                Configuration_HexData[i+7] = (uint8_T) (*data_Conf)>>8;  //retry
                retry[0] = Configuration_HexData[i+7];
                Configuration_Data[j+5] = retry[0];

                tmp[i] = (uint8_T) (*data_Conf)<<8;  //retryLimit High byte
                data_Conf = (int16_T *)(0x0000BC00+i+8);
                Configuration_HexData[i+8] = (uint8_T) (*data_Conf)>>8;  //retryLimit Low byte
                retryLimit[0] = (uint8_T)tmp[i]|(uint8_T) Configuration_HexData[i+8]; //retryLimit
                Configuration_Data[j+6] = Hextoint16(retryLimit, 1);

                tmp[i+1] = (uint8_T) (*data_Conf)<<8;  //retryInterval High byte
                data_Conf = (int16_T *)(0x0000BC00+i+9);
                Configuration_HexData[i+9] = (uint8_T) (*data_Conf)>>8;  //retryInterval Low byte
                retryInterval[0] = (uint8_T)tmp[i+1]|(uint8_T) Configuration_HexData[i+9];   //retryInterval
                Configuration_Data[j+7] = Hextoint16(retryInterval, 1);
        }

        for(i=545, j=0; i<570; i+=2, j++)
        {
            data_KpKi_Param = (int16_T *)(0x0000BC00+i);
            Configuration_HexData[i] = *data_KpKi_Param;
            data_KpKi_Param = (int16_T *)(0x0000BC00+i+1);
            Configuration_HexData[i+1] = *data_KpKi_Param;
            KpKi_Param[0] = Configuration_HexData[i];
            KpKi_Param[1] = Configuration_HexData[i+1];
            KpKi_Param_FloatData[j] = HextoFloat(KpKi_Param, 2);
        }


        for(i=0, j=0; i<32; i++, j+=8)
        {
            /*if(Configuration_Data[j] == 84)
            {
                Conf_item[i].disable = 0;
            }
            else
            {
                Conf_item[i].disable = 1;
            }*/
                Conf_item[i].disable = Configuration_Data[j];
                Conf_item[i].triggerPoint = Configuration_Data[j+1];
                Conf_item[i].responseTime = Configuration_Data[j+2];
                Conf_item[i].recoveryPoint = Configuration_Data[j+3];
                Conf_item[i].recoveryTime = Configuration_Data[j+4];
                Conf_item[i].retry = Configuration_Data[j+5];
                Conf_item[i].retryLimit = Configuration_Data[j+6];
                Conf_item[i].retryInterval = Configuration_Data[j+7];
        }

        Conf_Param.PFC_V_Kp = KpKi_Param_FloatData[0];
        Conf_Param.PFC_V_Ki = KpKi_Param_FloatData[1];
        Conf_Param.PFC_I_Kp = KpKi_Param_FloatData[2];
        Conf_Param.PFC_I_Ki = KpKi_Param_FloatData[3];
        Conf_Param.VPI_Upper_Limit = KpKi_Param_FloatData[4];
        Conf_Param.VPI_Lower_Limit = KpKi_Param_FloatData[5];
        Conf_Param.PFC_Gain = KpKi_Param_FloatData[6];
        Conf_Param.PFC_Io = KpKi_Param_FloatData[7];
        Conf_Param.LLC_V_Kp = KpKi_Param_FloatData[8];
        Conf_Param.LLC_V_Ki = KpKi_Param_FloatData[9];
        Conf_Param.LLC_I_Kp = KpKi_Param_FloatData[10];
        Conf_Param.LLC_I_Ki = KpKi_Param_FloatData[11];

    }


}


int16_T Hextoint16(int16_T *Array, size_t arr_size)
{
    int16_T Word1;

    union {
            int16_T conf[2];
            int16_T s16;
          } Hextoint16;

    Word1 = (int16_T)((uint16_T)(Array[0]) << 8);
    Word1 |= (int16_T)((uint16_T)(Array[0]) >> 8);


    Hextoint16.conf[0] = Word1;

    return Hextoint16.s16;
}


void Configuration_item_default(void)
{

    Conf_item[0].disable = 0;
    Conf_item[0].triggerPoint = 0.0;
    Conf_item[0].responseTime = 1000;
    Conf_item[0].recoveryPoint = 0.0;
    Conf_item[0].recoveryTime = 500;
    Conf_item[0].retry = 0;
    Conf_item[0].retryLimit = 0;
    Conf_item[0].retryInterval = 0;

    Conf_item[1].disable = 0;
    Conf_item[1].triggerPoint = 500.0;
    Conf_item[1].responseTime = 10;
    Conf_item[1].recoveryPoint = 430.0;
    Conf_item[1].recoveryTime = 1000;
    Conf_item[1].retry = 84;
    Conf_item[1].retryLimit = 3;
    Conf_item[1].retryInterval = 1000;

    Conf_item[2].disable = 0;
    Conf_item[2].triggerPoint = 0.9;
    Conf_item[2].responseTime = 0;
    Conf_item[2].recoveryPoint = 0.1;
    Conf_item[2].recoveryTime = 1000;
    Conf_item[2].retry = 84;
    Conf_item[2].retryLimit = 3;
    Conf_item[2].retryInterval = 1000;

    Conf_item[3].disable = 0;
    Conf_item[3].triggerPoint = 235.0;
    Conf_item[3].responseTime = 10;
    Conf_item[3].recoveryPoint = 250.0;
    Conf_item[3].recoveryTime = 1000;
    Conf_item[3].retry = 84;
    Conf_item[3].retryLimit = 3;
    Conf_item[3].retryInterval = 1000;

    Conf_item[4].disable = 0;
    Conf_item[4].triggerPoint = 24.0;
    Conf_item[4].responseTime = 100;
    Conf_item[4].recoveryPoint = 22.0;
    Conf_item[4].recoveryTime = 1000;
    Conf_item[4].retry = 84;
    Conf_item[4].retryLimit = 3;
    Conf_item[4].retryInterval = 1000;

    Conf_item[5].disable = 0;
    Conf_item[5].triggerPoint = 0.9;
    Conf_item[5].responseTime = 0;
    Conf_item[5].recoveryPoint = 0.1;
    Conf_item[5].recoveryTime = 1000;
    Conf_item[5].retry = 84;
    Conf_item[5].retryLimit = 3;
    Conf_item[5].retryInterval = 1000;

    Conf_item[6].disable = 0;
    Conf_item[6].triggerPoint = 390.0;
    Conf_item[6].responseTime = 10;
    Conf_item[6].recoveryPoint = 370.0;
    Conf_item[6].recoveryTime = 1000;
    Conf_item[6].retry = 0;
    Conf_item[6].retryLimit = 3;
    Conf_item[6].retryInterval = 1000;

    Conf_item[7].disable = 0;
    Conf_item[7].triggerPoint = 275.0;
    Conf_item[7].responseTime = 100;
    Conf_item[7].recoveryPoint = 265.0;
    Conf_item[7].recoveryTime = 1000;
    Conf_item[7].retry = 0;
    Conf_item[7].retryLimit = 3;
    Conf_item[7].retryInterval = 1000;

    Conf_item[8].disable = 0;
    Conf_item[8].triggerPoint = 80.0;
    Conf_item[8].responseTime = 100;
    Conf_item[8].recoveryPoint = 90.0;
    Conf_item[8].recoveryTime = 1000;
    Conf_item[8].retry = 0;
    Conf_item[8].retryLimit = 3;
    Conf_item[8].retryInterval = 1000;

    Conf_item[9].disable = 0;
    Conf_item[9].triggerPoint = 43.0;
    Conf_item[9].responseTime = 100;
    Conf_item[9].recoveryPoint = 45.0;
    Conf_item[9].recoveryTime = 1000;
    Conf_item[9].retry = 0;
    Conf_item[9].retryLimit = 3;
    Conf_item[9].retryInterval = 1000;

    Conf_item[10].disable = 0;
    Conf_item[10].triggerPoint = 67.0;
    Conf_item[10].responseTime = 100;
    Conf_item[10].recoveryPoint = 65.0;
    Conf_item[10].recoveryTime = 1000;
    Conf_item[10].retry = 0;
    Conf_item[10].retryLimit = 3;
    Conf_item[10].retryInterval = 1000;

    Conf_item[11].disable = 0;
    Conf_item[11].triggerPoint = 20.0;
    Conf_item[11].responseTime = 10;
    Conf_item[11].recoveryPoint = 10.0;
    Conf_item[11].recoveryTime = 1000;
    Conf_item[11].retry = 84;
    Conf_item[11].retryLimit = 3;
    Conf_item[11].retryInterval = 1000;

    Conf_item[12].disable = 0;
    Conf_item[12].triggerPoint = 0.9;
    Conf_item[12].responseTime = 0;
    Conf_item[12].recoveryPoint = 0.1;
    Conf_item[12].recoveryTime = 1000;
    Conf_item[12].retry = 84;
    Conf_item[12].retryLimit = 3;
    Conf_item[12].retryInterval = 1000;

    Conf_item[13].disable = 0;
    Conf_item[13].triggerPoint = 0.9;
    Conf_item[13].responseTime = 0;
    Conf_item[13].recoveryPoint = 0.1;
    Conf_item[13].recoveryTime =1000;
    Conf_item[13].retry = 84;
    Conf_item[13].retryLimit = 3;
    Conf_item[13].retryInterval = 1000;

    Conf_item[14].disable = 0;
    Conf_item[14].triggerPoint = 430.0;
    Conf_item[14].responseTime = 100;
    Conf_item[14].recoveryPoint = 410.0;
    Conf_item[14].recoveryTime = 1000;
    Conf_item[14].retry = 84;
    Conf_item[14].retryLimit = 3;
    Conf_item[14].retryInterval = 1000;

    Conf_item[15].disable = 0;
    Conf_item[15].triggerPoint = 370.0;
    Conf_item[15].responseTime = 100;
    Conf_item[15].recoveryPoint = 0.0;
    Conf_item[15].recoveryTime =1000;
    Conf_item[15].retry = 84;
    Conf_item[15].retryLimit = 3;
    Conf_item[15].retryInterval = 1000;

    Conf_item[16].disable = 0;
    Conf_item[16].triggerPoint = 9.0;
    Conf_item[16].responseTime = 100;
    Conf_item[16].recoveryPoint = 0;
    Conf_item[16].recoveryTime =1000;
    Conf_item[16].retry = 84;
    Conf_item[16].retryLimit = 3;
    Conf_item[16].retryInterval = 1000;

    Conf_item[17].disable = 0;
    Conf_item[17].triggerPoint = 18.0;
    Conf_item[17].responseTime = 100;
    Conf_item[17].recoveryPoint = 16.0;
    Conf_item[17].recoveryTime = 1000;
    Conf_item[17].retry = 84;
    Conf_item[17].retryLimit = 3;
    Conf_item[17].retryInterval = 1000;

    Conf_item[18].disable = 0;
    Conf_item[18].triggerPoint = 80.0;
    Conf_item[18].responseTime = 3000;
    Conf_item[18].recoveryPoint = 70.0;
    Conf_item[18].recoveryTime = 1000;
    Conf_item[18].retry = 0;
    Conf_item[18].retryLimit = 0;
    Conf_item[18].retryInterval = 0;

    Conf_item[19].disable = 0;
    Conf_item[19].triggerPoint = 110.0;
    Conf_item[19].responseTime = 3000;
    Conf_item[19].recoveryPoint = 90.0;
    Conf_item[19].recoveryTime = 1000;
    Conf_item[19].retry = 0;
    Conf_item[19].retryLimit = 3;
    Conf_item[19].retryInterval = 1000;

    Conf_item[20].disable = 0;
    Conf_item[20].triggerPoint = 110.0;
    Conf_item[20].responseTime = 3000;
    Conf_item[20].recoveryPoint = 90.0;
    Conf_item[20].recoveryTime = 1000;
    Conf_item[20].retry = 0;
    Conf_item[20].retryLimit = 3;
    Conf_item[20].retryInterval = 1000;

    Conf_item[21].disable = 0;
    Conf_item[21].triggerPoint = 0.0;
    Conf_item[21].responseTime = 20;
    Conf_item[21].recoveryPoint = 0.0;
    Conf_item[21].recoveryTime = 0;
    Conf_item[21].retry = 0;
    Conf_item[21].retryLimit = 0;
    Conf_item[21].retryInterval = 0;

    Conf_item[22].disable = 0;
    Conf_item[22].triggerPoint = 0.0;
    Conf_item[22].responseTime = 20;
    Conf_item[22].recoveryPoint = 0.0;
    Conf_item[22].recoveryTime = 0;
    Conf_item[22].retry = 0;
    Conf_item[22].retryLimit = 0;
    Conf_item[22].retryInterval = 0;

    Conf_item[23].disable = 0;
    Conf_item[23].triggerPoint = 0.0;
    Conf_item[23].responseTime = 20.0;
    Conf_item[23].recoveryPoint =0.0;
    Conf_item[23].recoveryTime = 0;
    Conf_item[23].retry = 0;
    Conf_item[23].retryLimit = 0;
    Conf_item[23].retryInterval = 0;

    Conf_item[24].disable = 0;
    Conf_item[24].triggerPoint = 0.0;
    Conf_item[24].responseTime = 20;
    Conf_item[24].recoveryPoint = 0.0;
    Conf_item[24].recoveryTime = 0;
    Conf_item[24].retry = 0;
    Conf_item[24].retryLimit = 0;
    Conf_item[24].retryInterval = 0;

    Conf_item[25].disable = 0;
    Conf_item[25].triggerPoint = 24.0;
    Conf_item[25].responseTime = 0;
    Conf_item[25].recoveryPoint = 0.0;
    Conf_item[25].recoveryTime  = 0;
    Conf_item[25].retry = 0;
    Conf_item[25].retryLimit = 0;
    Conf_item[25].retryInterval =0;

    Conf_item[26].disable = 0;
    Conf_item[26].triggerPoint = 530.0;
    Conf_item[26].responseTime = 0;
    Conf_item[26].recoveryPoint = 0.0;
    Conf_item[26].recoveryTime = 0;
    Conf_item[26].retry = 0;
    Conf_item[26].retryLimit = 0;
    Conf_item[26].retryInterval = 0;

    Conf_item[27].disable = 0;
    Conf_item[27].triggerPoint = 20.0;
    Conf_item[27].responseTime = 0;
    Conf_item[27].recoveryPoint = 0.0;
    Conf_item[27].recoveryTime = 0;
    Conf_item[27].retry = 0;
    Conf_item[27].retryLimit = 0;
    Conf_item[27].retryInterval = 0;

    Conf_item[28].disable = 0;
    Conf_item[28].triggerPoint = 16.0;
    Conf_item[28].responseTime = 0;
    Conf_item[28].recoveryPoint = 0.0;
    Conf_item[28].recoveryTime = 0;
    Conf_item[28].retry = 0;
    Conf_item[28].retryLimit = 0;
    Conf_item[28].retryInterval = 0;

    Conf_item[29].disable = 0;
    Conf_item[29].triggerPoint = 110.0;
    Conf_item[29].responseTime = 0;
    Conf_item[29].recoveryPoint = 0.0;
    Conf_item[29].recoveryTime = 0;
    Conf_item[29].retry = 0;
    Conf_item[29].retryLimit = 0;
    Conf_item[29].retryInterval = 0;

    Conf_item[30].disable = 0;
    Conf_item[30].triggerPoint = 110.0;
    Conf_item[30].responseTime = 0;
    Conf_item[30].recoveryPoint = 0.0;
    Conf_item[30].recoveryTime = 0;
    Conf_item[30].retry = 0;
    Conf_item[30].retryLimit = 0;
    Conf_item[30].retryInterval = 0;

    Conf_item[31].disable = 0;
    Conf_item[31].triggerPoint = 440.0;
    Conf_item[31].responseTime = 0;
    Conf_item[31].recoveryPoint = 0.0;
    Conf_item[31].recoveryTime = 0;
    Conf_item[31].retry = 0;
    Conf_item[31].retryLimit = 0;
    Conf_item[31].retryInterval = 0;

}

void Configuration_KpKi_Param_default(void)
{
    Conf_Param.PFC_V_Kp = 0.18;
    Conf_Param.PFC_V_Ki = 0.00025;
    Conf_Param.PFC_I_Kp = 0.015;
    Conf_Param.PFC_I_Ki = 0.005;
    Conf_Param.VPI_Upper_Limit = 100.0;
    Conf_Param.VPI_Lower_Limit = 0.0;
    Conf_Param.PFC_Gain = 0.0;
    Conf_Param.PFC_Io = 0.0;
    Conf_Param.LLC_V_Kp = 0.003375;
    Conf_Param.LLC_V_Ki = 0.11925;
    Conf_Param.LLC_I_Kp = 0.01;
    Conf_Param.LLC_I_Ki = 0.35;
}







