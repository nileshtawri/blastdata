/**
 * \file Main.h
 * \brief System initialization and main program implementation.
 *
 * \copyright Copyright (c) 2015 Infineon Technologies AG. All rights reserved.
 *
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 * This file may be used, copied, and distributed, with or without modification, provided
 * that all copyright notices are retained; that all modifications to this file are
 * prominently noted in the modified file; and that this paragraph is not modified.
 *
 * \defgroup main_sourceCode Source code documentation
 *
 * \defgroup main_sourceCodeApplication 1 - Application code
 * \ingroup main_sourceCode
 *
 * \defgroup library 3 - Library
 * \ingroup main_sourceCode
 *
 * \defgroup IfxLld 4 - iLLD
 * \ingroup main_sourceCode
 *
 * \defgroup IfxLld_Ext 5 - iLLD external device
 * \ingroup main_sourceCode
 *
 *
 * \defgroup main_sourceCodeGlobals 3 - Global variables
 * \ingroup main_sourceCodeApplication
 *
 */

#ifndef CAN_DEFINE_H
#define CAN_DEFINE_H


typedef char int8_t;
typedef unsigned char uint8_t;

typedef struct _OBC_Fault1_Info_Bits
{
    uint16_t HVDC_SCP_HW:1;
    uint16_t HVDC_OCP_SW:1;
    uint16_t PFC_AUX_UVP_SW:1;
    uint16_t PFC_AUX_OVP_SW:1;
    uint16_t PFC_UVP_SW:1;
    uint16_t PFC_OVP_SW:1;
    uint16_t PFC_OVP_HW:1;
    uint16_t PFC_D_OCP_SW:1;
    uint16_t PFC_C_OCP_SW:1;
    uint16_t PFC_B_OCP_SW:1;
    uint16_t PFC_A_OCP_SW:1;
    uint16_t GRID_RMS_UVP_SW:1;
    uint16_t GRID_RMS_OVP_SW:1;
    uint16_t GRID_OVP_SW:1;
    uint16_t GRID_UFP_SW:1;
    uint16_t GRID_OFP_SW:1;

} OBC_Fault1_Info_Bits;

typedef struct _OBC_Fault2_Info_Bits
{
    uint16_t DIAG_HV_SC_FAIL:1;
    uint16_t DIAG_HV_OC_FAIL:1;
    uint16_t DIAG_HV_OV_FAIL:1;
    uint16_t HVDC_OCP_HW:1;
    uint16_t LOST_OF_CAN:1;
    uint16_t DSP_CONF_EMPTY:1;
    uint16_t DSP_CONF_ERR:1;
    uint16_t DSP_CALI_EMPTY:1;
    uint16_t DSP_CALI_ERR:1;
    uint16_t DSP_SELF_TEST_ERR:1;
    uint16_t OBC_OTP_3_SW:1;
    uint16_t NTC_LLC_MOS_SW:1;
    uint16_t NTC_PFC_MOS_SW:1;
    uint16_t HVDC_UVP_SW:1;
    uint16_t HVDC_OVP_SW:1;
    uint16_t HVDC_OVP_HW:1;

} OBC_Fault2_Info_Bits;

typedef struct _OBC_Fault3_Info_Bits
{
    uint16_t REV1:5;
    uint16_t PFC_OVP_CMPSS7:1;
    uint16_t PFC_D_OCP_CMPSS6:1;
    uint16_t PFC_A_OCP_CMPSS6:1;
    uint16_t NTC_LLC_MOS_CMPSS5:1;
    uint16_t NTC_PFC_MOS_CMPSS4:1;
    uint16_t PFC_AUX_OVP_CMPSS3:1;
    uint16_t PFC_C_OCP_CMPSS2:1;
    uint16_t PFC_B_OCP_CMPSS2:1;
    uint16_t HVDC_OVP_CMPSS1:1;
    uint16_t HVDC_OCP_CMPSS1:1;
    uint16_t DIAG_PFC_OV_FAIL:1;

} OBC_Fault3_Info_Bits;

typedef struct _OBC_Fault4_Info_Bits
{
    uint8_t STATUS:8;
    uint16_t REV4:8;

} OBC_Fault4_Info_Bits;


/** \brief Application information */
typedef struct
{
    struct
    {
        struct
        {
            float32_t EVSE_IMAX;          /* ID:0x101 */
            float32_t APM_CURR_IN;        /* ID:0x101 */
            float32_t COOLANT_TEMP;        /* ID:0x101 */
		    float32_t PFC_V_Kp;           /* ID:0x111 */
            float32_t PFC_V_Ki;           /* ID:0x111 */
            float32_t PFC_I_Kp;           /* ID:0x111 */
            float32_t PFC_I_Ki;           /* ID:0x111 */
            int16_t  Upper_Limit;        /* ID:0x112 */
            int16_t  Lower_Limit;        /* ID:0x112 */
            float32_t Control_Gain;       /* ID:0x112 */
            float32_t PFC_Io;             /* ID:0x112 */
            float32_t LLC_V_Kp;           /* ID:0x113 */
            float32_t LLC_V_Ki;           /* ID:0x113 */
            float32_t LLC_I_Kp;           /* ID:0x113 */
            float32_t LLC_I_Ki;           /* ID:0x113 */
            uint8_t   MODE_CMD;           /* ID:0x100 */
            float32_t HVDC_VOLT_CMD;      /* ID:0x100 */
            float32_t HVDC_CURR_CMD;      /* ID:0x100 */
            
        }inbox;
        struct
        {
            uint8_t  DSP_APP_VER_MAJOR;   /* ID:0x602 */
            uint8_t  DSP_APP_VER_MINOR;   /* ID:0x602 */
            uint8_t  DSP_APP_VER_DEBUG;   /* ID:0x602 */
            uint8_t  DSP_APP_BUILD_HOST;  /* ID:0x602 */
            uint16_t DSP_APP_BUILD_YEAR;  /* ID:0x602 */
            uint8_t  DSP_APP_BUILD_MONTH; /* ID:0x602 */
            uint8_t  DSP_APP_BUILD_DAY;   /* ID:0x602 */
            
			float32_t GRID_CURR;           /* ID:0x116 */
            float32_t GRID_FREQ;           /* ID:0x116 */
            float32_t GRID_VOLT;           /* ID:0x116 */
            float32_t PFC_AUX_VOLT;        /* ID:0x116 */
			
            float32_t HVDC_CTRL_FREQ;      /* ID:0x11A */
            float32_t HVDC_CTRL_THETA;     /* ID:0x11A */
            float32_t HVDC_CURR_REF;       /* ID:0x11A */
            float32_t HVDC_VOLT_REF;       /* ID:0x11A */

            float32_t HVDC_CURR;           /* ID:0x11C */
            float32_t HVDC_VOLT;           /* ID:0x11C */
			
            uint8_t  STATUS;               /* ID:0x110 */
            uint8_t  OBC_CAN_STATE;        /* ID:0x110 */
            float32_t CC_Command_FB;       /* ID:0x110 */
            float32_t CV_Command_FB;       /* ID:0x110 */
			
            float32_t OBC_TEMP_1;          /* ID:0x120 */
            float32_t OBC_TEMP_2;          /* ID:0x120 */
            float32_t OBC_TEMP_3;          /* ID:0x120 */

            float32_t BULK_VOLT;           /* ID:0x114 */
            float32_t PFC_A_CURR;          /* ID:0x114 */
            float32_t PFC_B_CURR;          /* ID:0x114 */
            float32_t PFC_C_CURR;          /* ID:0x114 */
			float32_t PFC_D_CURR;          /* ID:0x114 */
            OBC_Fault1_Info_Bits fault1;
            OBC_Fault2_Info_Bits fault2;
            OBC_Fault3_Info_Bits fault3;
            OBC_Fault4_Info_Bits fault4;

        }outbox;
  
    }can;
				/**< Board version lock. TRUE: locked, FALSE: unlocked */
} App;

//________________________________________________________________________________________
// IMPORTED VARIABLES

//________________________________________________________________________________________
// GLOBAL VARIABLES

extern App TI_App;

//________________________________________________________________________________________
// FUNCTION PROTOTYPES
//________________________________________________________________________________________
//________________________________________________________________________________________
#endif
