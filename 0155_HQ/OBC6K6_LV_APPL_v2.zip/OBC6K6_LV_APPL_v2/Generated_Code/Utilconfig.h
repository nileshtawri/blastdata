/**
 * \file
 * \brief Configuration header file for Utility
 *
 * This header file is used to configure settings of the Utility module.
 */

#ifndef __Util_CONFIG_H
#define __Util_CONFIG_H

/* no configuration supported yet */

#endif /* __Util_CONFIG_H */
