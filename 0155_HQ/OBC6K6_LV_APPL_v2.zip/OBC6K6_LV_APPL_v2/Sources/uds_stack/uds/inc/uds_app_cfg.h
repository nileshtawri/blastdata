#ifndef DEF_UDS_APP_CFG_H
#define DEF_UDS_APP_CFG_H

/*********************Include headers************************/
#include "user_config.h"
#include "common_types.h"
#include "tp.h"
/**********************************************************/

typedef uint16 tUdsTime;

typedef struct
{
    tUdsId xUdsId;
    tUdsLen xDataLen;
    uint8 *aDataBuf;
    /*tx message call back*/
    void (*pfUDSTxMsgServiceCallBack)(uint8 bResult);
} tUdsAppMsgInfo;

typedef struct UDSServiceInfo tUDSService;

struct UDSServiceInfo
{
    uint8 SerNum;     /*service num. eg 0x3e/0x87...*/
    uint8 SessionMode;/*default session / program session / extend session*/
    uint8 SupReqMode; /*support physical / function addr*/
    uint8 ReqLevel;   /*request level.Lock/unlock*/
    void (*pfSerNameFun)(const tUDSService* pxSrvcInfo, tUdsAppMsgInfo* pxMsgInfo);
};

typedef void (*tpfPending)(void);


/*********************************************************/

/*S3 timer watermark time percent*/
#ifndef S3_TIMER_WATERMARK_PERCENT
#define S3_TIMER_WATERMARK_PERCENT (90u)
#endif

#if (S3_TIMER_WATERMARK_PERCENT <= 0) || (S3_TIMER_WATERMARK_PERCENT >= 100)
#error "S3_TIMER_WATERMARK_PERCENT should config (0, 100]"
#endif

/*uds negative value define*/
#define NEGTIVE_ID (0x7Fu)
#define	SNS (0x11u)          /*service not support*/
#define	SFNS (0x12u)         /*subfunction not support*/
#define	IMLOIF (0x13u)       /*incorrect message length or invalid format*/
#define	BRR (0x21u)          /*busy repeat request*/
#define	CNC (0x22u)          /*conditions not correct*/
#define	RSE (0x24u)          /*request 	sequence error*/
#define	ROOR (0x31u)         /*request out of range*/
#define	SAD (0x33u)          /*security access denied*/
#define	IK (0x35u)           /*invalid key*/
#define	ENOA (0x36u)         /*exceed number of attempts*/
#define	RCRRP (0x78u)        /*request correctly received-response pending*/
#define GPF (0x72u)          /*general programming failure*/

/*define session mode*/
#define DEFALUT_SESSION (1u << 0u)       /*default session*/
#define PROGRAM_SESSION (1u << 1u)       /*program session*/
#define EXTEND_SESSION (1u << 2u)        /*extend session*/

/*security request*/
#define NONE_SECURITY (1u << 0u)                          /*none security can request*/
#define SECURITY_LEVEL_1 ((1U << 1u) | NONE_SECURITY)     /*security level 1 request*/
#define SECURITY_LEVEL_2 ((1u << 2u) | SECURITY_LEVEL_1)  /*security level 2 request*/

/*********************************************************/
extern tpfPending gs_pfPendingFun;

/*set currrent session mode. DEFAULT_SESSION/PROGRAM_SESSION/EXTEND_SESSION */
extern void SetCurrentSession(const uint8 i_SerSessionMode);

/*Is current session DEFAULT return TRUE, else return FALSE.*/
extern uint8 IsCurDefaultSession(void);

/*Is S3server timeout?*/
extern uint8 IsS3ServerTimeout(void);

/*restart s3server time*/
extern void RestartS3Server(void);

/*Is current session can request?*/
extern uint8 IsCurSeesionCanRequest(uint8 i_SerSessionMode);

/*save received request id. If receved physical/function/none phy 
and function ID set rceived physicali/function/erro ID.*/
extern void SaveRequestIdType(const uint32 i_SerRequestID);

/*Is current received id can request?*/
extern uint8 IsCurRxIdCanRequest(uint8 i_SerRequestIdMode);

/*set security level*/
extern void SetSecurityLevel(const uint8 i_SerSecurityLevel);

/*Is current security level can request?*/
extern uint8 IsCurSecurityLevelRequet(uint8 i_SerSecurityLevel);

/* Get UDS config Service information */
extern const tUDSService* GetUDSServiceInfo(uint8 *m_pSupServItem);

/* If Rx UDS msg, set g_ucIsRxUdsMsg TURE */
extern void SetIsRxUdsMsg(const uint8 i_SetValue);

extern uint8 IsRxUdsMsg(void);

/*set negative erro code*/
extern void SetNegativeErroCode(const uint8 i_UDSServiceNum, 
                                const uint8 i_ErroCode,
                                tUdsAppMsgInfo *m_pstPDUMsg);

/*uds time control*/
extern void UDS_SystemTickCtl(void);

/*get UDS s3 watermark timer. return s3 * 5 * 1000/ 8*/
extern uint32 UDS_GetUDSS3WatermarkTimerMs(void);

extern void CheckFirstTimeEnterApp(void);

#endif /*__UDS_APP_CFG_H__*/
/***************************End file********************************/

