#ifndef DEF_UDS_APP_H
#define DEF_UDS_APP_H

#include "uds_app_cfg.h"

/*uds main function. ISO14229*/
extern void UDS_MainFun(void);

/*UDS init*/
extern void UDS_Init(void);

#endif /*__UDS_APP_H__*/

