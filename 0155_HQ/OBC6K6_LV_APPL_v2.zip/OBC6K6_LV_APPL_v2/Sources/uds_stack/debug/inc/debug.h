/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2019 NXP
 * All rights reserved.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DEF_DEBUG_H
#define DEF_DEBUG_H


/*******************************************************************************
 * User Include
 ******************************************************************************/
#include "user_config.h"
#include "common_types.h"


#ifdef EN_DEBUG_IO
#include "debug_IO.h"
#endif /*#ifdef EN_DEBUG_IO*/

#ifdef EN_DEBUG_TIMER
#include "debug_timer.h"
#endif /*#ifdef EN_DEBUG_TIMER*/

/*! 
 * @file: debug.h
 *
 * @brief: Add your description here for this file.
 *
 * @page misra_violations MISRA-C:2012 violations
 *
 * @section Rule_X-Y Rule: X.Y (Required)
 * Violates MISRA 2012 Required Rule X.Y, Rule description here.
 *
 * @par Version Histroy
<pre><b>
Version:   Author:       Date&&Time:      Revision Log: </b>
 V1.0.0  Tomlin Tang  2019-01-17 15:52:56  First Creat
When you update, please do not forgot to del me and add your info at here.
</pre>
 */

/*!
 * @addtogroup bootloader_debug
 * @{
 */

/*******************************************************************************
 * Definitions
 ******************************************************************************/

#if defined (__cplusplus)
extern "C" {
#endif


/****************************ASSERT and DEBUG IO/TIMER*******************/

#ifdef EN_ASSERT
#define ASSERT(xValue)\
do{\
	if(xValue)\
	{\
		while(1){}\
	}\
}while(0)

#define ASSERT_Printf(pString, xValue)\
do{\
	if(FALSE != xValue)\
	{\
		DebugPrintf(pString);\
	}\
}while(0)

#define ASSERT_DebugPrintf(pString, xValue)\
do{\
	if(FALSE != xValue)\
	{\
		DebugPrintf((pString));\
		while(1u){}\
	}\
}while(0)
#else
#define ASSERT(xValue)
#define ASSERT_Printf(pString, xValue)
#define ASSERT_DebugPrintf(pString, xValue)
#endif



/************************Debug config**************************/
#ifdef EN_DEBUG_FLS_MODULE
#define FLSDebugPrintf DebugPrintf
#else
#define FLSDebugPrintf(fmt, args...)
#endif

#ifdef EN_UDS_DEBUG
#define UDSDebugPrintf DebugPrintf
#else
#define UDSDebugPrintf(fmt, args...)
#endif

#ifdef EN_TP_DEBUG
#define TPDebugPrintf DebugPrintf
#else
#define TPDebugPrintf(fmt, args...)
#endif

#ifdef EN_APP_DEBUG
#define APPDebugPrintf DebugPrintf
#else
#define APPDebugPrintf(fmt, args...)
#endif

#ifdef EN_DEBUG_FIFO
#define FIFODebugPrintf DebugPrintf
#else
#define FIFODebugPrintf(fmt, args...)
#endif

#ifdef EN_OBC_DEBUG
#define ObcDebugPrintf DebugPrintf
#else
#define ObcDebugPrintf(fmt, args...)
#endif



/*******************************************************************************
 * API
 ******************************************************************************/
#ifdef EN_DEBUG_IO
#define InitDebugIO() DEBUG_IO_Init()
#define SetDebugIOHigh() DEBUG_IO_SetDebugIOHigh()
#define SetDebugIOLow() DEBUG_IO_SetDebugIOLow()
#define ToggleDebugIO() DEBUG_IO_ToggleDebugIO()
#else
#define InitDebugIO() 
#define SetDebugIOHigh() 
#define SetDebugIOLow() 
#define ToggleDebugIO() 
#endif /*#ifdef EN_DEBUG_IO*/



#ifdef EN_DEBUG_TIMER
#define InitDebugTimer() DEBUG_TIMER_Init()
#define GetDegbuTimerValue() DEBUG_TIMER_GetTimerValue()
#else
#define InitDebugTimer() 
#define GetDegbuTimerValue() 
#endif /*#ifdef EN_DEBUG_TIMER*/

#ifdef EN_DEBUG_PRINT
#define DEBUG_LOG_BUF_SIZE (200u)
extern void DebugPrintInit(void);
extern void DebugPrint(const char *fmt, ...);

#define InitDebugPrint() DebugPrintInit()
#define DebugPrintf(fmt, args...) DebugPrint(fmt, ##args)
#else
/*Some MCU cannot called printf lib. E.g., S12Gxxx*/
#define InitDebugPrint()
#define DebugPrintf(fmt, args...)
#endif


extern 	void BOOTLOADER_DEBUG_Init(void);

/*! @}*/

#if defined (__cplusplus)
}
#endif

/*! @}*/

#endif /* DEF_DEBUG_H */
/*******************************************************************************
 * EOF
 ******************************************************************************/
