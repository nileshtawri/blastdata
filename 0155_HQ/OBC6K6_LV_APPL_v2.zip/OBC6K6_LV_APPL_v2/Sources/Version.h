/**
 * @file        Version.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_VERSION_H
#define         DEF_VERSION_H

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------
typedef struct __attribute__((__packed__)) VER_INFO_S
{
    uint8_t bVerMajor;
    uint8_t bVerMinor;
    uint8_t bVerDebug;
    uint8_t bBuildHostId;
    uint16_t wBuildYear;
    uint8_t bBuildMonth;
    uint8_t bBuildDay;
    uint8_t abVersion[16];
    uint8_t abHgVersion[16];
    uint8_t abHgNode[16];
    uint8_t abBuildDateTime[32];
}ver_info_t;

extern const ver_info_t xApplVerInfo;

//------------------------------------------------------------------------------
#endif          // DEF_VERSION_H
