/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"

/* User includes (#include below this line is not maintained by Processor Expert) */
#include "timer.h"
#include "gpio.h"
#include "can.h"
#include "pwm.h"
#include "type.h"
#include "config.h"
#include "nvm.h"
#include "tp.h"
#include "uds_app.h"
#include "adc.h"
#include "sbc.h"
#include "DrvScst.h"
#include "housekeep.h"
#include "obc.h"
#include "evse.h"
#include "safetyMeasure.h"
#include "if.h"
#include "networkManagement.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


static volatile s32 exit_code = 0;

static void sInterruptSetupPriority(void);
static void sCpuInit(void);


/**
 * @brief       to initial the priority of interrupts,
 *              setup used interrupts to lowest priority, only PortC has higher
 *              priority.
 */
static void sInterruptSetupPriority(void)
{
    INT_SYS_DisableIRQGlobal();

    #if 0                                   // don't change priority, or SCST will hange
    INT_SYS_SetPriority(PendSV_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(SysTick_IRQn,       (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(DMA0_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA1_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA2_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA3_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA4_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA5_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA6_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA7_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA8_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA9_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA10_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA11_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA12_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA13_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA14_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA15_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(DMA_Error_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(MCM_IRQn,           (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTFC_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(Read_Collision_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LVD_LVW_IRQn,       (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTFC_Fault_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(WDOG_EWM_IRQn,      (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(RCM_IRQn,           (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(LPI2C0_Master_IRQn, (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPI2C0_Slave_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPSPI0_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPSPI1_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPSPI2_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPUART0_RxTx_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPUART1_RxTx_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPUART2_RxTx_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(ADC0_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(ADC1_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CMP0_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(ERM_single_fault_IRQn, (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(ERM_double_fault_IRQn, (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(RTC_IRQn,           (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(RTC_Seconds_IRQn,   (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(LPIT0_Ch0_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPIT0_Ch1_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPIT0_Ch2_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPIT0_Ch3_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PDB0_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(SCG_IRQn,           (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(LPTMR0_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PORTA_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PORTB_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PORTC_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PORTD_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PORTE_IRQn,         (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(SWI_IRQn,           (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(PDB1_IRQn,          (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FLEXIO_IRQn,        (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(CAN0_ORed_0_15_MB_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN0_ORed_16_31_MB_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN0_ORed_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN0_Error_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN0_Wake_Up_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN1_ORed_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN1_ORed_0_15_MB_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN1_Error_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN2_ORed_IRQn,     (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN2_ORed_0_15_MB_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(CAN2_Error_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);

    INT_SYS_SetPriority(FTM0_Ch0_Ch1_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM0_Ch2_Ch3_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM0_Ch4_Ch5_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM0_Ch6_Ch7_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM0_Fault_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM0_Ovf_Reload_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Ch0_Ch1_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Ch2_Ch3_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Ch4_Ch5_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Ch6_Ch7_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Fault_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM1_Ovf_Reload_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Ch0_Ch1_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Ch2_Ch3_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Ch4_Ch5_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Ch6_Ch7_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Fault_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM2_Ovf_Reload_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Ch0_Ch1_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Ch2_Ch3_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Ch4_Ch5_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Ch6_Ch7_IRQn,  (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Fault_IRQn,    (1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    INT_SYS_SetPriority(FTM3_Ovf_Reload_IRQn,(1UL << FEATURE_NVIC_PRIO_BITS) - 1UL);
    #endif

    INT_SYS_EnableIRQGlobal();
}


/**
 * @brief: CPU core init
 *
 * @note : blocked if initial fail
 */
static void sCpuInit(void)
{
    status_t xRet;

    (void)CLOCK_SYS_Init(   g_clockManConfigsArr,
                            CLOCK_MANAGER_CONFIG_CNT,
                            g_clockManCallbacksArr, 
                            CLOCK_MANAGER_CALLBACK_CNT);

    xRet = CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

    if(xRet != STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        sUartValSet(UART_VAL_MCU_ERR_CODE, MCU_ERR_CODE(MCU_DRV_CLK, xRet));
        #else
        for(;;)                                 /* NOTE! stop if init fail */
        {
            ;
        }
        #endif
    }

    /* Copy sCST initialized data from ROM to RAM */
    memcpy(__scst_data_start__, __SCST_DATA_ROM, (uint32_t)__SCST_DATA_SIZE);
    /* polyspace-begin MISRA-C3:D2.1 " undefined" */
    m4_scst_accumulated_signature = 0;
    /* polyspace-end MISRA-C3:D2.1 " undefined" */
    /* polyspace-begin MISRA-C3:17.3 "no visible prototype" */
    (void)m4_scst_execute_core_tests(0, 43U); /* perform all test function */
    /* polyspace-end MISRA-C3:17.3 "no visible prototype" */

    if (m4_scst_accumulated_signature != ACCUMULATED_SIGNATURE_ID0_43)
    {
        for(;;)                                 /* NOTE! stop if self-test fail */
        {
            ;
        }
    }

    sInterruptSetupPriority();
}

static void sCpuResetReason(void)
{
    u32 dwResetCause = RCM->SRS;

    if ((dwResetCause & RCM_PARAM_EWDOG_MASK) != 0)
    {
        // TODO: add a DTC

        #if (HAVE_DEBUG_UART != 0)
        DebugPrint("!! RESET BY WATCHDOG, 0x%X\n", RCM->SRS);
        #endif
    }

    if (dwResetCause != (RCM_PARAM_ELVD_MASK | RCM_PARAM_EPOR_MASK))
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrint("! ABNORMAL RESET BY 0x%X\n", RCM->SRS);
        #endif
    }
}

/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)  /* polyspace MISRA-C3:D4.6 "generated code" */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
    INT_SYS_DisableIRQGlobal();

    sCpuInit();
    sbIfDataInit();
    sGpioInit();
    sNvmInit();
    sTimerInit();    
    sCan0Init();
    sCan2Init();
    sPwmInit();
    TP_Init();
    UDS_Init();
    sAdcInit();
    sNmInit();

    INT_SYS_EnableIRQGlobal();

    sSBCInitial();

    #if (HAVE_DEBUG_UART != 0)
    sUartInit();
    #endif

    sCpuResetReason();
    CheckFirstTimeEnterApp();

    sObcInit();
    sEvseInit();
    sHouseKeepInit();
    
    for(;;)
    {
        sTimerRun();
        TP_MainFun();
        sIsoTpSendMsg();
        UDS_MainFun();
    }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
