/**
 * @file        SafetyMeasure.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "config.h"
#include "cpu.h"
#include "type.h"
#include "DrvScst.h"
#include "SafetyMeasure.h"
#include "HouseKeep.h"
#include "sbc.h"
#include "gpio.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define SCST_RETRY_TIME_MAX             (1000U / TEST_INTERVAL_MS)

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------
//static void sDisableUsedInterrupts(void);
//static void sEnableUsedInterrupts(void);

static void sTestScst(void);

//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static u32 dwScstErr = 0;

#if (HAVE_SBC_FUNCTION != 0)
static u32 dwSbcWdErr = 0;
static u8 bFS0BReleaseCounter = 0;
#endif
//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------
#if 0
static void sDisableUsedInterrupts(void)
{
    INT_SYS_DisableIRQGlobal();

    INT_SYS_DisableIRQ(CAN0_ORed_IRQn);
    INT_SYS_DisableIRQ(CAN0_Error_IRQn);
    INT_SYS_DisableIRQ(CAN0_ORed_0_15_MB_IRQn);
    INT_SYS_DisableIRQ(CAN0_ORed_16_31_MB_IRQn);

    INT_SYS_DisableIRQ(ADC0_IRQn);
    INT_SYS_DisableIRQ(ADC1_IRQn);

    INT_SYS_DisableIRQ(LPIT0_Ch0_IRQn);
    INT_SYS_DisableIRQ(LPIT0_Ch1_IRQn);

    INT_SYS_DisableIRQ(LPSPI1_IRQn);

    INT_SYS_DisableIRQ(PORTC_IRQn);
}

static void sEnableUsedInterrupts(void)
{
    INT_SYS_EnableIRQ(PORTC_IRQn);

    INT_SYS_EnableIRQ(LPSPI1_IRQn);

    INT_SYS_EnableIRQ(LPIT0_Ch0_IRQn);
    INT_SYS_EnableIRQ(LPIT0_Ch1_IRQn);

    INT_SYS_EnableIRQ(ADC0_IRQn);
    INT_SYS_EnableIRQ(ADC1_IRQn);

    INT_SYS_EnableIRQ(CAN0_ORed_IRQn);
    INT_SYS_EnableIRQ(CAN0_Error_IRQn);
    INT_SYS_EnableIRQ(CAN0_ORed_0_15_MB_IRQn);
    INT_SYS_EnableIRQ(CAN0_ORed_16_31_MB_IRQn);

    INT_SYS_EnableIRQGlobal();
}
#endif


#if 1
/**
 * @brief: perform periodically SCST test, it will test one case each time,
 *         if one SCST test case was interrupt by application code,
 *         then this test case will re-test in next iteration.
 *         If retry over 1 second, report the error code 'SCST_STUCK_ERR'. 
 */
static void sTestScst(void)
{
    static u16 wScstTestIndex = 0;
    static u32 dwScstRetry = 0;

    /* polyspace-begin MISRA-C3:17.3 "no visible prototype" */
    (void)m4_scst_execute_core_tests(wScstTestIndex, wScstTestIndex);
    /* polyspace-end MISRA-C3:17.3 "no visible prototype" */

    /* polyspace-begin MISRA-C3:D2.1 "undefined" */
    if ((m4_scst_test_was_interrupted == 0) 
        && (m4_scst_last_executed_test_number == wScstTestIndex))
    /* polyspace-end MISRA-C3:D2.1 " undefined" */
    {
        wScstTestIndex++;               // test pass, test next item
        dwScstRetry = 0;                // clear retry counter

        if(wScstTestIndex > SCST_TEST_ITEM_END)
        {
            wScstTestIndex = 0;
        }
    }
    else                                // if test not pass
    {
        /* polyspace-begin MISRA-C3:D2.1 "undefined" */
        if(m4_scst_accumulated_signature != SCST_TEST_INTERRUPTED)
        /* polyspace-end MISRA-C3:D2.1 " undefined" */
        {                               // and not interrupted, that is FAIL
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("SCST case %d ERROR 0x%X.\n",
                        m4_scst_last_executed_test_number,
                        m4_scst_test_was_interrupted);
            #endif

            dwScstErr = m4_scst_accumulated_signature;
        }
        else                            // if it just interrupted, try again
        {
            dwScstRetry++;

            if (dwScstRetry > SCST_RETRY_TIME_MAX)
            {                           // if retry over 1 second,
                #if (HAVE_DEBUG_UART != 0)
                DebugPrintf("SCST Stuck at %d.\n", m4_scst_last_executed_test_number);
                #endif

                dwScstErr = SCST_STUCK_ERR; // report error
            }
        }
    }
}
#endif
//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief: perform periodically refresh the SBC's watchdog
 */
void sIdleTask(void)
{
    #if (HAVE_SBC_FUNCTION != 0)
    status_t xStatus;

    xStatus = FS45_WD_Refresh();

    if(xStatus != STATUS_SUCCESS)
    {
        dwSbcWdErr++;
    }

    if(bFS0BReleaseCounter == 10)
    {
    	(void)sbSbcFs0bCheck();
    	bFS0BReleaseCounter = 0;
    }
    else
    {
    	bFS0BReleaseCounter++;
    }
    #endif

    /* Reset Watchdog counter */
    WDOG_DRV_Trigger(INST_DRVWDOG);
}


void WDOG_EWM_IRQHandler(void)
{
    #if (HAVE_DEBUG_UART != 0)
    u32 dwTime = OSIF_GetMilliseconds();
    DebugPrintf("!!! WatchDog timeout at %d\n", dwTime);
    #endif
}

/**
 * @brief: perform periodically test functions
 *          1. ARM Cortex M4 self test (SCST)
 *          2. TODO: check FIRC timer
 *          3. TODO: check Stack overflow or underflow by DWT
 *          4. TODO: check ADC internal voltage
 *          5. TODO: check the lowest priority interrupt
 *          6. TODO: to reflash internal watchdog timer
 */
void sTestTask(void)
{
    static u16 wTestItem = 0;

    #if 1
    #if (HAVE_DEBUG_GPIO != 0)
    PINS_DRV_SetPins(TEST_PIN0_PORT, (1UL << TEST_PIN0_INDEX));
    #endif

    sTestScst();

    #if (HAVE_DEBUG_GPIO != 0)
    PINS_DRV_ClearPins(TEST_PIN0_PORT, (1UL << TEST_PIN0_INDEX));
    #endif
    #endif

    switch(wTestItem)
    {
        case 0:                                 /* ARM CM4 SCST test function */
            if (dwScstErr != 0)
            {
                sEventFlagSet(MASK_CPU_ERR);
                // TODO: save DTC and Stop CPU
            }

            wTestItem++;
            break;

        case 1:
            // TODO: check FIRC timer
            wTestItem++;
            break;

        case 2:
            // TODO: check Stack overflow or underflow by DWT
            wTestItem++;
            break;

        case 3:
            // TODO: check ADC internal voltage
            wTestItem++;
            break;
    
        case 4:
            // TODO: check the lowest priority interrupt
            wTestItem++;
            break;

        default:
            // TODO: reflash internal watchdog
            wTestItem = 0;
            break;
    }
}

#if 0
/**
 * @brief: read SCST error code
 * @param[out]  pdwCnt  point to return buffer
 */
void sTestGetScstErrCode(u32 *pdwErr)
{
    *pdwErr = dwScstErr;
}
#endif

