/**
 * @file        ADC.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef ADC_H_
#define ADC_H_
//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "nvm.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))



//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef struct PACKED IF_ADC_DATA_S
{
    f32 flLvdcVolt;
    f32 flLvdcCurr;
    f32 flLvBatVolt;
    f32 flHvdcVolt;
    f32 flHvdcCurr;
    f32 flLvdcRemoteVolt;
    f32 flApmHvdcVolt;
    f32 flApmHvdcCurr;
    f32 flPcbTemp;
    f32 flSrTemp;
    f32 flCoolTemp;
    f32 flAuxLvVolt;
    f32 flAuxHvVolt;
    f32 flBoostVolt;
    f32 flBoostCurr;
    f32 flPilotVolt;
    f32 flProxiVolt;
}x_if_ai_t;



//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
extern void sAdcInit(void);
extern f32 sGetNTCTemp(u8 NTCNumber);
extern f32 sADCtoLSOutputVoltage(void);
extern f32 sADCtoLSOutputCurrent(void);
extern f32 sADCtoAUXVoltage(void);
extern f32 sADCtoHSInputVoltage(void);
extern f32 sADCtoHSInputCurrent(void);
extern f32 sADCtoBatteryVoltage(void);
extern void PDB0_IRQHandler(void);
extern void PDB1_IRQHandler(void);
extern u8 sAdcGainOffsetUpdate(const x_cali_data_t* pxData);
extern void sAdcGainOffsetClear(void);
extern void sVoutGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sVinGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sIoutGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sIinGainOffsetGet(f32 *pflGain, f32 *pflOffset);
extern void sVbatGainOffsetGet(f32 *pflGain, f32 *pflOffset);

/**
 * \brief   ADC task function
 */
extern void sAdcTask(void);
extern void sAdcIfInit(void);

#endif /* ADC_H_ */
