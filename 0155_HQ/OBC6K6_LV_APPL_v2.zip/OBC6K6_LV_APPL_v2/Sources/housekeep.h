/**
 * @file        housekeep.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef HOUSEKEEP_H_
#define HOUSEKEEP_H_


//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))

#define HOUSEKEEP_TIMEBASE                      10U         // 10ms
#define TIME(t)                         (u16)((t) * 1000.0F / HOUSEKEEP_TIMEBASE)


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------


typedef enum APM_WORK_MODE_E
{
    APM_MODE_INVALIDE           = 0,
    APM_MODE_POWERON            = 1U,
    APM_MODE_STANDBY            = 2U,
    APM_MODE_FAULT              = 3U,
    APM_MODE_IDLE               = 4U,
    APM_MODE_SOFTSTART          = 5U,
    APM_MODE_ACTIVE             = 6U,
    APM_MODE_PRECHARGE          = 7U,
    APM_MODE_DISCHARGE          = 8U,
    APM_MODE_FLASH              = 9U,
    APM_MODE_LATCH              = 10U,
    APM_MODE_SLEEP              = 11U,
    APM_MODE_DIAG               = 12U,
    APM_MODE_TEST               = 0xFFU,        // for test or debug only
}x_apm_work_mode_t;

typedef struct PACKED IF_HO_DATA_S
{
    x_apm_work_mode_t   eApmWorkMode;
    u64                 qwApmErrorFlag;

    f32                 flLvdcVcmd;
    f32                 flLvdcIcmd;
    u16                 wVcmdDutyCnt;
    u16                 wIcmdDutyCnt;

    e_bool_t            eIgnState;

    e_bool_t            eLvdcEnDol;
    e_bool_t            eBoostEnDol;
    e_bool_t            eApmAuxEnDoh;
    e_bool_t            eLatchUnlockDoh;
    e_bool_t            eDiagApmDoh;

    e_bool_t            eApmAuxUvCheck;
    e_bool_t            eLvdcUvCheck;
    e_bool_t            eBoostUvCheck;
}x_if_ho_t;

typedef enum EVENT_E
{
    EVENT_BST_OV_SW,                            // check boost SW OV event
    EVENT_BST_OV_HW,                            // check boost HW OV signal
    EVENT_BST_OC,                               // check boost over current
    EVENT_BST_UV,                               // check boost voltage is UV
    EVENT_LV_OV_SW,                             // check LVDC SW OV event
    EVENT_LV_UV,                                // check LVDC UV event
    EVENT_HVDC_OV,                              // check HVDC input is OV
    EVENT_HVDC_UV,                              // check HVDC input is UV
    EVENT_HVDC_OC,                              // check HVDC input is OC
    EVENT_HV_AUX_UV,                            // check HV side AUX UV event
    EVENT_HV_AUX_OV,                            // check HV side AUX OV event
    EVENT_LV_AUX_UV,                            // check LV side AUX UV event
    EVENT_LV_AUX_OV,                            // check LV side AUX OV event
    EVENT_LV_OC_SW,                             // check LV SW over current
    EVENT_LV_OV_HW,                             // check LV HW OV signal
    EVENT_LV_OC_HW,                             // check LV HW OC signal
    EVENT_LV_OP,                                // check LV over power event
    EVENT_PCB_OT,                               // check PCB over temperature
    EVENT_SR_OT,                                // check SR over temperature
    EVENT_COOLANT_OT,                           // check coolant over temperature
    EVENT_BAT_OV,                               // check battery over voltage
    EVENT_BAT_UV,                               // check battery under voltage
    EVENT_CP_OF,                                // check control pilot over freq
    EVENT_CP_UF,                                // check control pilot under freq
    EVENT_OBC_NG,                               // check OBC_OK signal
    EVENT_DSP_NG,                               // check DSP_OK signal
    EVENT_VCU_LOSS,                             // check CAN loss from VCU
    EVENT_DSP_LOSS,                             // check CAN loss from F280049
    EVENT_DIAG_OVP,                             // check to self-diagnostic OVP
    EVENT_DIAG_SCP,                             // check to self-diagnostic SCP
    EVENT_IGN_ON,                               // check ignition signal
    EVENT_BAT_LOW,                              // check battery voltage is low
    EVENT_BAT_HIGH,                             // check battery voltage is high
    EVENT_HVDC_LOW,                             // check to enabld/disable boost
    EVENT_HVDC_HIGH,                            // check to enabld/disable boost
    EVENT_NUM
}e_event_t;

typedef enum BIT_FLAG_E
{
    BIT_SBC_ERR = 0,                            // SBC initial error
    BIT_SBC_FS,                                 // SBC's fail safe is actived
    BIT_CONF_ERR,                               // configuration data in NVM is crrupt
    BIT_CONF_EMPTY,                             // configuration data in NVM is empty
    BIT_DSP_NG,                                 // F280049 is not OK
    BIT_DSP_LOSS,                               // loss F280049 CAN message
    BIT_VCU_LOSS,                               // loss VCU's CAN message
    BIT_OBC_NG,                                 // OBC is not OK
    BIT_BAT_OV,                                 // battery over voltage
    BIT_BAT_UV,                                 // battery under voltage
    BIT_LV_AUX_OV,                              // LV side's Aux. power over voltage
    BIT_LV_AUX_UV,                              // LV side's Aux. power under voltage
    BIT_LV_OV_HW,                               // LVDC over voltage with HW protection 
    BIT_LV_OV_SW,                               // LVDC over voltage with SW protection
    BIT_LV_UV,                                  // LVDC under voltage
    BIT_LV_OC_HW,                               // LVDC over current with HW protection
    BIT_LV_OC_SW,                               // LVDC over current with SW protection
    BIT_HV_OV,                                  // HVDC over voltage
    BIT_HV_UV,                                  // HVDC under voltage
    BIT_HV_OC,                                  // HVDC over current
    BIT_PCB_OT,                                 // PCB over temperature
    BIT_SR_OT,                                  // SR over temperature
    BIT_COOL_OT,                                // coolant over temperature
    BIT_BST_OV_SW,                              // Boost over voltage with SW protection
    BIT_BST_OV_HW,                              // Boost over voltage with HW protection
    BIT_BST_OC,                                 // Boost over current
    BIT_LV_OP,                                  // LVDC over power
    BIT_CP_OF,                                  // EVSE's control pilot over frequency
    BIT_CP_UF,                                  // EVSE's control pilot under frequency
    BIT_HV_AUX_OV,                              // HV side's Aux. power over voltage
    BIT_HV_AUX_UV,                              // HV side's Aux. power under voltage
    BIT_BST_UV,                                 // Boost under voltage
    BIT_CPU_ERR,                                // CPU core self-test error
    BIT_CALI_ERR,                               // calibration data in NVM is crrupt
    BIT_CALI_EMPTY,                             // calibration data in NVM is empty
    BIT_DIAG_OV_ERR,                            // diagnostic over voltage failed
    BIT_DIAG_SC_ERR,                            // diagnostic short circuit failed
    
    BIT_FLAG_NUM,
    BIT_INVALID,
}err_flag_t;

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

#define         MASK_SBC_ERR        (1ULL << (u8)BIT_SBC_ERR)
#define         MASK_SBC_FS         (1ULL << (u8)BIT_SBC_FS)
#define         MASK_CONF_ERR       (1ULL << (u8)BIT_CONF_ERR)
#define         MASK_CONF_EMPTY     (1ULL << (u8)BIT_CONF_EMPTY)
#define         MASK_DSP_NG         (1ULL << (u8)BIT_DSP_NG)
#define         MASK_DSP_LOSS       (1ULL << (u8)BIT_DSP_LOSS)
#define         MASK_VCU_LOSS       (1ULL << (u8)BIT_VCU_LOSS)
#define         MASK_OBC_NG         (1ULL << (u8)BIT_OBC_NG)
#define         MASK_BAT_OV         (1ULL << (u8)BIT_BAT_OV)
#define         MASK_BAT_UV         (1ULL << (u8)BIT_BAT_UV)
#define         MASK_LV_AUX_OV      (1ULL << (u8)BIT_LV_AUX_OV)
#define         MASK_LV_AUX_UV      (1ULL << (u8)BIT_LV_AUX_UV)
#define         MASK_LV_OV_HW       (1ULL << (u8)BIT_LV_OV_HW)
#define         MASK_LV_OV_SW       (1ULL << (u8)BIT_LV_OV_SW)
#define         MASK_LV_UV          (1ULL << (u8)BIT_LV_UV)
#define         MASK_LV_OC_HW       (1ULL << (u8)BIT_LV_OC_HW)
#define         MASK_LV_OC_SW       (1ULL << (u8)BIT_LV_OC_SW)
#define         MASK_HV_OV          (1ULL << (u8)BIT_HV_OV)
#define         MASK_HV_UV          (1ULL << (u8)BIT_HV_UV)
#define         MASK_HV_OC          (1ULL << (u8)BIT_HV_OC)
#define         MASK_PCB_OT         (1ULL << (u8)BIT_PCB_OT)
#define         MASK_SR_OT          (1ULL << (u8)BIT_SR_OT)
#define         MASK_COOL_OT        (1ULL << (u8)BIT_COOL_OT)
#define         MASK_BST_OV_SW      (1ULL << (u8)BIT_BST_OV_SW)
#define         MASK_BST_OV_HW      (1ULL << (u8)BIT_BST_OV_HW)
#define         MASK_BST_OC         (1ULL << (u8)BIT_BST_OC)
#define         MASK_LV_OP          (1ULL << (u8)BIT_LV_OP)
#define         MASK_CP_OF          (1ULL << (u8)BIT_CP_OF)
#define         MASK_CP_UF          (1ULL << (u8)BIT_CP_UF)
#define         MASK_HV_AUX_OV      (1ULL << (u8)BIT_HV_AUX_OV)
#define         MASK_HV_AUX_UV      (1ULL << (u8)BIT_HV_AUX_UV)
#define         MASK_BST_UV         (1ULL << (u8)BIT_BST_UV)
#define         MASK_CPU_ERR        (1ULL << (u8)BIT_CPU_ERR)
#define         MASK_CALI_ERR       (1ULL << (u8)BIT_CALI_ERR)
#define         MASK_CALI_EMPTY     (1ULL << (u8)BIT_CALI_EMPTY)
#define         MASK_DIAG_OV_ERR    (1ULL << (u8)BIT_DIAG_OV_ERR)
#define         MASK_DIAG_SC_ERR    (1ULL << (u8)BIT_DIAG_SC_ERR)

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sHousekeepIfInit(void);
extern void sHouseKeepInit(void);
extern void sHuoseKeepTask(void);
extern void sSoftStart(void);
//extern u64 sqwEventFlagGet (void);
extern void sEventFlagSet (u64 qwErrorbit);
extern void sEventFlagClear (u64 qwErrorbit);

extern void sFlushBuffer(void);

#endif /* HOUSEKEEP_H_ */
