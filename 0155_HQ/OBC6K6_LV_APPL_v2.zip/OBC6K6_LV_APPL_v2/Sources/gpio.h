/**
 * @file        Gpio.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef DEF_GPIO_H
#define DEF_GPIO_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "config.h"
#include "type.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


#if (BOARD_TARGET == BOARD_EVM)

#define TEST_PIN0_PTMUX                         PORTA
#define TEST_PIN0_PORT                          PTA
#define TEST_PIN0_INDEX                         13UL

#define TEST_PIN1_PTMUX                         PORTA
#define TEST_PIN1_PORT                          PTA
#define TEST_PIN1_INDEX                         0UL

#define TEST_PIN2_PTMUX                         PORTA
#define TEST_PIN2_PORT                          PTA
#define TEST_PIN2_INDEX                         10UL

#define TEST_PIN3_PTMUX                         PORTD
#define TEST_PIN3_PORT                          PTD
#define TEST_PIN3_INDEX                         10UL

#elif (BOARD_TARGET == BOARD_OBC_2IN1)

#define TEST_PIN0_PTMUX                         PORTA
#define TEST_PIN0_PORT                          PTA
#define TEST_PIN0_INDEX                         13UL

#define TEST_PIN1_PTMUX                         PORTE
#define TEST_PIN1_PORT                          PTE
#define TEST_PIN1_INDEX                         6UL

#define TEST_PIN2_PTMUX                         PORTA
#define TEST_PIN2_PORT                          PTA
#define TEST_PIN2_INDEX                         10UL

#define TEST_PIN3_PTMUX                         PORTD
#define TEST_PIN3_PORT                          PTD
#define TEST_PIN3_INDEX                         10UL

#elif (BOARD_TARGET == BOARD_APM)

#define TEST_PIN0_PTMUX                         PORTC
#define TEST_PIN0_PORT                          PTC
#define TEST_PIN0_INDEX                         14UL

#define TEST_PIN1_PTMUX                         PORTD
#define TEST_PIN1_PORT                          PTD
#define TEST_PIN1_INDEX                         5UL

#define TEST_PIN2_PTMUX                         PORTD
#define TEST_PIN2_PORT                          PTD
#define TEST_PIN2_INDEX                         6UL

#define TEST_PIN3_PTMUX                         PORTB
#define TEST_PIN3_PORT                          PTB
#define TEST_PIN3_INDEX                         2UL

#endif


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------


#define PACKED                                  __attribute__((__packed__))



//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------


typedef struct PACKED IF_DI_DATA_S
{
    e_bool_t            eLvdcScpDih;            // LVDC_SCP_DIH pin state
    e_bool_t            eLvdcOvpDih;            // LVDC_OVP_DIH pin state
    e_bool_t            eBoostOvpDih;           // BOOST_OVT_DIH pin state
    e_bool_t            eDspOkDih;              // DSP_OK_DIH pin state
    e_bool_t            eObcOkDih;              // OBC_OK_DIH pin state
    e_bool_t            eSbcIgnDih;             // SBC's IGN (IO0) state
    e_bool_t            eHwScpTriggered;        // LVDC_SCP_DIH interrupt assert
    e_bool_t            eHwOvpTriggered;        // LVDC_OVP_DIH interrupt assert
}x_if_di_t;



//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sGpioIfInit(void);
extern void sGpioInit(void);
extern void sGpioTask(void);
extern void PORTC_IRQHandler(void);
#endif

