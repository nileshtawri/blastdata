/**
 * @file        Obc.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_OBC_H
#define         DEF_OBC_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------


typedef enum OBC_STATE_E
{
    OBC_SLEEP = 0,
    OBC_POWER_ON,
    OBC_BOOTROM_START,
    OBC_BOOTROM_RUN,
    OBC_BOOTROM_END,
    OBC_APPL_START,
    OBC_APPL_RUN,
    OBC_APPL_END,
    OBC_POWER_OFF,
    #if 0
    OBC_TP_START,
    OBC_TP_DATA,
    OBC_TP_END,
    #endif
    OBC_STATE_UNKONW,
}obc_state_t;

typedef struct PACKED IF_OO_DATA_S
{
    obc_state_t         eObcState;
    u64                 qwObcErrorFlag;
    e_bool_t            eObcAuxEnDoh;
    e_bool_t            eDspResetDol;
    e_bool_t            eObcAuxUvCheck;
    e_bool_t            eDspBootModeDol;
    e_bool_t            eDspOkCheck;
}x_if_oo_t;


//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sObcIfInit(void);
extern void sObcInit(void);
extern void sObcStart(void);
extern void sObcStop(void);
extern void sObcTask(void);

#endif






