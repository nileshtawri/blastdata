/**
 * @file        evse.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "timer.h"
#include "gpio.h"
#include "can.h"
#include "nvm.h"
#include "user_config.h"
#include "housekeep.h"
#include "evse.h"
#include "adc.h"
#include "if.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define     CAP_CLOCK_HZ                (10UL * 1000 * 1000)  // 10MHz
#define     CAP_AVERAGE_TIME            10U
#define     CAP_CH_PILOT                0

#define     PERIOD_COUNT_MAX            (CAP_CLOCK_HZ / 500U)   // 500Hz
#define     PERIOD_COUNT_MIN            (CAP_CLOCK_HZ / 10000U) // 10KHz

#define     IMAX_GBT18487               63.0F
#define     IMAX_J1772                  80.0F
#define     IMAX_IEC61851_THREE_PHASE   63.0F
#define     IMAX_IEC61851_SINGLE_PHASE  70.0F

#define     DELAY_MS_CHECK_OBC_OK       10000U  // delay time to check OBC_OK_DIH

#define     DELAY_MS_CP_STABLE          500U

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------
static x_if_ei_t xIfEiData = 
{                                               // EVSE Charger Coupler status
    .eCpState       = EVSE_PILOT_STATE_A,
    .ePpState       = CON_DISCONNECTED,
    .eHavePulse     = BOOL_FALSE,
    .eObcOkCheck    = BOOL_FALSE,
    .flCpDuty       = 0.0F,                     // unit: 1%
    .flCpFreq       = 0.0F,
};

static x_if_eo_t xIfEoData = 
{                                               // EVSE Charger Coupler output signals
    .eCpReadyDoh    = BOOL_FALSE,               // EV is ready to charge
    .eCpState_D_Doh = BOOL_FALSE,               // STATE_D_DOH output pin control
    .eCpState_C_Doh = BOOL_FALSE,               // STATE_C_DOH output pin control
    .flEvseImax     = 0.0F,                     // EVSE's max current capacity
};

static bool blGotNewPulse = false;
static const x_if_ai_t *pxIfAi = NULL;      // point to IF_AI data
//static e_evse_std_t eChargeStandard = EVSE_STD_J1772;
static bool blVentilationReq = false;
static bool blObcCmdEnable = false;
static bool blJ1772Enable = true;

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/**
 * \brief to measure Control Pilot signal's duty and frequency
 */
static void sEvseCpDutyFreqMeasure(void)
{
    static u8 bAvgCnt = 0;
    static u32 dwPeriod;
    static u32 dwDuty;
    static u32 dwLastPulseTime = 0;
    f32 flPeriod;

    if (blJ1772Enable == true)
    {
        if (blGotNewPulse == true)
        {
            bAvgCnt++;
            bAvgCnt %= CAP_AVERAGE_TIME;

            dwLastPulseTime = OSIF_GetMilliseconds();

            if(bAvgCnt == 0)
            {
                f32 flPilotDuty;
                f32 flPilotFreq;

                /* polyspace-begin MISRA-C3:D1.1 "Conversion of integer to float" */
                flPeriod = (f32)dwPeriod / (f32)CAP_AVERAGE_TIME;

                if (flPeriod > (f32)PERIOD_COUNT_MAX)    // too slow
                {
                    flPilotFreq = (f32)(CAP_CLOCK_HZ / PERIOD_COUNT_MAX);
                    flPilotDuty = 0.0F;
                }
                else if (flPeriod < (f32)PERIOD_COUNT_MIN)   // too fast
                {
                    flPilotFreq = (f32)(CAP_CLOCK_HZ / PERIOD_COUNT_MIN);
                    flPilotDuty = 0.0F;
                }
                else                                // normal frequency
                {
                    flPilotFreq = (f32)CAP_CLOCK_HZ / flPeriod;
                    flPilotDuty = (f32)dwDuty / (f32)CAP_AVERAGE_TIME;
                    flPilotDuty /= flPeriod;
                    flPilotDuty *= 100.0F;           // unit is 1%
                }
                /* polyspace-end MISRA-C3:D1.1 "Conversion of integer to float" */

                dwPeriod = 0;
                dwDuty = 0;

                xIfEiData.flCpDuty = flPilotDuty;
                xIfEiData.flCpFreq = flPilotFreq;
                xIfEiData.eHavePulse = BOOL_TRUE;
            }

            dwPeriod += (u32)IC_GetMeasurement( &DrvCap_instance, 
                                                DrvCap_ChnConfig[0].hwChannelId);

            dwDuty += (u32)IC_GetMeasurement(   &DrvCap_instance, 
                                                DrvCap_ChnConfig[1].hwChannelId);
        }
        else
        {
            u32 dwCurrTick;

            dwCurrTick = OSIF_GetMilliseconds();
            bAvgCnt = 0;
            dwPeriod = 0;
            dwDuty = 0;
            
            if ((dwCurrTick - dwLastPulseTime) > 50U)
            {
                xIfEiData.flCpDuty = 0.0F;
                xIfEiData.flCpFreq = 0.0F;
                xIfEiData.eHavePulse = BOOL_FALSE;
            }
        }

        IC_DisableNotification(&DrvCap_instance, DrvCap_ChnConfig[0].hwChannelId);
        blGotNewPulse = false;
        IC_EnableNotification(&DrvCap_instance, DrvCap_ChnConfig[0].hwChannelId);
    }
    else
    {
        xIfEiData.flCpDuty = 0.0F;
        xIfEiData.flCpFreq = 0.0F;
        xIfEiData.eHavePulse = BOOL_FALSE;
    }

}

/**
 * \brief       check proximity signal status, update it to xIfEiData.ePpState,
 *              a bool value, xIfEiData.eDepresse, indicates user depresse the
 *              button of the charger coupler.
 */
static void sEvseProxStateDetect(void)
{
    f32 flProximityVolt = pxIfAi->flProxiVolt;
    static u32 dwNewStateTime = 0;
    u32 dwCurrTick;
    prox_state_t eCurrState;
    static prox_state_t eProxLastState;

    if (blJ1772Enable)
    {
        #if (EVSE_COUPLER_STD == EVSE_COUPLER_GBT18487)    // for China charger standard
            || (EVSE_COUPLER_STD == EVSE_COUPLER_IEC61851) // for EU charger standard

        if ((flProximityVolt >= 3.91F)
        	&& (flProximityVolt < 4.28F))       // depressed state (S3 open)
        {
        	eCurrState = CON_LATCH_DEPRESSED;
        }
        else if ((flProximityVolt >= 0.76F)
    		    && (flProximityVolt < 3.91F))   // release state (S3 close)
        {
        	eCurrState = CON_LATCH_RELEASED;
        }
        else                                    // disconnect state
        {
        	eCurrState = CON_DISCONNECTED;
        }

        #else                                   // for US J1772 charger standard

        if ((flProximityVolt >= 2.38F)
        	&& (flProximityVolt <= 3.16F))      // depressed state (S3 open)
        {
        	eCurrState = CON_LATCH_DEPRESSED;
        }
        else if((flProximityVolt >= 1.23F)
    		    && (flProximityVolt <= 1.82F))  // release state (S3 close)
        {
        	eCurrState = CON_LATCH_RELEASED;
        }
        else                                    // disconnect state
        {
        	eCurrState = CON_DISCONNECTED;
        }

        #endif

    }

    if (eCurrState != eProxLastState)           // if state is changing
    {
        dwNewStateTime = OSIF_GetMilliseconds();

        eProxLastState = eCurrState;
    }
    else
    {
        dwCurrTick = OSIF_GetMilliseconds();    // wait state is stable

        if ((dwCurrTick - dwNewStateTime) > 30U)
        {
            xIfEiData.ePpState = eCurrState;
        }
    }
}

/**
 * \brief   to detect Control Pilot signal is stable and ready
 *
 * \return  true or false
 */
static bool sEvseIsCpPpReadyAndStable(void)
{
    static bool blCpPpReadyLast = false;
    static u32 dwNewStateTime = 0;

    u32 dwCurrTick;
    bool blCpPpReady;
    bool blCpPpStable;
    pilot_state_t eCpStates = xIfEiData.eCpState;
    prox_state_t ePpState = xIfEiData.ePpState;
    bool blRet = false;

    if ((xIfEiData.eHavePulse == BOOL_TRUE)     // Pilot has pulse
        && (ePpState == CON_LATCH_RELEASED)     // Prox. is released (S3 close)
        && ((eCpStates == EVSE_PILOT_STATE_B)   // Pilot in state B
        || (eCpStates == EVSE_PILOT_STATE_C)))  // Pilot in state C
    {
        blCpPpReady = true;
    }
    else
    {
        blCpPpReady = false;
    }

    if (blCpPpReady == blCpPpReadyLast)
    {
        dwCurrTick = OSIF_GetMilliseconds();    // wait state is stable

        if ((dwCurrTick - dwNewStateTime) > DELAY_MS_CP_STABLE)
        {
            blCpPpStable = true;
        }
    }
    else
    {
        dwNewStateTime = OSIF_GetMilliseconds();

        blCpPpStable = false;
    }

    blRet = (blCpPpReady && blCpPpStable);

    if (blJ1772Enable == false)
    {
        blRet = false;
    }

    blCpPpReadyLast = blCpPpReady;

    return blRet;
}


/**
 * @brief   to check CP and PP state, and the request CAN command for OBC mode,
 *          to open(disable) or close(enable) S2 switch.
 */
static void sEvseVehicleReadyDetection(void)
{
    if (blJ1772Enable)
    {
        bool blCpAndPpIsReady;

        blCpAndPpIsReady = sEvseIsCpPpReadyAndStable();

        if (blCpAndPpIsReady)                       // check condiftion to close S2
        {
            if (blObcCmdEnable == true)             // CAN command is start charge
            {
                if (blVentilationReq == true)
                {
                    xIfEoData.eCpState_D_Doh = BOOL_TRUE;
                }
                else
                {
                    xIfEoData.eCpState_C_Doh = BOOL_TRUE;
                }

                xIfEoData.eCpReadyDoh = BOOL_TRUE;
            }
        }

        if (xIfEoData.eCpReadyDoh == BOOL_TRUE)     // check condiftion to open S2,
        {                                           // S2 is closed, and (S3 open or
            if ((blObcCmdEnable == false)           // CAN command is stop charging)
                || (xIfEiData.ePpState != CON_LATCH_RELEASED))
            {
                xIfEoData.eCpState_D_Doh = BOOL_FALSE;
                xIfEoData.eCpState_C_Doh = BOOL_FALSE;
                xIfEoData.eCpReadyDoh = BOOL_FALSE;
            }
        }
    }
    else                                            // if J1772 function disable
    {
        xIfEoData.eCpState_D_Doh = BOOL_FALSE;
        xIfEoData.eCpState_C_Doh = BOOL_FALSE;
        xIfEoData.eCpReadyDoh = BOOL_FALSE;
    }
}

/**
 * @brief       make a delay time to check OBC_OK_DIH,
 *              delay start condition is the S2 switch state from open to close
 */
static void sTimeToCheckObcOk(void)
{
    static e_bool_t eCpReadyLast = BOOL_FALSE;
    static u32 dwStartTime = 0;
    u32 dwCurrTick;

    if (xIfEoData.eCpReadyDoh == BOOL_TRUE)
    {
        if (eCpReadyLast == BOOL_FALSE)
        {
            dwStartTime = OSIF_GetMilliseconds();
        }

        dwCurrTick = OSIF_GetMilliseconds();

        if ((dwCurrTick - dwStartTime) >= DELAY_MS_CHECK_OBC_OK)
        {
            xIfEiData.eObcOkCheck = BOOL_TRUE;
        }
    }
    else
    {
        xIfEiData.eObcOkCheck = BOOL_FALSE;
    }

    eCpReadyLast = xIfEoData.eCpReadyDoh;
}


/**
 * @brief       Detect control pilot signal's state depend on its voltage
 */
static void sEvsePilotStateDetect(void)
{
    f32 flCpVolt = pxIfAi->flPilotVolt;

    if ((flCpVolt >= 8.36F)
    	&& (flCpVolt <= 9.59F))
    {
		xIfEiData.eCpState = EVSE_PILOT_STATE_B;
    }
    else if((flCpVolt >= 5.47F)
		&& (flCpVolt <= 6.53F))
    {
    	xIfEiData.eCpState = EVSE_PILOT_STATE_C;
    }
    else if((flCpVolt >= 2.58F)
		&& (flCpVolt <= 3.28F))
    {
    	xIfEiData.eCpState = EVSE_PILOT_STATE_D;
    }
    else if(flCpVolt <= -8.36F)
    {
    	xIfEiData.eCpState = EVSE_PILOT_STATE_F;
    }
    else
    {
    	xIfEiData.eCpState = EVSE_PILOT_STATE_A;
    }
}

/**
 * \brief   calculate EVSE' maxium output current, depend on Control pilot duty,
 *          (and cable code for EU/GB), then update it to xIfEoData.flEvseImax.
 *
 */
static void sEvseImax(void)
{
    f32 flCpDuty = xIfEiData.flCpDuty;
	u16 wCpDutyRange;

    /* polyspace-begin MISRA-C3:14.3 "always false", TODO: config by NVM */
    #if (EVSE_COUPLER_STD == EVSE_COUPLER_GBT18487)   // for China charger standard
    /* polyspace-end MISRA-C3:14.3 "always false", TODO: config by NVM */
    
    u16 wCableCapacity;

    if((flCpDuty >= 3.0F) && (flCpDuty <= 7.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_5;
	}
	else if((flCpDuty >= 8.0F) && (flCpDuty < 10.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10;
	}
	else if((flCpDuty >= 10.0F) && (flCpDuty <= 85.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10_85;
	}
	else if((flCpDuty > 85.0F) && (flCpDuty <= 90.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_85_9X;
	}
	else if((flCpDuty > 90.0F) && (flCpDuty <= 97.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_96;
	}
	else if(flCpDuty > 97.0F)
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_100;
	}
	else
	{
		wCpDutyRange = CP_DUTY_RANGE_INHIBIT;
	}

    switch(wCpDutyRange)
    {
        default:
        case CP_DUTY_RANGE_INHIBIT:
        case CP_DUTY_RANGE_PER_96:
        case CP_DUTY_RANGE_PER_100:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_5:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_10:
        	xIfEoData.flEvseImax = 6.0F;
        	break;

        case CP_DUTY_RANGE_PER_10_85:       // Imax = (% duty) * 0.6
        	xIfEoData.flEvseImax = flCpDuty * 0.6F;
        	break;

        case CP_DUTY_RANGE_PER_85_9X:       // Imax = (% duty - 64) * 2.5
        	xIfEoData.flEvseImax = (flCpDuty - 64.0F) * 2.5F;
        	break;
    }

    if(xIfEiData.ePpState == CON_LATCH_RELEASED)
    {
        f32 flProximityVolt = pxIfAi->flProxiVolt;

        if((flProximityVolt >= 3.42F)     // cable current code
    	    && (flProximityVolt < 3.91F))
        {
            wCableCapacity = 10U;
        }
        else if((flProximityVolt >= 2.49F)
    	    && (flProximityVolt < 3.42F))
        {
        	wCableCapacity = 16U;
        }
        else if((flProximityVolt >= 1.50F)
    	    && (flProximityVolt < 2.49F))
        {
            wCableCapacity = 32U;
        }
        else if((flProximityVolt >= 0.76F)
    	    && (flProximityVolt < 1.50F))
        {
            wCableCapacity = 63U;
        }
        else
        {
        	wCableCapacity = 0;
        }
    }

    if(xIfEoData.flEvseImax > (f32)wCableCapacity)
    {
        xIfEoData.flEvseImax = (f32)wCableCapacity;
    }

    if(xIfEoData.flEvseImax > IMAX_GBT18487)
    {
        xIfEoData.flEvseImax = IMAX_GBT18487;
    }
    
    /* polyspace-begin MISRA-C3:14.3 "always false", TODO: config by NVM */
    #elif (EVSE_COUPLER_STD == EVSE_COUPLER_IEC61851) // for EU charger standard
    /* polyspace-end MISRA-C3:14.3 "always false", TODO: config by NVM */

    u16 wCableCapacity;
    
    if((flCpDuty >= 3.0F) && (flCpDuty <= 7.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_5;
	}
	else if((flCpDuty >= 8.0F) && (flCpDuty < 10.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10;
	}
	else if((flCpDuty >= 10.0F) && (flCpDuty <= 85.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10_85;
	}
	else if((flCpDuty > 85.0F) && (flCpDuty <= 90.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_85_9X;
	}
	else if((flCpDuty > 90.0F) && (flCpDuty <= 97.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_96;
	}
	else if(flCpDuty > 97.0F)
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_100;
	}
	else
	{
		wCpDutyRange = CP_DUTY_RANGE_INHIBIT;
	}

    switch(wCpDutyRange)
    {
        default:
        case CP_DUTY_RANGE_INHIBIT:
        case CP_DUTY_RANGE_PER_96:
        case CP_DUTY_RANGE_PER_100:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_5:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_10:
        	xIfEoData.flEvseImax = 6.0F;
        	break;

        case CP_DUTY_RANGE_PER_10_85:       // Imax = (% duty) * 0.6
        	xIfEoData.flEvseImax = flCpDuty * 0.6F;
        	break;

        case CP_DUTY_RANGE_PER_85_9X:       // Imax = (% duty - 64) * 2.5
        	xIfEoData.flEvseImax = (flCpDuty - 64.0F) * 2.5F;
        	break;
    }

    if(xIfEiData.ePpState == CON_LATCH_RELEASED)
    {
        f32 flProximityVolt = pxIfAi->flProxiVolt;

        if((flProximityVolt >= 3.42F)     // cable current coding
    	    && (flProximityVolt < 3.91F)) // TODO: check current coding
        {
            wCableCapacity = 13U;
        }
        else if((flProximityVolt >= 2.49F) // TODO: check value
    	    && (flProximityVolt < 3.42F))
        {
        	wCableCapacity = 20U;
        }
        else if((flProximityVolt >= 1.50F) // TODO: check value
    	    && (flProximityVolt < 2.49F))
        {
            wCableCapacity = 32U;
        }
        else if((flProximityVolt >= 0.76F) // TODO: check value
    	    && (flProximityVolt < 1.50F))
        {
            wCableCapacity = 63U;
        }
        else
        {
        	wCableCapacity = 0;
        }
    }

    if(xIfEoData.flEvseImax > (f32)wCableCapacity)
    {
        xIfEoData.flEvseImax = (f32)wCableCapacity;
    }

    if(xIfEoData.flEvseImax > IMAX_IEC61851_SINGLE_PHASE)
    {
        xIfEoData.flEvseImax = IMAX_IEC61851_SINGLE_PHASE;
    }

    #else                                        // for J1772 US charger standard

    if((flCpDuty >= 3.0F) && (flCpDuty <= 7.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_5;
	}
	else if((flCpDuty >= 8.0F) && (flCpDuty < 10.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10;
	}
	else if((flCpDuty >= 10.0F) && (flCpDuty <= 85.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_10_85;
	}
	else if((flCpDuty > 85.0F) && (flCpDuty <= 96.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_85_9X;
	}
	else if((flCpDuty > 96.0F) && (flCpDuty <= 97.0F))
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_96;
	}
	else if(flCpDuty > 97.0F)
	{
		wCpDutyRange = CP_DUTY_RANGE_PER_100;
	}
	else
	{
		wCpDutyRange = CP_DUTY_RANGE_INHIBIT;
	}

    switch(wCpDutyRange)
    {
        default:
        case CP_DUTY_RANGE_INHIBIT:
        case CP_DUTY_RANGE_PER_100:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_5:
        	xIfEoData.flEvseImax = 0.0F;
        	break;

        case CP_DUTY_RANGE_PER_10:
        	xIfEoData.flEvseImax = 6.0F;
        	break;

        case CP_DUTY_RANGE_PER_10_85:       // Imax = (% duty) * 0.6
        	xIfEoData.flEvseImax = flCpDuty * 0.6F;
        	break;

        case CP_DUTY_RANGE_PER_85_9X:       // Imax = (% duty - 64) * 2.5
        	xIfEoData.flEvseImax = (flCpDuty - 64.0F) * 2.5F;
        	break;

        case CP_DUTY_RANGE_PER_96:
        	xIfEoData.flEvseImax = 80.0F;
        	break;
    }

    if(xIfEoData.flEvseImax > IMAX_J1772)
    {
        xIfEoData.flEvseImax = IMAX_J1772;
    }
    #endif

    if(xIfEoData.flEvseImax < 0.0F)
    {
        xIfEoData.flEvseImax = 0.0F;
    }

    if ((xIfEiData.eCpState != EVSE_PILOT_STATE_C)
        && (xIfEiData.eCpState != EVSE_PILOT_STATE_D))
    {
        xIfEoData.flEvseImax = 0.0F;
    }
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * \brief       to init IF_EI and IF_EO interface data pointer
 */
void sEvseIfInit(void)
{
    (void)sbIfSet(IF_EI, &xIfEiData);
    (void)sbIfSet(IF_EO, &xIfEoData);
}


/**
 * \brief       input capture callback function to detect no new pulse error
 */
/* polyspace-begin MISRA-C3:8.13 "pointer should point to a const-qualified type" */
void DrvCap_RisingEdgeCallback(ic_event_t event, void *userData)
/* polyspace-end MISRA-C3:8.13 "pointer should point to a const-qualified type" */
{
    (void)event;
    (void)userData;
    blGotNewPulse = true;
}

/**
 * \brief       to init input capture for control pilot detection
 */
void sEvseInit(void)
{
    status_t xStatus;
    x_conf_data_t *pxConf;

    sNvmConfDataPtrGet(&pxConf);
    blJ1772Enable = !(pxConf->baDisa[CONF_DISA_J1772] == (u8)'T');

    if (blJ1772Enable)
    {
        xStatus = IC_Init(&DrvCap_instance, &DrvCap_InitConfig); // init capture
        if(xStatus != STATUS_SUCCESS)
        {
            #if (HAVE_DEBUG_UART != 0)
    		DebugPrint("IC_Init failt %X\n", xStatus);
    		#endif
        }
    }

    /* polyspace-begin MISRA-C3:11.3 "different pointer type" */
    (void)sbIfGet(IF_AI, false, (const void**)&pxIfAi);
    /* polyspace-end MISRA-C3:11.3 "different pointer type" */
}


/**
 * \brief EVSE J1772 signal processing task
 */
void sEvseTask(void)
{
    sEvseCpDutyFreqMeasure();

    sEvseProxStateDetect();

    sEvsePilotStateDetect();

    sEvseVehicleReadyDetection();

    sTimeToCheckObcOk();

    sEvseImax();

    (void)sbIfSet(IF_EI, &xIfEiData);

    (void)sbIfSet(IF_EO, &xIfEoData);
}

/**
 * \brief       received command to turn on/off OBC, it will dicide to open
 *              close the S2 switch
 *
 * \param[in] blEnable  to enable OBC or not
 */
void sEvseObcEnableSet(bool blEnable)
{
    blObcCmdEnable = blEnable;
}

/**
 * \brief       received command to turn on/off EVSE's Ventilatio request
 *
 * \param[in] blVent  to enable or disable
 */
void sEvseVentReqSet(bool blVent)
{
    blVentilationReq = blVent;
}



