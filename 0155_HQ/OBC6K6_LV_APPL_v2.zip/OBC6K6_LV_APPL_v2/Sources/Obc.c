/**
 * @file        Obc.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "cpu.h"
#include "timer.h"
#include "gpio.h"
#include "can.h"
#include "nvm.h"
#include "user_config.h"
#include "housekeep.h"
#include "obc.h"
#include "if.h"
#include "DrvSci.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define C2K_LS7_ADDR    0x0000B800U             /* LS7 RAM address of C2K */

#define DELAY_MS_OBC_AUX                        50U
#define DELAY_MS_OBC_RST                        (DELAY_MS_OBC_AUX + 10U)
#define DELAY_MS_DSP_OK                         (DELAY_MS_OBC_RST + 20U)
#define DELAY_MS_BOOTROM                        (DELAY_MS_OBC_RST + 100U)
#define TIMEOUT_MS_BOOTROM                      1000U

#define HAVE_BYTE_SWAP                          // to swap BOOTROM data in words

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------

typedef struct PACKED C2K_BOOTROM_DATA_S        /* C2000 BOOTROM struct */
{
    uint16_t wKey;                              /* key value */
    uint16_t waReserved[8];                     /* not used */
    uint32_t dwEntryPoint;                      /* entry point */
    uint16_t wCaliDataLen;                      /* calibration data length */
    uint32_t dwCaliDataAddr;                    /* destination address */
    x_cali_data_t xCaliData;                    /* point to cali data */
    uint16_t wConfDataLen;                      /* configuration data length */
    uint32_t dwConfDataAddr;                    /* destination address */
    x_conf_data_t xConfData;                    /* point to conf data */
}c2k_bootrom_data_t;

//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------

#if 1                                           // c28x bootrom protocol
static void sObcBootromStart(void);
static void sObcBootromXfer(void);
static void sObcBootromEnd(void);
#endif

static void sObcPowerOn(void);
static void sObcPowerOff(void);

#if 0                                           // cancel bootrom protocol
static void sObcTpInit(void);
static void sObcTpData(void);
static void sObcTpEnd(void);
#endif

static void sObcApplStart(void);
static void sObcApplRun(void);
static void sObcApplEnd(void);



//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static obc_state_t eLastState = OBC_STATE_UNKONW;

static x_if_oo_t xIfOoData =
{
    .eObcState          = OBC_SLEEP,
    .qwObcErrorFlag     = 0ULL,
    .eObcAuxEnDoh       = BOOL_FALSE,
    .eDspResetDol       = BOOL_TRUE,
    .eObcAuxUvCheck     = BOOL_FALSE,
    .eDspBootModeDol    = BOOL_FALSE,
    .eDspOkCheck        = BOOL_FALSE,
};

static bool blC2kBootromFinish = false;
static bool blAutoBaudLocked = false;


static c2k_bootrom_data_t xC2kBootData;
static bool blC2kBootromFinish;
static u16 wBootromDataLen;
static u16 wBootromDataTxCnt;
static u8 bSciRxBuf;
static u16 wSciRxBuf;
static u16 wEchoData;

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/* SCI (UART0) Rx callback for continuous reception */
static void sSciRxCallback( void *driverState, 
                            uart_event_t event, 
                            void *userData)
{
    /* Unused parameters */
    (void)driverState;
    (void)userData;

    /* Check the event type */
    if (event == UART_EVENT_RX_FULL)
    {
        if (blAutoBaudLocked == false)
        {
            if (bSciRxBuf == (u8)'A')
            {
                blAutoBaudLocked = true;

                (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, (u8*)&wSciRxBuf, 2U);
            }
            else
            {
                (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, &bSciRxBuf, 1U);
            }
            
        }
        else
        {
            wEchoData = wSciRxBuf;

            (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, (u8*)&wSciRxBuf, 2U);
        }
    }
}

/* to initial SCI (UART0) interface, 
   change PTC3 (CP_READY_DOH) as UART TX pin, pin mux function 3,
   change PTC2 (OBC_OK_DIH) as UART RX pin, pin mux function 3, */
static void sSciInit(void)
{
    status_t xRet;

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_ALT4);
    
    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_ALT4);
    
    xRet = LPUART_DRV_Init( INST_DRVSCI, 
                            &DrvSci_State,
                            &DrvSci_InitConfig0);
    /*
    xRet |= EDMA_DRV_Init(  &dmaController1_State,
                            &DrvDma_InitConfig0,
                            edmaChnStateArray,
                            edmaChnConfigArray,
                            EDMA_CONFIGURED_CHANNELS_COUNT);
    */
    if (xRet != STATUS_SUCCESS)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("SCI INIT FAIL %X\n", xRet);
        #endif
    }

    (void)LPUART_DRV_SetRxBuffer(INST_DRVSCI, &bSciRxBuf, 1U);

    (void)LPUART_DRV_InstallRxCallback(INST_DRVSCI, sSciRxCallback, NULL);

}

/* disable SCI (UART0) interface, 
   change PTC3 (CP_READY_DOH) as GPIO, DO,
   change PTC2 (OBC_OK_DIH) as GPIO, DI */
static void sSciDeinit(void)
{
    (void)LPUART_DRV_Deinit(INST_DRVSCI);

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   CP_READY_DOH_PORT, 
                                CP_READY_DOH_PIN, 
                                (u8)GPIO_OUTPUT_DIRECTION);

    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_AS_GPIO);

    PINS_DRV_SetPinDirection(   OBC_OK_DIH_PORT, 
                                OBC_OK_DIH_PIN, 
                                (u8)GPIO_INPUT_DIRECTION);
}


/**
 * \brief   to power on OBC sub-module, and reset the PFC's MCU (DSP, F280049).
 *          
 */
static void sObcPowerOn(void)
{
    static u32 dwTickStart = 0;
    u32 dwTickCurr;

    if (eLastState != OBC_POWER_ON)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc aux pwr on\n");
        #endif

        dwTickStart = OSIF_GetMilliseconds();

        xIfOoData.eObcAuxEnDoh = BOOL_TRUE;

        #if (HVAE_C28X_BOOTROM != 0)

        xIfOoData.eDspBootModeDol = BOOL_TRUE;  // enable C28x's BOOTROM

        sSciInit();                             // init UART0 for C28x SCI

        #else

        xIfOoData.eDspBootModeDol = BOOL_FALSE; // disable C28x's BOOTROM

        #endif

        eLastState = xIfOoData.eObcState;
    }
    else
    {
        dwTickCurr = OSIF_GetMilliseconds();

        if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_AUX)
        {
            xIfOoData.eObcAuxUvCheck = BOOL_TRUE;

            if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_RST)
            {
                xIfOoData.eDspResetDol = BOOL_FALSE;

                #if (HVAE_C28X_BOOTROM != 0)

                if ((dwTickCurr - dwTickStart) >= DELAY_MS_BOOTROM)
                {
                    xIfOoData.eObcState = OBC_BOOTROM_START;
                }

                #else

                if ((dwTickCurr - dwTickStart) >= DELAY_MS_DSP_OK)
                {
                    xIfOoData.eDspOkCheck = BOOL_TRUE;

                    xIfOoData.eObcState = OBC_APPL_RUN;
                }
                #endif
            }
        }
    }
}


/**
 * \brief   to power off OBC sub-module, and stop OBC state machine
 *          
 */
static void sObcPowerOff(void)
{
    if (eLastState != OBC_POWER_OFF)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc aux pwr off\n");
        #endif

        xIfOoData.eDspResetDol = BOOL_TRUE;
        xIfOoData.eObcAuxEnDoh = BOOL_FALSE;
        xIfOoData.eDspOkCheck = BOOL_FALSE;
        xIfOoData.eObcAuxUvCheck = BOOL_FALSE;

        xIfOoData.eObcState = OBC_SLEEP;

        sTimerStop(TIMER_ID_OBC);
    }
    else
    {
        eLastState = OBC_POWER_OFF;
    }
}

static void sWordSwap(uint32 *pdwVal)
{
    u32 dwTmp;
    
    dwTmp = *pdwVal >> 16U;
    dwTmp |= *pdwVal << 16U;

    *pdwVal = dwTmp;
}


#ifdef HAVE_BYTE_SWAP
static void sByteSwap(uint16 *pwVal)
{
    u16 wTmp;
    
    wTmp = *pwVal >> 8U;
    wTmp |= *pwVal << 8U;

    *pwVal = wTmp;
}
#endif


/**
 * @brief       does calibration and configuration data send to C2K's BOOTROM?
 */
bool sblIsC2kBootromFinish(void)
{
    return blC2kBootromFinish;
}


/**
 * @brief   initial the xC2kBootData, it will send to C28x's BOOTROM
 */
static void sBootRomDataInit(void)
{
    u16 wLen;
    u16 i;

    #ifdef HAVE_BYTE_SWAP
    u16 *pwPtr;
    #endif

    xC2kBootData.wKey = 0x08AAU;
    for(i=0; i<8U; i++)
    {
        xC2kBootData.waReserved[i] = 0;
    }

    xC2kBootData.dwEntryPoint = 0x12345678U;    // test byte order
    sWordSwap(&xC2kBootData.dwEntryPoint);

    wLen = sizeof(x_cali_data_t);
    wLen = ((wLen%2U) != 0) ? ((wLen/2U)+1U) : wLen/2U;    
    xC2kBootData.wCaliDataLen = wLen;

    xC2kBootData.dwCaliDataAddr = C2K_LS7_ADDR;
    sWordSwap(&xC2kBootData.dwCaliDataAddr);

    sNvmCaliDataRead(&xC2kBootData.xCaliData);

    #ifdef HAVE_BYTE_SWAP
    pwPtr = (u16*)&xC2kBootData.xCaliData;
    for (i = 0; i < wLen; i++)
    {
        sByteSwap(pwPtr);
        pwPtr++;
    }
    #endif

    wLen = sizeof(x_conf_data_t);
    wLen = ((wLen%2U) != 0) ? ((wLen/2)+1U) : wLen/2U;
    xC2kBootData.wConfDataLen = wLen;

    xC2kBootData.dwConfDataAddr = C2K_LS7_ADDR + 0x400U;
    sWordSwap(&xC2kBootData.dwConfDataAddr);

    sNvmConfDataRead(&xC2kBootData.xConfData);

    #ifdef HAVE_BYTE_SWAP
    pwPtr = (u16*)&xC2kBootData.xConfData;
    for (i = 0; i < wLen; i++)
    {
        sByteSwap(pwPtr);
        pwPtr++;
    }
    #endif

    wLen = sizeof(c2k_bootrom_data_t);
    wBootromDataLen = ((wLen%2U) != 0) ? ((wLen/2)+1U) : wLen/2U;

    wBootromDataTxCnt = 0;
    blC2kBootromFinish = false;
}

/**
 * \brief   to initial the data structure for C28x BOOTROM protocol
 *          
 */
static void sObcBootromStart(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc boot start\n");
    #endif

    sBootRomDataInit();                         // init C28x SCI BOORTORM protocol data

    eLastState = OBC_BOOTROM_START;

    xIfOoData.eObcState = OBC_BOOTROM_RUN;

    sTimerPeriodSet(TIMER_ID_OBC, 1U);
    sTimerReset(TIMER_ID_OBC);
}

/**
 * \brief   transfer xC2kBootData to C28x BOOTROM,
 *          
 */
static void sObcBootromXfer(void)
{
    static u32 dwTickStart = 0;
    
    u32 dwTickCurr;

    if (eLastState != OBC_BOOTROM_RUN)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc boot xfer\n");
        #endif

        dwTickStart = OSIF_GetMilliseconds();
                
        wBootromDataTxCnt = 0;

        blAutoBaudLocked = false;

        eLastState = OBC_BOOTROM_RUN;
    }
    else
    {
        dwTickCurr = OSIF_GetMilliseconds();

        if(wBootromDataTxCnt >= wBootromDataLen)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("xfer done\n");
            #endif

            blC2kBootromFinish = true;

            xIfOoData.eObcState = OBC_BOOTROM_END;
        }
        else if((dwTickCurr - dwTickStart) >= TIMEOUT_MS_BOOTROM)
        {
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("boot xfer timeout !\n");
            #endif

            xIfOoData.eObcState = OBC_BOOTROM_END;
        }
        else if(blAutoBaudLocked == false)      // wait auto-baudrate lock
        {
            const u8 bChar = (u8)'A';

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, &bSciRxBuf, 1U);
            
            (void)LPUART_DRV_SendData(INST_DRVSCI, &bChar, 1U);
        }
        else
        {
            u16 *pwBuf;
            static u16 wTxBuf;                  // keep value for UART TX ISR
            bool blBootRomEchoFail = false;
            static u16 wLastSend = 0;

            pwBuf = (u16*)&xC2kBootData;
            wTxBuf = pwBuf[wBootromDataTxCnt];

            (void)LPUART_DRV_ReceiveData(INST_DRVSCI, (u8*)&wSciRxBuf, 2U); 

            (void)LPUART_DRV_SendData(INST_DRVSCI, (const u8*)&wTxBuf, 2U);
            
            #if (HAVE_DEBUG_UART != 0)
            DebugPrintf("SCI TX 0x%04X\n", wTxBuf);
            #endif

            if (wBootromDataTxCnt != 0)
            {
                if (wLastSend != wEchoData)          
                {
                    #if (HAVE_DEBUG_UART != 0)
                    DebugPrintf("SCI RX %d 0x%04X != 0x04X\n", 
                                wBootromDataTxCnt, 
                                wEchoData, 
                                wLastSend);
                    #endif

                    blBootRomEchoFail = true;
                }
            }

            wLastSend = wTxBuf;

            if (blBootRomEchoFail == true)
            {
                #if (HAVE_DEBUG_UART != 0)
                DebugPrintf("boot xfer error !\n");
                #endif

                xIfOoData.eObcState = OBC_BOOTROM_END;
            }
            else
            {
                wBootromDataTxCnt++;
            }
        }
    }
}

static void sObcBootromEnd(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc boot end\n");
    #endif

    sSciDeinit();

    xIfOoData.eDspResetDol = BOOL_TRUE;

    eLastState = OBC_BOOTROM_END;

    xIfOoData.eObcState = OBC_APPL_START;

    sTimerPeriodSet(TIMER_ID_OBC, 100U);
    sTimerReset(TIMER_ID_OBC);
}

#if 0
static void sObcTpInit(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc init can2\n");
    #endif

    xIfOoData.eObcAuxUvCheck = BOOL_TRUE;
    xIfOoData.eDspResetDol = BOOL_FALSE;

    eLastState = xIfOoData.eObcState;
}

static void sObcTpData(void)
{
    if(eLastState != xIfOoData.eObcState)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc tx tp data\n");
        #endif

        sTimerStart(TIMER_ID_CAN2_TP);

        eLastState = xIfOoData.eObcState;
    }
}

static void sObcTpEnd(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc tp end\n");
    #endif

    sTimerStop(TIMER_ID_CAN2_TP);

    // TODO: close isotp connection

    eLastState = xIfOoData.eObcState;
}
#endif


/**
 * \brief   to power on OBC sub-module, and reset the PFC's MCU (DSP, F280049).
 *          
 */
static void sObcApplStart(void)
{
    static u32 dwTickStart = 0;
    u32 dwTickCurr;

    if (eLastState != OBC_APPL_START)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc appl start\n");
        #endif

        dwTickStart = OSIF_GetMilliseconds();

        xIfOoData.eObcAuxEnDoh = BOOL_TRUE;
        xIfOoData.eDspBootModeDol = BOOL_FALSE; // disable C28x's BOOTROM

        eLastState = xIfOoData.eObcState;
    }
    else
    {
        dwTickCurr = OSIF_GetMilliseconds();

        if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_AUX)
        {
            xIfOoData.eObcAuxUvCheck = BOOL_TRUE;

            if ((dwTickCurr - dwTickStart) >= DELAY_MS_OBC_RST)
            {
                xIfOoData.eDspResetDol = BOOL_FALSE;

                if ((dwTickCurr - dwTickStart) >= DELAY_MS_DSP_OK)
                {
                    xIfOoData.eDspOkCheck = BOOL_TRUE;

                    xIfOoData.eObcState = OBC_APPL_RUN;
                }
            }
        }
    }
}

static void sObcApplRun(void)
{
//    static u32 dwTickStart = 0;
//    u32 dwTickCurr;

    if (eLastState != OBC_APPL_RUN)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("obc appl run\n");
        #endif

//        dwTickStart = OSIF_GetMilliseconds();

        eLastState = xIfOoData.eObcState;
    }
    else
    {
//        dwTickCurr = OSIF_GetMilliseconds();

//        xIfOoData.eObcState = OBC_APPL_END;
    }
}

static void sObcApplEnd(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc appl end\n");
    #endif

    xIfOoData.eDspOkCheck = BOOL_FALSE;
    
    xIfOoData.eDspResetDol = BOOL_TRUE;

    eLastState = OBC_APPL_END;

    xIfOoData.eObcState = OBC_POWER_OFF;
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * \brief   init IF_OO interface data pointer
 */
void sObcIfInit(void)
{
    (void)sbIfSet(IF_OO, &xIfOoData);
}

/**
 * \brief   init sObcTask internal data
 */
void sObcInit(void)
{
    #if (HAVE_DEBUG_UART != 0)
    DebugPrintf("obc init\n");
    #endif

    PINS_DRV_SetMuxModeSel( PORTC,
                            CP_READY_DOH_PIN, 
                            PORT_MUX_AS_GPIO);
    
    PINS_DRV_SetMuxModeSel( PORTC,
                            OBC_OK_DIH_PIN, 
                            PORT_MUX_AS_GPIO);

    eLastState = OBC_SLEEP;
}

/**
 * \brief   to star OBC sub-module, turn on OBC sub-module and enable sObcTask
 */
void sObcStart(void)
{
    eLastState = OBC_SLEEP;

    xIfOoData.eObcState = OBC_POWER_ON;

    (void)sbIfSet(IF_OO, &xIfOoData);

    sTimerStart(TIMER_ID_OBC);
}

/**
 * \brief   to stop OBC sub-module, turn off OBC sub-module and disable sObcTask
 */
void sObcStop(void)
{
    xIfOoData.eObcState = OBC_POWER_OFF;

    (void)sbIfSet(IF_OO, &xIfOoData);
}

/**
 * \brief   the main function to run OBC state machine
 */
void sObcTask(void)
{
    switch(xIfOoData.eObcState)
    {
        case OBC_SLEEP:
            ;
            break;

        case OBC_POWER_ON:
            sObcPowerOn();
            break;

        #if 0
        case OBC_TP_START:
            sObcTpInit();
            xIfOoData.eObcState = OBC_TP_DATA;
            break;

        case OBC_TP_DATA:
            sObcTpData();
            
            xIfOoData.eObcState = OBC_TP_END;
            break;

        case OBC_TP_END:
            sObcTpEnd();
            xIfOoData.eObcState = OBC_APPL_START;
            break;

        #else                                   // cancel bootrom protocol
        case OBC_BOOTROM_START:            
            sObcBootromStart();
            break;

        case OBC_BOOTROM_RUN:            
            sObcBootromXfer();
            break;

        case OBC_BOOTROM_END:            
            sObcBootromEnd();
            break;
        #endif

        case OBC_APPL_START:
            sObcApplStart();
            break;

        case OBC_APPL_RUN:
            sObcApplRun();
            break;

        case OBC_APPL_END:
            sObcApplEnd();
            break;

        case OBC_POWER_OFF:
            sObcPowerOff();
            break;

        default:
            ;
            break;
    }

    (void)sbIfSet(IF_OO, &xIfOoData);
}


