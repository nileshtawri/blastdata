
/**
 * @file        SafetyMeasure.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_SM_H
#define         DEF_SM_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------
#define ACCUMULATED_SIGNATURE_ID0_43            0x929940F1U
#define SCST_TEST_INTERRUPTED                   0xFF121212U
#define SCST_TEST_ITEM_END                      43U
#define SCST_STUCK_ERR                          0xCAFEBEEFU

#define TEST_INTERVAL_MS                        5U


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------
/* Linker defined variables used to copy initialized data from ROM to RAM */
/* polyspace-begin MISRA-C3:21.2 "reserved identifier or macro name" */
/* polyspace-begin MISRA-C3:8.11 "should be explicitly stated" */
extern uint32_t __SCST_DATA_ROM[];
extern uint32_t __SCST_DATA_SIZE[];
extern uint32_t __scst_data_start__[];
/* polyspace-end MISRA-C3:21.2 "reserved identifier or macro name" */
/* polyspace-end MISRA-C3:8.11 "should be explicitly stated" */

//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
extern void sTestTask(void);
extern void sIdleTask(void);

extern void sTestGetScstErrCode(u32 *pdwCnt);
extern void WDOG_EWM_IRQHandler(void);
#endif

