/**
 * @file        NetworkManagement.h
 * @copyright   Lite-On Technology Corp.
 */

#ifndef NETWORKMANAGEMENT_H_
#define NETWORKMANAGEMENT_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------
#define NM_EDU_ID                               0x0AU
#define NM_IMMEDIATE_NM_TIMES                   5U
#define NM_IMMEDIATE_CYCLE_TIME                 20U
#define NM_CYCLE_TIME                           100U
#define NM_START_APPL_FRAME_DELAY               20U
#define NM_REPEAT_MESSAGE_TIME                  1500U
#define NM_TIMEOUT_TIME                         2000U
#define NM_WAIT_BUS_SLEEP_TIME                  2000U
#define REPEAT_MESSAGE_REQUEST_BIT              0b00000001U
#define ACTIVE_WAKEUP_BIT                       0b00010000U

//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------
void sNmInit (void);
void sNmTimerProcess (void);
void sNmTask (void);
void sNmFrameTimeoutProcess (void);

u8 sbNmControlBitVectorGet (void);

void sNmApplFrameEnable (void);
void sNmApplFrameEnableSet (bool blEnable);
bool sblNmApplFrameEnableGet (void);
void sNmFrameEnableSet (bool blEnable);
bool sblNmFrameEnableGet (void);
bool sblPrepareBusSleepGet (void);
bool sblNmImmediateTransmitEnableGet (void);
u8 sbNmTransmitGet (void);
void sNmReleaseSet (bool blRelease);
void sNmImmediateFrameCount(void);
void sNmRxEventSet(void);
void sNmRepeatMessageReqSet(void);


#endif /* NETWORKMANAGEMENT_H_ */
