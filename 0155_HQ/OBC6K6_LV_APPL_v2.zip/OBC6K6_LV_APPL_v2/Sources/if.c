/**
 * @file        If.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"
#include "cpu.h"
#include "if.h"
#include "user_config.h"
#include "adc.h"
#include "housekeep.h"
#include "pwm.h"
#include "gpio.h"
#include "can.h"
#include "obc.h"
#include "evse.h"

#if (HAVE_DEBUG_UART != 0)
#include "uart.h"
#include "debug.h"
#endif


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal macro definition
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal type definitions
//------------------------------------------------------------------------------


typedef struct IF_S
{
    u16                 wSize;                  // data size (byte)
    const void          *pvData;                // point to the data address of producer module
    u32                 dwTimestamp;            // the timestamp (ms) when update
    u16                 wUpdateCycle;           // update timeout (ms), 0 is mean don't care
    u16                 wChecksum;              // checksum of (*pvData + dwTimestamp)
}x_if_t;

//------------------------------------------------------------------------------
// Internal function declaration
//------------------------------------------------------------------------------

static void swIfChecksum(const u8* pbBuf, u16 wLen, u32 dwTime, u16* pwCrc);


//------------------------------------------------------------------------------
// Internal variables
//------------------------------------------------------------------------------

static x_if_t xaIfTab[IF_NUM] =
{
    {                                           // IF_TEST
        (u16)sizeof(x_if_test_t),               // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        0,                                      // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_AI
        (u16)sizeof(x_if_ai_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        20U,                                    // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_CI0
        (u16)sizeof(x_if_ci0_t),                // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        100U,                                   // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_HO
        (u16)sizeof(x_if_ho_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        20U,                                    // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_CI2
        (u16)sizeof(x_if_ci2_t),                // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        100U,                                   // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_DI
        (u16)sizeof(x_if_di_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        20U,                                    // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_OO
        (u16)sizeof(x_if_oo_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        200U,                                   // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_EI
        (u16)sizeof(x_if_ei_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        20U,                                    // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
    {                                           // IF_EO
        (u16)sizeof(x_if_eo_t),                 // data size (bytes)
        NULL,                                   // point to data buffer
        0,                                      // update timestamp
        20U,                                    // update timeout time (ms)
        0,                                      // checksum or CRC16
    },
};

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

static void swIfChecksum(const u8* pbBuf, u16 wLen, u32 dwTime, u16* pwCrc)
{
    u32 dwCrcResult;
    crc_user_config_t xCrcConf;
    u32 dwTimeStamp = dwTime;

    (void)CRC_DRV_GetDefaultConfig(&xCrcConf);
    (void)CRC_DRV_Configure(INST_DRVCRC, &xCrcConf);

    CRC_DRV_WriteData(INST_DRVCRC, (const u8*)pbBuf, wLen);
    CRC_DRV_WriteData(INST_DRVCRC, (const u8*)&dwTimeStamp, 4U);

    dwCrcResult = CRC_DRV_GetCrcResult(INST_DRVCRC);
    *pwCrc = (u16)dwCrcResult;
}


//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------


/**
 * \brief   initial all interfaces' data pointer, prevent from sbIfGet() get
 *          un-initial data pointer
 */
void sbIfDataInit(void)
{
    sAdcIfInit();                               // init adc.c interface data
    sCanIfInit();                               // init can.c interface data
    sGpioIfInit();                              // init gpio.c interface data
    sObcIfInit();                               // init obc.c interface data
    sEvseIfInit();                              // init evse.c interface data
    sHousekeepIfInit();                         // init housekeep.c interface data
}



/**
 * \brief   update a data to the interface
 * \param[in]   eIfId   the ID of the interface, \e_if_id_t
 * \param[in]   pvData  point to input data buffer for new data
 * \return      return the error code of \e_if_err_t
 */
e_if_err_t sbIfSet(e_if_id_t eIfId, const void *pvData)
{
    e_if_err_t bRet = IF_ERR_NONE;
    
    if (eIfId < IF_NUM)
    {
        u16 wSize;
        u16 wCkSum;

        wSize = xaIfTab[eIfId].wSize;

        if (wSize == 0)
        {
            bRet = IF_ERR_SIZE;
        }
        else
        {
            xaIfTab[eIfId].dwTimestamp = OSIF_GetMilliseconds();

            xaIfTab[eIfId].pvData = pvData;

            swIfChecksum(   (const u8*)xaIfTab[eIfId].pvData, 
                            wSize, 
                            xaIfTab[eIfId].dwTimestamp,
                            &wCkSum);

            xaIfTab[eIfId].wChecksum = wCkSum;
        }
    }
    else
    {
        bRet = IF_ERR_ID;
    }

    if (bRet != IF_ERR_NONE)
    {
        #if (HAVE_DEBUG_UART != 0)
        DebugPrintf("sbIfSet %d err %d\n", eIfId, bRet);
        #endif
    }
    
    return bRet;
}

/**
 * \brief       read and check the data in an interface
 * \param[in]   eIfId   the ID of the interface, \e_if_id_t
 * \param[in]   blCheck does this Get function perform check any error event?
 * \param[out]  pvData  point to output data buffer for read data
 * \return      return the error code of \e_if_err_t
 */
e_if_err_t sbIfGet(e_if_id_t eIfId, bool blCheck, const void **pvData)
{
    e_if_err_t bRet = IF_ERR_NONE;

    if (blCheck)
    {
        if (eIfId < IF_NUM)
        {
            u16 wSize;
            u16 wCkSum;
            u32 dwTimeNow;
            u32 dwLastUpdate;
            u16 wTimeout;

            dwTimeNow = OSIF_GetMilliseconds();
            dwLastUpdate = xaIfTab[eIfId].dwTimestamp;
            wTimeout = xaIfTab[eIfId].wUpdateCycle;

            if (xaIfTab[eIfId].wSize == 0)
            {
                bRet = IF_ERR_SIZE;
            }
            else if (xaIfTab[eIfId].pvData == NULL)
            {
                bRet = IF_ERR_PTR;
            }
            else if (   (dwLastUpdate != 0)
                        && (wTimeout != 0)
                        && ((dwTimeNow - dwLastUpdate) > wTimeout))
            {
                bRet = IF_ERR_TIMEOUT;
            }
            else
            {
                wSize = xaIfTab[eIfId].wSize;

                swIfChecksum(   (const u8*)xaIfTab[eIfId].pvData, 
                                wSize, 
                                xaIfTab[eIfId].dwTimestamp,
                                &wCkSum);

                if (wCkSum != xaIfTab[eIfId].wChecksum)
                {
                    bRet = IF_ERR_CHKCKSUM;
                }
            }        
        }
        else
        {
            bRet = IF_ERR_ID;
        }
    }

    if (bRet != IF_ERR_NONE)
    {
        #if (HAVE_DEBUG_UART != 0)
        ; //DebugPrintf("sbIfGet %d err %d\n", eIfId, bRet);
        #endif
    }
    else
    {
        *pvData = xaIfTab[eIfId].pvData;       // return the pointer
    }
    
    return bRet;
}

