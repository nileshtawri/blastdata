

/**
 * @file        If.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_IF_H
#define         DEF_IF_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "type.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------



//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------

#define PACKED                                  __attribute__((__packed__))


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum IF_ID_E
{
    IF_TEST = 0,
    IF_AI,                                      // for xIfAiData in adc.c
    IF_CI0,                                     // for xIfCi0Data in can.c
    IF_HO,                                      // for xIfHoData in housekeep.c
    IF_CI2,                                     // for xIfCi2Data in can.c
    IF_DI,                                      // for xIfDiData in gpio.c
    IF_OO,                                      // for xIfOoData in obc.c
    IF_EI,                                      // for xIfEiData in evse.c
    IF_EO,                                      // for xIfEoData in evse.c
    IF_NUM,
}e_if_id_t;

typedef enum IF_ERR_E
{
    IF_ERR_NONE = 0,
    IF_ERR_ID,
    IF_ERR_SIZE,
    IF_ERR_PTR,
    IF_ERR_CHKCKSUM,
    IF_ERR_TIMEOUT,
}e_if_err_t;


typedef struct PACKED E2E_IF_TEST_S
{
    u8                  bTest;
    f32                 flTest;
}x_if_test_t;

typedef union
{
    u8  baBytes[sizeof(x_if_test_t)];
    x_if_test_t xIfTest;
}tu_test_t;

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------

extern void sbIfDataInit(void);
extern e_if_err_t sbIfSet(e_if_id_t eIfId, const void *pvData);
extern e_if_err_t sbIfGet(e_if_id_t eIfId, bool blCheck, const void **pvData);

#endif

