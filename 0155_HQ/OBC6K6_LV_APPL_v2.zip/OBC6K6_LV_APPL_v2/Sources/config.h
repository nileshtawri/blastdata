/**
 * @file        config.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_CONFIG_H
#define         DEF_CONFIG_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------


#define BOARD_EVM                               0U      /* EVM board */
#define BOARD_APM                               1U      /* APM 800V 3KW */
#define BOARD_OBC_2IN1                          2U      /* OBC 6K6W 2-in-1 */
#define BOARD_TARGET                            BOARD_EVM

#define EVSE_COUPLER_J1772                      0U
#define EVSE_COUPLER_IEC61851                   1U
#define EVSE_COUPLER_GBT18487                   2U
#define EVSE_COUPLER_STD                        EVSE_COUPLER_J1772


#ifndef HAVE_DEBUG_UART
#define HAVE_DEBUG_UART                         0U      /* UART debug function */
#endif

#ifndef HAVE_DEBUG_GPIO
#define HAVE_DEBUG_GPIO                         0U      /* GPIO debug pins */
#endif

#ifndef HAVE_SBC_FUNCTION
#define HAVE_SBC_FUNCTION                       1U      /* have SBC function */
#endif

#ifndef HVAE_TEST_MODE
#define HAVE_TEST_MODE                          1U      /* test mode for EE */
#endif

#ifndef HVAE_BOOST_FUNC
#define HVAE_BOOST_FUNC                         0U      /* have boost function */
#endif

#ifndef HVAE_C28X_BOOTROM
#define HVAE_C28X_BOOTROM                       1U      /* use c28x bootrom */
#endif

#ifndef HVAE_DEGBU_NM
#define HVAE_DEGBU_NM                           0U      /* add debug CAN msg for NM */
#endif


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

#define APM_VCMD_DEFAULT            13.8F       /* APM default output voltage */
#define APM_ICMD_DEFAULT            220.0F      /* APM default current limit */
#define APM_ICMD_MAX                230.0F      /* APM max output current */



//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------


#endif

