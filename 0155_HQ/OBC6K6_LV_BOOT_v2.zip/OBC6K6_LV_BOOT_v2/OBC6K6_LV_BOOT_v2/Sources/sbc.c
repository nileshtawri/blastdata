/**
 * @file        Sbc.c
 * @copyright   Lite-On Technology Corp.
 */

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include "Cpu.h"
#include "status.h"
#include "Sbc.h"

//------------------------------------------------------------------------------
// Public variables
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Internal function definitions
//------------------------------------------------------------------------------

/**
 * @brief       check error counter and then reelase FS0B pin
 */
status_t sbSbcFs0bCheck(void)
{
    status_t eRet;
    uint8_t bErrCount;

    eRet = FS45_GetFaultErrorCounterValue(&bErrCount);

    if((eRet == STATUS_SUCCESS) && (bErrCount == 0))
    {
    	eRet = FS45_ReleaseFSx(fs45ReleaseFs0b);
    }

    return eRet;
}

//------------------------------------------------------------------------------
// Public functions definitions
//------------------------------------------------------------------------------
/**
 * @brief       Initialize SBC
 */
status_t sSBCInitial(void)
{
    uint16_t wStatus = 0U;

    //Initial SPI
    LPSPI_DRV_MasterInit(LPSPICOM1, &lpspiCom1State, &lpspiCom1_MasterConfig0);

    wStatus = (uint16_t)FS45_Init(&sbc_fs45_InitConfig, LPSPICOM1, 50u);
    
    return (status_t)wStatus;
}

/**
 * \brief       Initialize SBC
 * \param[in]   bPinMask    
 * \param[out]  pblPin, point to input bool variable. true = high, false = low
 * \return      \enum status_t
 */
status_t sSbcReadIoPin(uint8_t bPinMask, bool *pblPin)
{
    fs45_rx_data_t xRxData;
    status_t xStatus;

    xStatus = FS45_ReadRegister(FS45_M_IO_INPUT_ADDR, &xRxData);

    if(xStatus == STATUS_SUCCESS)
    {
        *pblPin = ((xRxData.readData & bPinMask) != 0);
    }

    return xStatus;
}
