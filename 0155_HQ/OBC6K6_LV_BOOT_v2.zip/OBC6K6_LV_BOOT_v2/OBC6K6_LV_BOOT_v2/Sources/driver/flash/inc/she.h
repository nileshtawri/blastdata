/**
 * @file        she.h
 * @copyright   Lite-On Technology Corp.
 */
#ifndef         DEF_SHE_H
#define         DEF_SHE_H

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------
#include        "DrvCsec.h"

//------------------------------------------------------------------------------
// Constant definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Macro definitions
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Type definitions
//------------------------------------------------------------------------------

typedef enum xSheBootStatus_e
{
    SHE_BOOT_NO_TYPE = 0,
    SHE_BOOT_MAC_IS_EMPTY,
    SHE_BOOT_MAC_MISMATCH,
    SHE_BOOT_MAC_MATCH,
    SHE_BOOT_KEY_IS_EMPTY,
    SHE_BOOT_STATUS_UNKNOW,
}xSheBootStatus_t;

//------------------------------------------------------------------------------
// Public variables declaration
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// Public functions declaration
//------------------------------------------------------------------------------

void sbSheInit(void);

uint8_t sbSheBootModeSet(   uint32_t dwSize, 
                            csec_boot_flavor_t eMode, 
                            uint8_t *pbCmac);

uint8_t sbSheLoadKey(   csec_key_id_t ekeyId, 
                        uint8_t *pbKeyNew, 
                        uint8_t bCounter, 
                        bool blBootProtection);

#if 0
uint8_t sbMasterEcuKeyUpdate(   uint8_t bAuthKeyId,
                                const uint8_t* pbKeyBuf,
                                uint32_t dwCounter,
                                const uint8_t* pbUidBuf,
                                uint8_t *pbM4,
                                uint8_t *pbM5);
#endif

uint8_t sbSheSecureBootStautsGet(uint8_t* pbStatus);

uint8_t sbMasterEcuKeySet(void);

uint8_t sbSheMemoryUpdate(  csec_key_id_t ekeyId,
                            const uint8_t * m1,
                            const uint8_t * m2,
                            const uint8_t * m3,
                            uint8_t * m4,
                            uint8_t * m5);


uint8_t sbSheGetId( const uint8_t* pbChallenge,
                    uint8_t* pbUid,
                    uint8_t* pbSreg,
                    uint8_t* pbMac);

bool blIsSheMasterEcuKeyEmpty(void);

uint8_t sbSheGenerateRandomNumber(uint8_t *pbBuf);

uint8_t sbSheDecEcbByDefaultKey(const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout);

uint8_t sbSheDecEcbByUserKey1(  const uint8_t *pbCipherText,
                                uint32_t dwSize,
                                uint8_t *pbPlainText,
                                uint32_t dwTimeout);

uint8_t sbSheEncEcbByDefaultKey(const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout);


uint8_t sbSheEncEcbByUserKey1(  const uint8_t *pbPlainText,
                                uint32_t dwSize,
                                uint8_t *pbCipherText,
                                uint32_t dwTimeout);


#endif

