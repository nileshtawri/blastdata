
from datetime import datetime
from ctypes import *
import struct
import os
import sys
import yaml
# import ruamel.yaml as yaml
# from ruamel.yaml import YAML as yaml
from crccheck.crc import Crc16CcittFalse
# from crccheck.crc import Crc16Dnp
from uds_did import *

cali_yaml_file_name = 'ObcCali.yaml'
conf_yaml_file_name = 'ObcConf.yaml'

DATA_TYEP_CALIBRATION = 1
DATA_TYPE_CONFIGURATION = 2

target_address_cali_block = 0x0007F000
target_address_conf_block = 0x0007E000

ADC_GAIN_MIN = 0.5
ADC_GAIN_MAX = 1.5
ADC_OFFSET_MIN = -100.0
ADC_OFFSET_MAX = 100.0
VCMD_GAIN_MIN = 0.5
VCMD_GAIN_MAX = 1.5
VCMD_OFFSET_MIN = -10.0
VCMD_OFFSET_MAX = 10.0
ICMD_GAIN_MIN = 0.5
ICMD_GAIN_MAX = 1.5
ICMD_OFFSET_MIN = -50.0
ICMD_OFFSET_MAX = 50.0


conf_item_list = [['DSP_CAN_LOSS_MCU', CONF_ITEM_DSP_CAN_LOSS_MCU],
                  ['DSP_HV_OVP_SW', CONF_ITEM_DSP_HV_OVP_SW],
                  ['DSP_HV_OVP_HW', CONF_ITEM_DSP_HV_OVP_HW],
                  ['DSP_HV_UVP_SW', CONF_ITEM_DSP_HV_UVP],
                  ['DSP_HV_OCP_SW', CONF_ITEM_DSP_HV_OCP_SW],
                  ['DSP_HV_SCP_HW', CONF_ITEM_DSP_HV_OCP_HW],
                  ['DSP_GRID_OVP_SW', CONF_ITEM_DSP_GRID_OVP],
                  ['DSP_RMS_GRID_OVP_SW', CONF_ITEM_DSP_RMS_GRID_OVP],
                  ['DSP_RMS_GRID_UVP_SW', CONF_ITEM_DSP_RMS_GRID_UVP],
                  ['DSP_GRID_UFP_SW', CONF_ITEM_DSP_GRID_UFP],
                  ['DSP_GRID_OFP_SW', CONF_ITEM_DSP_GRID_OFP],
                  ['DSP_PFC_MOS_OCP_SW', CONF_ITEM_DSP_PFC_MOS_OCP],
                  ['DSP_LLC_OCP_HW', CONF_ITEM_DSP_LLC_OCP_HW],
                  ['DSP_PFC_OVP_HW', CONF_ITEM_DSP_PFC_OVP_HW],
                  ['DSP_BULK_OVP_SW', CONF_ITEM_DSP_BULK_OVP_SW],
                  ['DSP_BULK_UVP_SW', CONF_ITEM_DSP_BULK_UVP],
                  ['DSP_PFC_AUX_UVP_SW', CONF_ITEM_DSP_PFC_AUX_UVP],
                  ['DSP_PFC_AUX_OVP_SW', CONF_ITEM_DSP_PFC_AUX_OVP],
                  ['DSP_OTP_1', CONF_ITEM_DSP_OTP_1],
                  ['DSP_LLC_OTP', CONF_ITEM_DSP_LLC_OTP],
                  ['DSP_PFC_OTP', CONF_ITEM_DSP_PFC_OTP],
                  ['DSP_DIAG_HV_OVP_FAIL', CONF_ITEM_DSP_DIAG_HV_OVP],
                  ['DSP_DIAG_LLC_OCP_FAIL', CONF_ITEM_DSP_DIAG_LLC_OCP],
                  ['DSP_DIAG_HV_SCP_FAIL', CONF_ITEM_DSP_DIAG_HV_SCP],
                  ['DSP_DIAG_PFC_OVP_FAIL', CONF_ITEM_DSP_DIAG_PFC_OVP],
                  ['DSP_CMPSS_HV_OCP', CONF_ITEM_DSP_CMPSS_HV_OCP],
                  ['DSP_CMPSS_HV_OVP', CONF_ITEM_DSP_CMPSS_HV_OVP],
                  ['DSP_CMPSS_PFC_MOS_OCP', CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP],
                  ['DSP_CMPSS_PFC_AUX_OVP', CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP],
                  ['DSP_CMPSS_PFC_MOS_OTP', CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP],
                  ['DSP_CMPSS_LLC_MOS_OTP', CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP],
                  ['DSP_CMPSS_PFC_OVP', CONF_ITEM_DSP_CMPSS_PFC_OVP],
                  ['MCU_HV_AUX_UVP', CONF_ITEM_MCU_HV_AUX_UVP],
                  ['MCU_HV_AUX_OVP', CONF_ITEM_MCU_HV_AUX_OVP],
                  ['MCU_LV_OVP_SW', CONF_ITEM_MCU_LV_OVP_SW],
                  ['MCU_LV_OVP_HW', CONF_ITEM_MCU_LV_OVP_HW],
                  ['MCU_LV_UVP', CONF_ITEM_MCU_LV_UVP],
                  ['MCU_LV_AUX_UVP', CONF_ITEM_MCU_LV_AUX_UVP],
                  ['MCU_LV_AUX_OVP', CONF_ITEM_MCU_LV_AUX_OVP],
                  ['MCU_LV_OCP_HW', CONF_ITEM_MCU_LV_OCP_HW],
                  ['MCU_LV_OCP_SW', CONF_ITEM_MCU_LV_OCP_SW],
                  ['MCU_LV_OPP', CONF_ITEM_MCU_LV_OPP],
                  ['MCU_HV_OVP', CONF_ITEM_MCU_HV_OVP],
                  ['MCU_HV_UVP', CONF_ITEM_MCU_HV_UVP],
                  ['MCU_HV_OCP', CONF_ITEM_MCU_HV_OCP],
                  ['MCU_PCB_OTP', CONF_ITEM_MCU_PCB_OTP],
                  ['MCU_SR_OTP', CONF_ITEM_MCU_SR_OTP],
                  ['MCU_COOL_OTP', CONF_ITEM_MCU_COOLANT_OTP],
                  ['MCU_BAT_OVP', CONF_ITEM_MCU_BAT_OVP],
                  ['MCU_BAT_UVP', CONF_ITEM_MCU_BAT_UVP],
                  ['MCU_EVSE_CP_OFP', CONF_ITEM_MCU_EVSE_OFP],
                  ['MCU_EVSE_CP_UFP', CONF_ITEM_MCU_EVSE_UFP],
                  ['MCU_DIAG_LV_OVP_FAIL', CONF_ITEM_MCU_DIAG_OVP],
                  ['MCU_DIAG_LV_SCP_FAIL', CONF_ITEM_MCU_DIAG_SCP],
                  ['CONF_RESERVED_0', CONF_ITEM_RESERVED_0],
                  ['CONF_RESERVED_1', CONF_ITEM_RESERVED_1],
                  ['CONF_RESERVED_2', CONF_ITEM_RESERVED_2],
                  ['CONF_RESERVED_3', CONF_ITEM_RESERVED_3],
                  ['CONF_RESERVED_4', CONF_ITEM_RESERVED_4]]


def add_prot_record(ydata, item_name, param):
    """
    add protection YMAL data to ydata
    """
    # p = ConfParam.from_buffer(param)
    p = param
    ydata.update({item_name: []})
    ydata[item_name] = {'disable':       p.disable}
    ydata[item_name]['triggerPoint'] = p.trigger
    ydata[item_name]['resposeTime'] = p.t_time
    ydata[item_name]['recoveryPoint'] = p.recover
    ydata[item_name]['recoveryTime'] = p.r_time
    ydata[item_name]['retry'] = p.retry
    ydata[item_name]['retryLimit'] = p.limit
    ydata[item_name]['retryInterval'] = p.interval


def save_conf_yaml(byte_array=None):
    """
    convert configuration data byte_array to YAML file
    """
    if byte_array == None:                       # for test only
        with open('ObcConf.bin', 'rb') as file:
            binary_data = file.read()
            conf = ConfDataBlock.from_buffer(bytearray(binary_data))
    else:
        conf = ConfDataBlock.from_buffer(byte_array)

    conf_data = dict()
    conf_data.update({'SUB_FUNCTION': []})
    conf_data['SUB_FUNCTION'] = {
        'DISABLE_J1772': conf.func[CONF_DISA_J1772]}
    conf_data['SUB_FUNCTION']['DISABLE_DERATING'] = conf.func[CONF_DISA_DERATING]
    conf_data['SUB_FUNCTION']['DISABLE_PRECHARGE'] = conf.func[CONF_DISA_PRECHARGE]
    conf_data['SUB_FUNCTION']['DISABLE_DISCHARGE'] = conf.func[CONF_DISA_DISCHARGE]
    conf_data['SUB_FUNCTION']['DISABLE_NM'] = conf.func[CONF_DISA_NM]
    conf_data['SUB_FUNCTION']['DISABLE_CAN_WAKEUP'] = conf.func[CONF_DISA_CAN_WAKEUP]
    conf_data['SUB_FUNCTION']['DISABLE_RESERVED_1'] = conf.func[CONF_DISA_RESERVED_1]
    conf_data['SUB_FUNCTION']['DISABLE_RESERVED_2'] = conf.func[CONF_DISA_RESERVED_2]
    conf_data['SUB_FUNCTION']['DISABLE_RESERVED_3'] = conf.func[CONF_DISA_RESERVED_3]
    conf_data['SUB_FUNCTION']['DISABLE_RESERVED_4'] = conf.func[CONF_DISA_RESERVED_4]
    conf_data['SUB_FUNCTION']['DISABLE_RESERVED_5'] = conf.func[CONF_DISA_RESERVED_5]

    pdata = conf.prot[CONF_ITEM_DSP_CAN_LOSS_MCU]  # 0
    add_prot_record(conf_data, 'DSP_CAN_LOSS_MCU', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_HV_OVP_SW]  # 1
    add_prot_record(conf_data, 'DSP_HV_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_HV_UVP]  # 2
    add_prot_record(conf_data, 'DSP_HV_UVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_HV_OVP_HW]  # 3
    add_prot_record(conf_data, 'DSP_HV_OVP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_HV_OCP_HW]  # 4
    add_prot_record(conf_data, 'DSP_HV_SCP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_HV_OCP_SW]  # 5
    add_prot_record(conf_data, 'DSP_HV_OCP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_GRID_OVP]  # 6
    add_prot_record(conf_data, 'DSP_GRID_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_RMS_GRID_OVP]  # 7
    add_prot_record(conf_data, 'DSP_RMS_GRID_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_RMS_GRID_UVP]  # 8
    add_prot_record(conf_data, 'DSP_RMS_GRID_UVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_GRID_UFP]  # 9
    add_prot_record(conf_data, 'DSP_GRID_UFP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_GRID_OFP]  # 10
    add_prot_record(conf_data, 'DSP_GRID_OFP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_PFC_MOS_OCP]  # 11
    add_prot_record(conf_data, 'DSP_PFC_MOS_OCP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_LLC_OCP_HW]  # 12
    add_prot_record(conf_data, 'DSP_LLC_OCP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_PFC_OVP_HW]  # 13
    add_prot_record(conf_data, 'DSP_PFC_OVP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_BULK_OVP_SW]  # 14
    add_prot_record(conf_data, 'DSP_BULK_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_BULK_UVP]  # 15
    add_prot_record(conf_data, 'DSP_BULK_UVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_PFC_AUX_UVP]    # 16
    add_prot_record(conf_data, 'DSP_PFC_AUX_UVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_PFC_AUX_OVP]    # 17
    add_prot_record(conf_data, 'DSP_PFC_AUX_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_OTP_1]  # 18
    add_prot_record(conf_data, 'DSP_OTP_1', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_LLC_OTP]    # 19
    add_prot_record(conf_data, 'DSP_LLC_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_PFC_OTP]    # 20
    add_prot_record(conf_data, 'DSP_PFC_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_DIAG_HV_OVP]  # 21
    add_prot_record(conf_data, 'DSP_DIAG_HV_OVP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_DIAG_LLC_OCP]  # 22
    add_prot_record(conf_data, 'DSP_DIAG_LLC_OCP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_DIAG_HV_SCP]  # 23
    add_prot_record(conf_data, 'DSP_DIAG_HV_SCP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_DIAG_PFC_OVP]  # 24
    add_prot_record(conf_data, 'DSP_DIAG_PFC_OVP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_HV_OCP]  # 25
    add_prot_record(conf_data, 'DSP_CMPSS_HV_OCP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_HV_OVP]  # 26
    add_prot_record(conf_data, 'DSP_CMPSS_HV_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP]  # 27
    add_prot_record(conf_data, 'DSP_CMPSS_PFC_MOS_OCP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP]  # 28
    add_prot_record(conf_data, 'DSP_CMPSS_PFC_AUX_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP]  # 29
    add_prot_record(conf_data, 'DSP_CMPSS_PFC_MOS_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP]  # 30
    add_prot_record(conf_data, 'DSP_CMPSS_LLC_MOS_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_DSP_CMPSS_PFC_OVP]  # 31
    add_prot_record(conf_data, 'DSP_CMPSS_PFC_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_HV_AUX_UVP]  # 32
    add_prot_record(conf_data, 'MCU_HV_AUX_UVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_HV_AUX_OVP]  # 33
    add_prot_record(conf_data, 'MCU_HV_AUX_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_OVP_SW]  # 34
    add_prot_record(conf_data, 'MCU_LV_OVP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_UVP]  # 36 @
    add_prot_record(conf_data, 'MCU_LV_UVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_HV_OVP]  # 42 @
    add_prot_record(conf_data, 'MCU_HV_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_HV_UVP]  # 43 @
    add_prot_record(conf_data, 'MCU_HV_UVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_HV_OCP]  # 44 @
    add_prot_record(conf_data, 'MCU_HV_OCP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_AUX_UVP]  # 37 @
    add_prot_record(conf_data, 'MCU_LV_AUX_UVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_AUX_OVP]  # 38 @
    add_prot_record(conf_data, 'MCU_LV_AUX_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_OCP_SW]  # 40 @
    add_prot_record(conf_data, 'MCU_LV_OCP_SW', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_OVP_HW]  # 35 @
    add_prot_record(conf_data, 'MCU_LV_OVP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_OCP_HW]  # 39 @
    add_prot_record(conf_data, 'MCU_LV_OCP_HW', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_LV_OPP]  # 41 @
    add_prot_record(conf_data, 'MCU_LV_OPP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_PCB_OTP]  # 45
    add_prot_record(conf_data, 'MCU_PCB_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_SR_OTP]  # 46
    add_prot_record(conf_data, 'MCU_SR_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_COOLANT_OTP]  # 47
    add_prot_record(conf_data, 'MCU_COOL_OTP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_BAT_OVP]  # 48
    add_prot_record(conf_data, 'MCU_BAT_OVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_BAT_UVP]  # 49
    add_prot_record(conf_data, 'MCU_BAT_UVP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_EVSE_OFP]  # 50
    add_prot_record(conf_data, 'MCU_EVSE_CP_OFP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_EVSE_UFP]  # 51
    add_prot_record(conf_data, 'MCU_EVSE_CP_UFP', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_DIAG_OVP]  # 52
    add_prot_record(conf_data, 'MCU_DIAG_LV_OVP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_MCU_DIAG_SCP]  # 53
    add_prot_record(conf_data, 'MCU_DIAG_LV_SCP_FAIL', pdata)

    pdata = conf.prot[CONF_ITEM_RESERVED_0]  # 54
    add_prot_record(conf_data, 'CONF_RESERVED_0', pdata)

    pdata = conf.prot[CONF_ITEM_RESERVED_1]  # 55
    add_prot_record(conf_data, 'CONF_RESERVED_1', pdata)

    pdata = conf.prot[CONF_ITEM_RESERVED_2]  # 56
    add_prot_record(conf_data, 'CONF_RESERVED_2', pdata)

    pdata = conf.prot[CONF_ITEM_RESERVED_3]  # 57
    add_prot_record(conf_data, 'CONF_RESERVED_3', pdata)

    pdata = conf.prot[CONF_ITEM_RESERVED_4]  # 58
    add_prot_record(conf_data, 'CONF_RESERVED_4', pdata)

    conf_data.update({'DSP_KPKI_PARAM': []})
    conf_data['DSP_KPKI_PARAM'] = {
        'pfc_v_kp': conf.kpki[PARAM_PFC_V_KP]}
    conf_data['DSP_KPKI_PARAM']['pfc_v_ki'] = conf.kpki[PARAM_PFC_V_KI]
    conf_data['DSP_KPKI_PARAM']['pfc_i_kp'] = conf.kpki[PARAM_PFC_I_KP]
    conf_data['DSP_KPKI_PARAM']['pfc_i_ki'] = conf.kpki[PARAM_PFC_I_KI]
    conf_data['DSP_KPKI_PARAM']['pfc_max'] = conf.kpki[PARAM_PFC_MAX]
    conf_data['DSP_KPKI_PARAM']['pfc_min'] = conf.kpki[PARAM_PFC_MIN]
    conf_data['DSP_KPKI_PARAM']['pfc_gain'] = conf.kpki[PARAM_PFC_GAIN]
    conf_data['DSP_KPKI_PARAM']['pfc_io'] = conf.kpki[PARAM_PFC_IO]
    conf_data['DSP_KPKI_PARAM']['llc_v_kp'] = conf.kpki[PARAM_LLC_V_KP]
    conf_data['DSP_KPKI_PARAM']['llc_v_ki'] = conf.kpki[PARAM_LLC_V_KI]
    conf_data['DSP_KPKI_PARAM']['llc_i_kp'] = conf.kpki[PARAM_LLC_I_KP]
    conf_data['DSP_KPKI_PARAM']['llc_i_ki'] = conf.kpki[PARAM_LLC_I_KI]
    conf_data['DSP_KPKI_PARAM']['kpki_reserved_0'] = conf.kpki[PARAM_RESERVED_0]
    conf_data['DSP_KPKI_PARAM']['kpki_reserved_1'] = conf.kpki[PARAM_RESERVED_1]
    conf_data['DSP_KPKI_PARAM']['kpki_reserved_2'] = conf.kpki[PARAM_RESERVED_2]
    conf_data['DSP_KPKI_PARAM']['kpki_reserved_3'] = conf.kpki[PARAM_RESERVED_3]

    # print (conf_data)

    now = datetime.now()
    now_str = now.strftime("%Y%m%d_%H%M%S")
    fname = f'ObcConf_{now_str}.yaml'
    # fname = 'ObcConf_test.yaml'
    with open(fname, 'w') as file:  # dump YAML data to a file
        print(f'dump yaml data to {fname}')
        yaml.dump(conf_data,
                  file,
                  default_flow_style=False,
                  indent=4,
                  sort_keys=False)


def add_cali_record(ydata, item_name, param):
    """
    add a calibration item paramter to ydata
    """
    ydata.update({item_name: []})
    # ydata[item_name] = {'measure': [param.data[0], param.data[1]]}
    # ydata[item_name]['measure'][0] = param.data[0]
    # ydata[item_name]['measure'][0] = param.data[1]
    # ydata[item_name][0])+', '+str(param.data[1]) +']
    # ydata[item_name]['native'] = [param.data[2], param.data[3]]
    # ydata[item_name]['gain'] = param.data[4]
    # ydata[item_name]['offset'] = param.data[5]

    ydata[item_name] = {'gain': param.data[4]}
    ydata[item_name]['offset'] = param.data[5]
    ydata[item_name]['measure'] = [param.data[0], param.data[1]]
    ydata[item_name]['native'] = [param.data[2], param.data[3]]


def save_cali_yaml(byte_array=None):
    """
    convert calibration data byte_array to YAML file
    """
    if byte_array == None:                       # for test only
        with open('ObcCali.bin', 'rb') as file:
            binary_data = file.read()
            cali = CaliDataBlock.from_buffer(bytearray(binary_data))
    else:
        cali = CaliDataBlock.from_buffer(byte_array)

    cali_data = dict()
    add_cali_record(cali_data, 'apm_vout', cali.item[CALI_ITEM_LVDC_VOLT_ADC])
    add_cali_record(cali_data, 'apm_iout', cali.item[CALI_ITEM_LVDC_CURR_ADC])
    add_cali_record(cali_data, 'apm_vcmd', cali.item[CALI_ITEM_LVDC_VOLT_PWM])
    add_cali_record(cali_data, 'apm_icmd', cali.item[CALI_ITEM_LVDC_CURR_PWM])
    add_cali_record(cali_data, 'apm_vbat', cali.item[CALI_ITEM_BAT_VOLT_ADC])
    add_cali_record(cali_data, 'apm_vin',
                    cali.item[CALI_ITEM_HVDC_VOLT_APM_ADC])
    add_cali_record(cali_data, 'apm_iin',
                    cali.item[CALI_ITEM_HVDC_CURR_APM_ADC])
    add_cali_record(cali_data, 'obc_vout',
                    cali.item[CALI_ITEM_HVDC_VOLT_OBC_ADC])
    add_cali_record(cali_data, 'obc_iout',
                    cali.item[CALI_ITEM_HVDC_CURR_OBC_ADC])
    add_cali_record(cali_data, 'obc_vin', cali.item[CALI_ITEM_GRID_VOLT_ADC])
    add_cali_record(cali_data, 'obc_iin', cali.item[CALI_ITEM_GRID_CURR_ADC])
    add_cali_record(cali_data, 'obc_vbulk', cali.item[CALI_ITEM_BULK_VOLT_ADC])
    add_cali_record(cali_data, 'reserved_0', cali.item[CALI_ITEM_RESERVED_0])
    add_cali_record(cali_data, 'reserved_1', cali.item[CALI_ITEM_RESERVED_1])
    add_cali_record(cali_data, 'reserved_2', cali.item[CALI_ITEM_RESERVED_2])
    add_cali_record(cali_data, 'reserved_3', cali.item[CALI_ITEM_RESERVED_3])
    add_cali_record(cali_data, 'reserved_4', cali.item[CALI_ITEM_RESERVED_4])

    # print (cali_data)

    now = datetime.now()
    now_str = now.strftime("%Y%m%d_%H%M%S")
    fname = f'ObcCali_{now_str}.yaml'
    # fname = 'ObcCali_Test.yaml'
    with open(fname, 'w') as file:  # dump YAML data to a file
        print(f'dump yaml data to {fname}')
        yaml.dump(cali_data,
                  file,
                  default_flow_style=False,
                  indent=4,
                  sort_keys=False)


def load_conf_yaml_to_dict(sfunc, ydata, confData):
    try:
        # 2022.11 new type with good indenet
        confData.func[CONF_DISA_J1772] = sfunc['DISABLE_J1772']
        confData.func[CONF_DISA_DERATING] = sfunc['DISABLE_DERATING']
        confData.func[CONF_DISA_PRECHARGE] = sfunc['DISABLE_PRECHARGE']
        confData.func[CONF_DISA_DISCHARGE] = sfunc['DISABLE_DISCHARGE']
        confData.func[CONF_DISA_NM] = sfunc['DISABLE_NM']
        confData.func[CONF_DISA_CAN_WAKEUP] = sfunc['DISABLE_CAN_WAKEUP']
        confData.func[CONF_DISA_RESERVED_1] = sfunc['DISABLE_RESERVED_1']
        confData.func[CONF_DISA_RESERVED_2] = sfunc['DISABLE_RESERVED_2']
        confData.func[CONF_DISA_RESERVED_3] = sfunc['DISABLE_RESERVED_3']
        confData.func[CONF_DISA_RESERVED_4] = sfunc['DISABLE_RESERVED_4']
        confData.func[CONF_DISA_RESERVED_5] = sfunc['DISABLE_RESERVED_5']
        for i in range(len(conf_item_list)):
            protection = ydata[conf_item_list[i][0]]
            confData.prot[conf_item_list[i][1]] = (
                protection['disable'],
                protection['triggerPoint'],
                protection['resposeTime'],
                protection['recoveryPoint'],
                protection['recoveryTime'],
                protection['retry'],
                protection['retryLimit'],
                protection['retryInterval'],
            )
        param = ydata['DSP_KPKI_PARAM']
        confData.kpki[PARAM_PFC_V_KP] = param['pfc_v_kp']
        confData.kpki[PARAM_PFC_V_KI] = param['pfc_v_ki']
        confData.kpki[PARAM_PFC_I_KP] = param['pfc_i_kp']
        confData.kpki[PARAM_PFC_I_KI] = param['pfc_i_ki']
        confData.kpki[PARAM_PFC_MAX] = param['pfc_max']
        confData.kpki[PARAM_PFC_MIN] = param['pfc_min']
        confData.kpki[PARAM_PFC_GAIN] = param['pfc_gain']
        confData.kpki[PARAM_PFC_IO] = param['pfc_io']
        confData.kpki[PARAM_LLC_V_KP] = param['llc_v_kp']
        confData.kpki[PARAM_LLC_V_KI] = param['llc_v_ki']
        confData.kpki[PARAM_LLC_I_KP] = param['llc_i_kp']
        confData.kpki[PARAM_LLC_I_KI] = param['llc_i_ki']
        confData.kpki[PARAM_RESERVED_0] = param['kpki_reserved_0']
        confData.kpki[PARAM_RESERVED_1] = param['kpki_reserved_1']
        confData.kpki[PARAM_RESERVED_2] = param['kpki_reserved_2']
        confData.kpki[PARAM_RESERVED_3] = param['kpki_reserved_3']
        return confData
    except Exception as e:
        print("except")
        # print(e)
        sys.exit(e)  # Ricky add 防呆處理, 若有異常, 直接中斷離開此次命令呼叫


def load_conf_yaml():
    '''
    to convert a configuration YAML file to C data structure
    '''
    print(f'load configuration yaml file: {conf_yaml_file_name}')
    with open(conf_yaml_file_name, 'r') as file:
        ydata = yaml.full_load(file)

        # for item, doc in ydata.items():
        #    print(item, ":", doc)

    confData = ConfDataBlock()
    now = datetime.now()
    confData.header.tag = (c_ubyte * 2)(0x55, 0xAA)
    confData.header.size = sizeof(confData)
    confData.header.type = DATA_TYPE_CONFIGURATION
    confData.header.year = now.year
    confData.header.month = now.month
    confData.header.day = now.day
    confData.header.hour = now.hour
    confData.header.minute = now.minute
    confData.header.second = now.second
    confData.header.version = CONF_DATA_FORMAT_VERSION
    confData.header.writeCount = 0
    confData.header.crc16 = 0
    # initial data structure
    for i in range(CONF_DISA_NUMBER):
        confData.func[i] = c_ubyte(0)

    for i in range(CONF_ITEM_NUMBER):
        confData.prot[i].disable = c_ubyte(0)
        confData.prot[i].trigger = c_float(0.0)
        confData.prot[i].t_time = c_ushort(0)
        confData.prot[i].recover = c_float(0.0)
        confData.prot[i].r_time = c_ushort(0)
        confData.prot[i].retry = c_ubyte(0)
        confData.prot[i].limit = c_ushort(0)
        confData.prot[i].interval = c_ushort(0)

    for i in range(PARAM_NUMBER):
        confData.kpki[i] = c_float(0.0)
        # copy data from YAML
    sfunc = ydata['SUB_FUNCTION']
    load_conf_yaml_to_dict(sfunc, ydata, confData)

    head = bytearray(14)                        # compute new CRC
    rptr = (c_char * 14).from_buffer(head)
    memmove(rptr, byref(confData), 14)

    buf = bytearray(sizeof(confData)-16)
    rptr = (c_char * (sizeof(confData)-16)).from_buffer(buf)
    memmove(rptr, cast(addressof(confData)+16, c_void_p), (sizeof(confData)-16))
    # assign new CRC
    new_crc = Crc16CcittFalse.calc(head + buf)
    print(f'conf header crc is 0x{new_crc:04X}')

    confData.header.crc16 = new_crc

    temp_bin_name = conf_yaml_file_name.split('.')[0]
    temp_bin_name += '.bin'
    # output to a binary file
    with open(temp_bin_name, 'wb') as file:
        file.write(confData)

    # os.system("pause")
    return temp_bin_name


def load_cali_yaml():
    '''
    to convert a calibration YAML file to C data structure
    '''
    print(f'load calibration yaml file: {cali_yaml_file_name}')
    with open(cali_yaml_file_name, 'r') as file:
        ydata = yaml.full_load(file)

        # for item, doc in ydata.items():
        #    print(item, ":", doc)

    caliData = CaliDataBlock()

    now = datetime.now()

    try:

        caliData.header.tag = (c_ubyte * 2)(0x55, 0xAA)
        caliData.header.size = sizeof(caliData)
        caliData.header.type = DATA_TYEP_CALIBRATION
        caliData.header.year = now.year
        caliData.header.month = now.month
        caliData.header.day = now.day
        caliData.header.hour = now.hour
        caliData.header.minute = now.minute
        caliData.header.second = now.second
        caliData.header.version = CALI_DATA_FORMAT_VERSION
        caliData.header.writeCount = 0
        caliData.header.crc16 = 0
        # initial data structure
        for i in range(CALI_ITEM_NUMBER):
            caliData.item[i].data = (c_float * 6)(0, 0, 0, 0, 1.0, 0.0)

            # copy data from YAML
        caliData.item[CALI_ITEM_LVDC_VOLT_ADC].data = (
            ydata['apm_vout']['measure'][0],
            ydata['apm_vout']['measure'][1],
            ydata['apm_vout']['native'][0],
            ydata['apm_vout']['native'][1],
            ydata['apm_vout']['gain'],
            ydata['apm_vout']['offset']
        )
        if (ydata['apm_vout']['gain'] < ADC_GAIN_MIN) or \
            (ydata['apm_vout']['gain'] > ADC_GAIN_MAX) or \
            (ydata['apm_vout']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['apm_vout']['offset'] > ADC_OFFSET_MAX):
            print('Error! apm_vout gain/offset over range')
            return None

        '''
        print ('apm_vout YAML:')
        for f in caliData.item[CALI_ITEM_LVDC_VOLT_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_LVDC_CURR_ADC].data = (
            ydata['apm_iout']['measure'][0],
            ydata['apm_iout']['measure'][1],
            ydata['apm_iout']['native'][0],
            ydata['apm_iout']['native'][1],
            ydata['apm_iout']['gain'],
            ydata['apm_iout']['offset']
        )
        if (ydata['apm_iout']['gain'] < ADC_GAIN_MIN) or \
            (ydata['apm_iout']['gain'] > ADC_GAIN_MAX) or \
            (ydata['apm_iout']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['apm_iout']['offset'] > ADC_OFFSET_MAX):
            print('Error! apm_iout gain/offset over range')
            return None
        '''
        print ('apm_iout YAML:')
        for f in caliData.item[CALI_ITEM_LVDC_CURR_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_LVDC_VOLT_PWM].data = (
            ydata['apm_vcmd']['measure'][0],
            ydata['apm_vcmd']['measure'][1],
            ydata['apm_vcmd']['native'][0],
            ydata['apm_vcmd']['native'][1],
            ydata['apm_vcmd']['gain'],
            ydata['apm_vcmd']['offset']
        )
        if (ydata['apm_vcmd']['gain'] < VCMD_GAIN_MIN) or \
            (ydata['apm_vcmd']['gain'] > VCMD_GAIN_MAX) or \
            (ydata['apm_vcmd']['offset'] < VCMD_OFFSET_MIN) or \
                (ydata['apm_vcmd']['offset'] > VCMD_OFFSET_MAX):
            print('Error! apm_vcmd gain/offset over range')
            return None
        '''
        print ('apm_vcmd YAML:')
        for f in caliData.item[CALI_ITEM_LVDC_VOLT_PWM].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_LVDC_CURR_PWM].data = (
            ydata['apm_icmd']['measure'][0],
            ydata['apm_icmd']['measure'][1],
            ydata['apm_icmd']['native'][0],
            ydata['apm_icmd']['native'][1],
            ydata['apm_icmd']['gain'],
            ydata['apm_icmd']['offset']
        )
        if (ydata['apm_icmd']['gain'] < ICMD_GAIN_MIN) or \
            (ydata['apm_icmd']['gain'] > ICMD_GAIN_MAX) or \
            (ydata['apm_icmd']['offset'] < ICMD_OFFSET_MIN) or \
                (ydata['apm_icmd']['offset'] > ICMD_OFFSET_MAX):
            print('Error! apm_icmd gain/offset over range')
            return None
        '''
        print ('apm_icmd YAML:')
        for f in caliData.item[CALI_ITEM_LVDC_CURR_PWM].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_BAT_VOLT_ADC].data = (
            ydata['apm_vbat']['measure'][0],
            ydata['apm_vbat']['measure'][1],
            ydata['apm_vbat']['native'][0],
            ydata['apm_vbat']['native'][1],
            ydata['apm_vbat']['gain'],
            ydata['apm_vbat']['offset']
        )
        if (ydata['apm_vbat']['gain'] < ADC_GAIN_MIN) or \
            (ydata['apm_vbat']['gain'] > ADC_GAIN_MAX) or \
            (ydata['apm_vbat']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['apm_vbat']['offset'] > ADC_OFFSET_MAX):
            print('Error! apm_vbat gain/offset over range')
            return None
        '''
        print ('apm_vbat YAML:')
        for f in caliData.item[CALI_ITEM_BAT_VOLT_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_HVDC_VOLT_APM_ADC].data = (
            ydata['apm_vin']['measure'][0],
            ydata['apm_vin']['measure'][1],
            ydata['apm_vin']['native'][0],
            ydata['apm_vin']['native'][1],
            ydata['apm_vin']['gain'],
            ydata['apm_vin']['offset']
        )
        if (ydata['apm_vin']['gain'] < ADC_GAIN_MIN) or \
            (ydata['apm_vin']['gain'] > ADC_GAIN_MAX) or \
            (ydata['apm_vin']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['apm_vin']['offset'] > ADC_OFFSET_MAX):
            print('Error! apm_vin gain/offset over range')
            return None
        '''
        print ('apm_vin YAML:')
        for f in caliData.item[CALI_ITEM_HVDC_VOLT_APM_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_HVDC_CURR_APM_ADC].data = (
            ydata['apm_iin']['measure'][0],
            ydata['apm_iin']['measure'][1],
            ydata['apm_iin']['native'][0],
            ydata['apm_iin']['native'][1],
            ydata['apm_iin']['gain'],
            ydata['apm_iin']['offset']
        )
        if (ydata['apm_iin']['gain'] < ADC_GAIN_MIN) or \
            (ydata['apm_iin']['gain'] > ADC_GAIN_MAX) or \
            (ydata['apm_iin']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['apm_iin']['offset'] > ADC_OFFSET_MAX):
            print('Error! apm_iin gain/offset over range')
            return None
        '''
        print ('apm_iin YAML:')
        for f in caliData.item[CALI_ITEM_HVDC_CURR_APM_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_HVDC_VOLT_OBC_ADC].data = (
            ydata['obc_vout']['measure'][0],
            ydata['obc_vout']['measure'][1],
            ydata['obc_vout']['native'][0],
            ydata['obc_vout']['native'][1],
            ydata['obc_vout']['gain'],
            ydata['obc_vout']['offset']
        )
        if (ydata['obc_vout']['gain'] < ADC_GAIN_MIN) or \
            (ydata['obc_vout']['gain'] > ADC_GAIN_MAX) or \
            (ydata['obc_vout']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['obc_vout']['offset'] > ADC_OFFSET_MAX):
            print('Error! obc_vout gain/offset over range')
            return None
        '''
        print ('obc_vout YAML:')
        for f in caliData.item[CALI_ITEM_HVDC_VOLT_OBC_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_HVDC_CURR_OBC_ADC].data = (
            ydata['obc_iout']['measure'][0],
            ydata['obc_iout']['measure'][1],
            ydata['obc_iout']['native'][0],
            ydata['obc_iout']['native'][1],
            ydata['obc_iout']['gain'],
            ydata['obc_iout']['offset']
        )
        if (ydata['obc_iout']['gain'] < ADC_GAIN_MIN) or \
            (ydata['obc_iout']['gain'] > ADC_GAIN_MAX) or \
            (ydata['obc_iout']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['obc_iout']['offset'] > ADC_OFFSET_MAX):
            print('Error! obc_iout gain/offset over range')
            return None
        '''
        print ('obc_iout YAML:')
        for f in caliData.item[CALI_ITEM_HVDC_CURR_OBC_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_GRID_VOLT_ADC].data = (
            ydata['obc_vin']['measure'][0],
            ydata['obc_vin']['measure'][1],
            ydata['obc_vin']['native'][0],
            ydata['obc_vin']['native'][1],
            ydata['obc_vin']['gain'],
            ydata['obc_vin']['offset']
        )
        if (ydata['obc_vin']['gain'] < ADC_GAIN_MIN) or \
            (ydata['obc_vin']['gain'] > ADC_GAIN_MAX) or \
            (ydata['obc_vin']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['obc_vin']['offset'] > ADC_OFFSET_MAX):
            print('Error! obc_vin gain/offset over range')
            return None
        '''
        print ('obc_vin YAML:')
        for f in caliData.item[CALI_ITEM_GRID_VOLT_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_GRID_CURR_ADC].data = (
            ydata['obc_iin']['measure'][0],
            ydata['obc_iin']['measure'][1],
            ydata['obc_iin']['native'][0],
            ydata['obc_iin']['native'][1],
            ydata['obc_iin']['gain'],
            ydata['obc_iin']['offset']
        )
        if (ydata['obc_iin']['gain'] < ADC_GAIN_MIN) or \
            (ydata['obc_iin']['gain'] > ADC_GAIN_MAX) or \
            (ydata['obc_iin']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['obc_iin']['offset'] > ADC_OFFSET_MAX):
            print('Error! obc_iin gain/offset over range')
            return None
        '''
        print ('obc_iin YAML:')
        for f in caliData.item[CALI_ITEM_GRID_CURR_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_BULK_VOLT_ADC].data = (
            ydata['obc_vbulk']['measure'][0],
            ydata['obc_vbulk']['measure'][1],
            ydata['obc_vbulk']['native'][0],
            ydata['obc_vbulk']['native'][1],
            ydata['obc_vbulk']['gain'],
            ydata['obc_vbulk']['offset']
        )
        if (ydata['obc_vbulk']['gain'] < ADC_GAIN_MIN) or \
            (ydata['obc_vbulk']['gain'] > ADC_GAIN_MAX) or \
            (ydata['obc_vbulk']['offset'] < ADC_OFFSET_MIN) or \
                (ydata['obc_vbulk']['offset'] > ADC_OFFSET_MAX):
            print('Error! obc_vbulk gain/offset over range')
            return None
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_BULK_VOLT_ADC].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_RESERVED_0].data = (
            ydata['reserved_0']['measure'][0],
            ydata['reserved_0']['measure'][1],
            ydata['reserved_0']['native'][0],
            ydata['reserved_0']['native'][1],
            ydata['reserved_0']['gain'],
            ydata['reserved_0']['offset']
        )
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_RESERVED_0].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_RESERVED_1].data = (
            ydata['reserved_1']['measure'][0],
            ydata['reserved_1']['measure'][1],
            ydata['reserved_1']['native'][0],
            ydata['reserved_1']['native'][1],
            ydata['reserved_1']['gain'],
            ydata['reserved_1']['offset']
        )
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_RESERVED_1].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_RESERVED_2].data = (
            ydata['reserved_2']['measure'][0],
            ydata['reserved_2']['measure'][1],
            ydata['reserved_2']['native'][0],
            ydata['reserved_2']['native'][1],
            ydata['reserved_2']['gain'],
            ydata['reserved_2']['offset']
        )
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_RESERVED_2].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_RESERVED_3].data = (
            ydata['reserved_3']['measure'][0],
            ydata['reserved_3']['measure'][1],
            ydata['reserved_3']['native'][0],
            ydata['reserved_3']['native'][1],
            ydata['reserved_3']['gain'],
            ydata['reserved_3']['offset']
        )
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_RESERVED_3].data:
            print (f)
        '''
        caliData.item[CALI_ITEM_RESERVED_4].data = (
            ydata['reserved_4']['measure'][0],
            ydata['reserved_4']['measure'][1],
            ydata['reserved_4']['native'][0],
            ydata['reserved_4']['native'][1],
            ydata['reserved_4']['gain'],
            ydata['reserved_4']['offset']
        )
        '''
        print ('obc_vbulk YAML:')
        for f in caliData.item[CALI_ITEM_RESERVED_4].data:
            print (f)
        '''
    except Exception as e:
        print("except")
        # print(e)
        sys.exit(e)  # Ricky add 防呆處理, 若有異常, 直接中斷離開此次命令呼叫

    head = bytearray(14)
    rptr = (c_char * 14).from_buffer(head)
    memmove(rptr, byref(caliData), 14)

    buf = bytearray(sizeof(caliData)-16)
    rptr = (c_char * (sizeof(caliData)-16)).from_buffer(buf)
    memmove(rptr, cast(addressof(caliData)+16, c_void_p), (sizeof(caliData)-16))
    # assign new CRC
    new_crc = Crc16CcittFalse.calc(head + buf)
    print(f'cali header crc is 0x{new_crc:04X}')

    caliData.header.crc16 = new_crc

    temp_bin_name = cali_yaml_file_name.split('.')[0]
    temp_bin_name += '.bin'
    # output to a binary file
    with open(temp_bin_name, 'wb') as file:
        file.write(caliData)

    return temp_bin_name


def main():
    print('yaml2bin tool')

    # load_cali_yaml()
    # load_conf_yaml()
    # save_conf_yaml()
    save_cali_yaml()


if __name__ == '__main__':
    main()
