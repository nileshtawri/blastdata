#!/usr/bin/env python3
"""
test the Secure Hardwre Extensions (SHE) memory update protocol,

It is the test vector of the section 4.13.2.10 in AUTOSAR FO R19-11.
--------------------------------------------------------
KEYNEW              0f0e0d0c0b0a09080706050403020100
KEYAuthID           000102030405060708090a0b0c0d0e0f
KEY_UPDATE_ENC_C    010153484500800000000000000000b0
KEY_UPDATE_MAC_C    010253484500800000000000000000b0
UID‘                000000000000000000000000000001
ID                  4 (KEY_1)
AuthID              1 (MASTER_ECU_KEY)
CID‘                0000001
FID‘                0
K1                  118a46447a770d87828a69c222e2d17e
K2                  2ebb2a3da62dbd64b18ba6493e9fbe22
M1                  00000000000000000000000000000141
M2                  2b111e2d93f486566bcbba1d7f7a9797
                    c94643b050fc5d4d7de14cff682203c3
M3                  b9d745e5ace7d41860bc63c2b9f5bb46
K3                  ed2de7864a47f6bac319a9dc496a788f
K4                  ec9386fefaa1c598246144343de5f26a
M4                  00000000000000000000000000000141
                    b472e8d8727d70d57295e74849a27917
M5                  820d8d95dc11b4668878160cb2a4e23e
--------------------------------------------------------

It is the memory update protocol in the Figure 4.5 of AUTOSAR FO R19-11.
--------------------------------------------------------
K1 = KDF(KEYAuthID, KEY_UPDATE_ENC_C)
K2 = KDF(KEYAuthID, KEY_UPDATE_MAC_C)
M1 = UID' | ID | AuthID
M2 = ENCcbc,k1,iv=0(CID' | FID' | "0...0"95b | KID' )
M3 = CMACk2(M1 | M2)
--------------------------------------------------------

It is the memory update protocol in the Figure 4.6 of AUTOSAR FO R19-11.
--------------------------------------------------------
K3 = KDF(KEYID, KEY_UPDATE_ENC_C)
K4 = KDF(KEYID, KEY_UPDATE_MAC_C)
M4 = UID | ID | AuthID | ENCecb,k3(CID)
M5 = CMACk4(M4)
--------------------------------------------------------

KDF(K, C) is AES-MP(K | C), which state at section 4.3.3.1 key derivation,
AES-MP(x) : ENCecb,iv=0(x)0?
It is the test vector of the section 4.13.2.5 in AUTOSAR FO R19-11.
--------------------------------------------------------
K                   000102030405060708090a0b0c0d0e0f
C                   010153484500800000000000000000b0
KDerived            118a46447a770d87828a69c222e2d17e
--------------------------------------------------------
"""
from aes import AES
from cryptography.hazmat.primitives.cmac import CMAC
from cryptography.hazmat.primitives.ciphers import algorithms
from cryptography.hazmat import backends

KEYNEW =            '0f0e0d0c0b0a09080706050403020100'
KEYAuthID =         '000102030405060708090a0b0c0d0e0f'
KEY_UPDATE_ENC_C =  '010153484500800000000000000000b0'
KEY_UPDATE_MAC_C =  '010253484500800000000000000000b0'
UID =               '000000000000000000000000000001'
ID =                '4'         # KEY_1
AuthID =            '1'         # MASTER_ECU_KEY
CID =               '0000001'   # CID'  28 bits, (new counter value)
FID =               '0'         # FID'  5 bits, (key's flags)

K =                 '000102030405060708090a0b0c0d0e0f'
C =                 '010153484500800000000000000000b0'

def xor(x, y, z):
    i = 0
    out = bytearray(16)
    for i in range(len(x)):
        out[i] = x[i] ^ y[i] ^ z[i]
    return out

def aes_mp(k, c):
    if isinstance(k, str):
        k = bytes.fromhex(k)
    #print(f'K : {k.hex()}')
    
    if isinstance(c, str):
        c = bytes.fromhex(c)
    #print(f'C : {c.hex()}')
    
    out0 = bytes([0]*16)
    aes = AES(out0)
    out1 = aes.encrypt_block(k)
    out1 = xor(out1, k, out0)
    aes = AES(out1)
    out2 = aes.encrypt_block(c)
    out2 = xor(out2, c, out1)
    #print(f'out : {out2.hex()}')
    
    return out2

if __name__ == '__main__':

    aes_mp(K, C)                                # AES-MP key derivation test
        
    k1 = aes_mp(KEYAuthID, KEY_UPDATE_ENC_C)    #K1 = KDF(KEYAuthID, KEY_UPDATE_ENC_C)
    print(f'K1 : {k1.hex()}')
    
    k2 = aes_mp(KEYAuthID, KEY_UPDATE_MAC_C)    #K2 = KDF(KEYAuthID, KEY_UPDATE_MAC_C)
    print(f'K2 : {k2.hex()}')
    
    m1_str = UID + ID + AuthID
    m1 = bytes.fromhex(m1_str)                  #M1 = UID' | ID | AuthID
    print(f'M1 : {m1.hex()}')
    
    cf128 = 0
    cid = int(CID, base = 16) & 0x0FFFFFFF      # CID is 28 bits
    cf128 = cid << (128-28)
    fid = int(FID, base = 16) & 0x1F            # FID is 5 bits
    cf128 |= fid << (128-28-5)                  # ( CID | FID | 0..0 ) 128bits
    
    m2_str = f'{cf128:032X}' + KEYNEW           # M2plaintext = (CID|FID|0..0|KEYNEW) 256bits
    m2_plaintext = bytes.fromhex(m2_str)
    print(f'm2_plaintext : {m2_plaintext.hex()}')
    aes = AES(k1)
    iv = bytes([0]*16)
    m2 = aes.encrypt_cbc(m2_plaintext, iv)      #M2 = ENCcbc,k1,iv=0(M2plaintext)
    m2 = m2[0:32]
    print(f'M2 : {m2.hex()}')
    
    m3_str = m1.hex() + m2.hex()                #M3plaintext = M1 | M2 
    m3_plaintext = bytes.fromhex(m3_str)
    print(f'm3_plaintext : {m3_plaintext.hex()}')
    backend = backends.default_backend()
    cmac = CMAC(algorithms.AES(k2), backend)
    cmac.update(m3_plaintext)
    m3 = cmac.finalize()
    print(f'M3 : {m3.hex()}')
    
    k3 = aes_mp(KEYNEW, KEY_UPDATE_ENC_C)       #K3 = KDF(KEYID, KEY_UPDATE_ENC_C)
    print(f'K3 : {k3.hex()}')
    
    k4 = aes_mp(KEYNEW, KEY_UPDATE_MAC_C)       #K4 = KDF(KEYID, KEY_UPDATE_MAC_C)
    print(f'K4 : {k4.hex()}')
    
    cf128 = 0
    cid = int(CID, base = 16) & 0x0FFFFFFF      # CID (counter) is 28 bits
    cf128 = cid << (128-28)
    cf128 |= 1 << (128-28-1)                    # ( CID | '1' | 0..0 ) 128bits
    cid_str = f'{cf128:032X}'
    cid_plaintext = bytes.fromhex(cid_str)
    print(f'cid_plaintext : {cid_plaintext.hex()}')
    aes = AES(k3)
    m4p = aes.encrypt_block(cid_plaintext)
    print(f"M4' : {m4p.hex()}")

    m4_str = UID + ID + AuthID + m4p.hex()      #M4 = UID | ID | AuthID | M4'
    m4_plaintext = bytes.fromhex(m4_str)
    print(f'M4 : {m4_plaintext.hex()}')
    
    cmac = CMAC(algorithms.AES(k4), backend)
    cmac.update(m4_plaintext)
    m5 = cmac.finalize()                        #M5 = CMACk4(M4)
    print(f'M5 : {m5.hex()}')
    

    