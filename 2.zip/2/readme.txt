
OBC_6K6_2in1 Windows CLI tool
--------------------------------------------------------------------------------
Release Version                                 : V1.2
Release Date                                    : 20221226

(0) NOTE !! this tool needs related firmware version
    MCU's bootloader version require            : V0.2.0 ★☆★
    MCU's application version require           : V0.2.1+

(1) Include files
    main program                                : obc.exe
    flash driver                                : flash_api.bin
    OBC calibration file                        : ObcCali.yaml
    OBC configuration file                      : ObcConf.yaml
    input file for mew MCU application firmware : McuAppl.bin
    Hex/S19 file editor tool                    : srec_cat.exe
    OBC_DSP_Bootloader firmware (run in SRAM)   : OBC_400V_6k6_2in1_DSP_Bootloader.hex
    OBC_DSP_Application firmware                : OBC_400V_6k6_2in1.hex

(2) Cli Tool Output files
    binary file convert from ObcCali.yaml       : ObcCali.bin
    binary file convert from ObcConf.yaml       : ObcConf.bin
	
    
(3) Command list
    write calibration   to MCU & DSP  		: obc.exe write cali
    read calibration    to MCU & DSP  		: obc.exe read cali
    clear calibration   to MCU & DSP  		: obc.exe clear cali
    write configuration to MCU & DSP  		: obc.exe write conf
    read configuration  to MCU & DSP  		: obc.exe read conf

    reflash LV MCU's application firmware       : obc.exe reflash mcu
    update OBC_DSP's data via OBC MCU           : obc.exe reflash dspApp

    read dtc status                             : obc.exe read dtc status
    read dtc status number                      : obc.exe read dtc number
    read dtc detail status of the number        : obc.exe read snapshot 0x
    calean all dtc status                       : obc.exe clear dtc all	


(4) CLI tool source code repository
    \\Fls106\evps_rd\Repo_hg\OBC6K6_CLI_v2\     : rev. 60+


--------------------------------------------------------------------------------
Revision Information:
rev.    date.       changes
V1.2    20221226    1. 調整燒錄DSP Conf/Cali 的bin檔不再重複產生,
                       讓燒進 MCU & DSP 的 Conf/Cali 資料一致, CRC 一致
                    2. 增加PCAN Channel 選擇功能, 最多選到 Channel 6
                       在各命令後面新增命令, 如: -p 1,  -p 2, ...., -p 6
                    3. 燒錄時增加進度條以及計時秒數
                    4. 增加 Conf/Cali讀取時的防呆機制, 若有異常則直接跳掉程式
                       (呼叫 sys.exit 離開)

V1.1    20221115    1. revise the yaml file format of the read conf/cali 
                       for text-align the ":"
                    2. revise the write/read/clear function
                       not only to the MCU but also to the DSP
                       so this function time will be more 25 seconds

V1.0    20221102    1. add OBC_DSP_Bootloader function for update DSP App/Conf/Cali
                    2. add hex2bin_converter function for F28x format

V0.5    20220523    1. add more protection items to configuration data

V0.4    20220428    1. add DISABLE_CAN_WAKEUP configuration option

V0.3    20220408    1. add NM disable setting in configuration data
                    2. check the value range of calibraion gain/offset
                    3. add 'obc.exe clear cali' command to erase cali. data
                    4. add calibration.xlsx file
                    
V0.2    20220325    1. complete print data when read cali. or conf. data
                    2. dump a YAML file when read cali. or conf. data
                    
V0.1    20220318    first release