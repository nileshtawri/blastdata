
from ctypes import *
import struct
import udsoncan
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.client import Client
import udsoncan.configs
import isotp

CALI_DATA_FORMAT_VERSION = 1
CONF_DATA_FORMAT_VERSION = 1

''' DATA ID LIST '''
DID_CalData = 0xCADA
DID_SerialNumber = 0xF18C
DID_ConfData = 0xC0F1
DID_AppFinger = 0xF15A
DID_SecureBootStatus = 0xFF04

DID_ApmApplVer = 0xFE0A
DID_ApmBootVer = 0xFE0C
DID_ObcApplVer = 0xFE29
DID_ObcBootVer = 0xFE2B

DID_Snapshot = 0xC000


''' CALI_ITEM LIST '''
CALI_ITEM_LVDC_VOLT_ADC = 0                     # REMOTE_VOLT_ADC
CALI_ITEM_LVDC_CURR_ADC = 1                     # LVDC_CURR_ADC
CALI_ITEM_LVDC_VOLT_PWM = 2                     # LVDC_CVCC_VOLT_PWM
CALI_ITEM_LVDC_CURR_PWM = 3                     # LVDC_CVCC_CURR_PWM
CALI_ITEM_BAT_VOLT_ADC = 4                      # SBC_MUX_ADC
CALI_ITEM_HVDC_VOLT_APM_ADC = 5                 # HVDC_VOLT_ADC
CALI_ITEM_HVDC_CURR_APM_ADC = 6                 # APM_CURR_ADC
CALI_ITEM_HVDC_VOLT_OBC_ADC = 7                 # OBC_VOLT_ADC
CALI_ITEM_HVDC_CURR_OBC_ADC = 8                 # OBC_CURR_ADC
CALI_ITEM_GRID_VOLT_ADC = 9                     # AC_N/L_VOLT_ADC (RMS)
CALI_ITEM_GRID_CURR_ADC = 10                    # PFC_CSA_ADC x 4
CALI_ITEM_BULK_VOLT_ADC = 11                    # BULK_VOLT_ADC
CALI_ITEM_RESERVED_0 = 12                       # for further use
CALI_ITEM_RESERVED_1 = 13                       # for further use
CALI_ITEM_RESERVED_2 = 14                       # for further use
CALI_ITEM_RESERVED_3 = 15                       # for further use
CALI_ITEM_RESERVED_4 = 16                       # for further use
CALI_ITEM_NUMBER = 17


''' config Protection item list, it must the same as enum CONF_PROT_E '''
CONF_ITEM_DSP_CAN_LOSS_MCU = 0
CONF_ITEM_DSP_HV_OVP_SW = 1
CONF_ITEM_DSP_HV_OVP_HW = 2
CONF_ITEM_DSP_HV_UVP = 3
CONF_ITEM_DSP_HV_OCP_SW = 4
CONF_ITEM_DSP_HV_OCP_HW = 5
CONF_ITEM_DSP_GRID_OVP = 6
CONF_ITEM_DSP_RMS_GRID_OVP = 7
CONF_ITEM_DSP_RMS_GRID_UVP = 8
CONF_ITEM_DSP_GRID_UFP = 9
CONF_ITEM_DSP_GRID_OFP = 10
CONF_ITEM_DSP_PFC_MOS_OCP = 11
CONF_ITEM_DSP_LLC_OCP_HW = 12
CONF_ITEM_DSP_PFC_OVP_HW = 13
CONF_ITEM_DSP_BULK_OVP_SW = 14
CONF_ITEM_DSP_BULK_UVP = 15
CONF_ITEM_DSP_PFC_AUX_UVP = 16
CONF_ITEM_DSP_PFC_AUX_OVP = 17
CONF_ITEM_DSP_OTP_1 = 18
CONF_ITEM_DSP_LLC_OTP = 19
CONF_ITEM_DSP_PFC_OTP = 20
CONF_ITEM_DSP_DIAG_HV_OVP = 21
CONF_ITEM_DSP_DIAG_LLC_OCP = 22
CONF_ITEM_DSP_DIAG_HV_SCP = 23
CONF_ITEM_DSP_DIAG_PFC_OVP = 24
CONF_ITEM_DSP_CMPSS_HV_OCP = 25
CONF_ITEM_DSP_CMPSS_HV_OVP = 26
CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP = 27
CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP = 28
CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP = 29
CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP = 30
CONF_ITEM_DSP_CMPSS_PFC_OVP = 31
CONF_ITEM_MCU_HV_AUX_UVP = 32
CONF_ITEM_MCU_HV_AUX_OVP = 33
CONF_ITEM_MCU_LV_OVP_SW = 34
CONF_ITEM_MCU_LV_OVP_HW = 35
CONF_ITEM_MCU_LV_UVP = 36
CONF_ITEM_MCU_LV_AUX_UVP = 37
CONF_ITEM_MCU_LV_AUX_OVP = 38
CONF_ITEM_MCU_LV_OCP_HW = 39
CONF_ITEM_MCU_LV_OCP_SW = 40
CONF_ITEM_MCU_LV_OPP = 41
CONF_ITEM_MCU_HV_OVP = 42
CONF_ITEM_MCU_HV_UVP = 43
CONF_ITEM_MCU_HV_OCP = 44
CONF_ITEM_MCU_PCB_OTP = 45
CONF_ITEM_MCU_SR_OTP = 46
CONF_ITEM_MCU_COOLANT_OTP = 47
CONF_ITEM_MCU_BAT_OVP = 48
CONF_ITEM_MCU_BAT_UVP = 49
CONF_ITEM_MCU_EVSE_OFP = 50
CONF_ITEM_MCU_EVSE_UFP = 51
CONF_ITEM_MCU_DIAG_OVP = 52
CONF_ITEM_MCU_DIAG_SCP = 53
CONF_ITEM_RESERVED_0 = 54
CONF_ITEM_RESERVED_1 = 55
CONF_ITEM_RESERVED_2 = 56
CONF_ITEM_RESERVED_3 = 57
CONF_ITEM_RESERVED_4 = 58
CONF_ITEM_NUMBER = 59


''' config enable/disable item list '''
CONF_DISA_J1772 = 0             # to disable J1772 detection
CONF_DISA_DERATING = 1          # to disable derating function
CONF_DISA_PRECHARGE = 2         # to bypass pre-charge state
CONF_DISA_DISCHARGE = 3         # to bypass dis-charge state
CONF_DISA_NM = 4                # to disable NM function
CONF_DISA_CAN_WAKEUP = 5        # to disable CAN wakeup function
CONF_DISA_RESERVED_1 = 6
CONF_DISA_RESERVED_2 = 7
CONF_DISA_RESERVED_3 = 8
CONF_DISA_RESERVED_4 = 9
CONF_DISA_RESERVED_5 = 10
CONF_DISA_NUMBER = 11

''' config controller Kp/Ki item list '''
PARAM_PFC_V_KP = 0
PARAM_PFC_V_KI = 1
PARAM_PFC_I_KP = 2
PARAM_PFC_I_KI = 3
PARAM_PFC_MAX = 4
PARAM_PFC_MIN = 5
PARAM_PFC_GAIN = 6
PARAM_PFC_IO = 7
PARAM_LLC_V_KP = 8
PARAM_LLC_V_KI = 9
PARAM_LLC_I_KP = 10
PARAM_LLC_I_KI = 11
PARAM_RESERVED_0 = 12
PARAM_RESERVED_1 = 13
PARAM_RESERVED_2 = 14
PARAM_RESERVED_3 = 15
PARAM_NUMBER = 16

''' Calibration Parameters '''

class Header(LittleEndianStructure):
    '''
    C data structure for NVM date header
    '''
    _pack_ = 1
    _fields_ = [("tag",             c_ubyte * 2),
                ("size",            c_ushort),
                ("type",            c_ubyte),
                ("year",            c_ushort),
                ("month",           c_ubyte),
                ("day",             c_ubyte), 
                ("hour",            c_ubyte), 
                ("minute",          c_ubyte), 
                ("second",          c_ubyte),
                ("version",         c_ubyte),
                ("writeCount",      c_ubyte),
                ("crc16",           c_ushort)]
                
class CaliDataPoint(LittleEndianStructure):
    '''
    C data structure for calibration data parameters, six floating value.
    1. measure low,
    2. measure high,
    3. native low,
    4. native high,
    5. gain,
    6. offset
    '''
    _pack_ = 1
    _fields_ = [("data",            c_float * 6)]
    
class CaliDataBlock(LittleEndianStructure):
    '''
    C data structure for calibration date block, i.e., Header + CaliDataPoint
    '''
    _pack_ = 1
    _fields_ = [("header",          Header),
                ("item",            CaliDataPoint * CALI_ITEM_NUMBER)]
                
class VersionNumber(LittleEndianStructure):
    '''
    C data structure for firmware version number
    '''
    _pack_ = 1
    _fields_ = [("Major",           c_ubyte),
                ("Minor",           c_ubyte),
                ("Debug",           c_ubyte),
                ("BuildId",         c_ubyte)]


class DiagDid_VersionNumber(udsoncan.DidCodec):
    def encode(self, verData):                   # copy bytes to Python from a ctypes.Structure
        return verData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        verData = VersionNumber()
        fit = min(len(bytes), sizeof(VersionNumber))
        memmove(addressof(verData), bytes, fit)
        return verData

    def __len__(self):
        return sizeof(VersionNumber)            # encoded paylaod size


class DiagDid_CalParameter(udsoncan.DidCodec):
    def encode(self, calData):                  # copy bytes to Python from a ctypes.Structure
        return calData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        calData = CaliDataBlock()
        fit = min(len(bytes), sizeof(CaliDataBlock))
        memmove(addressof(calData), bytes, fit)
        return calData

    def __len__(self):
        return sizeof(CaliDataBlock)            # encoded paylaod size

class SerialNumber(LittleEndianStructure):
    _fields_ = [("SnString", c_byte * 16)]

class DiagDid_SerialNumber(udsoncan.DidCodec):
    def encode(self, SnData):                   # copy bytes to Python from a ctypes.Structure
        return SnData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        snStr = SerialNumber()
        fit = min(len(bytes), sizeof(SerialNumber))
        memmove(addressof(snStr), bytes, fit)
        return snStr

    def __len__(self):
        return sizeof(SerialNumber)             # encoded paylaod is 4 byte long.
        
        
class SecureBootStatus(LittleEndianStructure):
    _fields_ = [("SecureBootStatus", c_byte)]

class DiagDid_SecureBootStatus(udsoncan.DidCodec):
    def encode(self, Status):                   # copy bytes to Python from a ctypes.Structure
        return Status

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        Status = SecureBootStatus()
        fit = min(len(bytes), sizeof(Status))
        memmove(addressof(Status), bytes, fit)
        return Status

    def __len__(self):
        return sizeof(SecureBootStatus)         # encoded paylaod is 4 byte long.
        
                
class ConfParam(LittleEndianStructure):
    '''
    C data structure for configuration data parameters
    1. disable  ==> bDisableSetting
    2. trigger  ==> flTriggerPoint
    3. t_time   ==> wResponseTime
    4. recover  ==> flRecoveryPoint
    5. r_time   ==> wRecoveryTime
    6. retry    ==> bEnableRetry
    7. limit    ==> wRetryLimit
    8. interval ==> wRetryInterval
    '''
    _pack_ = 1
    _fields_ = [("disable",             c_ubyte),
                ("trigger",             c_float),
                ("t_time",              c_ushort),
                ("recover",             c_float),
                ("r_time",              c_ushort),
                ("retry",               c_ubyte),
                ("limit",               c_ushort),
                ("interval",            c_ushort),]
    
class ConfDataBlock(LittleEndianStructure):
    '''
    C data structure for calibration date block, i.e., Header + CaliDataPoint
    '''
    _pack_ = 1
    _fields_ = [("header",              Header),
                ("func",                c_ubyte * CONF_DISA_NUMBER),
                ("prot",                ConfParam * CONF_ITEM_NUMBER),
                ("padding",             c_ubyte),
                ("kpki",                c_float * PARAM_NUMBER)]

class DiagDid_ConfData(udsoncan.DidCodec):
    def encode(self, ConfData):                 # copy bytes to Python from a ctypes.Structure
        return ConfData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        confData = ConfDataBlock()
        fit = min(len(bytes), sizeof(ConfDataBlock))
        memmove(addressof(confData), bytes, fit)
        return confData

    def __len__(self):
        return sizeof(ConfDataBlock)            # get paylaod size

class ApplFingerPrintData(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("ApplFp",          c_ubyte * 2),]
       
class DiagDid_AppFingerPrint(udsoncan.DidCodec):
    def encode(self, fpData):                   # copy bytes to Python from a ctypes.Structure
        return fpData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        fpData = ApplFingerPrintData()
        fit = min(len(bytes), sizeof(ApplFingerPrintData))
        memmove(addressof(fpData), bytes, fit)
        return fpData

    def __len__(self):
        return sizeof(ApplFingerPrintData)      # get paylaod size
        
class SnapshotRecordData(LittleEndianStructure):
    '''
    C data structure for DID_0xC000, snapshot record
    
    '''
    _pack_ = 1
    _fields_ = [("wYear",               c_ushort),
                ("bMonth",              c_ubyte),
                ("bDay",                c_ubyte), 
                ("bHour",               c_ubyte), 
                ("bMinute",             c_ubyte), 
                ("bSecond",             c_ubyte),
                ("b100ms",              c_ubyte),
                
                ("bApmIgnStatus",       c_ubyte),
                ("bHvAuxEnStatus",      c_ubyte),
                ("bApmModeCmd",         c_ubyte),
                ("bApmWorkMode",        c_ubyte),
                ("flLvdcVcmd",          c_float),
                ("flLvdcIcmd",          c_float),
                ("flLvIoutLimit",       c_float),
                ("qwApmErrorFlag",      c_ulonglong),
                ("flApmHvdcVolt",       c_float),
                ("flApmHvdcCurr",       c_float),
                ("flApmLvdcVolt",       c_float),
                ("flApmLvdcCurr",       c_float),
                ("flApmTempPcb",        c_float),
                ("flApmTempSr",         c_float),
                ("flApmTempCool",       c_float),
                ("flApmLvAuxVolt",      c_float),
                ("flApmBatVolt",        c_float),

                ("bObcModeCmd",         c_ubyte),
                ("bObcWorkMode",        c_ubyte),
                ("flHvdcVcmd",          c_float),
                ("flHvdcIcmd",          c_float),
                ("qwObcErrorFlag",      c_ulonglong),
                ("flObcPfcAuxVolt",     c_float),
                ("flObcPfcCurrA",       c_float),
                ("flObcPfcCurrB",       c_float),
                ("flObcPfcCurrC",       c_float),
                ("flObcPfcCurrD",       c_float),
                ("flObcGridVolt",       c_float),
                ("flObcGridCurr",       c_float),
                ("flObcGridFreq",       c_float),
                ("flObcHvdcVolt",       c_float),
                ("flObcHvdcCurr",       c_float),
                ("flObcBulkVolt",       c_float),
                ("flObcHvVoltRef",      c_float),
                ("flObcHvCurrRef",      c_float),
                ("flObcCtrlTheta",      c_float),
                ("flObcCtrlFreq",       c_float),
                ("flObcTempLlc",        c_float),
                ("flObcTempPfc",        c_float),

                ("flEvseProxVolt",      c_float),
                ("flEvsePilotVolt",     c_float),
                ("flEvsePilotDuty",     c_float),
                ("flEvseImax",          c_float),
                ("bS2Status",           c_ubyte),]
                
class DiagDid_Snapshot(udsoncan.DidCodec):
    def encode(self, fpData):                   # copy bytes to Python from a ctypes.Structure
        return fpData

    def decode(self, bytes):                    # copy bytes to a ctypes.Structure from Python
        fpData = SnapshotRecordData()
        fit = min(len(bytes), sizeof(SnapshotRecordData))
        memmove(addressof(fpData), bytes, fit)
        return fpData

    def __len__(self):
        return sizeof(SnapshotRecordData)       # get paylaod size
            
DidCfg = dict(udsoncan.configs.default_client_config)
DidCfg['data_identifiers'] = \
{
    DID_CalData         : DiagDid_CalParameter(),   # DID for calibration data encode/decode
    DID_SerialNumber    : DiagDid_SerialNumber(),   # DID for serial number encode/decode
    DID_ConfData        : DiagDid_ConfData(),       # DID for configuration data encode/decode
    DID_AppFinger       : DiagDid_AppFingerPrint(), # DID for application finger print
    DID_SecureBootStatus: DiagDid_SecureBootStatus(), # DID for secure boot status
    DID_Snapshot        : DiagDid_Snapshot(),       # DID for DTC snapshot record
    DID_ApmApplVer      : DiagDid_VersionNumber(),
    DID_ApmBootVer      : DiagDid_VersionNumber(),
    DID_ObcApplVer      : DiagDid_VersionNumber(),
    DID_ObcBootVer      : DiagDid_VersionNumber(),
}                    
                    
                    
                    
                    