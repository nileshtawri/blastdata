
from aes import AES
from cryptography.hazmat.primitives.cmac import CMAC
from cryptography.hazmat.primitives.ciphers import algorithms


''' ROUTINE ID LIST '''
RID_CalDataClear = 0xCADA
RID_CalDataCheck = 0xCADB
RID_CrcCheck = 0x0202
RID_EraseFlash = 0xFF00
RID_CheckDependency = 0xFF01
RID_ConfigSecureBoot = 0xFF04
RID_LoadSecureKey = 0xFF05
RID_GetSheId = 0xFF06

''' Secure Boot Mode '''
SB_MODE_STRICT = 0
SB_MODE_SERIAL = 1
SB_MODE_PARALLEL = 2
SB_MODE_DISABLE = 3
SECURE_BOOT_SIZE = 0x20700 * 8                  # secure boot check size in bits


empty_key =   'ffffffffffffffffffffffffffffffff'
master_key =  'cafebeefbafeface0123456789abecef'
boot_key =    '0123456789abecefcafebeefbafeface'

default_key = '000102030405060708090a0b0c0d0e0f'
user_key1 =   '118a46447a770d87828a69c222e2d17e'
user_key2 =   '9d9d31fe67e43af48490fc1ff41464b6'
user_key3 =   '260614ebe1a1ab36778aff970bfc36de'
user_key5 =   'f6851b4ed2ca85b53495391adbfb3817'

KEY_UPDATE_ENC_C =  '010153484500800000000000000000b0'
KEY_UPDATE_MAC_C =  '010253484500800000000000000000b0'

she_slot_master_key = {
    'name'  : 'master',
    'id'    : '1', 
    'value' : master_key, 
    'usage' : "wirte to other slots and compute UID's CMAC"
}

she_slot_boot_key = {
    'name'  : 'boot_key',
    'id'    : '2', 
    'value' : boot_key, 
    'usage' : "SHE secure boot use this key verify MCU's flash"
}

she_slot_boot_mac = {
    'name'  : 'boot_mac',
    'id'    : '3', 
    'value' : empty_key, 
    'usage' : "SHE secure boot CMAC value"
}

she_slot_user_key_1 = {
    'name'  : 'user1',
    'id'    : '4', 
    'value' : user_key1, 
    'usage' : "APM use this key to unlock UDS security access service"
}

she_slot_user_key_2 = {
    'name'  : 'user2',
    'id'    : '5', 
    'value' : empty_key, 
    'usage' : "not define"
}

she_slot_user_key_3 = {
    'name'  : 'user3',
    'id'    : '6', 
    'value' : user_key3, 
    'usage' : "not define"
}

she_slot_user_key_4 = {
    'name'  : 'user4',
    'id'    : '7', 
    'value' : empty_key, 
    'usage' : "not define"
}

she_slot_user_key_5 = {
    'name'  : 'user5',
    'id'    : '8', 
    'value' : user_key5, 
    'usage' : "not define"
}

she_slot_user_key_6 = {
    'name'  : 'user6',
    'id'    : '9', 
    'value' : empty_key, 
    'usage' : "not define"
}

she_slot_user_key_7 = {
    'name'  : 'user7',
    'id'    : 'A', 
    'value' : boot_key, 
    'usage' : "APM use this key to generate BOOT_MAC, value is same as boot_key"
              "It is the final key of APM's CSEc"
}

she_keys = [she_slot_master_key, 
            she_slot_boot_key, 
            she_slot_boot_mac, 
            she_slot_user_key_1,
            she_slot_user_key_2,
            she_slot_user_key_3,
            she_slot_user_key_4,
            she_slot_user_key_5,
            she_slot_user_key_6,
            she_slot_user_key_7]

def xor(x, y, z):
    i = 0
    out = bytearray(16)
    for i in range(len(x)):
        out[i] = x[i] ^ y[i] ^ z[i]
    return out

def aes_mp(k, c):
    """
    KDF(K, C) is AES-MP(K | C), which state at section 4.3.3.1 key derivation,
    AES-MP(x) : ENCecb,iv=0(x)0?
    It is the test vector of the section 4.13.2.5 in AUTOSAR FO R19-11.
    --------------------------------------------------------
    K                   000102030405060708090a0b0c0d0e0f
    C                   010153484500800000000000000000b0
    KDerived            118a46447a770d87828a69c222e2d17e
    \prarm
    """
    if isinstance(k, str):
        k = bytes.fromhex(k)
    else:
        return None
    
    if isinstance(c, str):
        c = bytes.fromhex(c)
    else:
        return None
        
    #print(f'K : {k.hex()}')
    #print(f'C : {c.hex()}')
    
    out0 = bytes([0]*16)
    aes = AES(out0)
    out1 = aes.encrypt_block(k)
    out1 = xor(out1, k, out0)
    aes = AES(out1)
    out2 = aes.encrypt_block(c)
    out2 = xor(out2, c, out1)
    #print(f'out : {out2.hex()}')    
    return out2

def check_paramaters(UID, KEYNEW, ID, CID, FID, KEYAuthID, AuthID):
    """
    Input Paramaters, all these input paramaters are Hex string.
    KEYNEW      : new key plaintext, 16 bytes
    KEYAuthID   : the authentication secret key plaintext, 16 bytes
    UID         : the unique ID in the SHE, 15 bytes
    ID          : the key ID (4 bit) will be update, 1 digite
    AuthID      : the authentication secret key ID (4 bit), 1 digite
    CID         : the update counter value (28 bits) of the new key, 4 byte
    FID         : the flags (5 bits) of the new key, 1 byte
    """
    if isinstance(UID, str) == False or len(UID) != 30:
        return 1
    if isinstance(KEYNEW, str) == False or len(KEYNEW) != 32:
        return 2
    if isinstance(ID, str) == False or len(ID) != 1:
        return 3
    if isinstance(CID, str) == False or len(CID) != 8:
        return 4
    if isinstance(FID, str) == False or len(FID) != 2:
        return 5
    if isinstance(KEYAuthID, str) == False or len(KEYAuthID) != 32:
        return 6
    if isinstance(AuthID, str) == False or len(AuthID) != 1:
        return 7
    return 0
    
def she_memory_update(UID, KEYNEW, ID, CID, FID, KEYAuthID, AuthID):
    """
    Input Paramaters, all these input paramaters are Hex string.
    KEYNEW      : new key plaintext, 16 bytes
    KEYAuthID   : the authentication secret key plaintext, 16 bytes
    UID         : the unique ID in the SHE, 15 bytes
    ID          : the key ID will be update, 1 digite
    AuthID      : the authentication secret key ID, 1 digite
    CID         : the update counter value (28 bits) of the new key, 4 byte
    FID         : the flags (5 bits) of the new key, 1 byte
    
    Output Vectors, all output vectors are Hex string.
    M1          : 16 bytes
    M2          : 32 bytes
    M3          : 16 bytes
    M4          : 32 bytes
    M5          : 16 bytes
    
    It is the memory update protocol in the Figure 4.5 of AUTOSAR FO R19-11.
    --------------------------------------------------------
    K1 = KDF(KEYAuthID, KEY_UPDATE_ENC_C)
    K2 = KDF(KEYAuthID, KEY_UPDATE_MAC_C)
    M1 = UID' | ID | AuthID
    M2 = ENCcbc,k1,iv=0(CID' | FID' | "0...0"95b | KEYNEW )
    M3 = CMACk2(M1 | M2)
    --------------------------------------------------------

    It is the memory update protocol in the Figure 4.6 of AUTOSAR FO R19-11.
    --------------------------------------------------------
    K3 = KDF(KEYID, KEY_UPDATE_ENC_C)
    K4 = KDF(KEYID, KEY_UPDATE_MAC_C)
    M4 = UID | ID | AuthID | ENCecb,k3(CID)
    M5 = CMACk4(M4)
    --------------------------------------------------------
    """
    ret = check_paramaters(UID, KEYNEW, ID, CID, FID, KEYAuthID, AuthID)
    if ret != 0:
        print(f'check_paramaters error {ret}')
        return None
        
    k1 = aes_mp(KEYAuthID, KEY_UPDATE_ENC_C)    #K1 = KDF(KEYAuthID, KEY_UPDATE_ENC_C)
    print(f'K1 : {k1.hex()}')
    
    k2 = aes_mp(KEYAuthID, KEY_UPDATE_MAC_C)    #K2 = KDF(KEYAuthID, KEY_UPDATE_MAC_C)
    print(f'K2 : {k2.hex()}')
    
    m1_str = UID + ID + AuthID
    m1 = bytes.fromhex(m1_str)                  #M1 = UID' | ID | AuthID
    M1 = m1.hex()
    print(f'M1 : {M1}')
    
    cf128 = 0
    cid = int(CID, base = 16) & 0x0FFFFFFF      # CID is 28 bits
    cf128 = cid << (128-28)
    fid = int(FID, base = 16) & 0x1F            # FID is 5 bits
    cf128 |= fid << (128-28-5)                  # ( CID | FID | 0..0 ) 128bits
    
    m2_str = f'{cf128:032X}' + KEYNEW           # M2plaintext = (CID|FID|0..0|KEYNEW) 256bits
    m2_plaintext = bytes.fromhex(m2_str)
    print(f'm2_plaintext : {m2_plaintext.hex()}')
    aes = AES(k1)
    iv = bytes([0]*16)
    m2 = aes.encrypt_cbc(m2_plaintext, iv)      #M2 = ENCcbc,k1,iv=0(M2plaintext)
    m2 = m2[0:32]
    M2 = m2.hex()
    print(f'M2 : {M2}')
    
    m3_str = m1.hex() + m2.hex()                #M3plaintext = M1 | M2 
    m3_plaintext = bytes.fromhex(m3_str)
    #print(f'm3_plaintext : {m3_plaintext.hex()}')
    cmac = CMAC(algorithms.AES(k2))
    cmac.update(m3_plaintext)
    m3 = cmac.finalize()
    M3 = m3.hex()
    print(f'M3 : {M3}')
    
    k3 = aes_mp(KEYNEW, KEY_UPDATE_ENC_C)       #K3 = KDF(KEYID, KEY_UPDATE_ENC_C)
    print(f'K3 : {k3.hex()}')
    
    k4 = aes_mp(KEYNEW, KEY_UPDATE_MAC_C)       #K4 = KDF(KEYID, KEY_UPDATE_MAC_C)
    print(f'K4 : {k4.hex()}')
    
    cf128 = 0
    cid = int(CID, base = 16) & 0x0FFFFFFF      # CID (counter) is 28 bits
    cf128 = cid << (128-28)
    cf128 |= 1 << (128-28-1)                    # ( CID | '1' | 0..0 ) 128bits
    cid_str = f'{cf128:032X}'
    cid_plaintext = bytes.fromhex(cid_str)
    #print(f'cid_plaintext : {cid_plaintext.hex()}')
    aes = AES(k3)
    m4p = aes.encrypt_block(cid_plaintext)
    #print(f"M4' : {M4)}")
    m4_str = UID + ID + AuthID + m4p.hex()      #M4 = UID | ID | AuthID | M4'
    M4 = m4_str
    print(f'M4 : {M4}')
    
    cmac = CMAC(algorithms.AES(k4))
    m4 = bytes.fromhex(m4_str)
    cmac.update(m4)
    m5 = cmac.finalize()                        #M5 = CMACk4(M4)
    M5 = m5.hex()
    print(f'M5 : {M5}')
    
    if(len(M1+M2+M3+M4+M5) != 224):             # check output length
        print('M1~M5 length error')
        return None
    
    return M1, M2, M3, M4, M5
    
    
def she_write(key_target, key_auth, uid, new_counter, key_flag, uds_routine):
    """
    \brief      write a key (or MAC) to a SHE's key slot
    \param[in]  key_target  the target KEY slot ID
    \param[in]  key_auth    the authentication KEY ID for this write operation
    \param[in]  uid         the UID of the SHE module
    \param[in]  new_counter the new counter value of the target key
    \param[in]  key_flag    the key flags (write_ban | boot_ban | debug_ban | cmac | wildcard)
    \param[in]  uds_routine reference to UDS Routine Control function
    """
    
    print (f'start to load key:{key_target} by key:{key_auth}')
    print (f'UID: {uid.hex()}')
    
    write_protection = 0x10
    
    if(key_flag & write_protection) != 0:
        print(f'DO NOT enable write_protection to a key, flag:{key_flag:02X}')
        return -1
    
    keyid = ''
    for key in she_keys:
        if key['name'] == key_target:
            newkey = key['value']
            keyid = key['id']
            cid_str = f'{new_counter:08X}'
            fid_str = f'{key_flag:02X}'
    
    authkid = ''
    for key in she_keys:
        if key['name'] == key_auth:
            authkey = key['value']
            authkid = key['id']
            
    if keyid == '' or authkid == '':
        print (f'key name error, key_target:{key_target}, key_auth:{key_auth}')
        return -2
        
    if keyid == authkid and new_counter == 1:   # if firth time write key by itself
        print('1st time write key by itself, use empty_key for authentication.')
        authkey = empty_key                     # key value is all '1'
    
    UID =               uid.hex()   # UID get from CMD_GET_ID
    KEYNEW =            newkey      # new key value
    ID =                keyid       # target KEY ID
    CID =               cid_str     # CID 28 bits, (new counter value)
    FID =               fid_str     # FID 5 bits, (new key flags)
    KEYAuthID =         authkey     # authentication key value
    AuthID =            authkid     # authentication KEY ID
    
    ret = she_memory_update(UID, KEYNEW, ID, CID, FID, KEYAuthID, AuthID)                
    if (ret != None):
        (M1, M2, M3, M4, M5) = ret
        m1m2m3 = bytes.fromhex(M1+M2+M3)
    else:
        return -3
                                    # Routine 0xFF05, CMD_LOAD_KEY
    ret = uds_routine(RID_LoadSecureKey, m1m2m3)
    if(ret.positive):
        if (len(ret.data) != (3+32+16)):
            print(f'Routine 0X{RID:04X} ERROR! ret_len={ret_len}')
            return -4
        print(f'CMD_LOAD_KEY ok')
        m4_ret = ret.data[3:(3+32)]
        m5_ret = ret.data[(3+32):(3+32+16)]
        print(f'M4 = {m4_ret.hex()}')
        print(f'M5 = {m5_ret.hex()}')
    
    if M4.lower() != m4_ret.hex() or M5.lower() != m5_ret.hex():
        print('CMD_LOAD_KEY M4 M5 verify error')
        return -5
    else:
        return 0
    
    
def she_set_secure_boot_mode(mode, size, uds_routine):
    """
    \brief      setup the secure boot mode of the MCU's CSEc
    \param[in]  mode    secure boot mode
    \param[in]  size    verify flash size in bits
    \param[in]  uds_routine reference to UDS Routine Control function
    """
    boot_cmac = ''
    reflash_counter = 0
    
    if (mode == SB_MODE_STRICT):
        print('DO NOT select STRICT mode, mode: {mode}')
        return 1, 0
    
    mode_and_size = bytearray(5)
    mode_and_size[0] = mode
    mode_and_size[1] = (size >> 24) & 0x0FF
    mode_and_size[2] = (size >> 16) & 0x0FF
    mode_and_size[3] = (size >> 8) & 0x0FF
    mode_and_size[4] = size & 0x0FF
    print(f'mode_and_size: {mode_and_size.hex()}')
    mode_size = bytes(mode_and_size)
    
    ret = uds_routine(RID_ConfigSecureBoot, mode_size)
    if(ret.positive):
        if (len(ret.data) != (3+16+3)):         # 16B is CMAC, 3B is counter
            print(f'Routine 0X{RID:04X} ERROR! ret_len={ret_len}')
            return -1, 0
        else:
            boot_cmac = (ret.data[3:(3+16)]).hex()
            print(f'new BOOT_MAC: {boot_cmac}')
            
            reflash_counter = ret.data[3+16]
            reflash_counter = (reflash_counter << 8) + ret.data[3+17]
            reflash_counter = (reflash_counter << 8) + ret.data[3+18]
            print(f'new reflash counter: {reflash_counter}')
            if(reflash_counter >= 0x00FFFFFF):
                print("reflash counter overflow")
                return -2, 0
    else:
        return -3, 0
        
    if len(boot_cmac) != 32:
        print(f'BOOT_MAC error: {boot_cmac}')
        return -4, 0
    
    she_slot_boot_mac['value'] = boot_cmac
    return 0, reflash_counter
    
def she_get_uid(uds_routine):
    """
    \brief      read SHE's UID in the MCU
    \param[in]  uds_routine reference to UDS Routine Control function
    """
    challenge = '000102030405060708090a0b0c0d0e0f'
    uid = bytearray(15)
    sreg = 0
    mac = bytearray(16)
    
    ret = uds_routine(RID_GetSheId, bytes.fromhex(challenge))
    ret_len = len(ret.data)
    if(ret.positive != True):
        print(f'Routine 0X{RID_GetSheId:04X} ERROR!')
        print(f'NRC:0x{ret.code:x}')
        return -1, uid
    elif (ret_len != (3+32)):
        print(f'Routine 0X{RID_GetSheId:04X} ERROR! ret_len={ret_len}')
        return -2, uid
    else:
        print(f'CMD_GET_ID ok')
        uid = ret.data[3:(3+15)]        # ID is 15 bytes
        sreg = ret.data[(3+15)]         # SREG is one byte
        mac = ret.data[(3+16):(3+32)]   # CMAC is 16 bytes
        haveMasterEcuKey = True if any(mac) else False
        print(f'UID:  {uid.hex()}')
        print(f'Sreg: 0x{sreg:02X}')
        print(f'MAC:  {mac.hex()}')
        print(f'Have MASTER_ECU_KEY ? {haveMasterEcuKey}')

        if(haveMasterEcuKey):           # if SHE has master key, 
            mkey = bytes.fromhex(master_key)
            msg_str = challenge + uid.hex() + f'{sreg:02X}'
            msg = bytes.fromhex(msg_str)
            cmac = CMAC(algorithms.AES(mkey))
            cmac.update(msg)            # get the CMAC from UID
            mac_str = cmac.finalize().hex()
            print(f"MAC': {mac_str}")
            if(mac_str != mac.hex()):
                print('UID CMAC check failed')
                return -3, uid
    return 0, uid
    
    
    
    
    
    
    
    