
from datetime import datetime
from ctypes import *
import struct
import os
import yaml
from crccheck.crc import Crc16CcittFalse
#from crccheck.crc import Crc16Dnp
from uds_did import *

cali_yaml_file_name = 'ObcCali.yaml'
conf_yaml_file_name = 'ObcConf.yaml'

DATA_TYEP_CALIBRATION = 1
DATA_TYPE_CONFIGURATION = 2

target_address_cali_block = 0x0007F000
target_address_conf_block = 0x0007F000


"""
class Header(LittleEndianStructure):
    '''
    C data structure for NVM date header
    '''
    _pack_ = 1
    _fields_ = [("tag",             c_ubyte * 4),
                ("type",            c_ubyte),
                ("year",            c_ushort),
                ("month",           c_ubyte),
                ("day",             c_ubyte), 
                ("hour",            c_ubyte), 
                ("minute",          c_ubyte), 
                ("second",          c_ubyte),
                ("writeCount",      c_ushort),
                ("crc16",           c_ushort)]

class CaliDataPoint(LittleEndianStructure):
    '''
    C data structure for calibration data parameters, six floating value.
    1. measure low,
    2. measure high,
    3. native low,
    4. native high,
    5. gain,
    6. offset
    '''
    _pack_ = 1
    _fields_ = [("data",            c_float * 6)]

class CaliDataBlock(LittleEndianStructure):
    '''
    C data structure for calibration date block, i.e., Header + CaliDataPoint
    '''
    _pack_ = 1
    _fields_ = [("header",          Header),
                ("item",            CaliDataPoint * CALI_ITEM_NUMBER)]
"""

def load_cali_yaml():
    '''
    C data structure for calibration date block, i.e., Header + CaliDataPoint
    '''
    print (f'load calibration yaml file: {cali_yaml_file_name}')
    with open(cali_yaml_file_name, 'r') as file:
        ydata = yaml.full_load(file)
        
        #for item, doc in ydata.items():
        #    print(item, ":", doc)
            
    caliData = CaliDataBlock()
    
    now = datetime.now()
    caliData.header.tag = (c_ubyte * 4)(0x55, 0xAA, 0x30, 0x00)
    caliData.header.type = DATA_TYEP_CALIBRATION
    caliData.header.year = now.year
    caliData.header.month = now.month
    caliData.header.day = now.day
    caliData.header.hour = now.hour
    caliData.header.minute = now.minute
    caliData.header.second = now.second
    caliData.header.writeCount = 1                 # this field will update by MCU
    caliData.header.crc16 = 0
    
    for i in range(CALI_ITEM_NUMBER):
        caliData.item[i].data = (c_float * 6)(0, 0, 0, 0, 1.0, 0.0)
    
    caliData.item[CALI_ITEM_LVDC_VOLT_ADC].data = \
        (
        ydata['apm_vout']['measure'][0],
        ydata['apm_vout']['measure'][1],
        ydata['apm_vout']['native'][0],
        ydata['apm_vout']['native'][1],
        ydata['apm_vout']['gain'],
        ydata['apm_vout']['offset']
        )
    '''
    print ('apm_vout YAML:')
    for f in caliData.item[CALI_ITEM_LVDC_VOLT_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_LVDC_CURR_ADC].data = \
        (
        ydata['apm_iout']['measure'][0],
        ydata['apm_iout']['measure'][1],
        ydata['apm_iout']['native'][0],
        ydata['apm_iout']['native'][1],
        ydata['apm_iout']['gain'],
        ydata['apm_iout']['offset']
        )
    '''
    print ('apm_iout YAML:')
    for f in caliData.item[CALI_ITEM_LVDC_CURR_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_LVDC_VOLT_PWM].data = \
        (
        ydata['apm_vcmd']['measure'][0],
        ydata['apm_vcmd']['measure'][1],
        ydata['apm_vcmd']['native'][0],
        ydata['apm_vcmd']['native'][1],
        ydata['apm_vcmd']['gain'],
        ydata['apm_vcmd']['offset']
        )
    '''
    print ('apm_vcmd YAML:')
    for f in caliData.item[CALI_ITEM_LVDC_VOLT_PWM].data:
        print (f)
    '''    
    caliData.item[CALI_ITEM_LVDC_CURR_PWM].data = \
        (
        ydata['apm_icmd']['measure'][0],
        ydata['apm_icmd']['measure'][1],
        ydata['apm_icmd']['native'][0],
        ydata['apm_icmd']['native'][1],
        ydata['apm_icmd']['gain'],
        ydata['apm_icmd']['offset']
        )
    '''
    print ('apm_icmd YAML:')
    for f in caliData.item[CALI_ITEM_LVDC_CURR_PWM].data:
        print (f)    
    '''
    caliData.item[CALI_ITEM_BAT_VOLT_ADC].data = \
        (
        ydata['apm_vbat']['measure'][0],
        ydata['apm_vbat']['measure'][1],
        ydata['apm_vbat']['native'][0],
        ydata['apm_vbat']['native'][1],
        ydata['apm_vbat']['gain'],
        ydata['apm_vbat']['offset']
        )
    '''
    print ('apm_vbat YAML:')
    for f in caliData.item[CALI_ITEM_BAT_VOLT_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_HVDC_VOLT_APM_ADC].data = \
        (
        ydata['apm_vin']['measure'][0],
        ydata['apm_vin']['measure'][1],
        ydata['apm_vin']['native'][0],
        ydata['apm_vin']['native'][1],
        ydata['apm_vin']['gain'],
        ydata['apm_vin']['offset']
        )
    '''
    print ('apm_vin YAML:')
    for f in caliData.item[CALI_ITEM_HVDC_VOLT_APM_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_HVDC_CURR_APM_ADC].data = \
        (
        ydata['apm_iin']['measure'][0],
        ydata['apm_iin']['measure'][1],
        ydata['apm_iin']['native'][0],
        ydata['apm_iin']['native'][1],
        ydata['apm_iin']['gain'],
        ydata['apm_iin']['offset']
        )
    '''
    print ('apm_iin YAML:')
    for f in caliData.item[CALI_ITEM_HVDC_CURR_APM_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_HVDC_VOLT_OBC_ADC].data = \
        (
        ydata['obc_vout']['measure'][0],
        ydata['obc_vout']['measure'][1],
        ydata['obc_vout']['native'][0],
        ydata['obc_vout']['native'][1],
        ydata['obc_vout']['gain'],
        ydata['obc_vout']['offset']
        )
    '''
    print ('obc_vout YAML:')
    for f in caliData.item[CALI_ITEM_HVDC_VOLT_OBC_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_HVDC_CURR_OBC_ADC].data = \
        (
        ydata['obc_iout']['measure'][0],
        ydata['obc_iout']['measure'][1],
        ydata['obc_iout']['native'][0],
        ydata['obc_iout']['native'][1],
        ydata['obc_iout']['gain'],
        ydata['obc_iout']['offset']
        )
    '''     
    print ('obc_iout YAML:')
    for f in caliData.item[CALI_ITEM_HVDC_CURR_OBC_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_GRID_VOLT_ADC].data = \
        (
        ydata['obc_vin']['measure'][0],
        ydata['obc_vin']['measure'][1],
        ydata['obc_vin']['native'][0],
        ydata['obc_vin']['native'][1],
        ydata['obc_vin']['gain'],
        ydata['obc_vin']['offset']
        )
    '''
    print ('obc_vin YAML:')
    for f in caliData.item[CALI_ITEM_GRID_VOLT_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_GRID_CURR_ADC].data = \
        (
        ydata['obc_iin']['measure'][0],
        ydata['obc_iin']['measure'][1],
        ydata['obc_iin']['native'][0],
        ydata['obc_iin']['native'][1],
        ydata['obc_iin']['gain'],
        ydata['obc_iin']['offset']
        )
    '''
    print ('obc_iin YAML:')
    for f in caliData.item[CALI_ITEM_GRID_CURR_ADC].data:
        print (f)
    '''
    caliData.item[CALI_ITEM_BULK_VOLT_ADC].data = \
        (
        ydata['obc_vbulk']['measure'][0],
        ydata['obc_vbulk']['measure'][1],
        ydata['obc_vbulk']['native'][0],
        ydata['obc_vbulk']['native'][1],
        ydata['obc_vbulk']['gain'],
        ydata['obc_vbulk']['offset']
        )
    '''
    print ('obc_vbulk YAML:')
    for f in caliData.item[CALI_ITEM_BULK_VOLT_ADC].data:
        print (f)
    '''
    head = bytearray(14)
    rptr = (c_char * 14).from_buffer(head)
    memmove(rptr, byref(caliData), 14)
    
    buf = bytearray(sizeof(caliData)-16)
    rptr = (c_char * (sizeof(caliData)-16)).from_buffer(buf)
    memmove(rptr, cast(addressof(caliData)+16, c_void_p), (sizeof(caliData)-16))
    
    new_crc = Crc16CcittFalse.calc(head + buf)
    print (f'cali header crc is 0x{new_crc:04X}')
    
    caliData.header.crc16 = new_crc
        
    temp_bin_name = cali_yaml_file_name.split('.')[0]
    temp_bin_name += '.bin'
    
    with open(temp_bin_name, 'wb') as binfile:
        binfile.write(bytearray(caliData))
        
    out_s19_file = cali_yaml_file_name.split('.')[0]
    out_s19_file += '.s19'

    print (f'convert {temp_bin_name} to {out_s19_file}')

    cmd_str = f'srec_cat.exe {temp_bin_name} -binary -offset 0x{target_address_cali_block:08X} -o {out_s19_file} -motorola -address-length=4'

    print (f'RUN: {cmd_str}')
    
    os.system(cmd_str)
    
    return out_s19_file

def main():
    print ('yaml2s19 tool')
    
    load_cali_yaml()
    

if __name__ == '__main__':
    main()
