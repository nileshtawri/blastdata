#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ast import Return
from pickle import NONE
from sre_constants import RANGE
import sys
import os
import struct
import argparse  # for receive the command form cmd window
from argparse import RawTextHelpFormatter
import binascii
# import string
from crccheck.crc import Crc16Dnp  # for cal the crc of the hex data

# from binascii import hexlify, unhexlify
from intelhex import IntelHex, HexReaderError  # , IntelHex16bit
from intelhex.compat import asstr

# ********************* This py's version
# this_hex2bin_version_info = '[hex2bin version v0.1   2022/10/19 18:00]'
# this_hex2bin_version_info = '[rev v0.1_b   2022/10/24 13:00]'
# """
# v0.1_b:
# A. add CRC-16 DNP
# B. Switch the EntryPoint Address SWAP method
# C. revise the address calculate formulate
# """
this_hex2bin_version_info = '[version v0.1]'  # 2022/10/31 14:00
""" v0.1_c :
A. Optimize class cHex2Bin()
B. Optimize the process : copy the yaml/bin file, 
                          function in "copy_yaml_bin_file
"""


# ********************* file name here
filename_DSP_Boot = 'OBC_400V_6k6_2in1_DSP_Bootloader.hex'
filename_DSP_APP = 'OBC_400V_6k6_2in1.hex'
filename_DSP_DEBUG = 'OBC_400V_6k6_2in1.hex'
file_out_DSP_Boot = 'DspBoot.bin'
file_out_DSP_APP = 'DspAppl.bin'
file_out_DSP_CONF = 'DspConf.bin'
file_out_DSP_CALI = 'DspCali.bin'
file_out_DSP_CALI_CLR = 'DspCaliClr.bin'

# *********************internal use
empty_bin_data = b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'


def swap32(x_in):
    return (((x_in << 24) & 0xFF000000) |
            ((x_in << 8) & 0x00FF0000) |
            ((x_in >> 8) & 0x0000FF00) |
            ((x_in >> 24) & 0x000000FF))


def swap32_by_2B(x_in):
    return (((x_in >> 16) & 0x0000FFFF) |
            ((x_in << 16) & 0xFFFF0000))


def swap16(x_in):
    return (((x_in >> 8) & 0x00FF) |
            ((x_in << 8) & 0xFF00))


def swap16_4B(x_in):
    return (((swap16((x_in & 0xFFFF0000) >> 16)) << 16) |
            ((swap16((x_in & 0x0000FFFF) >> 0)) << 0))


# *********************key function here
def convert_file_format(filename, fileout, ModuleType):

    # initial variable
    start = 0x00
    end = 0x00
    entrypoint = (0)
    # fwversion = (0)
    size = 0
    size_new = 0
    # FW_information = 0
    fwversion_list = []
    hex_data_list = []
    hex_data_list_new = []
    crc = 0

    if ModuleType == 'OBC_DSP_DEBUG':
        binary_data_alignment_size = 4
    else:
        binary_data_alignment_size = 16
    # print('binary_data_alignment_size=', binary_data_alignment_size)

    # print('filename=', filename)

    # ************************fetch hexfile ************************
    (_, ext) = os.path.splitext(filename)
    # https://docs.python.org/zh-tw/3/library/functions.html?highlight=open#open
    # with open(filename, 'rb' if ext == '.bin' else 'rt') as fin, open(fileout, 'wb') as fout:
    with open(filename, 'rb' if ext == '.bin' else 'rt') as fin:
        try:
            h = IntelHex(fin)
        except HexReaderError:
            e = sys.exc_info()[1]  # current exception
            txt = "ERROR: bad HEX file: %s" % str(e)
            raise Exception(txt)

        # fetch the information from the hex file

        # this is the different segment area
        # can locate the absolute address
        segments = h.segments()
        # print('segments=', segments)

        # due to different Type of hex file,
        # it has contail different format, ie start/end address,
        if ModuleType == 'OBC_DSP_APP':
            # print('debug_APP*')
            start = segments[0][0]
            end = segments[len(segments)-1][1] - 1
            entrypoint = h.gets(start, 4)
            fwversion = h.gets(start+32, 96)
            fwversion = asstr(binascii.b2a_hex(fwversion))
            fwversion_data = bytearray.fromhex(fwversion)
            for x in fwversion_data:
                fwversion_list.append(x)

        elif (ModuleType == 'OBC_DSP_BOOT'):
            # print('debug_BOOT**')
            start = segments[1][0]
            end = segments[len(segments)-1][1] - 1
            entrypoint = h.gets(segments[0][0], 4)
            fwversion = h.gets(start, 96)
            fwversion = asstr(binascii.b2a_hex(fwversion))
            fwversion_data = bytearray.fromhex(fwversion)
            for x in fwversion_data:
                fwversion_list.append(x)

        elif (ModuleType == 'OBC_DSP_CONF') or (ModuleType == 'OBC_DSP_CALI') or (ModuleType == 'OBC_DSP_CALI_CLR'):
            # print('debug_CONF/CALI***')
            # due to this bin file is load from another yaml2bin
            # so, it need to transfer to ccs format (Word SWAP)
            # start transfer:
            fout2_read_new = []
            with open(fileout, 'rb+') as fout2:
                # print('CONF/CALI')
                fout2_read = fout2.read()   # read out bin file
                for x in range(len(fout2_read) >> 1):
                    fout2_read_new.append(fout2_read[x*2+1])
                    fout2_read_new.append(fout2_read[x*2])

                    # transfer this List as struct.pack format to bin
                packdata = struct.pack('>B', fout2_read_new[0])
                for x in range(len(fout2_read_new)-1):
                    packdata += struct.pack('>B', fout2_read_new[x+1])

                start = 0
                end = len(fout2_read_new)
                entrypoint = 0
                diff = 0

                # padding with 0xFF
                if ((end % 16) != 0):
                    diff = 16-(end % 16)
                    #print("diff=", diff)
                    end = end + diff
                    # packdata = struct.pack('>B', 0xFF)
                    for i in range(diff):
                        packdata += struct.pack('>B', 0xFF)
                        # start saving
                        # move the cursor to the start
                fout2.seek(0)  # move fingure index to 0
                fout2.write(packdata)  # write new packdata to bin file
                fout2.close
                # os.system("pause")

            for x in range(96):
                fwversion_list.append(255)

        elif (ModuleType == 'OBC_DSP_DEBUG'):
            entrypoint = h.gets(segments[1][0], 4)
            # print('entrypoint=', entrypoint)
            fwversion = entrypoint+entrypoint+entrypoint + \
                entrypoint+entrypoint+entrypoint+entrypoint+entrypoint
            start = segments[1][0]
            end = segments[1][1]
            fwversion = asstr(binascii.b2a_hex(fwversion))
            fwversion_data = bytearray.fromhex(fwversion)
            for x in fwversion_data:
                fwversion_list.append(x)
        else:
            start = segments[0][0]
            end = segments[len(segments)-1][1] - 1

        size = end-start
        if ((ModuleType == 'OBC_DSP_CONF') or (ModuleType == 'OBC_DSP_CALI')):
            # limit the Conf/Cali size under 0x1000(word)/8096 Bytes
            if size > (0x1000 << 1):
                size = (0x1000 << 1)
                end = start + (0x1000 << 1)

        # if (ModuleType == 'OBC_DSP_BOOT') or (ModuleType == 'OBC_DSP_APP'):
        if ((size % binary_data_alignment_size) != 0):
            end = end + (binary_data_alignment_size-size %
                         binary_data_alignment_size)  # fill empty area
        size_new = end - start
        # ****************************save to bin file*********************
        if (ModuleType == 'OBC_DSP_BOOT') or (ModuleType == 'OBC_DSP_APP'):
            with open(fileout, 'wb') as fout:
                try:
                    h.padding = 0xFF  # pad with 0xFF
                    # save as bub file format
                    h.tobinfile(fileout, start, end-1)
                except IOError:
                    e = sys.exc_info()[1]  # current exception
                    txt = "ERROR: Could not write to file: %s: %s" % (
                        fout, str(e))
                    raise Exception(txt)
                fout.close

    # second part
    print('                     code size=', size_new, end='')
    print(' (', size_new/1024, ' KB)', end='')
    print(' / Words=', hex(size_new >> 1))
    print('                     code size (+header 32B)=', size_new+32)

    # Here is start to combine the header information
    # 00-01 : Block ID
    if ModuleType == 'OBC_DSP_BOOT':
        wBlockID = swap16(10)
    elif ModuleType == 'OBC_DSP_APP':
        wBlockID = swap16(11)
    elif ModuleType == 'OBC_DSP_CONF':
        wBlockID = swap16(12)
    elif ModuleType == 'OBC_DSP_CALI':
        wBlockID = swap16(13)
    elif ModuleType == 'OBC_DSP_CALI_CLR':
        wBlockID = swap16(13)

    # 02-03 : RSVD1
    wRSVD1 = swap16(0xFFFF)

    # 04-07 : Code Size
    dwCodeSize = swap32((end-start+1) >> 1)

    # 08-0B : crc , behind the [with open(fileout, 'rb+') as fout:]

    # 0C-0F : Entry Point
    if (ModuleType == 'OBC_DSP_BOOT') or (ModuleType == 'OBC_DSP_APP'):
        entrypoint = asstr(binascii.b2a_hex(entrypoint))
        entrypoint = int(entrypoint, 16)
        entrypoint = swap16_4B(entrypoint)
        entrypoint = entrypoint & 0x000FFFFF
        print('                     entrypoint=', hex(entrypoint))
        entrypoint = swap16_4B(entrypoint)
        if ModuleType == 'OBC_DSP_BOOT':
            # dWEntryPoint = swap16_4B(entrypoint)  # old version before 10/19
            dWEntryPoint = swap32_by_2B(entrypoint)  # 10/19 revise
        else:
            dWEntryPoint = swap32_by_2B(entrypoint)  # <--------
    else:  # CONF and CALI don't need entry point
        dWEntryPoint = 0xFFFFFFFF

    # 10-13 FW Version from hex version.c
    dwFWVersion = swap16_4B(
        (fwversion_list[1] << 24) + (fwversion_list[0] << 16) + (fwversion_list[3] << 8) + (fwversion_list[2] << 0))

    # 14-17 Data Code
    wYear = swap16(2022)  # 2022
    wYear = swap16((fwversion_list[5] << 8) + (fwversion_list[4] << 0))
    wMMDD = swap16((10 << 8) + 17)  # 10/17
    wMMDD = swap16((fwversion_list[7] << 8) + (fwversion_list[6] << 0))

    # 18-1F RSVD2~RSVD5
    wRSVD2 = 0xFFFF
    wRSVD3 = 0xFFFF
    wRSVD4 = 0xFFFF
    wRSVD5 = 0xFFFF

    # ****************************append_header****************************
    with open(fileout, 'rb+') as fout:
        data = fout.read()  # read back bin file
        fout.seek(0)  # move fingure index to 0

        # convert the bin code to hex data format
        fwversion = asstr(binascii.b2a_hex(data))
        hex_data_list = bytearray.fromhex(fwversion)

        # 08-0B : crc , calculate from the read file
        for x in range(len(hex_data_list) >> 1):  # for swap u16 data for CRC calculate
            hex_data_list_new.append(hex_data_list[x*2+1])
            hex_data_list_new.append(hex_data_list[x*2+0])
        crc = Crc16Dnp.calc(hex_data_list_new)
        print("                     crc-16DNP=", hex(crc))
        dwCRC32 = swap32(crc)

        # Combin above information and write back to the bin fild
        # pack size reference : https://docs.python.org/zh-cn/3/library/struct.html
        # pack size map : B/H/I/Q = 1/2/4/8
        # pack formate is define in OBC_DSP_Bootloader develope Guide
        # pack formate = 2 + 2 + 4 + 4 + 4 + 2 + 2 + 2 + 2 + 8
        #                |   |   |   |   |   |   |   |   |   RSVD2-5(8Bytes)
        #                |   |   |   |   |   |   |   |   Buid Month + Day
        #                |   |   |   |   |   |   |   Year
        #                |   |   |   |   |   |   debug + host version
        #                |   |   |   |   |   Major + Minor Version
        #                |   |   |   |   Entry Point
        #                |   |   |   CRC value
        #                |   |   Code Size
        #                |   RSVD1
        #                Block ID
        packdata = struct.pack('>H', wBlockID) + \
            struct.pack('>H', wRSVD1) + \
            struct.pack('>I', dwCodeSize) + \
            struct.pack('>I', dwCRC32) + \
            struct.pack('>I', dWEntryPoint) + \
            struct.pack('>I', dwFWVersion) + \
            struct.pack('>H', wYear) + \
            struct.pack('>H', wMMDD) + \
            struct.pack('>H', wRSVD2) + \
            struct.pack('>H', wRSVD3) + \
            struct.pack('>H', wRSVD4) + \
            struct.pack('>H', wRSVD5)

        fout.write(packdata)  # append the header information (write)
        fout.write(data)     # and next append the original data (write)
        # data = fout.read()
        # print(data)
        fout.close()

    with open(fileout, 'wb') as fout:
        fout.write(packdata)  # append the header information (write)
        fout.write(data)     # and next append the original data (write)
        # data = fout.read()
        # print(data)
        fout.close()


def RecordisIntelHex16(ModuleType):
    with open('RecordisIntelHex16.txt', 'w') as frecord:
        if ((ModuleType == 'OBC_DSP_APP') or (ModuleType == 'OBC_DSP_BOOT') or
                (ModuleType == 'OBC_DSP_CONF') or (ModuleType == 'OBC_DSP_CALI')):
            frecord.write('1')
        else:
            frecord.write('0')
        frecord.close


def ReadisIntelHex16():
    with open('RecordisIntelHex16.txt', 'r') as frecord:
        print(frecord.read())
        frecord.close


class cHex2Bin():

    def __init__(self):
        self.manual_file_name = ''

    # Module Type:
    #               1.OBC_DSP_APP
    #               2.OBC_DSP_BOOT
    #               3.OBC_DSP_CONF
    #               4.OBC_DSP_CALI
    def convert(self, ModuleType):
        # print("start conver hex2bin....")
        # print('ModuleType=', ModuleType)
        #print(f'DSP bin file converter{this_hex2bin_version_info}')
        try:
            if self.manual_file_name != '':
                file_in = self.manual_file_name
            elif ModuleType == 'OBC_DSP_APP':
                file_in = filename_DSP_APP
            elif ModuleType == 'OBC_DSP_BOOT':
                file_in = filename_DSP_Boot
            elif ModuleType == 'OBC_DSP_CONF':
                file_in = filename_DSP_APP
            elif ModuleType == 'OBC_DSP_CALI':
                file_in = filename_DSP_APP
            elif ModuleType == 'OBC_DSP_CALI_CLR':
                file_in = filename_DSP_APP
            else:
                print("Input type error.")
                print(
                    "Only can input (OBC_DSP_APP) or (OBC_DSP_BOOT) or (OBC_DSP_CONF) or (OBC_DSP_CALI)")
                return False
                # file_in = filename_DSP_Boot
            RecordisIntelHex16(ModuleType)
            # ReadisIntelHex16()
            (fname, _) = os.path.splitext(file_in)  # remove Filename Extension
            # file_out = fname + "_" + args.module_type + \
            #    ".bin"  # combine the last name & .bin
            if ModuleType == 'OBC_DSP_APP':
                file_out = file_out_DSP_APP
            elif ModuleType == 'OBC_DSP_BOOT':
                file_out = file_out_DSP_Boot
            elif ModuleType == 'OBC_DSP_CONF':
                file_out = file_out_DSP_CONF
            elif ModuleType == 'OBC_DSP_CALI':
                file_out = file_out_DSP_CALI
            elif ModuleType == 'OBC_DSP_CALI_CLR':
                file_out = file_out_DSP_CALI_CLR
            else:
                print("Input type error.")
                print(
                    "Only can input (OBC_DSP_APP) or (OBC_DSP_BOOT) or (OBC_DSP_CONF) or (OBC_DSP_CALI)")
                return
            print("start conver Hex/Yami to bin....")
            convert_file_format(file_in, file_out, ModuleType)
            print("conver Hex/Yami to bin finish")
            print()

            # return file name
            # return file_out
            return True
        except:
            print("conver hex2bin error")
            # return NONE
            e = sys.exc_info()[1]  # current exception
            txt = "*****************\n error information =  %s" % str(e)
            raise Exception(txt)
            # return False

    def copy_yaml_bin_file(self, ModuleType):
        if ModuleType == 'OBC_DSP_CONF':
            try:
                with open(file_out_DSP_CONF, 'wb') as fout, open('ObcConf.bin', 'rb+') as fyaml_conf:
                    fout.seek(0)
                    fout.write(fyaml_conf.read())
                    # ....
                    fout.close()
                    fyaml_conf.close()
                    return True
            except:
                print('Open <ObcConf.bin> file error, please check.')
                return False

        elif ModuleType == 'OBC_DSP_CALI':
            try:
                with open(file_out_DSP_CALI, 'wb') as fout, open('ObcCali.bin', 'rb+') as fyaml_conf:
                    fout.seek(0)
                    fout.write(fyaml_conf.read())
                    # ...
                    fout.close()
                    fyaml_conf.close()
                    return True
            except:
                print('Open <ObcCali.bin> file error, please check.')
                return False
        elif ModuleType == 'OBC_DSP_CALI_CLR':
            try:
                with open(file_out_DSP_CALI_CLR, 'wb') as fout, open('ObcCali.bin', 'rb+') as fyaml_conf:
                    fout.seek(0)

                    #print('empty_bin_data', empty_bin_data)
                    #print('empty_bin_data', fyaml_conf.read())
                    # fout.write(fyaml_conf.read())
                    fout.write(empty_bin_data)
                    # ...
                    fout.close()
                    fyaml_conf.close()
                    return True
            except:
                print('Open <ObcCali.bin> file error, please check.')
                return False
        elif ModuleType == 'OBC_DSP_APP':
            return True  # do nothing
        else:
            print('Boodfile Type false')
            return False  # type not App/Conf/Cali

    def input_hex_file_manual(self, args):

        self.manual_file_name = ''
        if args.input_hex_file_manual:
            self.manual_file_name = args.input_hex_file_manual


def main():
    parser = argparse.ArgumentParser(
        description="""Convert hex file format to bin file format
        \r"""+f"{this_hex2bin_version_info}", formatter_class=RawTextHelpFormatter)

    parser.add_argument('-f', '--file', dest='input_hex_file_manual',
                        help='the hex file to be converted', required=False)

    parser.add_argument('-t', '--type', dest='module_type',
                        choices=('OBC_DSP_APP', 'OBC_DSP_BOOT', 'OBC_DSP_CONF', 'OBC_DSP_CALI', 'OBC_DSP_CALI_CLR',
                                 'OBC_DSP_DEBUG'),
                        help='which firmware type to be upgraded.', required=True)

    args = parser.parse_args()

    if args.module_type:
        ModuleType = args.module_type

    hex2bin = cHex2Bin()

    hex2bin.input_hex_file_manual(parser.parse_args())
    if hex2bin.copy_yaml_bin_file(ModuleType) != True:
        print('Hex/Yami to bin copy fail, please check')
    if hex2bin.convert(ModuleType) != True:
        print(f' {ModuleType} Hex/Yami to bin conver fail, please check')


"""
    if args.input_hex_file_manual:
        file_in = args.input_hex_file
    else:
        if ModuleType == 'OBC_DSP_APP':
            file_in = filename_DSP_APP
        elif ModuleType == 'OBC_DSP_BOOT':
            file_in = filename_DSP_Boot
        elif ModuleType == 'OBC_DSP_CONF':
            file_in = filename_DSP_APP
        elif ModuleType == 'OBC_DSP_CALI':
            file_in = filename_DSP_APP
        elif ModuleType == 'OBC_DSP_DEBUG':
            file_in = filename_DSP_DEBUG
        else:
            print('ModuleType input fail')
            return

        if ModuleType == 'OBC_DSP_CONF':
            with open(file_out_DSP_CONF, 'wb') as fout, open('ObcConf.bin', 'rb+') as fyaml_conf:
                fout.seek(0)
                fout.write(fyaml_conf.read())
                # ....
                fout.close()
                fyaml_conf.close()
        if ModuleType == 'OBC_DSP_CALI':
            with open(file_out_DSP_CALI, 'wb') as fout, open('ObcCali.bin', 'rb+') as fyaml_conf:
                fout.seek(0)
                fout.write(fyaml_conf.read())
                # ...
                fout.close()
                fyaml_conf.close()

    print("start conver Hex/Yami to bin....")

    # try:
    RecordisIntelHex16(ModuleType)
    # ReadisIntelHex16()

    (fname, _) = os.path.splitext(file_in)  # remove Filename Extension
    # file_out = fname + "_" + args.module_type + \
    #    ".bin"  # combine the last name & .bin

    if ModuleType == 'OBC_DSP_APP':
        file_out = file_out_DSP_APP
    elif ModuleType == 'OBC_DSP_BOOT':
        file_out = file_out_DSP_Boot
    elif ModuleType == 'OBC_DSP_CONF':
        file_out = file_out_DSP_CONF
    elif ModuleType == 'OBC_DSP_CALI':
        file_out = file_out_DSP_CALI
    elif ModuleType == 'OBC_DSP_DEBUG':
        file_out = file_out_DSP_APP
    else:
        print('ModuleType input fail')
        return

    convert_file_format(file_in, file_out, ModuleType)
    print("conver hex2bin finish")
    return file_out
    # except:
    #    print("conver hex2bin error")
    #    return NONE
"""

if __name__ == "__main__":
    main()
