# IntelHex library version information 
version_info = (2, 2, 1)
version_str = '.'.join([str(i) for i in version_info])
