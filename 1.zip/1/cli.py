import can
import cantools
import isotp
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.client import Client
from udsoncan.services import *
from udsoncan import Dtc

from ctypes import *
from aes import AES
from uds_did import *
from uds_rid import *
from datetime import datetime
from crccheck.crc import Crc16CcittFalse
from crccheck.crc import Crc16Dnp
import yaml
#from ruamel.yaml import YAML as yaml
import sys
import bincopy
import math
from yaml2bin import *
import os
import argparse  # for receive the command form cmd window
from argparse import RawTextHelpFormatter

from hex2bin_converter import cHex2Bin
import time


OBC_CLI_VERSION = '1.3'  # 2023.01.11

CALI_YAML_FILE = 'ObcCali.yaml'
CONF_YAML_FILE = 'ObcConf.yaml'

FlashDriverFileName = 'flash_api.bin'
FlashDriverTargetAddr = 0x1FFF8010
FlashDriverBlockId = 0

McuApplicationFileName = 'McuAppl.bin'
McuApplicationTargetAddr = 0x00020200
McuApplicationBlockId = 1

ConfigurationDataFileName = 'ObcConf.bin'
ConfigurationDataTargetAddr = 0x0007E000
ConfigurationDataBlockId = 2

CalibrationDataFileName = 'ObcCali.bin'
CalibrationDataTargetAddr = 0x0007F000
CalibrationDataBlockId = 3

DspBootloaderFileName = 'DspBoot.bin'
DspBootloaderTargetAddr = 0x00008000    # address in F280049 SRAM
DspBootloaderBlockId = 10

DspApplicationFileName = 'DspAppl.bin'
DspApplicationTargetAddr = 0x0000A000    # address in F280049 SRAM
DspApplicationBlockId = 11

DspConfigFileName = 'DspConf.bin'
DspConfigTargetAddr = 0x0000A000    # address in F280049 SRAM
DspConfigBlockId = 12

DspCalibrationFileName = 'DspCali.bin'
DspCalibrationTargetAddr = 0x0000A000    # address in F280049 SRAM
DspCalibrationBlockId = 13

DspCalibrationClrFileName = 'DspCaliClr.bin'
DspCalibrationClrTargetAddr = 0x0000A000    # address in F280049 SRAM
DspCalibrationClrBlockId = 13

'''
    DCDC CAN message ID
'''
CAN_MSG_RX_DIAGNOS_RESP_ID = 0x7E8
CAN_MSG_TX_DIAGNOS_PHY_ID = 0x7E0
CAN_MSG_TX_DIAGNOS_FUN_ID = 0x7DF

DID_DATA_TYEP_CALIBRATION = 1
DID_DATA_TYPE_CONFIGURATION = 2

isotp_params = {
    # Will request the sender to wait 32ms between consecutive frame. 0-127ms or 100-900ns with values from 0xF1-0xF9
    'stmin': 0,
    # Request the sender to send 8 consecutives frames before sending a new flow control message
    'blocksize': 0,
    # Number of wait frame allowed before triggering an error
    'wftmax': 0,
    # Link layer (CAN layer) works with 8 byte payload (CAN 2.0)
    'll_data_length': 8,
    # Will pad all transmitted CAN messages with byte 0xAA. None means no padding
    'tx_padding': 0xaa,
    # Triggers a timeout if a flow control is awaited for more than 1000 milliseconds
    'rx_flowcontrol_timeout': 3000,
    # Triggers a timeout if a consecutive frame is awaited for more than 1000 milliseconds
    'rx_consecutive_frame_timeout': 3000,
    # When sending, respect the stmin requirement of the receiver. If set to True, go as fast as possible.
    'squash_stmin_requirement': False
}


class OBC():

    def __init__(self):
        super().__init__()

        self.pcan = None                        # channel of the CAN bus device
        self.dbc = None                         # DBC file handler
        self.channel = None                     # OBC on which PCAN channel
        self.log = None                         # temporary MDF log file handler

        self.LvFwVer = ''                       # firmware version of LV MCU

        return

    def canOpen(self, can_channel, can_handler):
        if can != None:
            self.pcan = can_handler
            self.channel = can_channel

            if ('PCAN' in self.channel):
                self.enablePcanAutoReset()

            # create a ISO-TP connection
            isotp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits,
                                       txid=CAN_MSG_TX_DIAGNOS_PHY_ID,
                                       rxid=CAN_MSG_RX_DIAGNOS_RESP_ID)

            stack = isotp.CanStack(bus=self.pcan,
                                   address=isotp_addr,
                                   params=isotp_params)

            self.IsoTpConn = PythonIsoTpConnection(stack)

    # Ricky add this function @ 2022.12.23
    def progress_bar(self, i, chunk_num, time_start):
        progress = (i/chunk_num)*100
        #print(f'\r[{progress:.2f}%]', end='')
        # 加入進度條
        # https://steam.oxxostudio.tw/category/python/example/progress-bar.html
        progress_bar_total = int(100/2)
        progress_int = int(progress/2)
        # 加入計時
        # https://www.gushiciku.cn/pl/pEJ1/zh-tw
        time_end = time.time()
        time_c = time_end-time_start
        print(
            f'\r[{progress:.2f}%][{"█"*progress_int}{" "*(progress_bar_total-progress_int)}] {time_c:.1f}second', end='')

    def enablePcanAutoReset(self):
        PCAN_BUSOFF_AUTORESET = c_ubyte(0x07)
        PCAN_PARAMETER_ON = int(0x01)
        PCAN_USBBUS1 = c_ushort(0x51)
        PCAN_USBBUS2 = c_ushort(0x52)
        PCAN_USBBUS3 = c_ushort(0x53)
        PCAN_USBBUS4 = c_ushort(0x54)

        if self.channel == 'PCAN_USBBUS1':
            channel = PCAN_USBBUS1
        elif self.channel == 'PCAN_USBBUS2':
            channel = PCAN_USBBUS2
        elif self.channel == 'PCAN_USBBUS3':
            channel = PCAN_USBBUS3
        elif self.channel == 'PCAN_USBBUS4':
            channel = PCAN_USBBUS4
        else:
            channel = PCAN_USBBUS1

        ret = self.pcan.m_objPCANBasic.SetValue(
            channel,
            PCAN_BUSOFF_AUTORESET,
            PCAN_PARAMETER_ON)
        # print (f"{self.channel} enable auto_reset, ret=0x{ret:08X}")

    def requestFirmwareVersion(self):
        '''
        send a UDS service 0xB0_06 to request MCUs' fw version
        '''
        self.LvFwVer = '...'

        with Client(self.IsoTpConn,
                    request_timeout=1) as client:

            # enter extend session before write DID
            ret = client.change_session(3)
            if (ret.positive):
                ret_ok = True
                print('request OBC to change its session to extend, OK')

    def getApmModeCmd(self, cmd):
        '''
        get the APM command name string from DBC signal
        '''
        apmCmdDict = {0: 'INVALID',
                      1: 'OFF(IDLE)',
                      2: 'STANDBY',
                      3: 'DCDC',
                      4: 'PRECHARGE',
                      5: 'DISCHARGE',
                      255: 'TEST'}

        if cmd in apmCmdDict:
            cmdStr = apmCmdDict[cmd]
        else:
            cmdStr = 'Unknown'

        return cmdStr

    def getApmWrokingMode(self, index):
        '''
        get the APM working mode name string from DBC signal
        '''
        apmModeDict = {1: 'PowerOn',
                       2: 'Standby',
                       3: 'Fault',
                       4: 'Idle',
                       5: 'Soft-Start',
                       6: 'DCDC',
                       7: 'Precharge',
                       8: 'Discharge',
                       9: 'Flash',
                       10: 'Latch',
                       11: 'Sleep',
                       15: 'Test'}

        if index in apmModeDict:
            modeStr = apmModeDict[index]
        else:
            modeStr = 'Unknown'

        return modeStr

    def getObcModeCmd(self, cmd):
        '''
        get the OBC command name string from DBC signal
        '''
        obcCmdDict = {0: 'STANDBY',
                      1: 'ACDC',
                      2: 'OFF',
                      3: 'START', }

        if cmd in obcCmdDict:
            cmdStr = obcCmdDict[cmd]
        else:
            cmdStr = 'Unknown'

        return cmdStr

    def getObcWrokingMode(self, index):
        '''
        get the OBC working mode name string from DBC signal
        '''
        obcModeDict = {0: 'START',
                       1: 'IDLE',
                       2: 'STANDBY',
                       3: 'ACDC',
                       4: 'OFF',
                       5: 'FAULT',
                       6: 'LATCH', }

        if index in obcModeDict:
            modeStr = obcModeDict[index]
        else:
            modeStr = 'Unknown'

        return modeStr

    def getApmErrFlag(self, flags):
        '''
        get APM's error flag name string list
        '''
        if flags == 0:
            errStr = 'None'
        else:
            errStr = ''
            errStr += 'SBC_ERR ' if ((flags & 0x0000000001) != 0) else ''
            errStr += 'SBC_FS ' if ((flags & 0x0000000002) != 0) else ''
            errStr += 'CONF_ERR ' if ((flags & 0x0000000004) != 0) else ''
            errStr += 'CONF_EMPTY ' if ((flags & 0x0000000008) != 0) else ''
            errStr += 'DSP_NG ' if ((flags & 0x0000000010) != 0) else ''
            errStr += 'CAN_LOSS_DSP ' if ((flags & 0x0000000020) != 0) else ''
            errStr += 'CAN_LOSS_VCU ' if ((flags & 0x0000000040) != 0) else ''
            errStr += 'OBC_NG ' if ((flags & 0x0000000080) != 0) else ''

            errStr += 'BAT_OV ' if ((flags & 0x0000000100) != 0) else ''
            errStr += 'BAT_UV ' if ((flags & 0x0000000200) != 0) else ''
            errStr += 'LV_AUX_OV ' if ((flags & 0x0000000400) != 0) else ''
            errStr += 'LV_AUX_UV ' if ((flags & 0x0000000800) != 0) else ''
            errStr += 'LV_OV_HW ' if ((flags & 0x0000001000) != 0) else ''
            errStr += 'LV_OV_SW ' if ((flags & 0x0000002000) != 0) else ''
            errStr += 'LV_UV ' if ((flags & 0x0000004000) != 0) else ''
            errStr += 'LV_OC_HW ' if ((flags & 0x0000008000) != 0) else ''

            errStr += 'LV_OC_SW ' if ((flags & 0x0000010000) != 0) else ''
            errStr += 'APM_HV_OV ' if ((flags & 0x0000020000) != 0) else ''
            errStr += 'APM_HV_UV ' if ((flags & 0x0000040000) != 0) else ''
            errStr += 'APM_HV_OC ' if ((flags & 0x0000080000) != 0) else ''
            errStr += 'PCB_OT ' if ((flags & 0x0000100000) != 0) else ''
            errStr += 'SR_OT ' if ((flags & 0x0000200000) != 0) else ''
            errStr += 'COOL_OT ' if ((flags & 0x0000400000) != 0) else ''
            errStr += 'BST_OV_SW ' if ((flags & 0x0000800000) != 0) else ''

            errStr += 'BST_OV_HW ' if ((flags & 0x0001000000) != 0) else ''
            errStr += 'BST_OC ' if ((flags & 0x0002000000) != 0) else ''
            errStr += 'LV_OP ' if ((flags & 0x0004000000) != 0) else ''
            errStr += 'CP_OF ' if ((flags & 0x0008000000) != 0) else ''
            errStr += 'CP_UF ' if ((flags & 0x0010000000) != 0) else ''
            errStr += 'HV_AUX_OV ' if ((flags & 0x0020000000) != 0) else ''
            errStr += 'HV_AUX_UV ' if ((flags & 0x0040000000) != 0) else ''
            errStr += 'BST_UV ' if ((flags & 0x0080000000) != 0) else ''

            errStr += 'CPU_ERR ' if ((flags & 0x0100000000) != 0) else ''
            errStr += 'CALI_ERR ' if ((flags & 0x0200000000) != 0) else ''
            errStr += 'CALI_EMPTY ' if ((flags & 0x0400000000) != 0) else ''
            errStr += 'DIAG_OV_FAIL ' if ((flags & 0x0800000000) != 0) else ''
            errStr += 'DIAG_SC_FAIL ' if ((flags & 0x1000000000) != 0) else ''

        return errStr

    def getObcErrFlag(self, flags):
        '''
        get OBC's error flag name string list
        '''
        if flags == 0:
            errStr = 'None'
        else:
            errStr = ''
            errStr += 'PFC_C_OCP_SW ' if ((flags & 0x0000000001) != 0) else ''
            errStr += 'PFC_B_OCP_SW ' if ((flags & 0x0000000002) != 0) else ''
            errStr += 'PFC_A_OCP_SW ' if ((flags & 0x0000000004) != 0) else ''
            errStr += 'GRID_RMS_UVP_SW ' if ((flags &
                                             0x0000000008) != 0) else ''
            errStr += 'GRID_RMS_OVP_SW ' if ((flags &
                                             0x0000000010) != 0) else ''
            errStr += 'GRID_OVP_SW ' if ((flags & 0x0000000020) != 0) else ''
            errStr += 'GRID_UFP_SW ' if ((flags & 0x0000000040) != 0) else ''
            errStr += 'GRID_OFP_SW ' if ((flags & 0x0000000080) != 0) else ''

            errStr += 'HVDC_SCP_HW ' if ((flags & 0x0000000100) != 0) else ''
            errStr += 'HVDC_OCP_SW ' if ((flags & 0x0000000200) != 0) else ''
            errStr += 'PFC_AUX_UVP_SW ' if ((flags &
                                            0x0000000400) != 0) else ''
            errStr += 'PFC_AUX_OVP_SW ' if ((flags &
                                            0x0000000800) != 0) else ''
            errStr += 'PFC_UVP_SW ' if ((flags & 0x0000001000) != 0) else ''
            errStr += 'PFC_OVP_SW ' if ((flags & 0x0000002000) != 0) else ''
            errStr += 'PFC_OVP_HW ' if ((flags & 0x0000004000) != 0) else ''
            errStr += 'PFC_D_OCP_SW ' if ((flags & 0x0000008000) != 0) else ''

            errStr += 'DSP_CALI_ERR ' if ((flags & 0x0000010000) != 0) else ''
            errStr += 'DSP_SELF_TEST_ERR ' if ((flags &
                                               0x0000020000) != 0) else ''
            errStr += 'OBC_OTP_3_SW ' if ((flags & 0x0000040000) != 0) else ''
            errStr += 'NTC_LLC_MOS_SW ' if ((flags &
                                            0x0000080000) != 0) else ''
            errStr += 'NTC_PFC_MOS_SW ' if ((flags &
                                            0x0000100000) != 0) else ''
            errStr += 'HVDC_UVP_SW ' if ((flags & 0x0000200000) != 0) else ''
            errStr += 'HVDC_OVP_SW ' if ((flags & 0x0000400000) != 0) else ''
            errStr += 'HVDC_OVP_HW ' if ((flags & 0x0000800000) != 0) else ''

            errStr += 'DIAG_HV_SC_FAIL ' if ((flags &
                                             0x0001000000) != 0) else ''
            errStr += 'DIAG_HV_OC_FAIL ' if ((flags &
                                             0x0002000000) != 0) else ''
            errStr += 'DIAG_HV_OV_FAIL ' if ((flags &
                                             0x0004000000) != 0) else ''
            errStr += 'HVDC_OCP_HW ' if ((flags & 0x0008000000) != 0) else ''
            errStr += 'LOST_OF_CAN ' if ((flags & 0x0010000000) != 0) else ''
            errStr += 'DSP_CONF_EMPTY ' if ((flags &
                                            0x0020000000) != 0) else ''
            errStr += 'DSP_CONF_ERR ' if ((flags & 0x0040000000) != 0) else ''
            errStr += 'DSP_CALI_EMPTY ' if ((flags &
                                            0x0080000000) != 0) else ''

            errStr += 'NTC_LLC_MOS_CMPSS5 ' if (
                (flags & 0x0100000000) != 0) else ''
            errStr += 'NTC_PFC_MOS_CMPSS4 ' if (
                (flags & 0x0200000000) != 0) else ''
            errStr += 'PFC_AUX_OVP_CMPSS3 ' if (
                (flags & 0x0400000000) != 0) else ''
            errStr += 'PFC_C_OCP_CMPSS2 ' if ((flags &
                                              0x0800000000) != 0) else ''
            errStr += 'PFC_B_OCP_CMPSS2 ' if ((flags &
                                              0x1000000000) != 0) else ''
            errStr += 'HVDC_OVP_CMPSS1 ' if ((flags &
                                             0x2000000000) != 0) else ''
            errStr += 'HVDC_OCP_CMPSS1 ' if ((flags &
                                             0x4000000000) != 0) else ''
            errStr += 'DIAG_PFC_OV_FAIL ' if ((flags &
                                              0x8000000000) != 0) else ''

            errStr += 'PFC_OVP_CMPSS7 ' if ((flags &
                                            0x200000000000) != 0) else ''
            errStr += 'PFC_D_OCP_CMPSS6 ' if ((flags &
                                              0x400000000000) != 0) else ''
            errStr += 'PFC_A_OCP_CMPSS6 ' if ((flags &
                                              0x800000000000) != 0) else ''

        return errStr

    def printSnapshotRecord(self, data):
        '''
        print snapshot record data structure
        '''
        snapshot = DiagDid_Snapshot()
        record = snapshot.decode(data)
        year = record.wYear
        mon = record.bMonth
        day = record.bDay
        hour = record.bHour
        min = record.bMinute
        sec = record.bSecond
        ms = record.b100ms

        ApmModeCmdStr = self.getApmModeCmd(record.bApmModeCmd)
        ApmWorkModeStr = self.getApmWrokingMode(record.bApmWorkMode)
        ObcWorkModeStr = self.getObcWrokingMode(record.bObcWorkMode)
        ObcModeCmdStr = self.getObcModeCmd(record.bObcModeCmd)
        ApmErrStr = self.getApmErrFlag(record.qwApmErrorFlag)
        ObcErrStr = self.getObcErrFlag(record.qwObcErrorFlag)

        print(f'Time: {year}/{mon:02}/{day:02}_{hour:02}:{min:02}:{sec:02}')
        print(f'ApmIgnStatus: {record.bApmIgnStatus}')
        print(f'ApmModeCmd: {ApmModeCmdStr}')
        print(f'ApmWorkingMode: {ApmWorkModeStr}')
        print(f'ApmVcmd: {record.flLvdcVcmd}')
        print(f'ApmIcmd: {record.flLvdcIcmd}')
        print(f'ApmILimit: {record.flLvIoutLimit}')
        print(f'ApmErrorFlag: 0x{record.qwApmErrorFlag:016X}')
        print(f'            = {ApmErrStr}')
        print(f'ApmHvdcVolt: {record.flApmHvdcVolt}')
        print(f'ApmHvdcCurr: {record.flApmHvdcCurr}')
        print(f'ApmLvdcVolt: {record.flApmLvdcVolt}')
        print(f'ApmLvdcCurr: {record.flApmLvdcCurr}')
        print(f'ApmTempPcb: {record.flApmTempPcb}')
        print(f'ApmTempSr: {record.flApmTempSr}')
        print(f'ApmTempCool: {record.flApmTempCool}')
        print(f'ApmLvAuxVolt: {record.flApmLvAuxVolt}')
        print(f'ApmBatVolt: {record.flApmBatVolt}')

        print(f'ObcAuxEnStatus: {record.bHvAuxEnStatus}')
        print(f'ObcModeCmd: {ObcModeCmdStr}')
        print(f'ObcWorkingMode: {ObcWorkModeStr}')
        print(f'ObcVcmd: {record.flHvdcVcmd}')
        print(f'ObcIcmd: {record.flHvdcIcmd}')
        print(f'ObcErrorFlag: 0x{record.qwObcErrorFlag:016X}')
        print(f'            = {ObcErrStr}')
        print(f'ObcPfcAuxVolt: {record.flObcPfcAuxVolt}')
        print(f'ObcPfcCurrA: {record.flObcPfcCurrA}')
        print(f'ObcPfcCurrB: {record.flObcPfcCurrB}')
        print(f'ObcPfcCurrC: {record.flObcPfcCurrC}')
        print(f'ObcPfcCurrD: {record.flObcPfcCurrD}')
        print(f'ObcGridVolt: {record.flObcGridVolt}')
        print(f'ObcGridCurr: {record.flObcGridCurr}')
        print(f'ObcGridFreq: {record.flObcGridFreq}')
        print(f'ObcHvdcVolt: {record.flObcHvdcVolt}')
        print(f'ObcHvdcCurr: {record.flObcHvdcCurr}')
        print(f'ObcBulkVolt: {record.flObcBulkVolt}')
        print(f'ObcHvVoltRef: {record.flObcHvVoltRef}')
        print(f'ObcHvCurrRef: {record.flObcHvCurrRef}')
        print(f'ObcCtrlTheta: {record.flObcCtrlTheta}')
        print(f'ObcCtrlFreq: {record.flObcCtrlFreq}')
        print(f'ObcTempLlc: {record.flObcTempLlc}')
        print(f'ObcTempPfc: {record.flObcTempPfc}')
        '''
        print (f'EvseProxVolt: {record.flEvseProxVolt}')
        print (f'EvsePilotVolt: {record.flEvsePilotVolt}')
        print (f'EvsePilotDuty: {record.flEvsePilotDuty}')
        print (f'EvseImax: {record.flEvseImax}')
        print (f'EvseS2Status: {record.bS2Status}')
        '''

    def printCaliData(self, data):
        '''
        print calibration data structure
        '''
        tag = data.header.tag
        size = data.header.size
        year = data.header.year
        month = data.header.month
        day = data.header.day
        hour = data.header.hour
        minute = data.header.minute
        second = data.header.second
        vbat = data.item[CALI_ITEM_BAT_VOLT_ADC].data
        apm_vout = data.item[CALI_ITEM_LVDC_VOLT_ADC].data
        apm_iout = data.item[CALI_ITEM_LVDC_CURR_ADC].data
        apm_vin = data.item[CALI_ITEM_HVDC_VOLT_APM_ADC].data
        apm_iin = data.item[CALI_ITEM_HVDC_CURR_APM_ADC].data
        apm_vcmd = data.item[CALI_ITEM_LVDC_VOLT_PWM].data
        apm_icmd = data.item[CALI_ITEM_LVDC_CURR_PWM].data
        obc_vout = data.item[CALI_ITEM_HVDC_VOLT_OBC_ADC].data
        obc_iout = data.item[CALI_ITEM_HVDC_CURR_OBC_ADC].data
        obc_vin = data.item[CALI_ITEM_GRID_VOLT_ADC].data
        obc_vbulk = data.item[CALI_ITEM_BULK_VOLT_ADC].data
        obc_iin = data.item[CALI_ITEM_GRID_CURR_ADC].data
        rsvd0 = data.item[CALI_ITEM_RESERVED_0].data
        rsvd1 = data.item[CALI_ITEM_RESERVED_1].data
        rsvd2 = data.item[CALI_ITEM_RESERVED_2].data
        rsvd3 = data.item[CALI_ITEM_RESERVED_3].data
        rsvd4 = data.item[CALI_ITEM_RESERVED_4].data

        print(f'calibration data structure:')
        print(f'tag: {tag[0]:02X} {tag[1]:02X}')
        print(f'size: {size}')
        print(f'type: {data.header.type} (1:calibration, 2:configuration)')
        print(f'date: {year}/{month}/{day} {hour}:{minute}:{second}')
        print(f'data format version: {data.header.version}')
        print(f'write counter: {data.header.writeCount}')
        print(f'CRC16: 0x{data.header.crc16:04X}')
        print(f'APM Vbat Measurement (SBC_MUX_ADC):')
        print(f'      Meter: {vbat[0]:.4f}, {vbat[1]:.4f}')
        print(f'     Native: {vbat[2]:.4f}, {vbat[3]:.4f}')
        print(f'Gain/Offset: {vbat[4]:.4f}, {vbat[5]:.4f}\n')
        print(f'APM Vout Measurement (REMOTE_VOLT_ADC):')
        print(f'      Meter: {apm_vout[0]:.4f}, {apm_vout[1]:.4f}')
        print(f'     Native: {apm_vout[2]:.4f}, {apm_vout[3]:.4f}')
        print(f'Gain/Offset: {apm_vout[4]:.4f}, {apm_vout[5]:.4f}\n')
        print(f'APM Iout Measurement (LVDC_CURR_ADC):')
        print(f'      Meter: {apm_iout[0]:.4f}, {apm_iout[1]:.4f}')
        print(f'     Native: {apm_iout[2]:.4f}, {apm_iout[3]:.4f}')
        print(f'Gain/Offset: {apm_iout[4]:.4f}, {apm_iout[5]:.4f}\n')
        print(f'APM Vin Measurement (HVDC_VOLT_ADC):')
        print(f'      Meter: {apm_vin[0]:.4f}, {apm_vin[1]:.4f}')
        print(f'     Native: {apm_vin[2]:.4f}, {apm_vin[3]:.4f}')
        print(f'Gain/Offset: {apm_vin[4]:.4f}, {apm_vin[5]:.4f}\n')
        print(f'APM Iin Measurement (APM_CURR_ADC):')
        print(f'      Meter: {apm_iin[0]:.4f}, {apm_iin[1]:.4f}')
        print(f'     Native: {apm_iin[2]:.4f}, {apm_iin[3]:.4f}')
        print(f'Gain/Offset: {apm_iin[4]:.4f}, {apm_iin[5]:.4f}\n')
        print(f'APM Vcmd Adjustment (LVDC_CVCC_VOLT_PWM):')
        print(f'      Meter: {apm_vcmd[0]:.4f}, {apm_vcmd[1]:.4f}')
        print(f'     Native: {apm_vcmd[2]:.4f}, {apm_vcmd[3]:.4f}')
        print(f'Gain/Offset: {apm_vcmd[4]:.4f}, {apm_vcmd[5]:.4f}\n')
        print(f'APM Icmd Adjustment (LVDC_CVCC_CURR_PWM):')
        print(f'      Meter: {apm_icmd[0]:.4f}, {apm_icmd[1]:.4f}')
        print(f'     Native: {apm_icmd[2]:.4f}, {apm_icmd[3]:.4f}')
        print(f'Gain/Offset: {apm_icmd[4]:.4f}, {apm_icmd[5]:.4f}\n')
        print(f'OBC Vout Measurement (OBC_VOLT_ADC):')
        print(f'      Meter: {obc_vout[0]:.4f}, {obc_vout[1]:.4f}')
        print(f'     Native: {obc_vout[2]:.4f}, {obc_vout[3]:.4f}')
        print(f'Gain/Offset: {obc_vout[4]:.4f}, {obc_vout[5]:.4f}\n')
        print(f'OBC Iout Measurement (OBC_CURR_ADC):')
        print(f'      Meter: {obc_iout[0]:.4f}, {obc_iout[1]:.4f}')
        print(f'     Native: {obc_iout[2]:.4f}, {obc_iout[3]:.4f}')
        print(f'Gain/Offset: {obc_iout[4]:.4f}, {obc_iout[5]:.4f}\n')
        print(f'OBC Vin Measurement (AC_N/L_VOLT_ADC):')
        print(f'      Meter: {obc_vin[0]:.4f}, {obc_vin[1]:.4f}')
        print(f'     Native: {obc_vin[2]:.4f}, {obc_vin[3]:.4f}')
        print(f'Gain/Offset: {obc_vin[4]:.4f}, {obc_vin[5]:.4f}\n')
        print(f'OBC Vbulk Measurement (BULK_VOLT_ADC):')
        print(f'      Meter: {obc_vbulk[0]:.4f}, {obc_vbulk[1]:.4f}')
        print(f'     Native: {obc_vbulk[2]:.4f}, {obc_vbulk[3]:.4f}')
        print(f'Gain/Offset: {obc_vbulk[4]:.4f}, {obc_vbulk[5]:.4f}\n')
        print(f'OBC Iin Measurement (OBC input current):')
        print(f'      Meter: {obc_iin[0]:.4f}, {obc_iin[1]:.4f}')
        print(f'     Native: {obc_iin[2]:.4f}, {obc_iin[3]:.4f}')
        print(f'Gain/Offset: {obc_iin[4]:.4f}, {obc_iin[5]:.4f}')
        print(f'reserved_0:')
        print(f'      Meter: {rsvd0[0]:.4f}, {rsvd0[1]:.4f}')
        print(f'     Native: {rsvd0[2]:.4f}, {rsvd0[3]:.4f}')
        print(f'Gain/Offset: {rsvd0[4]:.4f}, {rsvd0[5]:.4f}')
        print(f'reserved_1:')
        print(f'      Meter: {rsvd1[0]:.4f}, {rsvd1[1]:.4f}')
        print(f'     Native: {rsvd1[2]:.4f}, {rsvd1[3]:.4f}')
        print(f'Gain/Offset: {rsvd1[4]:.4f}, {rsvd1[5]:.4f}')
        print(f'reserved_2:')
        print(f'      Meter: {rsvd2[0]:.4f}, {rsvd2[1]:.4f}')
        print(f'     Native: {rsvd2[2]:.4f}, {rsvd2[3]:.4f}')
        print(f'Gain/Offset: {rsvd2[4]:.4f}, {rsvd2[5]:.4f}')
        print(f'reserved_3:')
        print(f'      Meter: {rsvd3[0]:.4f}, {rsvd3[1]:.4f}')
        print(f'     Native: {rsvd3[2]:.4f}, {rsvd3[3]:.4f}')
        print(f'Gain/Offset: {rsvd3[4]:.4f}, {rsvd3[5]:.4f}')
        print(f'reserved_4:')
        print(f'      Meter: {rsvd4[0]:.4f}, {rsvd4[1]:.4f}')
        print(f'     Native: {rsvd4[2]:.4f}, {rsvd4[3]:.4f}')
        print(f'Gain/Offset: {rsvd4[4]:.4f}, {rsvd4[5]:.4f}')
        print('\n-END-')

    def printProtectionItem(self, prot_param, name):
        disable = prot_param.disable
        trigger = prot_param.trigger
        t_time = prot_param.t_time
        recover = prot_param.recover
        r_time = prot_param.r_time
        retry = prot_param.retry
        limit = prot_param.limit
        interval = prot_param.interval
        print(
            f'{name}\t[{chr(disable)}]\t{trigger:.01f}\t{t_time}\t{recover:.01f}\t{r_time}\t[{chr(retry)}]\t{limit}\t{interval}')

    def printConfData(self, data):
        '''
        print configuration data structure
        '''
        tag = data.header.tag
        size = data.header.size
        year = data.header.year
        month = data.header.month
        day = data.header.day
        hour = data.header.hour
        minute = data.header.minute
        second = data.header.second
        j1112 = data.func[CONF_DISA_J1772]
        derate = data.func[CONF_DISA_DERATING]
        prechg = data.func[CONF_DISA_PRECHARGE]
        dischg = data.func[CONF_DISA_DISCHARGE]
        nm = data.func[CONF_DISA_NM]

        print(f'tag: {tag[0]:02X} {tag[1]:02X}')
        print(f'size: {size}')
        print(f'type: {data.header.type} (1:calibration, 2:configuration)')
        print(f'date: {year}/{month}/{day} {hour}:{minute}:{second}')
        print(f'data format version: {data.header.version}')
        print(f'write counter: {data.header.writeCount}')
        print(f'CRC16: 0x{data.header.crc16:04X}\n')
        print(f'Disable Sub-Function:')
        print(f'J1772   Derate  PreChr  DisChr  NM      CanWake Rsvd...')
        for i in range(CONF_DISA_NUMBER):
            chart = chr(data.func[i])
            if chart == 'T':
                print(f'{chr(data.func[i])}', end='\t')
            else:
                print(f'{data.func[i]:02X}', end='\t')
        print('\n')
        print(
            f'ITEM\t  [DISABLE] trigger time(ms) recover time(ms) [retry] limit interval')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CAN_LOSS_MCU], 'DSP_CAN_LOSS')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_HV_OVP_SW], 'DSP_HV_OVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_HV_OVP_HW], 'DSP_HV_OVP_HW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_HV_UVP], 'DSP_HV_UVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_HV_OCP_SW], 'DSP_HV_OCP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_HV_OCP_HW], 'DSP_HV_SCP_HW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_GRID_OVP], 'DSP_GRID_OVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_RMS_GRID_OVP], 'DSP_RMS_GRID_OV')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_RMS_GRID_UVP], 'DSP_RMS_GRID_UV')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_GRID_UFP], 'DSP_GRID_UFP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_GRID_OFP], 'DSP_GRID_OFP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_PFC_MOS_OCP], 'DSP_PFC_MOS_OCP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_LLC_OCP_HW], 'DSP_LLC_OCP_HW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_PFC_OVP_HW], 'DSP_PFC_OVP_HW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_BULK_OVP_SW], 'DSP_BULK_OVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_BULK_UVP], 'DSP_BULK_UVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_PFC_AUX_UVP], 'DSP_PFC_AUX_UVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_PFC_AUX_OVP], 'DSP_PFC_AUX_OVP')
        self.printProtectionItem(data.prot[CONF_ITEM_DSP_OTP_1], 'DSP_OTP_1')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_LLC_OTP], 'DSP_LLC_OTP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_PFC_OTP], 'DSP_PFC_OTP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_DIAG_HV_OVP], 'DSP_DIAG_HV_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_DIAG_LLC_OCP], 'DSP_DIAG_LLC_OC')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_DIAG_HV_SCP], 'DSP_DIAG_HV_SCP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_DIAG_PFC_OVP], 'DSP_DIAG_PFC_OV')

        print(
            '\n'+f'ITEM\t  [DISABLE] trigger time(ms) recover time(ms) [retry] limit interval')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_HV_OCP], 'CMPS_HV_OC')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_HV_OVP], 'CMPS_HV_OV')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_PFC_MOS_OCP], 'CMPS_PFC_MOS_OC')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_PFC_AUX_OVP], 'CMPS_PFC_AUX_OV')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_PFC_MOS_OTP], 'CMPS_PFC_MOS_OT')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_LLC_MOS_OTP], 'CMPS_LLC_MOS_OT')
        self.printProtectionItem(
            data.prot[CONF_ITEM_DSP_CMPSS_PFC_OVP], 'CMPS_PFC_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_HV_AUX_OVP], 'MCU_HV_AUX_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_OVP_SW], 'MCU_LV_OVP_SW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_OVP_HW], 'MCU_LV_OVP_HW')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_LV_UVP], 'MCU_LV_UVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_AUX_UVP], 'MCU_LV_AUX_UVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_AUX_OVP], 'MCU_LV_AUX_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_OCP_HW], 'MCU_LV_OCP_HW')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_LV_OCP_SW], 'MCU_LV_OCP_SW')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_LV_OPP], 'MCU_LV_OPP')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_HV_OVP], 'MCU_HV_OVP')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_HV_UVP], 'MCU_HV_UVP')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_HV_OCP], 'MCU_HV_OCP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_PCB_OTP], 'MCU_PCB_OTP')
        self.printProtectionItem(data.prot[CONF_ITEM_MCU_SR_OTP], 'MCU_SR_OTP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_COOLANT_OTP], 'MCU_COOL_OTP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_BAT_OVP], 'MCU_BAT_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_BAT_UVP], 'MCU_BAT_UVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_EVSE_OFP], 'MCU_EVSE_OFP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_EVSE_UFP], 'MCU_EVSE_UFP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_DIAG_OVP], 'MCU_DIAG_OVP')
        self.printProtectionItem(
            data.prot[CONF_ITEM_MCU_DIAG_SCP], 'MCU_DIAG_SCP')
        self.printProtectionItem(data.prot[CONF_ITEM_RESERVED_0], 'RESERVED_0')
        self.printProtectionItem(data.prot[CONF_ITEM_RESERVED_1], 'RESERVED_1')
        self.printProtectionItem(data.prot[CONF_ITEM_RESERVED_2], 'RESERVED_2')
        self.printProtectionItem(data.prot[CONF_ITEM_RESERVED_3], 'RESERVED_3')
        self.printProtectionItem(data.prot[CONF_ITEM_RESERVED_4], 'RESERVED_4')

        print('\n')
        print(f'PFC Kp/Ki:', end='\t')
        for i in range(8):
            value = data.kpki[i]
            if value < 10.0:
                print(f'{value:.5f}', end='\t')
            else:
                print(f'{value:.2f}', end='\t')
        print(' ')

        print(f'LLC Kp/Ki:', end='\t')
        for i in range(8):
            value = data.kpki[i+8]
            if value < 10.0:
                print(f'{value:.5f}', end='\t')
            else:
                print(f'{value:.2f}', end='\t')
        print('\n-END-')

    def readCalibrationData(self):
        '''
        read calibration data by DID 0xCADA
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.read_data_by_identifier(DID_CalData)
            if (ret.positive):
                calData = ret.service_data.values[DID_CalData]
                print('read calibration data OK.')
                self.printCaliData(calData)
                save_cali_yaml(calData)
            else:
                print('read DID ERROR! ')

    def readConfigurationData(self):
        '''
        read configuration data by DID 0xC0F1
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.change_session(1)      # enter default session
            if (ret.positive):
                print('request OBC to change its session to default, OK')
            else:
                print('change_session(1) ERROR! ')

            ret = client.read_data_by_identifier(DID_ConfData)
            if (ret.positive):
                confData = ret.service_data.values[DID_ConfData]
                print('read configuration data OK.')
                self.printConfData(confData)

                save_conf_yaml(confData)
            else:
                print('read DID ERROR! ')

    def securityUnlockLevel(self, client, level, use_def_key=False):
        '''
        to unlock security at certain level
        '''
        IsUserKey1Loaded = False

        ret = client.request_seed(level)        # request seed
        if (ret.positive):
            print('request seed OK')
            payload = ret.get_payload()
            seed = payload[2:]

            '''
            if(any(seed[8:16])):
                print('User Key 1 is loaded')
                IsUserKey1Loaded = True
            else:
                print('Warnging !! User Key 1 is empty, use default eky')
                IsUserKey1Loaded = False
            '''
        else:
            print('request_seed(1) ERROR! ')

        if (ret.positive):                      # if no kye, use the default key
            if use_def_key == True:
                private_key = bytes.fromhex(default_key)
            else:
                if IsUserKey1Loaded == False:
                    private_key = bytes.fromhex(default_key)
                else:
                    private_key = bytes.fromhex(user_key1)

            aes128 = AES(private_key)

            result = aes128.encrypt_block(seed)  # key = AES128_Ectrypt(seed)
            keyHexStr = ''.join('{:02X}'.format(i) for i in result)
            print(f'result = {keyHexStr}')

            ret = client.send_key(1, result)    # send key
            if (ret.positive):
                print(f'send security key PASS')
            else:
                print('send security key, ERROR! ')

        return ret

    def writeCalibrationData(self, yaml_data=None):
        '''
        write calibration data by DID 0xCADA
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('request OBC to change its session to extend, OK')
            else:
                print('change_session(3) ERROR! ')

            if (ret.positive):                   # to unlock security
                ret = self.securityUnlockLevel(client, 1, True)

            if (ret.positive):
                caldata = CalibrationData()

                if yaml_data == None:
                    self.fillCaliDefaultData(caldata)
                else:
                    print(f'write Calibration Data = {CALI_YAML_FILE}')
                    self.fillCaliUserData(caldata, yaml_data)

                ret = client.write_data_by_identifier(DID_CalData, caldata)
                if (ret.positive):
                    print(f'write DID PASS')
                else:
                    print('write DID, ERROR! ')

    def writeConfigurationData(self, yaml_data=None):
        '''
        write configuration data by DID 0xC0F1
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('request OBC to change its session to extend, OK')
            else:
                print('change_session(3) ERROR! ')

            if (ret.positive):                   # to unlcok security
                ret = self.securityUnlockLevel(client, 1, True)

            if (ret.positive):
                confdata = ConfigurationData()
                if yaml_data == None:
                    print('write Configuration Data = default')
                    self.fillConfDefaultData(confdata)
                else:
                    print(f'write Configuration Data = {CONF_YAML_FILE}')
                    self.fillConfUserData(confdata, yaml_data)
                ret = client.write_data_by_identifier(DID_ConfData, confdata)
                if (ret.positive):
                    print(f'write DID PASS')
                else:
                    print('write DID, ERROR! ')

    def resetCalibrationData(self):
        '''
        clear the calibration data in the MCU's SRAM, it doesn't touch EEPROM
        '''
        with Client(self.IsoTpConn, request_timeout=1) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('request OBC to change its session to extend, OK')
            else:
                print('change_session(3) ERROR! ')

            if (ret.positive):                   # to unlcok security
                ret = self.securityUnlockLevel(client, 1, True)

            if (ret.positive):
                ret = client.start_routine(RID_CalDataClear)

    def openSrecordFile(self, fname):
        try:
            self.s19 = bincopy.BinFile(fname)
            # print(f'S-Record : {self.s19.info()}')
        except Exception as e:
            print(e)
            self.s19 = None

        if self.s19 == None:
            return -1
        else:
            self.s19.fill()
            self.s19.crc = Crc16Dnp.calc(self.s19.segments[0].data)
            print(f'S-Record after fill, {self.s19.info()}')
            for segment in self.s19.segments:
                print(
                    f'addr = 0x{segment.address:08X}, size = {len(segment.data)}')
            print(f'CRC16ndt = 0x{self.s19.crc:04X}')
            return 0

    def openFlashDriverFile(self):
        fname = FlashDriverFileName
        addr = FlashDriverTargetAddr
        try:
            binfile = open(fname, 'rb')
            self.fd = bincopy.BinFile()
            filedata = binfile.read()
            self.fd.add_binary(filedata, address=addr)
            self.fd.crc = Crc16Dnp.calc(filedata)
            self.fd.id = FlashDriverBlockId
        except Exception as e:
            print(e)
            self.fd = None

        if self.fd == None:
            return -1
        else:
            print(f'Binary file, {self.fd.info()}')
            for segment in self.fd.segments:
                print(
                    f'addr = 0x{segment.address:08X}, size = {len(segment.data)}')
            print(f'CRC16ndt = 0x{self.fd.crc:04X}')
            print(f'Block ID = 0x{self.fd.id}')
            return 0

    def openInputFile(self, fname):

        if fname == McuApplicationFileName:
            addr = McuApplicationTargetAddr
            id = McuApplicationBlockId
        elif fname == ConfigurationDataFileName:
            addr = ConfigurationDataTargetAddr
            id = ConfigurationDataBlockId
        elif fname == CalibrationDataFileName:
            addr = CalibrationDataTargetAddr
            id = CalibrationDataBlockId
        elif fname == DspBootloaderFileName:
            addr = DspBootloaderTargetAddr
            id = DspBootloaderBlockId
        elif fname == DspApplicationFileName:
            addr = DspApplicationTargetAddr
            id = DspApplicationBlockId
        elif fname == DspConfigFileName:
            addr = DspConfigTargetAddr
            id = DspConfigBlockId
        elif fname == DspCalibrationFileName:
            addr = DspCalibrationTargetAddr
            id = DspCalibrationBlockId
        elif fname == DspCalibrationClrFileName:
            addr = DspCalibrationClrTargetAddr
            id = DspCalibrationClrBlockId
        else:
            print(f'Unknown input file, {fname}')
            return -1

        try:
            binfile = open(fname, 'rb')
            self.block = bincopy.BinFile()
            filedata = binfile.read()
            self.block.add_binary(filedata, address=addr)
            self.block.crc = Crc16Dnp.calc(filedata)
            self.block.id = id
        except Exception as e:
            print(e)
            self.block = None

        if self.block == None:
            return -1
        else:
            print(f'Input file, {self.block.info()}')
            for segment in self.block.segments:
                print(
                    f'addr = 0x{segment.address:08X}, size = {len(segment.data)}')
            print(f'CRC16ndt = 0x{self.block.crc:04X}')
            print(f'Block ID = 0x{self.block.id}')
            return 0

    def clearCalibrationData(self):
        '''
        erase the calibraton data sector
        '''
        self.fd = None                          # flash driver file handler
        self.block = None                       # input file handler

        ret = self.openFlashDriverFile()        # read flash driver binary file
        if (ret != 0):
            print(f"Can't open {FlashDriverFileName}")
            return -1

        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('change to extend session')
            else:
                print('change_session(3) ERROR! ')
                return -2

                # communication control
            comm_off = CommunicationControl.ControlType.disableRxAndTx
            subnet = 0
            normal_msg = True
            nm_msg = True
            comm_type = udsoncan.CommunicationType(subnet, normal_msg, nm_msg)
            ret = client.communication_control(comm_off, comm_type)
            if (ret.positive):
                print('trun off normal and nm msg')
            else:
                print('CommunicationControl ERROR! ')
                return -2

            ret = client.change_session(2)      # enter program session
            if (ret.positive):
                print('change to program session')
            else:
                print('change_session(2) ERROR! ')
                return -2
                # to unlcok security
            ret = self.securityUnlockLevel(client, 1, False)
            if (ret.positive):
                print('security unlocked')
            else:
                print('CommunicationControl ERROR! ')
                return -2

            fpData = ApplFingerPrintData()
            fpData.ApplFp = (c_ubyte * 2)(0x55, 0x55)
            ret = client.write_data_by_identifier(DID_AppFinger, fpData)
            if (ret.positive):
                print('clear DID 0xF15A (fingerprint)')
            else:
                print('WriteData fingerprint ERROR! ')
                return -2
                # request download flash driver
            addr = self.fd.id
            size = len(self.fd.segments[0].data)
            memBlock = udsoncan.MemoryLocation(addr, size, 8, 32)
            bufSize = 0

            ret = client.request_download(memBlock)
            if (ret.positive):
                bufSize = ret.service_data.max_length
                print(f'Max Download Block Size: {bufSize}')
            else:
                print('RequestDownload ERROR!')
                return -2

            i = 0                               # tranfer data
            chunk_num = math.ceil(size/bufSize)
            print(f'Transfer Data ...\n total block number: {chunk_num}')

            time_start = time.time()
            for chunk in self.fd.segments[0].chunks(bufSize):
                i += 1
                seq = i % 256
                data = bytes(chunk.data)
                ret = client.transfer_data(seq, data)
                if (ret.positive != True):
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    self.progress_bar(i, chunk_num, time_start)
                    # progress = (i/chunk_num)*100
                    # print(f'\r[{progress:.2f}%]', end='')

            ret = client.request_transfer_exit()  # transfer exit
            if (ret.positive != True):
                print(f'\nTransferExit ERROR! NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'\nTranfer {FlashDriverFileName} to SRAM complete')

                # start routine, check CRC
            bin_crc = bytes([0, 0, (self.fd.crc >> 8), (self.fd.crc & 0x00FF)])
            ret = client.start_routine(RID_CrcCheck, bin_crc)
            if (ret.positive != True):
                print(f'Routine 0X{RID_CrcCheck:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'CRC check for {FlashDriverFileName} ok')

                # erase calibration data sector
            FormatAndBlockId = bytes([0x41, CalibrationDataBlockId])
            ret = client.start_routine(RID_EraseFlash, FormatAndBlockId)
            if (ret.positive != True):
                print(f'Routine 0X{RID_EraseFlash:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'Erase the calibration sector complete')

            hard_reset = udsoncan.services.ECUReset.ResetType.hardReset
            ret = client.ecu_reset(hard_reset)  # ECU reset
            if (ret.positive != True):
                print(f'ECU reset ERROR!')
                return -2
            else:
                print(f'Enter application code OK.')

            return 0

    def kebab(self, inputFileName):

        # Ricky add for tranfer hex2bin
        hex2bin = cHex2Bin()

        if hex2bin.convert('OBC_DSP_BOOT') != True:
            print(' [OBC_DSP_Bootloader] Hex/Yami to bin conver fail, please check')
            return -2
        BootloaderFileType = ''
        if inputFileName == DspApplicationFileName:
            BootloaderFileType = 'OBC_DSP_APP'
        elif inputFileName == DspConfigFileName:
            BootloaderFileType = 'OBC_DSP_CONF'
            # conf_bin_file = load_conf_yaml()  # force rebuild conf.bin once @@@@@@@@@@@@
            temp_bin_name = conf_yaml_file_name.split('.')[0]
            temp_bin_name += '.bin'
            conf_bin_file = temp_bin_name  # only fetch the file name
            if conf_bin_file == None:
                sys.exit(-6)
        elif inputFileName == DspCalibrationFileName:
            BootloaderFileType = 'OBC_DSP_CALI'
            # cali_bin_file = load_cali_yaml()   # force rebuild conf.bin once @@@@@@@@@@@@
            temp_bin_name = cali_yaml_file_name.split('.')[0]
            temp_bin_name += '.bin'
            cali_bin_file = temp_bin_name  # only fetch the file name
            if cali_bin_file == None:
                sys.exit(-5)
        elif inputFileName == DspCalibrationClrFileName:
            BootloaderFileType = 'OBC_DSP_CALI_CLR'
            cali_bin_file = load_cali_yaml()   # force rebuild conf.bin once  @@@@@@@@@@@@
            # temp_bin_name = cali_yaml_file_name.split('.')[0]
            # temp_bin_name += '.bin'
            # cali_bin_file = temp_bin_name  # only fetch the file name
            if cali_bin_file == None:
                sys.exit(-5)
        else:
            print('BOOT Type fail.')
            return

        # os.system("pause")

        # copy bin file
        if hex2bin.copy_yaml_bin_file(BootloaderFileType) != True:
            print('Hex/Yami to bin copy fail, please check')
            return -2

        if hex2bin.convert(BootloaderFileType) != True:
            print(f' {BootloaderFileType} Hex/Yami to bin conver fail, please check')
            return -2
        # os.system("pause")
        """
        reflash DSP application with UDSonCAN bootloader
       """
        self.block = None                       # input file handler

        # 1st START  ----------------------------DSP.1st: Bootloader Function
        # this is fix the Bootloader file name
        ret = self.openInputFile(DspBootloaderFileName)  # read the input file
        print('DspBootloaderFileName2=', DspBootloaderFileName)

        if (ret != 0):
            print(f"Can't open {DspBootloaderFileName}")
            return -1

        with Client(self.IsoTpConn, request_timeout=5.0, config=DidCfg) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('change to extend session')
            else:
                print('change_session(3) ERROR! ')
                return -2

                # communication control
            comm_off = CommunicationControl.ControlType.disableRxAndTx
            subnet = 0
            normal_msg = True
            nm_msg = True
            comm_type = udsoncan.CommunicationType(subnet, normal_msg, nm_msg)
            ret = client.communication_control(comm_off, comm_type)
            if (ret.positive):
                print('trun off normal and nm msg')
            else:
                print('CommunicationControl ERROR! ')
                return -2

            ret = client.change_session(2)      # enter program session
            if (ret.positive):
                print('change to program session')
            else:
                print('change_session(2) ERROR! ')
                return -2

                # to unlcok security
            ret = self.securityUnlockLevel(client, 1, False)
            if (ret.positive):
                print('security unlocked')
            else:
                print('security unlocked ERROR! ')
                return -2

            addr = self.block.id                # request download DSP bootloader
            size = len(self.block.segments[0].data)  # : address is 1 byte only
            memBlock = udsoncan.MemoryLocation(addr, size, 8, 32)
            bufSize = 0

            ret = client.request_download(memBlock)
            if (ret.positive):
                bufSize = ret.service_data.max_length
                print(f'Max Download Block Size: {bufSize}')
            else:
                print('RequestDownload ERROR!')
                return -2

            i = 0                               # tranfer data : DSP.1st:Bootloader Function
            chunk_num = math.ceil(size/bufSize)
            print(f'Transfer Data ...\n total block number: {chunk_num}\n')

            time_start = time.time()
            for chunk in self.block.segments[0].chunks(bufSize):
                i += 1
                seq = i % 256
                data = bytes(chunk.data)
                ret = client.transfer_data(seq, data)
                if (ret.positive != True):
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    self.progress_bar(i, chunk_num, time_start)
                    # progress = (i/chunk_num)*100
                    # print(f'\r[{progress:.2f}%]', end='')

            ret = client.request_transfer_exit()  # transfer exit
            if (ret.positive != True):
                print(f'\nTransferExit ERROR! NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'\nTranfer {DspBootloaderFileName} to flash complete')

            # os.system("pause")
            # DOWNLOAD APP SECTION
            # 2ND START  ----------------------------DSP.2nd: App/Conf/Cali
            ret = self.openInputFile(inputFileName)  # read the input file
            if (ret != 0):
                print(f"Can't open {inputFileName}")
                return -1

            addr = self.block.id                # request download DSP appl
            size = len(self.block.segments[0].data)  # : address is 1 byte only
            memBlock = udsoncan.MemoryLocation(addr, size, 8, 32)
            bufSize = 0

            ret = client.request_download(memBlock)
            if (ret.positive):
                bufSize = ret.service_data.max_length
                print(f'Max Download Block Size: {bufSize}')
            else:
                print('RequestDownload ERROR!')
                return -2

            i = 0                               # tranfer data : DSP.2nd: App/Conf/Cali
            chunk_num = math.ceil(size/bufSize)
            print(f'Transfer Data ...\n total block number: {chunk_num}\n')

            time_start = time.time()
            for chunk in self.block.segments[0].chunks(bufSize):
                i += 1
                seq = i % 256
                data = bytes(chunk.data)
                ret = client.transfer_data(seq, data)
                if (ret.positive != True):
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    self.progress_bar(i, chunk_num, time_start)
                    # progress = (i/chunk_num)*100
                    # print(f'\r[{progress:.2f}%]', end='')

            # print('')
            # print('')
            # print('held debug++++++')
            # print('')
            # os.system("pause")
            ret = client.request_transfer_exit()  # transfer exit
            if (ret.positive != True):
                print(f'\nTransferExit ERROR! NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'\nTranfer {inputFileName} to flash complete')

            # 2ND END

            block_crc = self.block.crc          # start routine, check CRC
            # MCU ask DSP start Boot code function
            bin_crc = bytes([0, 0, (block_crc >> 8), (block_crc & 0x00FF)])
            ret = client.start_routine(RID_CrcCheck, bin_crc)
            if (ret.positive != True):
                print(f'Routine 0X{RID_CrcCheck:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'CRC check for {inputFileName} ok')

            # print('')
            # print('')
            # print('held debug 222  ++++++')
            # print('')
            # os.system("pause")

            # if reflash appl., check dependency routine
            # if self.block.id == DspApplicationBlockId or self.block.id == DspConfigBlockId or self.block.id == DspCalibrationBlockId:
            # mcu ask DSP reset, wait DSP Start APP function and start UDS Communication
            ret = client.start_routine(RID_CheckDependency)
            if (ret.positive != True):
                print(f'Routine 0X{RID_CheckDependency:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'Dependency check complete')

            print('Kebab completa')
            print('DSP Bootloader complete.')

            hard_reset = udsoncan.services.ECUReset.ResetType.hardReset
            ret = client.ecu_reset(hard_reset)  # ECU reset
            if (ret.positive != True):
                print(f'ECU reset ERROR!')
                return -2
            else:
                print(f'Enter application code OK.')
            return 0

    def download(self, inputFileName):
        '''
        reflash MCU application with UDSonCAN bootloader
        '''
        self.fd = None                          # flash driver file handler
        self.block = None                       # input file handler

        ret = self.openFlashDriverFile()        # read flash driver binary file
        if (ret != 0):
            print(f"Can't open {FlashDriverFileName}")
            return -1

        ret = self.openInputFile(inputFileName)  # read the input file
        if (ret != 0):
            print(f"Can't open {inputFileName}")
            return -1

        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:

            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                print('change to extend session')
            else:
                print('change_session(3) ERROR! ')
                return -2

                # communication control
            comm_off = CommunicationControl.ControlType.disableRxAndTx
            subnet = 0
            normal_msg = True
            nm_msg = True
            comm_type = udsoncan.CommunicationType(subnet, normal_msg, nm_msg)
            ret = client.communication_control(comm_off, comm_type)
            if (ret.positive):
                print('trun off normal and nm msg')
            else:
                print('CommunicationControl ERROR! ')
                return -2

            ret = client.change_session(2)      # enter program session
            if (ret.positive):
                print('change to program session')
            else:
                print('change_session(2) ERROR! ')
                return -2
                # to unlcok security
            ret = self.securityUnlockLevel(client, 1, False)
            if (ret.positive):
                print('security unlocked')
            else:
                print('security unlocked ERROR! ')
                return -2

            fpData = ApplFingerPrintData()      # write fingerprint
            fpData.ApplFp = (c_ubyte * 2)(0x55, 0x55)
            ret = client.write_data_by_identifier(DID_AppFinger, fpData)
            if (ret.positive):
                print('clear DID 0xF15A (fingerprint)')
            else:
                print('WriteData fingerprint ERROR! ')
                return -2
                # request download flash driver
            addr = self.fd.id
            size = len(self.fd.segments[0].data)
            memBlock = udsoncan.MemoryLocation(addr, size, 8, 32)
            bufSize = 0

            ret = client.request_download(memBlock)
            if (ret.positive):
                bufSize = ret.service_data.max_length
                print(f'Max Download Block Size: {bufSize}')
            else:
                print('RequestDownload ERROR!')
                return -2

            i = 0                               # tranfer data
            chunk_num = math.ceil(size/bufSize)
            print(f'Transfer Data ...\ntotal block number: {chunk_num}')

            time_start = time.time()
            for chunk in self.fd.segments[0].chunks(bufSize):
                i += 1
                seq = i % 256
                data = bytes(chunk.data)
                ret = client.transfer_data(seq, data)
                if (ret.positive != True):
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    self.progress_bar(i, chunk_num, time_start)
                    # progress = (i/chunk_num)*100
                    # print(f'\r[{progress:.2f}%]', end='')

            ret = client.request_transfer_exit()  # transfer exit
            if (ret.positive != True):
                print(f'\nTransferExit ERROR! NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'\nTranfer {FlashDriverFileName} to SRAM complete')

                # start routine, check CRC
            bin_crc = bytes([0, 0, (self.fd.crc >> 8), (self.fd.crc & 0x00FF)])
            ret = client.start_routine(RID_CrcCheck, bin_crc)
            if (ret.positive != True):
                print(f'Routine 0X{RID_CrcCheck:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'CRC check for {FlashDriverFileName} ok')

                # start routine, erase flash
            FormatAndBlockId = bytes([0x41, self.block.id])
            ret = client.start_routine(RID_EraseFlash, FormatAndBlockId)
            if (ret.positive != True):
                print(f'Routine 0X{RID_EraseFlash:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'Erase Flash complete')

            addr = self.block.id                # request download input file
            size = len(self.block.segments[0].data)  # : address is 1 byte only
            memBlock = udsoncan.MemoryLocation(addr, size, 8, 32)
            bufSize = 0

            ret = client.request_download(memBlock)
            if (ret.positive):
                bufSize = ret.service_data.max_length
                print(f'Max Download Block Size: {bufSize}')
            else:
                print('RequestDownload ERROR!')
                return -2

            i = 0                               # tranfer data
            chunk_num = math.ceil(size/bufSize)
            print(f'Transfer Data ...\n total block number: {chunk_num}\n')

            time_start = time.time()
            for chunk in self.block.segments[0].chunks(bufSize):
                i += 1
                seq = i % 256
                data = bytes(chunk.data)
                ret = client.transfer_data(seq, data)
                if (ret.positive != True):
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    self.progress_bar(i, chunk_num, time_start)
                    # progress = (i/chunk_num)*100
                    # print(f'\r[{progress:.2f}%]', end='')

            ret = client.request_transfer_exit()  # transfer exit
            if (ret.positive != True):
                print(f'\nTransferExit ERROR! NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'\nTranfer {inputFileName} to flash complete')

                # start routine, check CRC
            block_crc = self.block.crc
            bin_crc = bytes([0, 0, (block_crc >> 8), (block_crc & 0x00FF)])
            ret = client.start_routine(RID_CrcCheck, bin_crc)
            if (ret.positive != True):
                print(f'Routine 0X{RID_CrcCheck:04X} ERROR!')
                print(f'NRC:0x{ret.code:x}')
                return -2
            else:
                print(f'CRC check for {inputFileName} ok')

                # if reflash appl., check dependency routine
            if self.block.id == McuApplicationBlockId:
                ret = client.start_routine(RID_CheckDependency)
                if (ret.positive != True):
                    print(f'Routine 0X{RID_CheckDependency:04X} ERROR!')
                    print(f'NRC:0x{ret.code:x}')
                    return -2
                else:
                    print(f'Dependency check complete')

            hard_reset = udsoncan.services.ECUReset.ResetType.hardReset
            ret = client.ecu_reset(hard_reset)  # ECU reset
            if (ret.positive != True):
                print(f'ECU reset ERROR!')
                return -2
            else:
                print(f'Enter application code OK.')

            print('CAN reflash complete, Finish.')
            return 0

    def loadKey(self, key_name):
        '''
        write a Key or CMAC into the CSEc of the MCU
        '''

        haveMasterEcuKey = False

        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:

            ret = client.change_session(2)      # enter program session
            if (ret.positive):
                print('change to program session')
            else:
                print('change_session(2) ERROR! ')
                return -2

            ret = client.read_data_by_identifier(DID_SecureBootStatus)
            if (ret.positive):
                status = ret.service_data.values[DID_SecureBootStatus]
                print(
                    f'read DID_SecureBootStatus OK, {status.SecureBootStatus}')
            else:
                print('read DID ERROR! ')

            ret = client.change_session(2)      # enter program session
            if (ret.positive):
                print('change to program session')
            else:
                print('change_session(2) ERROR! ')
                return -1

                # to unlock security
            ret = self.securityUnlockLevel(client, 1)
            if (ret.positive):
                print('security unlocked')
            else:
                print('CommunicationControl ERROR! ')
                return -4

                # get UID and SREG by CMD_GET_ID
            ret, uid = she_get_uid(client.start_routine)
            if ret != 0:
                print('she_get_uid ERROR! {ret}')
                return -5

            if (key_name == 'master'):           # write the master key to CSEc
                key_target = 'master'
                key_auth = 'master'
                new_cnt = 1
                key_flag = 0
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'user1'):         # write the user_key1 to CSEc
                key_target = 'user1'
                key_auth = 'user1'
                new_cnt = 1
                key_flag = 0
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'user2'):         # write the user_key2 to CSEc
                key_target = 'user2'
                key_auth = 'user2'
                new_cnt = 1
                key_flag = 0
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'user3'):         # write the user_key3 to CSEc
                ''' Key flags = WRITE_PROTECTION | BOOT_PROTECTION
                                | DEBUGGER_PROTECTION | KEY_USAGE | WILDCARD '''
                key_target = 'user3'
                key_auth = 'user3'
                new_cnt = 1
                key_flag = 0x08                 # BOOT_PROTECTION = 1
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'user5'):         # write the user_key5 to CSEc
                key_target = 'user5'
                key_auth = 'user5'
                new_cnt = 4
                key_flag = 0x00
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'boot_key'):      # write boot_key and key_7
                key_target = 'boot_key'
                key_auth = 'master'
                new_cnt = 1
                key_flag = 0x00
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

                key_target = 'user7'
                key_auth = 'master'
                new_cnt = 1
                key_flag = 0x02                 # KEY_USAGE = 1 for compute CMAC
                routine = client.start_routine

                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            elif (key_name == 'boot_mode'):     # write boot_mode and boot_mac
                print('setup SHE Secure Boot Mode')
                mode = SB_MODE_SERIAL
                size = SECURE_BOOT_SIZE
                routine = client.start_routine
                ret, counter = she_set_secure_boot_mode(mode, size, routine)
                if (ret != 0):
                    return -1

                key_target = 'boot_mac'
                key_auth = 'master'
                new_cnt = counter
                key_flag = 0x00
                routine = client.start_routine
                she_write(key_target, key_auth, uid,
                          new_cnt, key_flag, routine)

            else:
                print('unknown command, exit')
                return 0

    def printDtcNameById(self, dtcDataStr):

        if 'DTC ID=0x100101' in dtcDataStr:
            print('DTC 0x100101 : APM LVDC')

        if 'DTC ID=0x100102' in dtcDataStr:
            print('DTC 0x100102 : APM HVDC')

        if 'DTC ID=0x100103' in dtcDataStr:
            print('DTC 0x100103 : APM OTP')

        if 'DTC ID=0x100104' in dtcDataStr:
            print('DTC 0x100104 : APM AUX')

        if 'DTC ID=0x100105' in dtcDataStr:
            print('DTC 0x100105 : APM BAT')

        if 'DTC ID=0xD00101' in dtcDataStr:
            print('DTC 0xD00101 : APM INIT')

        if 'DTC ID=0xD00102' in dtcDataStr:
            print('DTC 0xD00102 : APM CAN')

        if 'DTC ID=0x100001' in dtcDataStr:
            print('DTC 0x100001 : OBC GRID')

        if 'DTC ID=0x100002' in dtcDataStr:
            print('DTC 0x100002 : OBC HVDC')

        if 'DTC ID=0x100003' in dtcDataStr:
            print('DTC 0x100003 : OBC OTP')

        if 'DTC ID=0x100004' in dtcDataStr:
            print('DTC 0x100004 : OBC PFC')

        if 'DTC ID=0x100005' in dtcDataStr:
            print('DTC 0x100005 : OBC AUX')

        if 'DTC ID=0x100006' in dtcDataStr:
            print('DTC 0x100006 : OBC BULK')

        if 'DTC ID=0xD00001' in dtcDataStr:
            print('DTC 0xD00001 : OBC INIT')

        if 'DTC ID=0xD00002' in dtcDataStr:
            print('DTC 0xD00002 : OBC CAN')

        if 'DTC ID=0xD00003' in dtcDataStr:
            print('DTC 0xD00003 : OBC EVSE')

    def readDtcByStatusMask(self, mask=0xFF):
        '''
        read DTC by status mask (reportDTCByStatusMask)
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.change_session(1)      # enter default session
            if (ret.positive):
                # print('request OBC to change its session to default, OK')
                pass
            else:
                print('change_session(1) ERROR! ')

            # mask = Dtc.Status(test_failed=True)

            ret = client.get_dtc_by_status_mask(mask)
            if (ret.positive):
                dtcData = ret.service_data.dtcs
                print(f'reportDTCByStatusMask: {dtcData}')
                self.printDtcNameById(repr(dtcData))
            else:
                print('read DTC ERROR! ')

        print(f'read DTC by status, DONE')

        return 0

    def readDtcNumber(self, mask=0xFF):
        '''
        read DTC number by status mask (reportNumberOfDTCByStatusMask)
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.change_session(1)      # enter default session
            if (ret.positive):
                # print('request OBC to change its session to default, OK')
                pass
            else:
                print('change_session(1) ERROR! ')

            ret = client.get_number_of_dtc_by_status_mask(mask)
            if (ret.positive):
                dtcData = ret.service_data.dtc_count
                print(f'reportNumber: {dtcData}')
            else:
                print('read DTC ERROR! ')

        print(f'read DTC number, DONE')

        return 0

    def clearDtc(self, group='all'):
        '''
        clear DTC by group = { 'all' }
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.change_session(3)      # enter extend session
            if (ret.positive):
                # print('request OBC to change its session to default, OK')
                pass
            else:
                print('change_session(3) ERROR! ')
            '''
            if (group == 'apm'):                # clear APM's DTC
                group_num = 0x100000            # TODO: what is group for APM
            elif (group == 'obc'):              # clear OBC's DTC
                group_num = 0x100100            # TODO: what is group for OBC
            else:                               # clear all DTC
                group_num = 0xFFFFFF
            '''
            group_num = 0xFFFFFF
            client.clear_dtc(group=group_num)

        print(f'clear DTC, DONE')

        return 0

    def readSnapshot(self, dtcIdHexStr):
        '''
        read a DTC's snapshot record
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.change_session(1)      # enter default session
            if (ret.positive):
                # print('request OBC to change its session to default, OK')
                pass
            else:
                print('change_session(1) ERROR! ')

            dtcId = int(dtcIdHexStr, 16)

            ret = client.get_dtc_snapshot_by_dtc_number(dtcId, 1)
            if (ret.positive):
                payload = ret.get_payload()
                snapshotDidData = payload[10:]
                print(
                    f'DTC_0x{dtcId:06X} snapshot: {len(snapshotDidData)} bytes')
                self.printSnapshotRecord(snapshotDidData)
            else:
                print('read DTC snapshot ERROR! ')

        print(f"read DTC_0x{dtcId:06X}'s snapshot, DONE")

        return 0

    def readVersionNumber(self):
        '''
        read version DID
        '''
        with Client(self.IsoTpConn, request_timeout=1, config=DidCfg) as client:
            ret = client.read_data_by_identifier(DID_ApmApplVer)
            if (ret.positive):
                ver = ret.service_data.values[DID_ApmApplVer]
                major = ver.Major
                minor = ver.Minor
                debug = ver.Debug
                bid = ver.BuildId
                print(f'ApmApplVer: {major}.{minor}.{debug}  buildId:{bid}')
            else:
                print('read DID_ApmApplVer ERROR! ')

            ret = client.read_data_by_identifier(DID_ApmBootVer)
            if (ret.positive):
                ver = ret.service_data.values[DID_ApmBootVer]
                major = ver.Major
                minor = ver.Minor
                debug = ver.Debug
                bid = ver.BuildId
                print(f'ApmBootVer: {major}.{minor}.{debug}  buildId:{bid}')
            else:
                print('read DID_ApmBootVer ERROR! ')

            ret = client.read_data_by_identifier(DID_ObcApplVer)
            if (ret.positive):
                ver = ret.service_data.values[DID_ObcApplVer]
                major = ver.Major
                minor = ver.Minor
                debug = ver.Debug
                bid = ver.BuildId
                print(f'ObcApplVer: {major}.{minor}.{debug}  buildId:{bid}')
            else:
                print('read DID_ObcApplVer ERROR! ')

        return 0


def main():

    print(f'OBC_CLI tool, rev {OBC_CLI_VERSION}:')

    parser = argparse.ArgumentParser(
        description="CLI Extension  Command", formatter_class=RawTextHelpFormatter)
    parser.add_argument('-p', '--PCAN_Port', dest='PCAN_Port',
                        help='select the PCAN channel numver', required=False)

    args = parser.parse_args_SkipForOBC()  # 客製

    if args.PCAN_Port:
        try:
            # python 在v3.10前沒有switch case, 只能用 if else,
            # v3.10之後有提供match替代switch
            if args.PCAN_Port == '1':
                PCAN_CHANNEL = 'PCAN_USBBUS1'
            elif args.PCAN_Port == '2':
                PCAN_CHANNEL = 'PCAN_USBBUS2'
            elif args.PCAN_Port == '3':
                PCAN_CHANNEL = 'PCAN_USBBUS3'
            elif args.PCAN_Port == '4':
                PCAN_CHANNEL = 'PCAN_USBBUS4'
            elif args.PCAN_Port == '5':
                PCAN_CHANNEL = 'PCAN_USBBUS5'
            elif args.PCAN_Port == '6':
                PCAN_CHANNEL = 'PCAN_USBBUS6'
            else:
                PCAN_CHANNEL = 'PCAN_USBBUS1'
        except:
            PCAN_CHANNEL = 'PCAN_USBBUS1'

        for idx, data in enumerate(sys.argv):  # 去除 [-p 的命令 + 命令資料]
            if data == '-p':
                del sys.argv[int(idx):int(idx)+2]
    else:
        PCAN_CHANNEL = 'PCAN_USBBUS1'

    # print(sys.argv)

    #can_channel = 'PCAN_USBBUS1'
    can_channel = PCAN_CHANNEL
    bus = None
    bus = can.ThreadSafeBus(bustype='pcan',
                            # channel='PCAN_USBBUS1',
                            channel=PCAN_CHANNEL,
                            bitrate=500000)
    if (bus == None):
        print("ERROR: can't open PCAN_USBBUS1")
        sys.exit(-4)
    can_handler = bus
    obc = OBC()
    obc.canOpen(can_channel, can_handler)

    if ((len(sys.argv) == 3) and (sys.argv[1] == 'reflash') and
            ((sys.argv[2] == 'dspApp') or (sys.argv[2] == 'dspConf') or (sys.argv[2] == 'dspCali') or (sys.argv[2] == 'dspCaliClr'))):
        if sys.argv[2] == 'dspApp':
            input_file_name = DspApplicationFileName
        elif sys.argv[2] == 'dspConf':
            input_file_name = DspConfigFileName
        elif sys.argv[2] == 'dspCali':
            input_file_name = DspCalibrationFileName
        elif sys.argv[2] == 'dspCaliClr':
            input_file_name = DspCalibrationClrFileName
        else:
            print('type error')
            return
            # input_file_name = DspApplicationFileName

        ret = obc.kebab(input_file_name)
        sys.exit(ret)

    if (len(sys.argv) == 3) and (sys.argv[1] == 'she'):
        ret = obc.loadKey(sys.argv[2])
        sys.exit(ret)

    if (len(sys.argv) == 3) and (sys.argv[1] == 'reflash') and (sys.argv[2] == 'mcu'):
        input_file_name = McuApplicationFileName
        ret = obc.download(input_file_name)
        sys.exit(ret)

    if ((len(sys.argv) == 3)
        and ((sys.argv[1] == 'read') or (sys.argv[1] == 'write')
        or (sys.argv[1] == 'reset') or (sys.argv[1] == 'clear'))
        and ((sys.argv[2] == 'conf') or (sys.argv[2] == 'cali')
             or (sys.argv[2] == 'dtc') or (sys.argv[2] == 'ver'))):
        pass
    elif ((len(sys.argv) == 4)
          and ((sys.argv[1] == 'read') or (sys.argv[1] == 'clear'))
          and ((sys.argv[2] == 'dtc') or (sys.argv[2] == 'snapshot'))
          and ((sys.argv[3] == 'status') or (sys.argv[3] == 'number')
               or (sys.argv[3] == 'all') or ('0x' in sys.argv[3]))):
        pass
    else:
        print('ERROR: invalid command or arguments')
        print('example: obc.exe read ver       : to read back the MCU/Bootloader/DSP ver')
        print('example: obc.exe read conf      : to read configuration data of the MCU')
        print('example: obc.exe write cali     : to write calibration data of the MCU')
        print('example: obc.exe clear cali     : to clear calibration data of the MCU')
        print('example: obc.exe read dtc       : to get DTC by status mask')
        print('example: obc.exe read snapshot (+ number) : ex "0x1000101" -> to get DTC_1000101 snapshot')
        print('example: obc.exe reflash mcu    : to upgrade MCU APP')
        print('example: obc.exe reflash dspApp : to upgrade DSP APP')
        sys.exit(-1)

    # if ((sys.argv[1] == 'reset') and (sys.argv[2] == 'cali')):
    #    obc.resetCalibrationData()             # remove calibration file

    if ((sys.argv[1] == 'read') and (sys.argv[2] == 'ver')):
        ret = obc.readVersionNumber()
        sys.exit(ret)

    if ((sys.argv[1] == 'read') and (sys.argv[2] == 'cali')):
        ret = obc.readCalibrationData()
        sys.exit(ret)

    if ((sys.argv[1] == 'clear') and (sys.argv[2] == 'cali')):
        ret = obc.clearCalibrationData()
        # Ricky add for DSP use
        input_file_name = DspCalibrationClrFileName
        ret = obc.kebab(input_file_name)
        sys.exit(ret)

    elif ((sys.argv[1] == 'write') and (sys.argv[2] == 'cali')):
        yaml_calidata = None
        with open(CALI_YAML_FILE, 'r') as f:
            yaml_calidata = yaml.load(f, Loader=yaml.FullLoader)
            # yaml_calidata = yaml.load(f)  # use ruamel.yaml

        if (yaml_calidata == None):
            print(f"ERROR:can't open {CALI_YAML_FILE}")
            sys.exit(-2)

        cali_bin_file = load_cali_yaml()
        if cali_bin_file == None:
            sys.exit(-5)
        ret = obc.download(cali_bin_file)

        if ret:
            sys.exit(ret)
        else:  # Ricky add 防呆處理, 若有異常, 直接中斷離開此次命令呼叫
            input_file_name = DspCalibrationFileName
            ret = obc.kebab(input_file_name)
            sys.exit(ret)

    elif ((sys.argv[1] == 'write') and (sys.argv[2] == 'conf')):
        yaml_confdata = None
        with open(CONF_YAML_FILE, 'r') as f:
            yaml_confdata = yaml.load(f, Loader=yaml.FullLoader)
            # yaml_confdata = yaml.load(f)  # use ruamel.yaml

        if (yaml_confdata == None):
            print(f"ERROR:can't open {CONF_YAML_FILE}")
            sys.exit(-3)

        conf_bin_file = load_conf_yaml()
        if conf_bin_file == None:
            sys.exit(-6)
        ret = obc.download(conf_bin_file)
        if ret:
            sys.exit(ret)
        else:   # Ricky add 防呆處理, 若有異常, 直接中斷離開此次命令呼叫
            input_file_name = DspConfigFileName
            ret = obc.kebab(input_file_name)
            sys.exit(ret)

    elif ((sys.argv[1] == 'read') and (sys.argv[2] == 'conf')):
        ret = obc.readConfigurationData()
        sys.exit(ret)

    elif (len(sys.argv) == 4) and ((sys.argv[1] == 'read')
                                   and (sys.argv[2] == 'dtc') and (sys.argv[3] == 'status')):
        ret = obc.readDtcByStatusMask(0xFF)
        sys.exit(ret)

    elif (len(sys.argv) == 4) and ((sys.argv[1] == 'read')
                                   and (sys.argv[2] == 'dtc') and (sys.argv[3] == 'number')):
        ret = obc.readDtcNumber(0xFF)
        sys.exit(ret)

    elif (len(sys.argv) == 4) and ((sys.argv[1] == 'clear')
                                   and (sys.argv[2] == 'dtc') and (sys.argv[3] == 'all')):
        ret = obc.clearDtc(sys.argv[3])
        sys.exit(ret)

    elif (len(sys.argv) == 4) and ((sys.argv[1] == 'read')
                                   and (sys.argv[2] == 'snapshot') and ('0x' in sys.argv[3])):
        ret = obc.readSnapshot(sys.argv[3])
        sys.exit(ret)

    else:
        print('ERROR: unkonw command')
        sys.exit(-7)


if __name__ == '__main__':
    main()
