% Motor Parameters

J=0.01;     %kg*m^2
b=0.1;      %N*m/(rad/s)
K=0.01;     %V/(rad/s)
R=1;        %Ohm
L=0.5;      %H